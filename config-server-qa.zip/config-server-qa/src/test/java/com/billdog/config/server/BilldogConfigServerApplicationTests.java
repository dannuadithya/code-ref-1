package com.billdog.config.server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BilldogConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
