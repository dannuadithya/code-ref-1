This contains billdog service properties 
