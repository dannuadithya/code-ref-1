package com.billdog.pushnotification.authorization;

import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@Service
public class JWTAuthentication {

	private static final String SECRET_KEY = "70c349b2-9b18-4dc3-b5f6-57b10cc74f56";

	public Claims verifyToken(String token) {
		try {
			final Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
			if (claims == null) {
				return null;
			}
			return claims;
		} catch (Exception e) {
			return null;
		}
	}
}