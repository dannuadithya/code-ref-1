package com.billdog.pushnotification.authorization;

import java.time.LocalDateTime;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.billdog.pushnotifications.common.DateAndTimeUtil;
import com.billdog.pushnotifications.common.ExceptionMessages;
import com.billdog.pushnotifications.exception.InvalidAuthTokenException;
import com.billdog.pushnotifications.exception.TokenExpiredException;
import com.billdog.pushnotifications.service.UserService;
import com.billdog.pushnotifications.view.MemberInfoResponse;

import io.jsonwebtoken.Claims;

public class RequestProcessingInterceptorAdapter extends HandlerInterceptorAdapter {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	JWTAuthentication jwtAuthentication;

	@Autowired
	UserService userService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		if (handler instanceof HandlerMethod) {
			HandlerMethod method = (HandlerMethod) handler;
			if (method != null) {
				EnableTokenAuthorisation methodAnnotation = method.getMethodAnnotation(EnableTokenAuthorisation.class);
				if (methodAnnotation != null) {
					String header = request.getHeader("Authorization");

					if (header != null) {
						Claims verifyToken = jwtAuthentication.verifyToken(header);
						if (verifyToken != null) {
							String[] token = verifyToken.getSubject().split("-");

							long id = 0;
							try {
								id = Long.valueOf(token[token.length - 1]);
							} catch (Exception e) {
								throw new InvalidAuthTokenException(ExceptionMessages.SESSION_EXPIRED);
							}
							logger.info("Token type:: {} id:: {}", token[0], id);
							if (token[0].equals("USER")) {
								// handle user token
								MemberInfoResponse verifyUserToken = userService.verifyUserToken(header, id);
								checkTokenTime(verifyUserToken);
								request.setAttribute("type", token[0]);
								request.setAttribute("id", verifyUserToken.getUserId());
								request.setAttribute("organizationId", verifyUserToken.getOrganizationId());
							} else if (token[0].equals("MEMBER")) {
								// need to add member checking
								MemberInfoResponse verifyMemberToken = userService.verifyMemberToken(header, id);
								checkTokenTime(verifyMemberToken);
								request.setAttribute("id", verifyMemberToken.getId());
								request.setAttribute("type", token[0]);
								request.setAttribute("organizationId", verifyMemberToken.getOrganizationId());
								/*
								 * if (verifyMemberToken.getMemberId() != null) {
								 * request.setAttribute("memberId", verifyMemberToken.getMemberId()); } if
								 * (verifyMemberToken.getMemberStatus() != null) {
								 * request.setAttribute("memberStatus", verifyMemberToken.getMemberStatus()); }
								 * if (verifyMemberToken.getMemberEmail() != null) {
								 * request.setAttribute("memberEmail", verifyMemberToken.getMemberEmail()); } if
								 * (verifyMemberToken.getMemberName() != null) {
								 * request.setAttribute("memberName", verifyMemberToken.getMemberName()); } if
								 * (verifyMemberToken.getFromEmail() != null) {
								 * request.setAttribute("fromEmail", verifyMemberToken.getFromEmail()); } if
								 * (verifyMemberToken.getOrganizationContact() != null) {
								 * request.setAttribute("organizationContact",
								 * verifyMemberToken.getOrganizationContact()); } if
								 * (verifyMemberToken.getOrganizationName() != null) {
								 * request.setAttribute("organizationName",
								 * verifyMemberToken.getOrganizationName()); }
								 */

							} else {
								throw new InvalidAuthTokenException(ExceptionMessages.SESSION_EXPIRED);
							}

						} else {
							throw new TokenExpiredException(ExceptionMessages.SESSION_EXPIRED);
						}
					} else {
						throw new TokenExpiredException(ExceptionMessages.SESSION_EXPIRED);
					}
				}
			}
		}
		return super.preHandle(request, response, handler);
	}

	private void checkTokenTime(MemberInfoResponse verifyToken) {
		if (verifyToken == null || verifyToken.getTokenExpiredAt() == null) {
			throw new InvalidAuthTokenException(ExceptionMessages.SESSION_EXPIRED);
		} else {
			LocalDateTime tokenTime = LocalDateTime.parse(verifyToken.getTokenExpiredAt());
			if (tokenTime.isBefore(DateAndTimeUtil.now())) {
				if (verifyToken.getTokenMessage() != null) {
					throw new InvalidAuthTokenException(verifyToken.getTokenMessage());
				} else {
					throw new InvalidAuthTokenException(ExceptionMessages.SESSION_EXPIRED);
				}
			}
		}
	}

}
