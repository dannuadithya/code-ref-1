package com.billdog.pushnotifications.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "NOTIFICATION_MASTER")
@Table(name = "notification_master")
public class NotificationMaster extends BaseEntity {

	@Column(name = "message")
	private String message;

	@Column(name = "title_name")
	private String titleName;

	@Column(name = "in_app")
	private boolean inApp;

	@Column(name = "push_notification")
	private boolean pushNotification;

	@Column(name = "is_tappable")
	private boolean isTappable;

	@ManyToOne
	@JoinColumn(name = "screen_name_master_id")
	private ScreenNameMaster screenNameMasterId;

	@Column(name = "modified_by")
	private String modifiedBy;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTitleName() {
		return titleName;
	}

	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}

	public boolean isInApp() {
		return inApp;
	}

	public void setInApp(boolean inApp) {
		this.inApp = inApp;
	}

	public boolean isPushNotification() {
		return pushNotification;
	}

	public void setPushNotification(boolean pushNotification) {
		this.pushNotification = pushNotification;
	}

	public boolean isTappable() {
		return isTappable;
	}

	public void setTappable(boolean isTappable) {
		this.isTappable = isTappable;
	}

	public ScreenNameMaster getScreenNameMasterId() {
		return screenNameMasterId;
	}

	public void setScreenNameMasterId(ScreenNameMaster screenNameMasterId) {
		this.screenNameMasterId = screenNameMasterId;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

}
