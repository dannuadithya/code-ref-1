package com.billdog.pushnotifications.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.amazonaws.services.lightsail.model.UnauthenticatedException;
import com.billdog.pushnotifications.common.ExceptionMessages;
import com.billdog.pushnotifications.exception.BadRequestException;
import com.billdog.pushnotifications.exception.InternalServerException;
import com.billdog.pushnotifications.exception.RecordNotFoundException;
import com.billdog.pushnotifications.exception.ServiceUnavailableException;
import com.billdog.pushnotifications.exception.UnauthorizedException;
import com.billdog.pushnotifications.repository.UserRepository;
import com.billdog.pushnotifications.view.MemberInfoResponse;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Component
public class UserService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(UserService.class);

	@Value("${userservice.baseurl}")
	private String userBaseUrl;

	private UserRepository getUserRepository(String token) {
		OkHttpClient.Builder userHttpClient;
		if (StringUtils.isNotBlank(token)) {
			userHttpClient = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
				@Override
				public Response intercept(Chain chain) throws IOException {
					Request request = chain.request().newBuilder().addHeader("authorization", token).build();
					return chain.proceed(request);
				}
			});
		} else {
			userHttpClient = new OkHttpClient.Builder();
		}
		Retrofit retrofit = new Retrofit.Builder().baseUrl(userBaseUrl)
				.addConverterFactory(GsonConverterFactory.create())
				.client(userHttpClient.connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build())
				.build();
		return retrofit.create(UserRepository.class);
	}

	public MemberInfoResponse verifyUserToken(String token, Long userId) {
		LOGGER.info("verifyUserToken method started..!");
		UserRepository userRepository = getUserRepository(token);
		Call<MemberInfoResponse> callSync = userRepository.verifyUserToken(userId);

		try {
			retrofit2.Response<MemberInfoResponse> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new UnauthenticatedException(ExceptionMessages.SESSION_EXPIRED);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionMessages.VERIFY_USER_TOKEN_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionMessages.USER_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionMessages.USER_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionMessages.VERIFY_TOKEN_ISSUE);
				}

			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getCause());
			throw new UnauthorizedException(
					exception.getMessage().equalsIgnoreCase(ExceptionMessages.SESSION_EXPIRED) ? exception.getMessage()
							: ExceptionMessages.SOMETHING_WENT_WRONG);
		}
	}

	public MemberInfoResponse verifyMemberToken(String token, Long memberId) {
		LOGGER.info("verifyMemberToken method started..!");
		UserRepository userRepository = getUserRepository(token);
		Call<MemberInfoResponse> callSync = userRepository.verifyMemberToken(memberId);

		try {
			retrofit2.Response<MemberInfoResponse> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 401) {
					throw new UnauthorizedException(ExceptionMessages.MEMBER_SESSION_EXPIRED);
				}
				if (response.code() == 404) {
					throw new RecordNotFoundException(ExceptionMessages.VERIFY_MEMBER_TOKEN);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionMessages.VERIFY_MEMBER_TOKEN_BAD_REQUEST);
				} else {
					throw new BadRequestException(ExceptionMessages.VERIFY_TOKEN_ISSUE);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new UnauthorizedException(
					exception.getMessage().equalsIgnoreCase(ExceptionMessages.MEMBER_SESSION_EXPIRED) ? exception.getMessage()
							: ExceptionMessages.SOMETHING_WENT_WRONG);
		}
	}

}
