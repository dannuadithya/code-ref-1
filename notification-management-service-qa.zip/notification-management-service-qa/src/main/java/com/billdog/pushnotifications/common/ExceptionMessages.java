package com.billdog.pushnotifications.common;

public class ExceptionMessages {

	public static final String VERIFY_USER_TOKEN = "Verify user token api not found";
	public static final String VERIFY_USER_TOKEN_BAD_REQUEST = "Please provide valid inputs to verify user token";
	public static final String USER_SERVICE_UNAVAILABLE = "User service unavilable, please try after sometime";
	public static final String VERIFY_TOKEN_ISSUE = "Facing technical issue while verifying token";
	public static final String VERIFY_MEMBER_TOKEN = "Verify member token api not found";
	public static final String VERIFY_MEMBER_TOKEN_BAD_REQUEST = "Please provide valid request to Verify member token api not found";
	public static final String SESSION_EXPIRED = "Session Expired. Please Login";
	public static final String MEMBER_SESSION_EXPIRED = "Please log in again.";

	public static final String SOMETHING_WENT_WRONG = "Something went wrong. Please try again";

}
