package com.billdog.pushnotifications.common;

public class Constants {

	public static final String FAILED = "Failed";
	public static final String TITLE_NOT_FOUND = "Title not found";
	public static final String SUCCESS = "Success";
	public static final String NOTIFICATION_FETCHED = "Notifications fetched successfully";
	public static final String USER = "userId";
	public static final String MEMBER = "memberId";
	public static final String NOTIFICATION_NOT_FOUND = "Notification not found";
	public static final String NOTIFICATION_UPDATED = "Notification status updated successfully";
	public static final String CASE_UPDATED = "Case Updated";
	public static final String NEW_MESSAGE = "New message";
	public static final String CHAT = "ChatView";
	public static final String CASE = "caseDetail";

}
