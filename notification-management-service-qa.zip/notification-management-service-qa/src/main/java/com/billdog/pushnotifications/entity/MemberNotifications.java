package com.billdog.pushnotifications.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "MEMBER_NOTIFICATIONS")
@Table(name = "member_notifications")
public class MemberNotifications extends BaseEntity {

	@Column(name = "notification_sent_date")
	private LocalDateTime notificationSentDate;

	@Column(name = "is_notification_read")
	private boolean notificationRead;

	@Column(name = "notification_read_time")
	private LocalDateTime notificationReadTime;

	@Column(name = "case_Id")
	private String caseId;

	@Column(name = "member_Id")
	private Long memberId;

	@ManyToOne
	@JoinColumn(name = "notification_master_Id")
	private NotificationMaster notificationMasterId;

	@Column(name = "message")
	private String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public LocalDateTime getNotificationReadTime() {
		return notificationReadTime;
	}

	public void setNotificationReadTime(LocalDateTime notificationReadTime) {
		this.notificationReadTime = notificationReadTime;
	}

	public LocalDateTime getNotificationSentDate() {
		return notificationSentDate;
	}

	public void setNotificationSentDate(LocalDateTime notificationSentDate) {
		this.notificationSentDate = notificationSentDate;
	}


	public boolean isNotificationRead() {
		return notificationRead;
	}

	public void setNotificationRead(boolean notificationRead) {
		this.notificationRead = notificationRead;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public NotificationMaster getNotificationMasterId() {
		return notificationMasterId;
	}

	public void setNotificationMasterId(NotificationMaster notificationMasterId) {
		this.notificationMasterId = notificationMasterId;
	}

}
