package com.billdog.pushnotifications.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.billdog.pushnotifications.entity.MemberNotifications;
import com.billdog.pushnotifications.entity.NotificationMaster;

public interface MemberNotificationRepository extends JpaRepository<MemberNotifications, Long> {

	// List<MemberNotifications> findByMemberId(Long memberId);

	@Query(value = "select count(*) from member_notifications where is_notification_read = false and member_id = ?1", countQuery = "select count(*) from member_notifications where is_notification_read = false and member_id = ?1", nativeQuery = true)
	BigInteger getUnreadNotificationCount(Long memberId);

	Optional<MemberNotifications> findByIdAndMemberId(Long notificationId, Long memberId);

	@Query(value = "select mn.* from member_notifications mn where mn.member_id = ?1 order by mn.created_at desc", countQuery = "select mn.* from member_notifications mn where mn.member_id = ?1 order by mn.created_at desc", nativeQuery = true)
	Page<MemberNotifications> getMemberNotifications(Long memberId, PageRequest pageRequest);

	List<MemberNotifications> findByMemberIdAndCaseIdAndNotificationRead(Long memberId, String caseId, boolean read);

	List<MemberNotifications> findByMemberIdAndCaseIdAndNotificationReadAndNotificationMasterId(Long memberId,
			String caseId, boolean b, NotificationMaster notificationMaster);

}
