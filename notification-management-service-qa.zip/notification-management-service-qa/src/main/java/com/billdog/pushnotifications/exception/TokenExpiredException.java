package com.billdog.pushnotifications.exception;

@SuppressWarnings("serial")
public class TokenExpiredException extends UnauthorizedException {
	public TokenExpiredException(String errMsg) {
		super(errMsg);
	}
	
	public TokenExpiredException(String message, Throwable cause) {
        super(message, cause);
    }

}
