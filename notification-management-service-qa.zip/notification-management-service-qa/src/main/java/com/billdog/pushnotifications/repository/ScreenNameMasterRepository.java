package com.billdog.pushnotifications.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.pushnotifications.entity.ScreenNameMaster;

public interface ScreenNameMasterRepository extends JpaRepository<ScreenNameMaster, Long> {

	Optional<ScreenNameMaster> findByScreenName(String screenflow);

}
