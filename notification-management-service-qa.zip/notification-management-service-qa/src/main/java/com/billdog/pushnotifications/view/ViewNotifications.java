package com.billdog.pushnotifications.view;

public class ViewNotifications {

	private String message;
	private String dateOn;
	private String day;
	private boolean isTapable;
	private String caseId;
	private String screenName;
	private Long notificationId;
	private boolean isNotificationRead;

	public boolean isNotificationRead() {
		return isNotificationRead;
	}

	public void setNotificationRead(boolean isNotificationRead) {
		this.isNotificationRead = isNotificationRead;
	}

	public Long getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(Long notificationId) {
		this.notificationId = notificationId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getDateOn() {
		return dateOn;
	}

	public void setDateOn(String dateOn) {
		this.dateOn = dateOn;
	}

	public String getDay() {
		return day;
	}

	public void setDay(String day) {
		this.day = day;
	}

	public boolean isTapable() {
		return isTapable;
	}

	public void setTapable(boolean isTapable) {
		this.isTapable = isTapable;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

}
