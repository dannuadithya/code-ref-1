package com.billdog.pushnotifications.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name = "screen_name_master")
@Table(name = "SCREEN_NAME_MASTER")
public class ScreenNameMaster extends BaseEntity {

	@Column(name = "screen_name")
	private String screenName;

	@Column(name = "status")
	private String status;

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
