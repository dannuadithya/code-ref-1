package com.billdog.pushnotifications.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.pushnotifications.authorization.EnableTokenAuthorisation;
import com.billdog.pushnotifications.common.Constants;
import com.billdog.pushnotifications.common.ExceptionMessages;
import com.billdog.pushnotifications.exception.InvalidAuthTokenException;
import com.billdog.pushnotifications.model.PushNotificationRequest;
import com.billdog.pushnotifications.model.PushNotificationResponse;
import com.billdog.pushnotifications.request.NotificationReadStatusRequest;
import com.billdog.pushnotifications.request.UpdateNotificationReadStatusRequest;
import com.billdog.pushnotifications.service.PushNotificationService;
import com.billdog.pushnotifications.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
public class PushNotificationController {

	@Autowired
	private PushNotificationService pushNotificationService;

	@Value("${userservice.baseurl}")
	private String userBaseUrl;

	private static final Logger LOGGER = LoggerFactory.getLogger(PushNotificationController.class);

	public void isValidToken(HttpServletRequest httpRequest, Long requestUserId, Long requestmemberId) {
		requestUserId = requestUserId == null ? 0l : requestUserId;
		requestmemberId = requestmemberId == null ? 0l : requestmemberId;
		try {
			long userId = 0;
			if (httpRequest.getAttribute(Constants.USER) != null) {
				userId = Long.parseLong(httpRequest.getAttribute(Constants.USER).toString());
				String email = httpRequest.getAttribute("email").toString();
				LOGGER.info("Requested User Id :{}", userId);
				LOGGER.info("Based on AccessToken userId {}, email: {}", userId, email);
				if (userId != requestUserId) {
					throw new InvalidAuthTokenException(ExceptionMessages.SESSION_EXPIRED);
				}
			} else if (httpRequest.getAttribute(Constants.MEMBER) != null) {
				Long memberId = Long.parseLong(httpRequest.getAttribute(Constants.MEMBER).toString());
				LOGGER.info("Requested Member Id : {}", memberId);
				LOGGER.info("Based on AccessToken {}", memberId);
				if (!memberId.equals(requestmemberId)) {
					throw new InvalidAuthTokenException(ExceptionMessages.SESSION_EXPIRED);
				}
			} else {
				throw new InvalidAuthTokenException(ExceptionMessages.SESSION_EXPIRED);
			}

		} catch (Exception e) {
			throw new InvalidAuthTokenException(ExceptionMessages.SESSION_EXPIRED);
		}
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = PushNotificationResponse.class, message = "Send Notifications based on Token"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = String.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = String.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = String.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/notification/token", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<PushNotificationResponse> sendTokenNotification(
			@RequestBody PushNotificationRequest request) {
		pushNotificationService.sendNotifications(request);
		LOGGER.info("PushNotification sent successfully inside PushNotificationController");
		return new ResponseEntity<>(
				new PushNotificationResponse(HttpStatus.OK.value(), "Notification sent successfully."), HttpStatus.OK);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = PushNotificationResponse.class, message = "member notification details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = PushNotificationResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/member-notification", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getMemberNotifications(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId,
			@RequestParam(required = false) Integer pageNumber, @RequestParam(required = false) Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		isValidToken(httpRequest, null, memberId);
		return pushNotificationService.getNotificationByMember(memberId,pageNumber,pageLimit);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = PushNotificationResponse.class, message = "member notification details updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = PushNotificationResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/update-notification", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateNotificationReadStatus(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestBody NotificationReadStatusRequest notificationReadStatusRequest) {
		isValidToken(httpRequest, null, notificationReadStatusRequest.getMemberId());
		return pushNotificationService.notificationRead(notificationReadStatusRequest);
	}
	
	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = PushNotificationResponse.class, message = "member notification details updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = PushNotificationResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/notification-status", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> updateNotificationReadStatus(
			@RequestBody UpdateNotificationReadStatusRequest notificationReadStatusRequest) {
		return pushNotificationService.notificationStatusRead(notificationReadStatusRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = PushNotificationResponse.class, message = "member notification details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = PushNotificationResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/notification-count", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getMemberNotificationCount(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId) {
		isValidToken(httpRequest, null, memberId);
		return pushNotificationService.notificationUnReadCount(memberId);
	}

}
