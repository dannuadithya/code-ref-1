package com.billdog.pushnotifications.service;

import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.billdog.pushnotifications.common.Constants;
import com.billdog.pushnotifications.common.DateAndTimeUtil;
import com.billdog.pushnotifications.entity.MemberNotifications;
import com.billdog.pushnotifications.entity.NotificationMaster;
import com.billdog.pushnotifications.entity.ScreenNameMaster;
import com.billdog.pushnotifications.exception.RecordNotFoundException;
import com.billdog.pushnotifications.firebase.FCMService;
import com.billdog.pushnotifications.model.PushNotificationRequest;
import com.billdog.pushnotifications.repository.MemberNotificationRepository;
import com.billdog.pushnotifications.repository.NotificationMasterRepository;
import com.billdog.pushnotifications.repository.ScreenNameMasterRepository;
import com.billdog.pushnotifications.request.NotificationReadStatusRequest;
import com.billdog.pushnotifications.request.UpdateNotificationReadStatusRequest;
import com.billdog.pushnotifications.view.ViewNotifications;
import com.billdog.pushnotifications.view.ViewResponse;

@Service
public class PushNotificationService {

	@Autowired
	NotificationMasterRepository notificationMasterRepository;

	@Autowired
	MemberNotificationRepository memberNotificationRepository;

	@Autowired
	ScreenNameMasterRepository screenNameMasterRepository;

	@Value("#{${app.notifications.defaults}}")
	private Map<String, String> defaults;

	private Logger logger = LoggerFactory.getLogger(PushNotificationService.class);
	private FCMService fcmService;

	public PushNotificationService(FCMService fcmService) {
		this.fcmService = fcmService;
	}

	@Scheduled(initialDelay = 60000, fixedDelay = 60000)
	public void sendSamplePushNotification() {
		try {
			fcmService.sendMessageWithoutData(getSamplePushNotificationRequest());
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	public void sendPushNotification(PushNotificationRequest request) {
		try {
			fcmService.sendMessage(getSamplePayloadData(), request);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	public void sendPushNotificationWithoutData(PushNotificationRequest request) {
		try {
			fcmService.sendMessageWithoutData(request);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	public void sendPushNotificationToToken(PushNotificationRequest request) {
		try {
			fcmService.sendMessageToToken(request);
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	private Map<String, String> getSamplePayloadData() {
		Map<String, String> pushData = new HashMap<>();
		pushData.put("messageId", defaults.get("payloadMessageId"));
		pushData.put("text", defaults.get("payloadData") + " " + LocalDateTime.now());
		return pushData;
	}

	private PushNotificationRequest getSamplePushNotificationRequest() {
		PushNotificationRequest request = new PushNotificationRequest(defaults.get("title"), defaults.get("message"),
				defaults.get("topic"));
		return request;
	}

	public ViewResponse sendNotifications(PushNotificationRequest request) {

		NotificationMaster notificationMaster = titleMethod(request.getTitle());
		if (!StringUtils.isBlank(request.getTitle()) && request.getTitle().equalsIgnoreCase(Constants.CASE_UPDATED)) {
			String message = notificationMaster.getMessage().replace("{{caseId}}", request.getCaseId());
			request.setMessage(message);
		}
		if (!StringUtils.isBlank(request.getTitle()) && request.getTitle().equalsIgnoreCase(Constants.NEW_MESSAGE)) {
			String message = notificationMaster.getMessage().replace("{{caseId}}", request.getCaseId());
			request.setMessage(message);
		}
		if (request.getPushnotificationsEnum().toString().equalsIgnoreCase("PUSH_NOTIFICATION")) {
			if (notificationMaster.isPushNotification()) {
				sendPushNotificationToToken(request);
			}
		}
		if (request.getPushnotificationsEnum().toString().equalsIgnoreCase("IN_APP")) {
			if (notificationMaster.isInApp()) {
				sendInAppNotification(request, notificationMaster);
			}
		}
		if (request.getPushnotificationsEnum().toString().equalsIgnoreCase("BOTH")) {

			if (notificationMaster.isPushNotification()) {
				sendPushNotificationToToken(request);
			}

			if (notificationMaster.isInApp()) {
				sendInAppNotification(request, notificationMaster);
			}
		}

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage("Notification sent successfully");
		return viewResponse;

	}

	private void sendInAppNotification(PushNotificationRequest request, NotificationMaster notificationMaster) {

		MemberNotifications memberNotifications = new MemberNotifications();
		memberNotifications.setCreatedAt(DateAndTimeUtil.now());
		memberNotifications.setUpdatedAt(DateAndTimeUtil.now());
		memberNotifications.setCaseId(request.getCaseId());
		memberNotifications.setNotificationSentDate(DateAndTimeUtil.now());
		memberNotifications.setMemberId(request.getMemberId());
		memberNotifications.setNotificationRead(false);
		memberNotifications.setNotificationMasterId(notificationMaster);
		memberNotifications.setMessage(request.getMessage());
		memberNotificationRepository.save(memberNotifications);

	}

	private NotificationMaster titleMethod(String title) {

		Optional<NotificationMaster> notificationMaster = notificationMasterRepository.findByTitleName(title);
		if (!notificationMaster.isPresent()) {
			throw new RecordNotFoundException(Constants.TITLE_NOT_FOUND);
		}
		return notificationMaster.get();

	}

	public ResponseEntity<ViewResponse> getNotificationByMember(Long memberId, int pageNumber, int pageLimit) {

		List<ViewNotifications> viewNotificationsList = new ArrayList<>();
		Page<MemberNotifications> memberNotifications = memberNotificationRepository.getMemberNotifications(memberId,
				getPageRequest(pageNumber, pageLimit));
		memberNotifications.getContent().forEach(notification -> {
			ViewNotifications viewNotifications = new ViewNotifications();
			viewNotifications.setCaseId(notification.getCaseId());
			viewNotifications
					.setDateOn(DateAndTimeUtil.convertLocalDateToString(notification.getCreatedAt().toLocalDate()) + " "
							+ DateAndTimeUtil.getTime(notification.getCreatedAt().toLocalTime()));
			viewNotifications.setNotificationId(notification.getId());
			viewNotifications.setNotificationRead(notification.isNotificationRead());
			Optional<NotificationMaster> notificationMaster = notificationMasterRepository
					.findById(notification.getNotificationMasterId().getId());
			if (notificationMaster.isPresent()) {
				viewNotifications.setTapable(notificationMaster.get().isTappable());
				viewNotifications.setMessage(notification.getMessage());
				Optional<ScreenNameMaster> screenName = screenNameMasterRepository
						.findById(notificationMaster.get().getScreenNameMasterId().getId());
				viewNotifications.setScreenName(screenName.get().getScreenName());
			}

			LocalDate date = notification.getNotificationSentDate().toLocalDate();
			if (LocalDate.now().minusDays(1).equals(date)) {
				viewNotifications.setDay("Yesterday");
			} else if (LocalDate.now().equals(date)) {
				viewNotifications.setDay("Today");
			} else {
				viewNotifications.setDay(date.toString());
			}
			viewNotificationsList.add(viewNotifications);
		});

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.SUCCESS);
		viewResponse.setStatusText(Constants.NOTIFICATION_FETCHED);
		viewResponse.setTotalElements(memberNotifications.getTotalElements());
		viewResponse.setData(viewNotificationsList);
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public ResponseEntity<ViewResponse> notificationRead(NotificationReadStatusRequest notificationReadStatusRequest) {
		String title=Constants.CASE_UPDATED;
		if (!StringUtils.isBlank(notificationReadStatusRequest.getScreenName())
				&& notificationReadStatusRequest.getScreenName().equalsIgnoreCase(Constants.CHAT)) {
			title=Constants.NEW_MESSAGE;
		}
		if (!StringUtils.isBlank(notificationReadStatusRequest.getScreenName())
				&& notificationReadStatusRequest.getScreenName().equalsIgnoreCase(Constants.CASE)) {
			title=Constants.CASE_UPDATED;
		}
		NotificationMaster notificationMaster = titleMethod(title);
		Optional<MemberNotifications> notificationOptional = memberNotificationRepository.findByIdAndMemberId(
				notificationReadStatusRequest.getNotificationId(), notificationReadStatusRequest.getMemberId());
		if (notificationOptional.isPresent()) {
			List<MemberNotifications> memberNotifications = memberNotificationRepository
					.findByMemberIdAndCaseIdAndNotificationReadAndNotificationMasterId(
							notificationReadStatusRequest.getMemberId(), notificationOptional.get().getCaseId(), false,
							notificationMaster);
			List<MemberNotifications> memberNotificationsList = new ArrayList<>();
			memberNotifications.forEach(notification -> {
				notification.setNotificationRead(notificationReadStatusRequest.isReadStatus());
				memberNotificationsList.add(notification);
			});
			memberNotificationRepository.saveAll(memberNotificationsList);
		}

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.SUCCESS);
		viewResponse.setStatusText(Constants.NOTIFICATION_UPDATED);
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewResponse> notificationStatusRead(
			UpdateNotificationReadStatusRequest notificationReadStatusRequest) {
		NotificationMaster notificationMaster = titleMethod(notificationReadStatusRequest.getTitle());
		List<MemberNotifications> memberNotifications = memberNotificationRepository
				.findByMemberIdAndCaseIdAndNotificationReadAndNotificationMasterId(
						notificationReadStatusRequest.getMemberId(), notificationReadStatusRequest.getCaseId(), false,
						notificationMaster);
		List<MemberNotifications> memberNotificationsList = new ArrayList<>();
		memberNotifications.forEach(notification -> {
			notification.setNotificationRead(notificationReadStatusRequest.isReadStatus());
			memberNotificationsList.add(notification);
		});
		memberNotificationRepository.saveAll(memberNotificationsList);
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.SUCCESS);
		viewResponse.setStatusText(Constants.NOTIFICATION_UPDATED);
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewResponse> notificationUnReadCount(Long memberId) {

		BigInteger notificationUnreadCount = memberNotificationRepository.getUnreadNotificationCount(memberId);

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.SUCCESS);
		viewResponse.setStatusText(Constants.NOTIFICATION_FETCHED);
		viewResponse.setUnreadCount(notificationUnreadCount.longValue());
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private String getTime(LocalTime time) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");
		return formatter.format(time);
	}

}
