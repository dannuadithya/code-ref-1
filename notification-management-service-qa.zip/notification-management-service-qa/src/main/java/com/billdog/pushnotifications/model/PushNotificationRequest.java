package com.billdog.pushnotifications.model;

import com.billdog.pushnotifications.common.PushnotificationsEnum;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PushNotificationRequest {

	private String screenflow;
	private String title;
	private String message;
	private String topic;
	private String token;
	private PushnotificationsEnum pushnotificationsEnum;
	private String caseId;
	private Long memberId;
	/* private Apns apns; */

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public PushnotificationsEnum getPushnotificationsEnum() {
		return pushnotificationsEnum;
	}

	public void setPushnotificationsEnum(PushnotificationsEnum pushnotificationsEnum) {
		this.pushnotificationsEnum = pushnotificationsEnum;
	}

	public String getScreenflow() {
		return screenflow;
	}

	public void setScreenflow(String screenflow) {
		this.screenflow = screenflow;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public PushNotificationRequest() {
	}

	public PushNotificationRequest(String title, String messageBody, String topicName) {
		this.title = title;
		this.message = messageBody;
		this.topic = topicName;
	}

}
