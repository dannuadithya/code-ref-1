package com.billdog.pushnotifications.firebase;

import java.time.Duration;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutionException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billdog.pushnotifications.common.Constants;
import com.billdog.pushnotifications.entity.NotificationMaster;
import com.billdog.pushnotifications.exception.RecordNotFoundException;
import com.billdog.pushnotifications.model.PushNotificationRequest;
import com.billdog.pushnotifications.model.SubscriptionTopicRequest;
import com.billdog.pushnotifications.repository.NotificationMasterRepository;
import com.google.firebase.messaging.AndroidConfig;
import com.google.firebase.messaging.AndroidNotification;
import com.google.firebase.messaging.ApnsConfig;
import com.google.firebase.messaging.Aps;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingException;
import com.google.firebase.messaging.Message;
import com.google.firebase.messaging.Notification;
import com.google.firebase.messaging.TopicManagementResponse;

@Service
public class FCMService {

	@Autowired
	NotificationMasterRepository notificationMasterRepository;

	private Logger logger = LoggerFactory.getLogger(FCMService.class);

	public void sendMessage(Map<String, String> data, PushNotificationRequest request)
			throws InterruptedException, ExecutionException {
		Message message = getPreconfiguredMessageWithData(data, request);
		String response = sendAndGetResponse(message);
		logger.info("Sent message with data. Topic: " + request.getTopic() + ", " + response);
	}

	public void sendMessageWithoutData(PushNotificationRequest request)
			throws InterruptedException, ExecutionException {
		Message message = getPreconfiguredMessageWithoutData(request);
		String response = sendAndGetResponse(message);
		logger.info("Sent message without data. Topic: " + request.getTopic() + ", " + response);
	}

	public void sendMessageToToken(PushNotificationRequest request) throws InterruptedException, ExecutionException {
		Message message = getPreconfiguredMessageToToken(request);
		String response = sendAndGetResponse(message);
		logger.info("Sent message to token. Device token: " + request.getToken() + ", " + response);
	}

	private String sendAndGetResponse(Message message) throws InterruptedException, ExecutionException {
		return FirebaseMessaging.getInstance().sendAsync(message).get();
	}

	private AndroidConfig getAndroidConfig(String topic) {
		return AndroidConfig.builder().setTtl(Duration.ofMinutes(2).toMillis()).setCollapseKey(topic)
				.setPriority(AndroidConfig.Priority.HIGH)
				.setNotification(AndroidNotification.builder().setSound(NotificationParameter.SOUND.getValue())
						.setColor(NotificationParameter.COLOR.getValue()).setTag(topic).build())
				.build();
	}

	private ApnsConfig getApnsConfig(String topic) {
		return ApnsConfig.builder().setAps(Aps.builder().setSound(NotificationParameter.SOUND.getValue())
				.setCategory(topic).setThreadId(topic).build()).build();
	}

	private Message getPreconfiguredMessageToToken(PushNotificationRequest request) {
		return getPreconfiguredMessageBuilder(request).setToken(request.getToken()).build();
	}

	private Message getPreconfiguredMessageWithoutData(PushNotificationRequest request) {
		return getPreconfiguredMessageBuilder(request).setTopic(request.getTopic()).build();
	}

	private Message getPreconfiguredMessageWithData(Map<String, String> data, PushNotificationRequest request) {
		return getPreconfiguredMessageBuilder(request).putAllData(data).setTopic(request.getTopic()).build();
	}

	private Message.Builder getPreconfiguredMessageBuilder(PushNotificationRequest request) {
		NotificationMaster notificationMaster = titleMethod(request);
		AndroidConfig androidConfig = getAndroidConfig(request.getTopic());
		ApnsConfig apnsConfig = getApnsConfig(request.getTopic());
		return Message.builder().putData("screenflow", request.getScreenflow()).putData("caseId", request.getCaseId())
				.setApnsConfig(apnsConfig).setAndroidConfig(androidConfig)
				.setNotification(new Notification(notificationMaster.getTitleName(),
						notificationMaster.getMessage().replace("{{caseId}}", request.getCaseId())));
	}

	public void subscribeToTopic(SubscriptionTopicRequest request) {
		try {
			TopicManagementResponse response = FirebaseMessaging.getInstance()
					.subscribeToTopic(request.getDeviceTokens(), request.getTopic());
			logger.info("Success device Tokens Count :" + response.getSuccessCount());
		} catch (FirebaseMessagingException e) {

		}
	}

	private NotificationMaster titleMethod(PushNotificationRequest request) {

		Optional<NotificationMaster> notificationMaster = notificationMasterRepository
				.findByTitleName(request.getTitle());
		if (!notificationMaster.isPresent()) {
			throw new RecordNotFoundException(Constants.TITLE_NOT_FOUND);
		}
		return notificationMaster.get();

	}
}
