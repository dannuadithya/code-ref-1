package com.billdog.pushnotifications.repository;

import com.billdog.pushnotifications.view.MemberInfoResponse;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface UserRepository {

	@GET("/user/v1/user-token")
	public Call<MemberInfoResponse> verifyUserToken(@Query("userId") Long userId);

	@GET("/user/v1/member-token")
	public Call<MemberInfoResponse> verifyMemberToken(@Query("memberId") Long memberId);

}
