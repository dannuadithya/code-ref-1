package com.billdog.pushnotifications.common;

public enum PushnotificationsEnum {

	IN_APP,PUSH_NOTIFICATION,BOTH
}
