package com.billdog.pushnotifications.model;

import java.util.ArrayList;
import java.util.List;

public class SubscriptionTopicRequest {
	
	private String topic;
	private List<String> deviceTokens=new ArrayList<String>();
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public List<String> getDeviceTokens() {
		return deviceTokens;
	}
	public void setDeviceTokens(List<String> deviceTokens) {
		this.deviceTokens = deviceTokens;
	}
}
