#!/bin/bash
sed "s/latest/$1/g" Notification.yaml > Notification-management.yaml
