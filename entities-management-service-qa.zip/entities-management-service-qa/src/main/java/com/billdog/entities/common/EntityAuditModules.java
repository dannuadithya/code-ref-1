package com.billdog.entities.common;

public enum EntityAuditModules {

	Broker_Company, Individual_Provider, Individual_Broker, Employer, Company_Provider, Insurance_Company, Entities

}
