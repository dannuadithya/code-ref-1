package com.billdog.entities.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.entities.entity.OpportunityTypeMaster;

@Repository
public interface OpportunityTypeMasterRepository
		extends JpaRepository<OpportunityTypeMaster, Long>
{

	Optional<OpportunityTypeMaster> findByOpportunityParentNameAndOrganizationId(String block, Long organizationId);

	Optional<OpportunityTypeMaster> findByOpportunityParentName(String blockOpportunityName);

}
