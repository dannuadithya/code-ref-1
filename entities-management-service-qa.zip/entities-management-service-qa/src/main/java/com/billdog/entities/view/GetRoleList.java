package com.billdog.entities.view;

import java.util.List;

public class GetRoleList {

	private List<GetRole> data;
	private String statusText;

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public List<GetRole> getData() {
		return data;
	}

	public void setData(List<GetRole> data) {
		this.data = data;
	}

}