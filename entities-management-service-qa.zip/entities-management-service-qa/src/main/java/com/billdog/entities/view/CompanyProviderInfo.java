package com.billdog.entities.view;

public class CompanyProviderInfo {

	private long companyProviderId;
	private String companyProviderName;

	public long getCompanyProviderId() {
		return companyProviderId;
	}

	public void setCompanyProviderId(long companyProviderId) {
		this.companyProviderId = companyProviderId;
	}

	public String getCompanyProviderName() {
		return companyProviderName;
	}

	public void setCompanyProviderName(String companyProviderName) {
		this.companyProviderName = companyProviderName;
	}

}
