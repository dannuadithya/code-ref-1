package com.billdog.entities.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.BrokerCompany;
import com.billdog.entities.entity.IndividualBroker;
import com.billdog.entities.entity.Opportunity;
import com.billdog.entities.entity.OpportunityTypeMaster;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.entity.SubOpportunity;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.BrokerCompanyRepository;
import com.billdog.entities.repository.IndividualBrokerRepository;
import com.billdog.entities.repository.OpportunityRepository;
import com.billdog.entities.repository.OpportunityTypeMasterRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.repository.SubOpportunityRepository;
import com.billdog.entities.request.AddBrokerCompanyRequest;
import com.billdog.entities.request.CheckExternalUserEmail;
import com.billdog.entities.request.SearchBrokerCompanyRequest;
import com.billdog.entities.request.UpdateBrokerCompanyRequest;
import com.billdog.entities.request.UpdateExternalUser;
import com.billdog.entities.view.BrokerCompanyInfo;
import com.billdog.entities.view.ExternalUserBlockOpportunity;
import com.billdog.entities.view.ExternalUserGroupOpportunity;
import com.billdog.entities.view.GetRoleList;
import com.billdog.entities.view.ViewBrokerCompany;
import com.billdog.entities.view.ViewExternalUser;
import com.billdog.entities.view.ViewResponse;

@Service
public class BrokerCompanyService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(BrokerCompanyService.class);

	@Autowired
	BrokerCompanyRepository brokerCompanyRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	UserService userService;

	@Autowired
	AddInsuranceCompanyService addInsuranceCompanyService;

	@Autowired
	CompanyProviderService companyProviderService;

	@Autowired
	IndividualBrokerRepository individualBrokerRepository;

	@Autowired
	OpportunityRepository opportunityRepository;

	@Autowired
	OpportunityTypeMasterRepository opportunityTypeMasterRepository;

	@Autowired
	SubOpportunityRepository subOpportunityRepository;

	public ResponseEntity<ViewResponse> addBrokerCompany(AddBrokerCompanyRequest addBrokerCompanyRequest,
			String token) {
		LOGGER.info("addBrokerCompany method started..!");
		if (StringUtils.isBlank(addBrokerCompanyRequest.getBrokerCompanyName())) {
			throw new BadRequestException(ExceptionalMessages.BROKER_COMPANY_NAME_SIZE);
		}
		Optional<Organization> organization = organizationRepository
				.findById(addBrokerCompanyRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		requestValidate(addBrokerCompanyRequest);

		saveBrokerCompany(addBrokerCompanyRequest, organization.get(), token);

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.BROKER_COMPANY_CREATED);
		LOGGER.info("addBrokerCompany method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void saveBrokerCompany(AddBrokerCompanyRequest addBrokerCompanyRequest, Organization organization,
			String token) {
		LOGGER.debug("creating new object in broker company table.!!");
		BrokerCompany brokerCompany = new BrokerCompany();
		brokerCompany.setCreatedAt(DateAndTimeUtil.now());
		brokerCompany.setUpdatedAt(DateAndTimeUtil.now());
		brokerCompany.setBrokerCompanyName(WordUtils.capitalizeFully(addBrokerCompanyRequest.getBrokerCompanyName()));
		brokerCompany.setContactName(WordUtils.capitalizeFully(addBrokerCompanyRequest.getContactName()));
		brokerCompany.setEmail(addBrokerCompanyRequest.getEmail());
		brokerCompany.setContactNumber(addBrokerCompanyRequest.getContactNumber());
		brokerCompany.setAddress(addBrokerCompanyRequest.getAddress());
		if (addBrokerCompanyRequest.getSfdcId() != null && !addBrokerCompanyRequest.getSfdcId().isEmpty()) {
			brokerCompany.setSfdcId(addBrokerCompanyRequest.getSfdcId());
			brokerCompany.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		brokerCompany.setOrganizationId(organization);
		brokerCompany.setStatus(StatusConstants.ACTIVE);
		if (addBrokerCompanyRequest.getCountryCodeId() > 0) {
			companyProviderService.checkCountryCode(addBrokerCompanyRequest.getCountryCodeId(), organization.getId());
			brokerCompany.setCountryCodeId(addBrokerCompanyRequest.getCountryCodeId());
		}

		/*
		 * GetRoleList getRoles = getRole(addBrokerCompanyRequest.getUserId(), token);
		 * if (getRoles != null) { getRoles.getData().forEach(role -> { if
		 * (role.getName().equalsIgnoreCase("External Operator")) {
		 * brokerCompany.setRoleId(role.getRoleId()); } }); }
		 */
		brokerCompany.setUserId(addBrokerCompanyRequest.getUserId());
		brokerCompanyRepository.save(brokerCompany);
	}

	public GetRoleList getRole(long userId, String token) {
		GetRoleList getRoles = userService.getRole(userId, token);
		if (getRoles == null || (!getRoles.getStatusText().equalsIgnoreCase(Constants.SUCCESS))) {
			throw new RecordNotFoundException(ExceptionalMessages.ROLE_NOT_FOUND);
		}
		return getRoles;
	}

	private void requestValidate(AddBrokerCompanyRequest addBrokerCompanyRequest) {

		Optional<BrokerCompany> brokerCompanyName = brokerCompanyRepository
				.findByBrokerCompanyName(addBrokerCompanyRequest.getBrokerCompanyName());
		if (brokerCompanyName.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NAME);
		}
		if (addBrokerCompanyRequest.getEmail() != null && !addBrokerCompanyRequest.getEmail().isEmpty()) {
			Optional<BrokerCompany> brokerCompanyEmail = brokerCompanyRepository
					.findByEmail(addBrokerCompanyRequest.getEmail());
			if (brokerCompanyEmail.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
			}

			Optional<IndividualBroker> individualBroker = individualBrokerRepository
					.findByEmail(addBrokerCompanyRequest.getEmail());
			if (individualBroker.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_BROKER_EMAIL);
			}
		}

		if (addBrokerCompanyRequest.getSfdcId() != null && !addBrokerCompanyRequest.getSfdcId().isEmpty()) {
			if (addBrokerCompanyRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<BrokerCompany> brokerCompany = brokerCompanyRepository
					.findBySfdcId(addBrokerCompanyRequest.getSfdcId());
			if (brokerCompany.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		if (addBrokerCompanyRequest.getContactName() != null && !addBrokerCompanyRequest.getContactName().isEmpty()) {
			if (addBrokerCompanyRequest.getContactName().length() < 2
					|| addBrokerCompanyRequest.getContactName().length() > 20) {
				throw new RecordNotFoundException(ExceptionalMessages.CONTACT_NAME);
			}
		}

		if (addBrokerCompanyRequest.getContactNumber() != null && !addBrokerCompanyRequest.getContactNumber().isEmpty()
				&& !StringUtils.isNumeric(addBrokerCompanyRequest.getContactNumber())) {
			throw new RecordNotFoundException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (addBrokerCompanyRequest.getContactNumber() != null && !addBrokerCompanyRequest.getContactNumber().isEmpty()
				&& addBrokerCompanyRequest.getContactNumber().length() != 10) {
			throw new RecordNotFoundException(ExceptionalMessages.MOBILE_NUMER);
		}
		if (addBrokerCompanyRequest.getAddress() != null && !addBrokerCompanyRequest.getAddress().isEmpty()
				&& addBrokerCompanyRequest.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}

	}

	public ResponseEntity<ViewResponse> searchBrokerCompany(SearchBrokerCompanyRequest searchBrokerCompanyRequest) {
		LOGGER.info("searchBrokerCompany method started..!");

		String brokerCompanyName = null;
		String contactName = null;
		String contactNo = null;
		String email = null;
		String sfdcId = null;
		String status = null;
		if (searchBrokerCompanyRequest.getBrokerCompanyName() != null
				&& !searchBrokerCompanyRequest.getBrokerCompanyName().equals("")) {
			brokerCompanyName = "%" + searchBrokerCompanyRequest.getBrokerCompanyName() + "%";
		} else {
			brokerCompanyName = searchBrokerCompanyRequest.getBrokerCompanyName();
		}

		if (searchBrokerCompanyRequest.getContactNo() != null
				&& !searchBrokerCompanyRequest.getContactNo().equals("")) {
			contactNo = "%" + searchBrokerCompanyRequest.getContactNo() + "%";
		} else {
			contactNo = searchBrokerCompanyRequest.getContactNo();
		}

		if (searchBrokerCompanyRequest.getContactName() != null
				&& !searchBrokerCompanyRequest.getContactName().equals("")) {
			contactName = "%" + searchBrokerCompanyRequest.getContactName() + "%";
		} else {
			contactName = searchBrokerCompanyRequest.getContactName();
		}

		if (searchBrokerCompanyRequest.getEmailId() != null && !searchBrokerCompanyRequest.getEmailId().equals("")) {
			email = "%" + searchBrokerCompanyRequest.getEmailId() + "%";
		} else {
			email = searchBrokerCompanyRequest.getEmailId();
		}

		if (searchBrokerCompanyRequest.getSfdcId() != null && !searchBrokerCompanyRequest.getSfdcId().equals("")) {
			sfdcId = "%" + searchBrokerCompanyRequest.getSfdcId() + "%";
		} else {
			sfdcId = searchBrokerCompanyRequest.getSfdcId();
		}

		status = searchBrokerCompanyRequest.getStatus();

		Integer pageNumber = searchBrokerCompanyRequest.getPageNumber() > 0 ? searchBrokerCompanyRequest.getPageNumber()
				: 0;
		Integer pageLimit = searchBrokerCompanyRequest.getPageLimit() > 0 ? searchBrokerCompanyRequest.getPageLimit()
				: 20;
		// native query for searching broker company and assigning parameters
		// respectively
		Page<Object[][]> brokerCompany = brokerCompanyRepository.getBrokerCompanies(brokerCompanyName,
				brokerCompanyName, contactName, contactName, contactNo, contactNo, email, email, sfdcId, sfdcId, status,
				status, getPageRequest(pageNumber, pageLimit));

		// for loop for users searched with native query and assigning values
		// respectively

		List<ViewBrokerCompany> viewBrokerCompanyList = getBrokerCompanyList(brokerCompany);
		LOGGER.debug("Setting member details for new member object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.BROKER_COMPANY);
		if (viewBrokerCompanyList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewBrokerCompanyList);
		response.setTotal(brokerCompany.getTotalElements());

		LOGGER.info("searchBrokerCompany method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewBrokerCompany> getBrokerCompanyList(Page<Object[][]> brokerCompany) {
		List<ViewBrokerCompany> viewBrokerCompanyList = new ArrayList<>();
		for (Object[] objects : brokerCompany) {
			ViewBrokerCompany viewBrokerCompany = new ViewBrokerCompany();
			viewBrokerCompany.setBrokerCompanyName(((String) objects[0]));
			viewBrokerCompany.setContactName(((String) objects[1]));
			viewBrokerCompany.setContactNo((String) objects[3]);
			viewBrokerCompany.setEmailId((String) objects[2]);
			if ((String) objects[4] == null) {
				viewBrokerCompany.setSfdcId("");
			} else {
				viewBrokerCompany.setSfdcId((String) objects[4]);
			}
			viewBrokerCompany.setStatus((String) objects[5]);
			if ((BigInteger) objects[6] != null) {
				viewBrokerCompany.setCountryCodeId(((BigInteger) objects[6]).longValue());
			}
			viewBrokerCompany.setBrokerCompanyId(((BigInteger) objects[7]).longValue());
			viewBrokerCompany.setAddress((String) objects[8]);
			viewBrokerCompanyList.add(viewBrokerCompany);
		}
		return viewBrokerCompanyList;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public ResponseEntity<ViewBrokerCompany> getBrokerCompany(Long brokerCompanyId) {
		LOGGER.info("getBrokerCompany method started..!");

		// checking whether broker company with given id present or not
		Optional<BrokerCompany> brokerCompany = brokerCompanyRepository.findById(brokerCompanyId);
		if (!brokerCompany.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NOT_FOUND);
		}
		BrokerCompany brokerCompanyDetails = brokerCompany.get();
		LOGGER.info("setting broker company details to respective fields");
		ViewBrokerCompany viewBrokerCompany = new ViewBrokerCompany();
		viewBrokerCompany.setBrokerCompanyName(brokerCompanyDetails.getBrokerCompanyName());
		viewBrokerCompany.setContactName(brokerCompanyDetails.getContactName());
		viewBrokerCompany.setContactNo(brokerCompanyDetails.getContactNumber());
		viewBrokerCompany.setEmailId(brokerCompanyDetails.getEmail());
		if (brokerCompanyDetails.getSfdcId() != null) {
			viewBrokerCompany.setSfdcId(brokerCompanyDetails.getSfdcId());
		}
		viewBrokerCompany.setStatus(brokerCompanyDetails.getStatus());
		viewBrokerCompany.setCountryCodeId(brokerCompanyDetails.getCountryCodeId());
		viewBrokerCompany.setAddress(brokerCompanyDetails.getAddress());

		LOGGER.info("getBrokerCompany method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewBrokerCompany);
	}

	public ResponseEntity<ViewResponse> getBrokerCompanies(Long organizationId) {
		LOGGER.info("getBrokerCompanies method started..!");
		Optional<Organization> orgOptional = organizationRepository.findById(organizationId);
		if (!orgOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		LOGGER.info("Fetching all broker companies with organization id:: {}", organizationId);
		List<BrokerCompany> companyProviderList = brokerCompanyRepository
				.findByOrganizationIdAndStatus(orgOptional.get(), StatusConstants.ACTIVE);
		List<BrokerCompanyInfo> companyProviderInfoList = new ArrayList<>();
		companyProviderList.forEach(brokerCompany -> {
			BrokerCompanyInfo brokerCompanyInfo = new BrokerCompanyInfo();
			brokerCompanyInfo.setBrokerCompanyId(brokerCompany.getId());
			brokerCompanyInfo.setBrokerCompanyAffiliation(brokerCompany.getBrokerCompanyName());
			companyProviderInfoList.add(brokerCompanyInfo);
		});
		BrokerCompanyInfo brokerCompanyInfo = new BrokerCompanyInfo();
		brokerCompanyInfo.setBrokerCompanyAffiliation(Constants.INDEPENDENT);
		companyProviderInfoList.add(brokerCompanyInfo);
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.BROKER_COMPANY_LIST_FETCHED);
		if (companyProviderInfoList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(companyProviderInfoList);
		LOGGER.info("getBrokerCompanies method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> editBrokerCompany(UpdateBrokerCompanyRequest updateBrokerCompanyRequest) {
		LOGGER.info("editBrokerCompany method started..!");
		if (StringUtils.isBlank(updateBrokerCompanyRequest.getBrokerCompanyName())) {
			throw new BadRequestException(ExceptionalMessages.BROKER_COMPANY_NAME_SIZE);
		}
		Optional<BrokerCompany> brokerCompanyEntity = brokerCompanyRepository
				.findById(updateBrokerCompanyRequest.getBrokerCompanyId());
		if (!brokerCompanyEntity.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NOT_FOUND);
		}
		BrokerCompany brokerCompany = brokerCompanyEntity.get();
		if (brokerCompanyEntity.get().getBrokerCompanyName() != null && !brokerCompany.getBrokerCompanyName()
				.equalsIgnoreCase(updateBrokerCompanyRequest.getBrokerCompanyName())) {
			Optional<BrokerCompany> brokerCompanyName = brokerCompanyRepository
					.findByBrokerCompanyName(updateBrokerCompanyRequest.getBrokerCompanyName());
			if (brokerCompanyName.isPresent()
					&& brokerCompanyName.get().getId() != updateBrokerCompanyRequest.getBrokerCompanyId()) {
				throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NAME);
			}
		}

		if (!StringUtils.isBlank(updateBrokerCompanyRequest.getEmail())
				&& !updateBrokerCompanyRequest.getEmail().equalsIgnoreCase(brokerCompany.getEmail())) {
			Optional<BrokerCompany> brokerCompanyEmail = brokerCompanyRepository
					.findByEmail(updateBrokerCompanyRequest.getEmail());
			if (brokerCompanyEmail.isPresent()
					&& brokerCompanyEmail.get().getId() != updateBrokerCompanyRequest.getBrokerCompanyId()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
			}

			Optional<IndividualBroker> individualBroker = individualBrokerRepository
					.findByEmail(updateBrokerCompanyRequest.getEmail());
			if (individualBroker.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_BROKER_EMAIL);
			}
		}

		if (updateBrokerCompanyRequest.getSfdcId() != null && !updateBrokerCompanyRequest.getSfdcId().isEmpty()) {
			if (updateBrokerCompanyRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<BrokerCompany> brokerSfdc = brokerCompanyRepository
					.findBySfdcId(updateBrokerCompanyRequest.getSfdcId());
			if (brokerSfdc.isPresent() && brokerSfdc.get().getId() != updateBrokerCompanyRequest.getBrokerCompanyId()) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		if (updateBrokerCompanyRequest.getContactName() != null
				&& !updateBrokerCompanyRequest.getContactName().isEmpty()) {
			if (updateBrokerCompanyRequest.getContactName().length() < 2
					|| updateBrokerCompanyRequest.getContactName().length() > 20) {
				throw new RecordNotFoundException(ExceptionalMessages.CONTACT_NAME);
			}
		}

		if (updateBrokerCompanyRequest.getContactNumber() != null
				&& !updateBrokerCompanyRequest.getContactNumber().isEmpty()
				&& !StringUtils.isNumeric(updateBrokerCompanyRequest.getContactNumber())) {
			throw new RecordNotFoundException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (updateBrokerCompanyRequest.getContactNumber() != null
				&& !updateBrokerCompanyRequest.getContactNumber().isEmpty()
				&& updateBrokerCompanyRequest.getContactNumber().length() != 10) {
			throw new RecordNotFoundException(ExceptionalMessages.MOBILE_NUMER);
		}

		if (updateBrokerCompanyRequest.getAddress() != null && !updateBrokerCompanyRequest.getAddress().isEmpty()
				&& updateBrokerCompanyRequest.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}
		LOGGER.info("setting broker company details to respective fields");
		updateBrokerCompany(updateBrokerCompanyRequest, brokerCompany);

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.BROKER_COMPANY_UPDATED);
		LOGGER.info("editBrokerCompany method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void updateBrokerCompany(UpdateBrokerCompanyRequest updateBrokerCompanyRequest,
			BrokerCompany brokerCompany) {
		LOGGER.debug("updating broker company method started");

		brokerCompany.setUpdatedAt(DateAndTimeUtil.now());
		brokerCompany
				.setBrokerCompanyName(WordUtils.capitalizeFully(updateBrokerCompanyRequest.getBrokerCompanyName()));
		brokerCompany.setContactName(WordUtils.capitalizeFully(updateBrokerCompanyRequest.getContactName()));
		brokerCompany.setEmail(updateBrokerCompanyRequest.getEmail());
		brokerCompany.setContactNumber(updateBrokerCompanyRequest.getContactNumber());
		brokerCompany.setSfdcId(updateBrokerCompanyRequest.getSfdcId());
		if (updateBrokerCompanyRequest.getSfdcId() != null && !updateBrokerCompanyRequest.getSfdcId().isEmpty()) {
			brokerCompany.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		if (updateBrokerCompanyRequest.getStatus() != null && !updateBrokerCompanyRequest.getStatus().isEmpty()) {
			brokerCompany.setStatus(updateBrokerCompanyRequest.getStatus());
		}
		if (updateBrokerCompanyRequest.getCountryCodeId() > 0) {
			companyProviderService.checkCountryCode(updateBrokerCompanyRequest.getCountryCodeId(),
					brokerCompany.getOrganizationId().getId());
			brokerCompany.setCountryCodeId(updateBrokerCompanyRequest.getCountryCodeId());
		}
		brokerCompany.setUserId(updateBrokerCompanyRequest.getUserId());
		brokerCompany.setAddress(updateBrokerCompanyRequest.getAddress());
		brokerCompanyRepository.save(brokerCompany);
	}

	public ResponseEntity<ViewExternalUser> checkExternalUserEmail(CheckExternalUserEmail checkExternalUserEmail) {
		LOGGER.info("checkExternalUserEmail method started..!");

		ViewExternalUser viewExternalUser = new ViewExternalUser();

		if (checkExternalUserEmail.getEmail() != null && !checkExternalUserEmail.getEmail().isEmpty()) {
//			Optional<BrokerCompany> brokerCompanyEmail = brokerCompanyRepository
//					.findByEmail(checkExternalUserEmail.getEmail());
//			if (brokerCompanyEmail.isPresent()) {
//				viewExternalUser.setName(brokerCompanyEmail.get().getContactName());
//				viewExternalUser.setBrokerCompanyName(brokerCompanyEmail.get().getBrokerCompanyName());
//				List<ExternalUserBlockOpportunity> blockopportunitiesForBroker = getBlockopportunitiesForBroker(
//						viewExternalUser, brokerCompanyEmail.get());
//				viewExternalUser.setExternalUserBlockOpportunity(blockopportunitiesForBroker);
//				List<ExternalUserGroupOpportunity> groupopportunitiesForBroker = getGroupopportunitiesForBroker(
//						viewExternalUser, brokerCompanyEmail.get());
//				viewExternalUser.setExternalUserGroupOpportunity(groupopportunitiesForBroker);
//
//			}
			Optional<IndividualBroker> individualBroker = individualBrokerRepository
					.findByEmail(checkExternalUserEmail.getEmail());
			if (individualBroker.isPresent()) {
				viewExternalUser.setFirstName(individualBroker.get().getFirstName());
				viewExternalUser.setLastName(individualBroker.get().getLastName());
				if (individualBroker.get().getContactNumber() != null) {
					viewExternalUser.setContactNumber(individualBroker.get().getContactNumber());
				}

				viewExternalUser
						.setName(individualBroker.get().getFirstName() + " " + individualBroker.get().getLastName());
				if (individualBroker.get().getBrokerCompany() == null) {
					viewExternalUser.setBrokerCompanyName("Independent");
				} else {
					viewExternalUser
							.setBrokerCompanyName(individualBroker.get().getBrokerCompany().getBrokerCompanyName());
				}
				List<ExternalUserBlockOpportunity> blockopportunitiesForIndividual = getBlockopportunitiesForIndividual(
						viewExternalUser, individualBroker.get());
				viewExternalUser.setExternalUserBlockOpportunity(blockopportunitiesForIndividual);
				List<ExternalUserGroupOpportunity> groupopportunitiesForIndividual = getGroupopportunitiesForIndividual(
						viewExternalUser, individualBroker.get());
				viewExternalUser.setExternalUserGroupOpportunity(groupopportunitiesForIndividual);
			} else {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_NOT_FOUND);
			}
		}
		LOGGER.info("checkExternalUserEmail method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewExternalUser);

	}

//	private List<ExternalUserBlockOpportunity> getBlockopportunitiesForBroker(ViewExternalUser viewExternalUser,
//			BrokerCompany brokerCompany) {
//
//		List<ExternalUserBlockOpportunity> externalUserList = new ArrayList<>();
//		Optional<OpportunityTypeMaster> opportunityTypeOptional = opportunityTypeMasterRepository
//				.findByOpportunityParentNameAndOrganizationId(Constants.BLOCK,
//						brokerCompany.getOrganizationId().getId());
//		if (opportunityTypeOptional.isPresent()) {
//			List<Opportunity> opportunities = opportunityRepository
//					.findByBrokerCompanyIdAndOpportunityTypeMasterId(brokerCompany, opportunityTypeOptional.get());
//			opportunities.forEach(opportunity -> {
//				ExternalUserBlockOpportunity externalUserBlockOpportunity = new ExternalUserBlockOpportunity();
//				externalUserBlockOpportunity.setBlockOpportunityName(opportunity.getOpportunityName());
//				externalUserList.add(externalUserBlockOpportunity);
//			});
//		}
//
//		return externalUserList;
//	}
//
//	private List<ExternalUserGroupOpportunity> getGroupopportunitiesForBroker(ViewExternalUser viewExternalUser,
//			BrokerCompany brokerCompany) {
//
//		List<ExternalUserGroupOpportunity> externalUserList = new ArrayList<>();
//		Optional<OpportunityTypeMaster> opportunityTypeOptional = opportunityTypeMasterRepository
//				.findByOpportunityParentNameAndOrganizationId(Constants.GROUP,
//						brokerCompany.getOrganizationId().getId());
//		if (opportunityTypeOptional.isPresent()) {
//			List<Opportunity> opportunities = opportunityRepository
//					.findByBrokerCompanyIdAndOpportunityTypeMasterId(brokerCompany, opportunityTypeOptional.get());
//			List<SubOpportunity> opportunityRepositories = subOpportunityRepository
//					.findByOpportunityIdIn(opportunities);
//			opportunityRepositories.forEach(subOpportunities -> {
//				ExternalUserGroupOpportunity externalUserGroupOpportunity = new ExternalUserGroupOpportunity();
//				externalUserGroupOpportunity.setGroupOpportunityName(subOpportunities.getSubGroupOpportunityName());
//				externalUserList.add(externalUserGroupOpportunity);
//			});
//
//		}
//
//		return externalUserList;
//	}

	private List<ExternalUserBlockOpportunity> getBlockopportunitiesForIndividual(ViewExternalUser viewExternalUser,
			IndividualBroker individualBroker) {

		List<ExternalUserBlockOpportunity> externalUserList = new ArrayList<>();
		Optional<OpportunityTypeMaster> opportunityTypeOptional = opportunityTypeMasterRepository
				.findByOpportunityParentNameAndOrganizationId(Constants.BLOCK,
						individualBroker.getOrganizationId().getId());
		if (opportunityTypeOptional.isPresent()) {
			List<Opportunity> opportunities = opportunityRepository.findByIndividualBrokerIdAndOpportunityTypeMasterId(
					individualBroker, opportunityTypeOptional.get());
			opportunities.forEach(opportunity -> {
				ExternalUserBlockOpportunity externalUserBlockOpportunity = new ExternalUserBlockOpportunity();
				externalUserBlockOpportunity.setBlockOpportunityName(opportunity.getOpportunityName());
				externalUserList.add(externalUserBlockOpportunity);
			});
		}

		return externalUserList;
	}

	private List<ExternalUserGroupOpportunity> getGroupopportunitiesForIndividual(ViewExternalUser viewExternalUser,
			IndividualBroker individualBroker) {

		List<ExternalUserGroupOpportunity> externalUserList = new ArrayList<>();
		Optional<OpportunityTypeMaster> opportunityTypeOptional = opportunityTypeMasterRepository
				.findByOpportunityParentNameAndOrganizationId(Constants.GROUP,
						individualBroker.getOrganizationId().getId());
		if (opportunityTypeOptional.isPresent()) {
			List<Opportunity> opportunities = opportunityRepository.findByIndividualBrokerIdAndOpportunityTypeMasterId(
					individualBroker, opportunityTypeOptional.get());
			List<SubOpportunity> opportunityRepositories = subOpportunityRepository
					.findByOpportunityIdIn(opportunities);
			opportunityRepositories.forEach(subOpportunities -> {
				ExternalUserGroupOpportunity externalUserGroupOpportunity = new ExternalUserGroupOpportunity();
				externalUserGroupOpportunity.setGroupOpportunityName(subOpportunities.getSubGroupOpportunityName());
				externalUserList.add(externalUserGroupOpportunity);
			});

		}

		return externalUserList;
	}

	public ResponseEntity<ViewResponse> updateExternalUser(UpdateExternalUser updateExternalUser) {
		LOGGER.info("updateExternalUser method started..!");

		if (updateExternalUser.getOldEmail() != null && !updateExternalUser.getOldEmail().isEmpty()) {
			Optional<BrokerCompany> brokerCompanyEmail = brokerCompanyRepository
					.findByEmail(updateExternalUser.getOldEmail());
			if (brokerCompanyEmail.isPresent()) {
				Optional<BrokerCompany> brokerCompanyNewEmail = brokerCompanyRepository
						.findByEmail(updateExternalUser.getNewEmail());
				if (brokerCompanyNewEmail.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
				}
				brokerCompanyEmail.get().setContactName(updateExternalUser.getFirstName());
				brokerCompanyEmail.get().setBrokerCompanyName(updateExternalUser.getBrokerCompany());
				brokerCompanyEmail.get().setEmail(updateExternalUser.getNewEmail());
				brokerCompanyRepository.save(brokerCompanyEmail.get());
			}
			Optional<IndividualBroker> individualBroker = individualBrokerRepository
					.findByEmail(updateExternalUser.getOldEmail());
			if (individualBroker.isPresent()) {
				Optional<IndividualBroker> individualBrokerNewEmail = individualBrokerRepository
						.findByEmail(updateExternalUser.getNewEmail());
				if (individualBrokerNewEmail.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
				}
				individualBroker.get().setEmail(updateExternalUser.getNewEmail());
				individualBroker.get().setFirstName(updateExternalUser.getFirstName());
				individualBroker.get().setLastName(updateExternalUser.getLastName());
				Optional<BrokerCompany> brokerCompanyOptional = brokerCompanyRepository
						.findById(individualBroker.get().getBrokerCompany().getId());
				if (brokerCompanyOptional.isPresent()) {
					brokerCompanyOptional.get().setBrokerCompanyName(updateExternalUser.getBrokerCompany());
					brokerCompanyRepository.save(brokerCompanyOptional.get());
				}
				individualBrokerRepository.save(individualBroker.get());
			}
		}

		ViewResponse ViewResponse = new ViewResponse();
		ViewResponse.setStatusText(Constants.SUCCESS);
		ViewResponse.setMessage(Constants.EXTERNAL_USER_DETAILS_UPDATED);
		LOGGER.info("updateExternalUser method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(ViewResponse);
	}

}
