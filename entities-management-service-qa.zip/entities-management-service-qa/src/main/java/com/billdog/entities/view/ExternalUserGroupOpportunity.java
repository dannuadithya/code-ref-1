package com.billdog.entities.view;

public class ExternalUserGroupOpportunity {

	private String groupOpportunityName;

	public String getGroupOpportunityName() {
		return groupOpportunityName;
	}

	public void setGroupOpportunityName(String groupOpportunityName) {
		this.groupOpportunityName = groupOpportunityName;
	}

}
