package com.billdog.entities.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity(name = "OPPORTUNITY_TYPE_MASTER")
@Table(name = "opportunity_type_master", indexes = { @Index(name = "id_index", columnList = "ID", unique = true) })
public class OpportunityTypeMaster extends BaseEntity {

	@Column(name = "opportunity_parent_name")
	private String opportunityParentName;

	@Column(name = "STATUS")
	private String status;

	@JoinColumn(name = "organization_Id")
	private Long organizationId;

	public String getOpportunityParentName() {
		return opportunityParentName;
	}

	public void setOpportunityParentName(String opportunityParentName) {
		this.opportunityParentName = opportunityParentName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

}
