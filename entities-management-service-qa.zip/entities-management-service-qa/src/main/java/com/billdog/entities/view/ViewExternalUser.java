package com.billdog.entities.view;

import java.util.List;

public class ViewExternalUser {

	private String firstName;
	private String lastName;
	private String name;
	private String brokerCompanyName;
	private String contactNumber;
	private List<ExternalUserBlockOpportunity> externalUserBlockOpportunity;
	private List<ExternalUserGroupOpportunity> externalUserGroupOpportunity;

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBrokerCompanyName() {
		return brokerCompanyName;
	}

	public void setBrokerCompanyName(String brokerCompanyName) {
		this.brokerCompanyName = brokerCompanyName;
	}

	public List<ExternalUserBlockOpportunity> getExternalUserBlockOpportunity() {
		return externalUserBlockOpportunity;
	}

	public void setExternalUserBlockOpportunity(List<ExternalUserBlockOpportunity> externalUserBlockOpportunity) {
		this.externalUserBlockOpportunity = externalUserBlockOpportunity;
	}

	public List<ExternalUserGroupOpportunity> getExternalUserGroupOpportunity() {
		return externalUserGroupOpportunity;
	}

	public void setExternalUserGroupOpportunity(List<ExternalUserGroupOpportunity> externalUserGroupOpportunity) {
		this.externalUserGroupOpportunity = externalUserGroupOpportunity;
	}

}
