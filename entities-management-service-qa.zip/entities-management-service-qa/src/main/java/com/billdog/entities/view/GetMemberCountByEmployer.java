package com.billdog.entities.view;

import java.util.List;

public class GetMemberCountByEmployer {

	private List<ViewMembersCount> viewMembersCountList;

	public List<ViewMembersCount> getViewMembersCountList() {
		return viewMembersCountList;
	}

	public void setViewMembersCountList(List<ViewMembersCount> viewMembersCountList) {
		this.viewMembersCountList = viewMembersCountList;
	}

}
