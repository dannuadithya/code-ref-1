package com.billdog.entities.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UpdateSubGroupOpportunity {

	private long subGroupOpportunityId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter sub group opportunity name")
	@Size(min = 2, max = 44, message = "sub group opportunity name must be 2 to 44 characters")
	private String subGroupopportunityName;

	@NotNull(message = "Please select Employer")
	private Long employerId;
	private long count;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Size(max = 100, message = "sfdcId should not exceed 100 characters")
	private String sfdcId;
	@NotNull(message = "organizationId must not be null")
	private Long organizationId;

	public String getSubGroupopportunityName() {
		return subGroupopportunityName;
	}

	public void setSubGroupopportunityName(String subGroupopportunityName) {
		this.subGroupopportunityName = subGroupopportunityName;
	}

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public long getCount() {
		return count;
	}

	public void setCount(long count) {
		this.count = count;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public long getSubGroupOpportunityId() {
		return subGroupOpportunityId;
	}

	public void setSubGroupOpportunityId(long subGroupOpportunityId) {
		this.subGroupOpportunityId = subGroupOpportunityId;
	}

}
