package com.billdog.entities.request;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class BlockConversionRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String conversionTo;
	private Long opportunityId;
	private Long userId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String opportunityName;

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getConversionTo() {
		return conversionTo;
	}

	public void setConversionTo(String conversionTo) {
		this.conversionTo = conversionTo;
	}

	public Long getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Long opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
