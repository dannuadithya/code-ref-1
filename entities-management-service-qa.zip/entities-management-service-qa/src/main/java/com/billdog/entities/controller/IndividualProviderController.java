package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.request.AddIndividualProviderRequest;
import com.billdog.entities.request.SearchIndividualProviderRequest;
import com.billdog.entities.request.UpdateIndividualProviderRequest;
import com.billdog.entities.service.IndividualProviderService;
import com.billdog.entities.view.MemberInfoResponse;
import com.billdog.entities.view.UpdateIndividualProviderResponse;
import com.billdog.entities.view.ViewIndividualProvider;
import com.billdog.entities.view.ViewMemberResponse;
import com.billdog.entities.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class IndividualProviderController {

	@Autowired
	IndividualProviderService individualProviderService;

	@Autowired
	IndividualBrokerController brokerController;

	@Autowired
	EmployerController employerController;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(IndividualProviderController.class);

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/addIndividualProvider", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addIndividualProviderDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody AddIndividualProviderRequest addIndividualProviderRequest) {
		employerController.isTokenValid(httpRequest, addIndividualProviderRequest.getUserId(), null);
		return individualProviderService.addIndividualProvider(addIndividualProviderRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/individualProvider", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchIndividualProviderDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody SearchIndividualProviderRequest individualProviderRequest) {
		employerController.isTokenValid(httpRequest, individualProviderRequest.getUserId(), null);
		MemberInfoResponse infoResponse = brokerController.getMemberInfo(httpRequest);
		return ResponseEntity.status(HttpStatus.OK).body(individualProviderService
				.searchIndividualProvider(individualProviderRequest, infoResponse.getOrganizationId()));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/individualProvider", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<UpdateIndividualProviderResponse> updateIndividualProviderDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody UpdateIndividualProviderRequest request) {
		employerController.isTokenValid(httpRequest, request.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK).body(individualProviderService.updateIndividualProvider(request));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Individual provider details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "company provider not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getIndividualProvider", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewIndividualProvider> getIndividualProviderDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long individualProviderId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return individualProviderService.getIndividualProvider(individualProviderId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Individual provider details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "company provider not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/individual-provider-list", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getIndividualProviders(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam Long companyProviderId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return individualProviderService.getIndividualProviders(companyProviderId);
	}
}
