package com.billdog.entities.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.entities.entity.GroupOpportunities;
import com.billdog.entities.entity.OpportunitySubTypeMaster;

public interface GroupOpportunitiesRepository extends JpaRepository<GroupOpportunities, Long> {

	List<GroupOpportunities> findByOpportunityTypeMasterId(OpportunitySubTypeMaster opportunitySubTypeMaster);

}
