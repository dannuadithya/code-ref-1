package com.billdog.entities.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.BrokerCompany;
import com.billdog.entities.entity.IndividualBroker;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.InValidInputException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.BrokerCompanyRepository;
import com.billdog.entities.repository.IndividualBrokerRepository;
import com.billdog.entities.repository.OpportunityRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.request.AddIndividualBrokerRequest;
import com.billdog.entities.request.ExternalUserUpdateRequest;
import com.billdog.entities.request.SearchIndividualBrokerRequest;
import com.billdog.entities.request.UpdateIndividualBrokerRequest;
import com.billdog.entities.view.IndividualBrokerInfo;
import com.billdog.entities.view.UpdateExternalUserView;
import com.billdog.entities.view.UpdateIndividualBrokerResponse;
import com.billdog.entities.view.ViewIndividualBroker;
import com.billdog.entities.view.ViewIndividualBrokerInfo;
import com.billdog.entities.view.ViewResponse;

@Service
public class IndividualBrokerService {
	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(IndividualBrokerService.class);

	@Autowired
	IndividualBrokerRepository individualBrokerRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	BrokerCompanyRepository brokerCompanyRepository;

	@Autowired
	UserService userService;

	@Autowired
	IndividualProviderService individualProviderService;

	@Autowired
	BrokerCompanyService brokerCompanyService;

	@Autowired
	OpportunityRepository opportunityRepository;

	public ViewResponse addIndividualBroker(AddIndividualBrokerRequest addIndividualBrokerRequest, String token) {
		LOGGER.info("addIndividualBroker method started..!");

		checkAddIndividualBrokerRequest(addIndividualBrokerRequest);

		Optional<Organization> organization = organizationRepository
				.findById(addIndividualBrokerRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		BrokerCompany brokerCompany = null;

		if (addIndividualBrokerRequest.getBrokerCompanyId() != null
				&& addIndividualBrokerRequest.getBrokerCompanyId() > 0) {
			Optional<BrokerCompany> brokerCompanyOptional = brokerCompanyRepository
					.findById(addIndividualBrokerRequest.getBrokerCompanyId());
			if (!brokerCompanyOptional.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NOT_FOUND);
			}
			brokerCompany = brokerCompanyOptional.get();
		}
		if (addIndividualBrokerRequest.getSfdcId() != null && !addIndividualBrokerRequest.getSfdcId().isEmpty()) {
			if (addIndividualBrokerRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<IndividualBroker> individualBroker = individualBrokerRepository
					.findBySfdcId(addIndividualBrokerRequest.getSfdcId());
			if (individualBroker.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		if (addIndividualBrokerRequest.getAddress() != null && !addIndividualBrokerRequest.getAddress().isEmpty()
				&& addIndividualBrokerRequest.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}

		saveIndividualBroker(addIndividualBrokerRequest, organization.get(), brokerCompany);

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.INDIVIDUAL_BROKER_ADDED);
		LOGGER.info("addIndividualBroker method has ended..!");
		return viewResponse;

	}

	private void checkAddIndividualBrokerRequest(AddIndividualBrokerRequest addIndividualBrokerRequest) {
		LOGGER.info("checkAddIndividualBrokerRequest method started..!");
		LOGGER.info("Checking contact number");
		if (StringUtils.isBlank(addIndividualBrokerRequest.getFirstName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME_SIZE);
		}
		if (StringUtils.isBlank(addIndividualBrokerRequest.getLastName())) {
			throw new BadRequestException(ExceptionalMessages.LAST_NAME_SIZE);
		}
		if (addIndividualBrokerRequest.getContactNumber() != null
				&& !addIndividualBrokerRequest.getContactNumber().isEmpty()
				&& !StringUtils.isNumeric(addIndividualBrokerRequest.getContactNumber())) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (addIndividualBrokerRequest.getContactNumber() != null
				&& !addIndividualBrokerRequest.getContactNumber().isEmpty()
				&& (addIndividualBrokerRequest.getContactNumber().length() <= 9
						|| addIndividualBrokerRequest.getContactNumber().length() > 10)) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
		}
		LOGGER.info("Contact number is valid");
		LOGGER.info("Checking email is valid or not");
		if (addIndividualBrokerRequest.getEmail() != null && !addIndividualBrokerRequest.getEmail().isEmpty()) {

			Optional<IndividualBroker> individualBroker = individualBrokerRepository
					.findByEmail(addIndividualBrokerRequest.getEmail());
			if (individualBroker.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
			}
			Optional<BrokerCompany> brokerCompanyEmail = brokerCompanyRepository
					.findByEmail(addIndividualBrokerRequest.getEmail());
			if (brokerCompanyEmail.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_EXISTS_AS_BROKER_COMPANY);
			}
		}
		LOGGER.info("Email is valid");
		LOGGER.info("checkAddIndividualBrokerRequest method ended..!");
	}

	private void saveIndividualBroker(AddIndividualBrokerRequest addIndividualBrokerRequest, Organization organization,
			BrokerCompany brokerCompany) {
		LOGGER.debug("creating new object in individual provider table.!!");
		IndividualBroker individualBroker = new IndividualBroker();
		individualBroker.setCreatedAt(DateAndTimeUtil.now());
		individualBroker.setUpdatedAt(DateAndTimeUtil.now());
		individualBroker.setFirstName(WordUtils.capitalizeFully(addIndividualBrokerRequest.getFirstName()));
		individualBroker.setLastName(WordUtils.capitalizeFully(addIndividualBrokerRequest.getLastName()));
		individualBroker.setEmail(addIndividualBrokerRequest.getEmail());
		individualBroker.setContactNumber(addIndividualBrokerRequest.getContactNumber());
		individualBroker.setAddress(addIndividualBrokerRequest.getAddress());
		if (addIndividualBrokerRequest.getSfdcId() != null && !addIndividualBrokerRequest.getSfdcId().isEmpty()) {
			individualBroker.setSfdcId(addIndividualBrokerRequest.getSfdcId());
			individualBroker.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		individualBroker.setOrganizationId(organization);
		individualBroker.setStatus(StatusConstants.ACTIVE);
		if (brokerCompany != null) {
			individualBroker.setBrokerCompany(brokerCompany);
		} else {
			individualBroker.setIndependent(true);
		}
		if (addIndividualBrokerRequest.getCountryCodeId() > 0) {
			individualProviderService.checkCountryCode(addIndividualBrokerRequest.getCountryCodeId(),
					organization.getId());
			individualBroker.setCountryCodeId(addIndividualBrokerRequest.getCountryCodeId());
		}
		individualBroker.setUserId(addIndividualBrokerRequest.getUserId());
		/*
		 * GetRoleList getRoles =
		 * brokerCompanyService.getRole(addIndividualBrokerRequest.getUserId(), token);
		 * if (getRoles != null) { getRoles.getData().forEach(role -> { if
		 * (role.getName().equalsIgnoreCase("External Operator")) {
		 * individualBroker.setRoleId(role.getRoleId()); } }); }
		 */
		individualBrokerRepository.save(individualBroker);
	}

	public ViewResponse searchIndividualBroker(SearchIndividualBrokerRequest request, long orgId) {
		LOGGER.info("searchIndividualBroker method started..!");
		BrokerCompany brokerCompany = null;
		String name = null;
		String contactNo = null;
		String email = null;
		String sfdcId = null;
		String status = null;
		LOGGER.info("Fetching company provider with id:: {}", request.getBrokerCompanyId());
		if (request.getBrokerCompanyId() != null && request.getBrokerCompanyId() > 0) {
			Optional<BrokerCompany> brokerCompanyOptional = brokerCompanyRepository
					.findById(request.getBrokerCompanyId());
			if (!brokerCompanyOptional.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NOT_FOUND);
			}
			brokerCompany = brokerCompanyOptional.get();
		}

		if (request.getBrokerName() != null && !request.getBrokerName().equals("")) {
			name = "%" + request.getBrokerName() + "%";
		}

		if (request.getContactNo() != null && !request.getContactNo().equals("")) {
			contactNo = "%" + request.getContactNo() + "%";
		} else {
			contactNo = request.getContactNo();
		}

		if (request.getEmailId() != null && !request.getEmailId().equals("")) {
			email = "%" + request.getEmailId() + "%";
		} else {
			email = request.getEmailId();
		}

		if (request.getSfdcId() != null && !request.getSfdcId().equals("")) {
			sfdcId = "%" + request.getSfdcId() + "%";
		} else {
			sfdcId = request.getSfdcId();
		}

		status = request.getStatus();

		Integer pageNumber = request.getPageNumber() > 0 ? request.getPageNumber() : 0;
		Integer pageLimit = request.getPageLimit() > 0 ? request.getPageLimit() : 20;
		// native query for searching company provider and assigning parameters
		// respectively

		Page<Object[][]> individualBrokersList = null;
		if (!request.isIndependent()) {
			individualBrokersList = individualBrokerRepository.getAllIndividualBrokers(name, name, name, name,
					brokerCompany, brokerCompany, email, email, contactNo, contactNo, sfdcId, sfdcId, status, status,
					orgId, getPageRequest(pageNumber, pageLimit));
		} else {
			individualBrokersList = individualBrokerRepository.getIndividualBrokers(name, name, name, name, email,
					email, contactNo, contactNo, sfdcId, sfdcId, status, status, orgId, request.isIndependent(),
					getPageRequest(pageNumber, pageLimit));
		}

		LOGGER.info("Fetching all individual brokers match with input request");

		List<IndividualBrokerInfo> individualBrokerInfoList = new ArrayList<>();
		if (individualBrokersList != null) {
			individualBrokerInfoList = getIndividualBrokerInfoList(individualBrokersList);
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.INDIVIDUAL_BROKER_LIST_FETCHED);
		if (individualBrokerInfoList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(individualBrokerInfoList);
		response.setTotal(individualBrokersList != null ? individualBrokersList.getTotalElements() : 0);
		LOGGER.info("searchIndividualBroker method ended..!");
		return response;
	}

	private List<IndividualBrokerInfo> getIndividualBrokerInfoList(Page<Object[][]> individualBrokersList) {
		List<IndividualBrokerInfo> individualBrokerInfoList = new ArrayList<>();
		for (Object[] broker : individualBrokersList) {
			IndividualBrokerInfo individualBrokerInfo = new IndividualBrokerInfo();
			String brokerName = null;

			if (((String) broker[0]) != null) {
				individualBrokerInfo.setFirstName(((String) broker[0]));
				brokerName = (String) broker[0];
			}
			if (broker[1] != null) {
				individualBrokerInfo.setLastName(((String) broker[1]));
				brokerName = brokerName != null ? brokerName + " " + (String) broker[1] : (String) broker[1];
			}
			individualBrokerInfo.setBrokerName(brokerName);
			if (broker[7] != null) {
				individualBrokerInfo.setBrokerCompanyId(((BigInteger) broker[7]).longValue());
			}
			if (broker[2] != null) {
				individualBrokerInfo.setBrokerCompanyAffiliation(((String) broker[2]));
			} else {
				individualBrokerInfo.setBrokerCompanyAffiliation(Constants.INDEPENDENT);
			}

			if ((String) broker[4] == null) {
				individualBrokerInfo.setContactNo("");
			} else {
				individualBrokerInfo.setContactNo(((String) broker[4]));
			}
			if ((String) broker[3] == null) {
				individualBrokerInfo.setEmailId("");
			} else {
				individualBrokerInfo.setEmailId(((String) broker[3]));
			}

			individualBrokerInfo.setIndividualBrokerId(((BigInteger) broker[8]).longValue());
			if ((String) broker[5] == null) {
				individualBrokerInfo.setSfdcId("");
			} else {
				individualBrokerInfo.setSfdcId(((String) broker[5]));
			}
			individualBrokerInfo.setStatus(((String) broker[6]));
			if ((BigInteger) broker[9] != null) {
				individualBrokerInfo.setCountryCodeId(((BigInteger) broker[9]).longValue());
			}
			individualBrokerInfo.setAddress((String) broker[10]);

			individualBrokerInfoList.add(individualBrokerInfo);

		}
		return individualBrokerInfoList;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public ViewIndividualBroker getIndividualBroker(Long individualBrokerId) {
		LOGGER.info("getIndividualBroker method started..!");

		// checking whether individual broker present or not with given id
		Optional<IndividualBroker> viewIndividualBrokerOptional = individualBrokerRepository
				.findById(individualBrokerId);
		if (!viewIndividualBrokerOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_BROKER_NOT_FOUND);
		}
		ViewIndividualBroker viewIndividualBroker = new ViewIndividualBroker();
		IndividualBroker individualProviderDetails = viewIndividualBrokerOptional.get();
		LOGGER.info("setting individual broker details to respective fields");
		viewIndividualBroker.setFirstName(individualProviderDetails.getFirstName());
		viewIndividualBroker.setIndividualBrokerId(individualBrokerId);
		viewIndividualBroker.setLastName(individualProviderDetails.getLastName());
		String brokerName = null;
		if (individualProviderDetails.getFirstName() != null) {
			brokerName = individualProviderDetails.getFirstName();
		}
		if (individualProviderDetails.getLastName() != null) {
			brokerName = brokerName != null ? brokerName + " " + individualProviderDetails.getLastName()
					: individualProviderDetails.getLastName();
		}
		viewIndividualBroker.setBrokerName(brokerName);
		viewIndividualBroker.setEmailId(individualProviderDetails.getEmail());
		viewIndividualBroker.setContactNumber(individualProviderDetails.getContactNumber());
		viewIndividualBroker.setCountryCodeId(individualProviderDetails.getCountryCodeId());
		if (individualProviderDetails.getSfdcId() != null) {
			viewIndividualBroker.setSfdcId(individualProviderDetails.getSfdcId());
		}
		viewIndividualBroker.setStatus(individualProviderDetails.getStatus());
		if (individualProviderDetails.getBrokerCompany() != null) {
			viewIndividualBroker.setBrokerCompanyId(individualProviderDetails.getBrokerCompany().getId());
			if (individualProviderDetails.getBrokerCompany().getBrokerCompanyName() != null) {
				viewIndividualBroker.setBrokerCompanyAffiliation(
						viewIndividualBrokerOptional.get().getBrokerCompany().getBrokerCompanyName());
			}
		}
		if (individualProviderDetails.isIndependent()) {
			viewIndividualBroker.setBrokerCompanyAffiliation(Constants.INDEPENDENT);
		}
		viewIndividualBroker.setAddress(individualProviderDetails.getAddress());

		LOGGER.info("getIndividualBroker method has ended..!");
		return viewIndividualBroker;
	}

	public UpdateIndividualBrokerResponse updateIndividualBroker(UpdateIndividualBrokerRequest request) {
		LOGGER.info("updateIndividualBroker method started..!");
		if (StringUtils.isBlank(request.getFirstName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME_SIZE);
		}
		if (StringUtils.isBlank(request.getLastName())) {
			throw new BadRequestException(ExceptionalMessages.LAST_NAME_SIZE);
		}
		if (request.getContactNumber() != null && !request.getContactNumber().isEmpty()
				&& !StringUtils.isNumeric(request.getContactNumber())) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (request.getContactNumber() != null && !request.getContactNumber().isEmpty()
				&& (request.getContactNumber().length() <= 9 || request.getContactNumber().length() > 10)) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
		}
		if (request.getEmail() != null && !request.getEmail().isEmpty() && !isValid(request.getEmail())) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
		}
		LOGGER.info("Checking email is valid or not");
		if (request.getEmail() != null && !request.getEmail().isEmpty()) {

			Optional<IndividualBroker> individualBroker = individualBrokerRepository.findByEmail(request.getEmail());
			if (individualBroker.isPresent() && individualBroker.get().getId() != request.getIndividualBrokerId()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
			}
			Optional<BrokerCompany> brokerCompanyEmail = brokerCompanyRepository.findByEmail(request.getEmail());
			if (brokerCompanyEmail.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_EXISTS_AS_BROKER_COMPANY);
			}
		}
		BrokerCompany brokerCompany = null;
		LOGGER.info("Email is valid");
		if (request.getBrokerCompanyId() != null && request.getBrokerCompanyId() > 0) {
			LOGGER.info("Fetching broker company info with id:: {}", request.getBrokerCompanyId());
			Optional<BrokerCompany> brokerCompanyOptional = brokerCompanyRepository
					.findById(request.getBrokerCompanyId());
			if (!brokerCompanyOptional.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NOT_FOUND);
			}
			brokerCompany = brokerCompanyOptional.get();
		}

		LOGGER.info("Fetching individual broker info with id:: {}", request.getIndividualBrokerId());
		Optional<IndividualBroker> individualBrokerOptional = individualBrokerRepository
				.findById(request.getIndividualBrokerId());
		if (!individualBrokerOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_BROKER_NOT_FOUND);
		}
		LOGGER.info("Checking sfdc id is already exists for any other record");
		if (request.getSfdcId() != null && !request.getSfdcId().isEmpty()) {
			if (individualBrokerOptional.get().getSfdcId() != null
					&& !individualBrokerOptional.get().getSfdcId().equals(request.getSfdcId())) {
				if (request.getSfdcId().length() > 100) {
					throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
				}
				Optional<IndividualBroker> individualBrokerProvider = individualBrokerRepository
						.findBySfdcId(request.getSfdcId());
				if (individualBrokerProvider.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
				}
			}
		}

		if (request.getAddress() != null && !request.getAddress().isEmpty() && request.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}

		individualBrokerOptional.get().setUpdatedAt(DateAndTimeUtil.now());
		individualBrokerOptional.get().setFirstName(WordUtils.capitalizeFully(request.getFirstName()));
		individualBrokerOptional.get().setLastName(WordUtils.capitalizeFully(request.getLastName()));
		if (request.getEmail() != null && individualBrokerOptional.get().getEmail() != null
				&& !individualBrokerOptional.get().getEmail().isEmpty()) {
			ExternalUserUpdateRequest externalUserUpdateRequest = new ExternalUserUpdateRequest();
			externalUserUpdateRequest.setNewEmail(request.getEmail());
			externalUserUpdateRequest.setOldEmail(individualBrokerOptional.get().getEmail());
			externalUserUpdateRequest.setType(Constants.EXTERNAL);
			externalUserUpdateRequest.setFirstName(WordUtils.capitalizeFully(request.getFirstName()));
			externalUserUpdateRequest.setLastName(WordUtils.capitalizeFully(request.getLastName()));
			externalUserUpdateRequest.setContactNumber(request.getContactNumber());
			externalUserUpdateRequest.setOrganizationId(individualBrokerOptional.get().getOrganizationId().getId());
			userService.updateExternalUserEmail(externalUserUpdateRequest);
		}
		individualBrokerOptional.get().setEmail(request.getEmail());
		individualBrokerOptional.get().setContactNumber(request.getContactNumber());
		individualBrokerOptional.get().setSfdcId(request.getSfdcId());
		if (request.getSfdcId() != null && !request.getSfdcId().isEmpty()) {
			individualBrokerOptional.get().setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		individualBrokerOptional.get().setStatus(request.getStatus());
		if (brokerCompany != null) {
			individualBrokerOptional.get().setBrokerCompany(brokerCompany);
			individualBrokerOptional.get().setIndependent(false);
		} else {
			individualBrokerOptional.get().setIndependent(true);
			individualBrokerOptional.get().setBrokerCompany(null);
		}
		if (request.getCountryCodeId() > 0
				&& request.getCountryCodeId() != individualBrokerOptional.get().getCountryCodeId()) {
			individualProviderService.checkCountryCode(request.getCountryCodeId(),
					individualBrokerOptional.get().getOrganizationId().getId());
			individualBrokerOptional.get().setCountryCodeId(request.getCountryCodeId());
		}
		individualBrokerOptional.get().setUserId(request.getUserId());
		individualBrokerOptional.get().setAddress(request.getAddress());
		LOGGER.info("updating individual broker info with id:: {}", request.getIndividualBrokerId());
		individualBrokerRepository.save(individualBrokerOptional.get());
		LOGGER.info("updated individual broker info with id:: {}", request.getIndividualBrokerId());
		UpdateIndividualBrokerResponse response = new UpdateIndividualBrokerResponse();
		response.setMessage(Constants.INDIVIDUAL_BROKER_UPDATED);
		response.setStatusText(Constants.SUCCESS);
		LOGGER.info("updateIndividualBroker method ended..!");
		return response;
	}

	private boolean isValid(String email) {
		String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		return email.matches(regex);
	}

	public ViewResponse getIndividualBrokersByBrokerCompany(Long brokerCompanyId, Long orgId, Boolean independent,
			boolean isOpportunity) {
		LOGGER.info("getIndividualBrokersByBrokerCompany method ended..!");

		List<IndividualBroker> individualBrokerList = new ArrayList<>();
		if (isOpportunity) {
			List<Long> individualBrokerIds = opportunityRepository.getIndividualBrokerIds(orgId);
			if (individualBrokerIds == null || individualBrokerIds.isEmpty()) {
				individualBrokerIds = new ArrayList<>();
				individualBrokerIds.add(0l);
			}
			if (independent != null && independent) {
				Optional<Organization> organization = organizationRepository.findById(orgId);
				if (!organization.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
				}
				individualBrokerList = individualBrokerRepository
						.findByOrganizationIdAndIndependentAndIdNotIn(organization.get(), true, individualBrokerIds);
			} else if (brokerCompanyId != null) {
				Optional<BrokerCompany> brokerCompanyOptional = brokerCompanyRepository.findById(brokerCompanyId);
				if (!brokerCompanyOptional.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NOT_FOUND);
				}
				individualBrokerList = individualBrokerRepository.findByBrokerCompanyAndOrganizationIdAndIdNotIn(
						brokerCompanyOptional.get(), brokerCompanyOptional.get().getOrganizationId(),
						individualBrokerIds);

			}
		} else {
			if (independent != null && independent) {
				Optional<Organization> organization = organizationRepository.findById(orgId);
				if (!organization.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
				}
				individualBrokerList = individualBrokerRepository.findByOrganizationIdAndIndependent(organization.get(),
						true);
			} else if (brokerCompanyId != null) {
				Optional<BrokerCompany> brokerCompanyOptional = brokerCompanyRepository.findById(brokerCompanyId);
				if (!brokerCompanyOptional.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.BROKER_COMPANY_NOT_FOUND);
				}
				individualBrokerList = individualBrokerRepository.findByBrokerCompanyAndOrganizationId(
						brokerCompanyOptional.get(), brokerCompanyOptional.get().getOrganizationId());

			}
		}

		List<ViewIndividualBrokerInfo> individualBrokerInfoList = new ArrayList<>();
		individualBrokerList.forEach(individualBroker -> {
			ViewIndividualBrokerInfo viewIndividualBrokerInfo = new ViewIndividualBrokerInfo();
			viewIndividualBrokerInfo.setIndividualBrokerId(individualBroker.getId());
			String name = "";
			if (!StringUtils.isBlank(individualBroker.getFirstName())) {
				name = name + individualBroker.getFirstName();
			}
			if (!StringUtils.isBlank(individualBroker.getLastName())) {
				name = name + " " + individualBroker.getLastName();
			}
			viewIndividualBrokerInfo.setIndividualBrokerName(name);
			individualBrokerInfoList.add(viewIndividualBrokerInfo);
		});
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.INDIVIDUAL_BROKER_LIST_FETCHED);
		if (individualBrokerInfoList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(individualBrokerInfoList);
		response.setTotal(individualBrokerInfoList.size());
		LOGGER.info("getIndividualBrokersByBrokerCompany method ended..!");
		return response;
	}

}
