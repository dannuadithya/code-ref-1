package com.billdog.entities.common;

public enum RecordsTime {

	ALL, LAST_WEEK, LAST_MONTH, LAST_3_MONTHS, LAST_6_MONTHS, LAST_YEAR, CUSTOM

}
