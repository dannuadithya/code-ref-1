package com.billdog.entities.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class SubGroupOpportunityRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter sub group opportunity name")
	@Size(min = 2, max = 44, message = "sub group opportunity name must be 2 to 44 characters")
	private String subGroupopportunityName;

	@NotNull(message = "Please select Employer")
	private Long employerId;
	@NotNull(message = "count must not be null")
	private Long totalcount;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter sfdcId")
	@Size(max = 100, message = "sfdcId should not exceed 100 characters")
	private String sfdcId;
	@NotNull(message = "organizationId must not be null")
	private Long organizationId;
	@NotNull(message = "userId must not be null")
	private Long userId;
	@NotNull(message = "Please provide Block Opportunity Id")
	private Long blockOpportunityId;

	public Long getBlockOpportunityId() {
		return blockOpportunityId;
	}

	public void setBlockOpportunityId(Long blockOpportunityId) {
		this.blockOpportunityId = blockOpportunityId;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getSubGroupopportunityName() {
		return subGroupopportunityName;
	}

	public void setSubGroupopportunityName(String subGroupopportunityName) {
		this.subGroupopportunityName = subGroupopportunityName;
	}

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public Long getTotalcount() {
		return totalcount;
	}

	public void setTotalcount(Long totalcount) {
		this.totalcount = totalcount;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

}
