package com.billdog.entities.common;

public enum OpportunityAuditModules {
	
	Block_Opportunity,Sub_Group_Opportunity,Broker_Sponsored,Employer_Direct,Opportunities

}
