package com.billdog.entities.view;

import java.util.List;

public class BlockOpportunityListView {

	private Long opportunityId;
	private String opportunityName;
	private String brokerage;
	private String brokerName;
	private String sfdcId;
	private long individualBrokerId;
	private long brokerCompanyId;
	private List<SubGroupOpportunityView> subGroupOpportunities;
	private long total;

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getBrokerage() {
		return brokerage;
	}

	public void setBrokerage(String brokerage) {
		this.brokerage = brokerage;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public List<SubGroupOpportunityView> getSubGroupOpportunities() {
		return subGroupOpportunities;
	}

	public void setSubGroupOpportunities(List<SubGroupOpportunityView> subGroupOpportunities) {
		this.subGroupOpportunities = subGroupOpportunities;
	}

	public long getIndividualBrokerId() {
		return individualBrokerId;
	}

	public void setIndividualBrokerId(long individualBrokerId) {
		this.individualBrokerId = individualBrokerId;
	}

	public long getBrokerCompanyId() {
		return brokerCompanyId;
	}

	public void setBrokerCompanyId(long brokerCompanyId) {
		this.brokerCompanyId = brokerCompanyId;
	}

	public Long getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Long opportunityId) {
		this.opportunityId = opportunityId;
	}

	public long getTotal() {
		return total;
	}

	public void setTotal(long total) {
		this.total = total;
	}


}
