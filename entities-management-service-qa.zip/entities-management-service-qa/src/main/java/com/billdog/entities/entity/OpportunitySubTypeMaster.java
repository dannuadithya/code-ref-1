package com.billdog.entities.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "OPPORTUNITY_SUB_TYPE_MASTER")
@Table(name = "opportunity_sub_type_master", indexes = { @Index(name = "id_index", columnList = "ID", unique = true) })
public class OpportunitySubTypeMaster extends BaseEntity {

	@Column(name = "opportunity_child_name")
	private String opportunityChildName;

	@Column(name = "STATUS")
	private String status;

	@ManyToOne
	@JoinColumn(name = "opportunity_type_master_Id")
	private OpportunityTypeMaster opportunityTypeMasterId;

	@JoinColumn(name = "organization_Id")
	private Long organizationId;

	@Column(name = "is_block_conversion")
	private boolean isBlockConversion;

	public boolean isBlockConversion() {
		return isBlockConversion;
	}

	public void setBlockConversion(boolean isBlockConversion) {
		this.isBlockConversion = isBlockConversion;
	}

	public String getOpportunityChildName() {
		return opportunityChildName;
	}

	public void setOpportunityChildName(String opportunityChildName) {
		this.opportunityChildName = opportunityChildName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public OpportunityTypeMaster getOpportunityTypeMasterId() {
		return opportunityTypeMasterId;
	}

	public void setOpportunityTypeMasterId(OpportunityTypeMaster opportunityTypeMasterId) {
		this.opportunityTypeMasterId = opportunityTypeMasterId;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

}
