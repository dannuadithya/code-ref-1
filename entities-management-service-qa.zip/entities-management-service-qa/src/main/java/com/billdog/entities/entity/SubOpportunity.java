package com.billdog.entities.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "sub_opportunity")
@Table(name = "sub_opportunity")
public class SubOpportunity extends BaseEntity {

	@Audited
	@Column(name = "sub_group_opportunity_name")
	private String subGroupOpportunityName;

	@Audited
	@Column(name = "status")
	private String status;

	@Audited
	@Column(name = "sfdc_id")
	private String sfdcId;

	@Audited
	@Column(name = "count")
	private Long count;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "opportunity_id")
	private Opportunity opportunityId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "employer_Id")
	private Employer employerId;

	@ManyToOne
	@JoinColumn(name = "organization_Id")
	private Organization organizationId;

	@Audited
	@Column(name = "USER_ID")
	private Long userId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "oppurtunity_sub_type_master_Id")
	private OpportunitySubTypeMaster opportunitySubTypeMasterId;

	@Audited
	@Column(name = "total_active_count")
	private Long totalActiveCount;

	public Long getTotalActiveCount() {
		return totalActiveCount;
	}

	public void setTotalActiveCount(Long totalActiveCount) {
		this.totalActiveCount = totalActiveCount;
	}

	public String getSubGroupOpportunityName() {
		return subGroupOpportunityName;
	}

	public void setSubGroupOpportunityName(String subGroupOpportunityName) {
		this.subGroupOpportunityName = subGroupOpportunityName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public Long getCount() {
		return count;
	}

	public void setCount(Long count) {
		this.count = count;
	}

	public Opportunity getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Opportunity opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Employer getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Employer employerId) {
		this.employerId = employerId;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public OpportunitySubTypeMaster getOpportunitySubTypeMasterId() {
		return opportunitySubTypeMasterId;
	}

	public void setOpportunitySubTypeMasterId(OpportunitySubTypeMaster opportunitySubTypeMasterId) {
		this.opportunitySubTypeMasterId = opportunitySubTypeMasterId;
	}

}
