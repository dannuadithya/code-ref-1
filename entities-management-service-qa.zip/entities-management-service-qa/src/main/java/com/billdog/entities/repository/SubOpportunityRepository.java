package com.billdog.entities.repository;

import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.billdog.entities.entity.Employer;
import com.billdog.entities.entity.Opportunity;
import com.billdog.entities.entity.OpportunitySubTypeMaster;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.entity.SubOpportunity;

@Repository
public interface SubOpportunityRepository extends JpaRepository<SubOpportunity, Long> {

	Optional<SubOpportunity> findBySubGroupOpportunityName(String subGroupopportunityName);

	Optional<SubOpportunity> findBySubGroupOpportunityNameAndOrganizationId(String subGroupopportunityName,
			Organization organizationId);

	List<SubOpportunity> findByOpportunityId(Opportunity opportunities);

	Optional<SubOpportunity> findByIdAndOpportunityId(long subGroupOpportunityId, Opportunity blockOpportunity);

	Optional<SubOpportunity> findBySubGroupOpportunityNameAndOrganizationIdAndOpportunitySubTypeMasterId(
			String subGroupopportunityName, Organization organizationId, OpportunitySubTypeMaster opportunityType);

	@Query(value = "select distinct(employer_Id) from sub_opportunity where organization_Id =?1", nativeQuery = true)
	List<Long> getEmployerIds(Organization organization);

	Optional<SubOpportunity> findByEmployerIdAndOpportunitySubTypeMasterId(Employer employer,
			OpportunitySubTypeMaster subTypeMaster);

	Optional<SubOpportunity> findBySfdcIdAndOpportunitySubTypeMasterId(String sfdcId,
			OpportunitySubTypeMaster subTypeMaster);

	Optional<SubOpportunity> findByEmployerId(Employer employer);

	Optional<SubOpportunity> findByIdAndStatus(Long employerDirectId, String active);

	Optional<SubOpportunity> findBySubGroupOpportunityNameAndOpportunitySubTypeMasterId(String opportunityName,
			OpportunitySubTypeMaster opportunityType);

	Optional<SubOpportunity> findBySubGroupOpportunityNameAndOpportunitySubTypeMasterIdAndOrganizationId(
			String opportunityName, OpportunitySubTypeMaster opportunitySubTypeMaster, Organization organizationId);

	Optional<SubOpportunity> findByIdAndOpportunitySubTypeMasterId(long employerDirectId,
			OpportunitySubTypeMaster opportunityType);

	List<SubOpportunity> findAllByOpportunitySubTypeMasterId(OpportunitySubTypeMaster opportunitySubTypeMaster);

	@Query(value = "SELECT sum(so.total_active_count) as totalActiveCount FROM sub_opportunity so where so.opportunity_id = ?1", nativeQuery = true)
	BigInteger getTotalActiveCount(Long blockOpportunityId);

	@Query(value = "SELECT sum(so.count) as totalCount  FROM sub_opportunity so where so.opportunity_id = ?1", nativeQuery = true)
	BigInteger getTotalCount(Long blockOpportunityId);

	List<SubOpportunity> findByOpportunityIdIn(List<Opportunity> opportunities);

	List<SubOpportunity> findByOpportunityIdOrderByCreatedAtDesc(Opportunity blockOpportunity);

	List<SubOpportunity> findByOpportunitySubTypeMasterId(OpportunitySubTypeMaster opportunitySubTypeMaster);

	@Query(value = "SELECT employer_id FROM sub_opportunity where opportunity_id = ?1", nativeQuery = true)
	List<Long> getEmployerCount(long l);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n" + "left join sub_opportunity sp on sp.id = sou.id\n"
			+ "join organization os on os.id = sp.organization_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN sou.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') \n"
			+ "and date(sou.updated_at) BETWEEN ?3 AND ?4 and sou.revtype in ?5 and otm.opportunity_child_name = 'Sub group opportunity' and sp.organization_id = ?6\n"
			+ "order by sou.updated_at desc", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join sub_opportunity sp on sp.id = sou.id\n"
					+ "join organization os on os.id = sp.organization_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id\n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN sou.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') \n"
					+ "and date(sou.updated_at) BETWEEN ?3 AND ?4 and sou.revtype in ?5 and otm.opportunity_child_name = 'Sub group opportunity' and sp.organization_id = ?6\n"
					+ "order by sou.updated_at desc", nativeQuery = true)
	Page<Object[]> getSubOpportunityAuditInfo(String name, String name2, String string, String endDate,
			List<Long> revtypes, long organizationId, PageRequest pageRequest);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
			+ "sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id\n"
			+ "where sou.id =?1 and sou.rev<?2 and otm.opportunity_child_name = 'Sub group opportunity' order by sou.rev desc limit 1", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
					+ "sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id\n"
					+ "where sou.id =?1 and sou.rev<?2 and otm.opportunity_child_name = 'Sub group opportunity' order by sou.rev desc limit 1", nativeQuery = true)
	List<Object[]> getSubOppAuditInfoByIdAndRev(long longValue, long longValue2);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
			+ "sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id where sou.id=?1 and otm.opportunity_child_name = 'Sub group opportunity' order by sou.rev desc", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
					+ "sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id where sou.id=?1 and otm.opportunity_child_name = 'Sub group opportunity' order by sou.rev desc", nativeQuery = true)
	Page<Object[]> getSubOppAuditInfoById(Long id, PageRequest pageRequest);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
			+ "sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n" + "left join sub_opportunity sp on sp.id = sou.id\n"
			+ "join organization os on os.id = sp.organization_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN sou.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') \n"
			+ "and date(sou.updated_at) BETWEEN ?3 AND ?4 and sou.revtype in ?5 and otm.opportunity_child_name = 'Broker sponsored'and sp.organization_id = ?6\n"
			+ "order by sou.updated_at desc, sou.rev desc ", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
					+ "sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join sub_opportunity sp on sp.id = sou.id\n"
					+ "join organization os on os.id = sp.organization_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id\n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN sou.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') \n"
					+ "and date(sou.updated_at) BETWEEN ?3 AND ?4 and sou.revtype in ?5 and otm.opportunity_child_name = 'Broker sponsored'and sp.organization_id = ?6\n"
					+ "order by sou.updated_at desc, sou.rev desc ", nativeQuery = true)
	Page<Object[]> getBrokerSponsoredAuditInfo(String name, String name2, String string, String endDate,
			List<Long> revtypes, long organizationId, PageRequest pageRequest);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
			+ "sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id\n"
			+ "where sou.id =?1 and sou.rev<?2 and otm.opportunity_child_name = 'Broker sponsored' order by sou.rev desc  limit 1", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
					+ "sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id\n"
					+ "where sou.id =?1 and sou.rev<?2 and otm.opportunity_child_name = 'Broker sponsored' order by sou.rev desc limit 1", nativeQuery = true)
	List<Object[]> getBrokerSponsoredAuditInfoByIdAndRev(long longValue, long longValue2);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
			+ "sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id where sou.id=?1 order by sou.rev desc", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
					+ "sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id where sou.id=?1 order by sou.rev desc", nativeQuery = true)
	Page<Object[]> getBrokerSponsoredAuditInfoById(Long id, PageRequest pageRequest);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n" + "left join sub_opportunity sp on sp.id = sou.id\n"
			+ "join organization os on os.id = sp.organization_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN sou.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') \n"
			+ "and date(sou.updated_at) BETWEEN ?3 AND ?4 and sou.revtype in ?5 and otm.opportunity_child_name = 'Employer Direct' and sp.organization_id = ?6\n"
			+ "order by sou.updated_at desc, sou.rev desc", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join sub_opportunity sp on sp.id = sou.id\n"
					+ "join organization os on os.id = sp.organization_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id\n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN sou.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') \n"
					+ "and date(sou.updated_at) BETWEEN ?3 AND ?4 and sou.revtype in ?5 and otm.opportunity_child_name = 'Employer Direct' and sp.organization_id = ?6\n"
					+ "order by sou.updated_at desc, sou.rev desc", nativeQuery = true)
	Page<Object[]> getEmployerDirectAuditInfo(String name, String name2, String string, String endDate,
			List<Long> revtypes, long organizationId, PageRequest pageRequest);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
			+ "sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id\n"
			+ "where sou.id =?1 and sou.rev<?2 and otm.opportunity_child_name = 'Employer Direct' order by sou.rev desc limit 1", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
					+ "sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id\n"
					+ "where sou.id =?1 and sou.rev<?2 and otm.opportunity_child_name = 'Employer Direct' order by sou.rev desc limit 1", nativeQuery = true)
	List<Object[]> getEmployerDirectAuditInfoByIdAndRev(long longValue, long longValue2);

	@Query(value = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
			+ "sou.status,sou.sub_group_opportunity_name,\n"
			+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
			+ "FROM billdog_entity.sub_opportunity_aud sou\n"
			+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
			+ "left join employer e on e.id = sou.employer_id\n"
			+ "left join opportunities o on o.id = sou.opportunity_id where sou.id=?1 order by sou.rev desc", countQuery = "select sou.id,sou.revtype,sou.updated_at,sou.user_id,sou.count,sou.sfdc_id,\n"
					+ "sou.status,sou.sub_group_opportunity_name,\n"
					+ "sou.employer_id,sou.opportunity_id,sou.total_active_count,sou.rev,e.employer_name,o.opportunity_name\n"
					+ "FROM billdog_entity.sub_opportunity_aud sou\n"
					+ "join opportunity_sub_type_master otm on otm.id = sou.oppurtunity_sub_type_master_Id\n"
					+ "left join employer e on e.id = sou.employer_id\n"
					+ "left join opportunities o on o.id = sou.opportunity_id where sou.id=?1 order by sou.rev desc", nativeQuery = true)
	Page<Object[]> getEmployerDirectAuditInfoById(Long id, PageRequest pageRequest);

	@Query("SELECT so FROM sub_opportunity so WHERE so.opportunityId=?1 ORDER BY so.createdAt DESC")
	Page<SubOpportunity> getSubOpportunities(Opportunity blockOpportunity,
			Pageable pageRequest);
}
