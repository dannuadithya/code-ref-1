package com.billdog.entities.view;

public class SubGroupOpportunityView {

	private String subGroupOpportunityName;
	private String employer;
	private long employerId;
	private long totalCount;
	private long activeCount;
	private Long subGroupOpportunityId;
	private String sfdcId;
	private String opportunityType;

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getSubGroupOpportunityName() {
		return subGroupOpportunityName;
	}

	public void setSubGroupOpportunityName(String subGroupOpportunityName) {
		this.subGroupOpportunityName = subGroupOpportunityName;
	}

	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(long employerId) {
		this.employerId = employerId;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

	public long getActiveCount() {
		return activeCount;
	}

	public void setActiveCount(long activeCount) {
		this.activeCount = activeCount;
	}

	public Long getSubGroupOpportunityId() {
		return subGroupOpportunityId;
	}

	public void setSubGroupOpportunityId(Long subGroupOpportunityId) {
		this.subGroupOpportunityId = subGroupOpportunityId;
	}

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

}
