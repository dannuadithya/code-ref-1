package com.billdog.entities.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.Employer;
import com.billdog.entities.entity.IndividualBroker;
import com.billdog.entities.entity.Opportunity;
import com.billdog.entities.entity.OpportunitySubTypeMaster;
import com.billdog.entities.entity.OpportunityTypeMaster;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.entity.SubOpportunity;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.RecordExistsException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.BrokerCompanyRepository;
import com.billdog.entities.repository.EmployerRepository;
import com.billdog.entities.repository.IndividualBrokerRepository;
import com.billdog.entities.repository.OpportunityRepository;
import com.billdog.entities.repository.OpportunitySubTypeMasterRepository;
import com.billdog.entities.repository.OpportunityTypeMasterRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.repository.SubOpportunityRepository;
import com.billdog.entities.request.AddBrokerSponsoredRequest;
import com.billdog.entities.request.AddEmployerDirectRequest;
import com.billdog.entities.request.BrokerSponsoredRequest;
import com.billdog.entities.request.EmployerDirectRequest;
import com.billdog.entities.request.ExternalUserBrokerSponsoredRequest;
import com.billdog.entities.request.MemberCountRequest;
import com.billdog.entities.request.UpdateBrokerSponsoredRequest;
import com.billdog.entities.request.UpdateEmployerDirectRequest;
import com.billdog.entities.view.GetCountryCodeInfo;
import com.billdog.entities.view.GetMemberCountByEmployer;
import com.billdog.entities.view.ViewBrokerSponsore;
import com.billdog.entities.view.ViewBrokerSponsored;
import com.billdog.entities.view.ViewEmployerDirect;
import com.billdog.entities.view.ViewMembersCount;
import com.billdog.entities.view.ViewResponse;

@Service
public class GroupOpportunityService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GroupOpportunityService.class);

	@Autowired
	OpportunityRepository opportunityRepository;

	@Autowired
	SubOpportunityRepository subOpportunityRepository;

	@Autowired
	EmployerRepository employerRepository;

	@Autowired
	BrokerCompanyRepository brokerCompanyRepository;

	@Autowired
	IndividualBrokerRepository brokerRepository;

	@Autowired
	OpportunitySubTypeMasterRepository opportunitySubTypeMasterRepository;
	@Autowired
	OpportunityTypeMasterRepository opportunityTypeMasterRepository;

	@Autowired
	UserService userService;

	@Autowired
	OrganizationRepository organizationRepository;

	public ResponseEntity<ViewResponse> searchBrokerSponsored(BrokerSponsoredRequest brokerSponsoredRequest) {
		LOGGER.info("searchBrokerSponsore method started..!");

		String opportunityName = null;
		String brokerage = null;
		String brokerName = null;
		String employer = null;
		String sfdcOpportunityId = null;
		if (brokerSponsoredRequest.getOpportunityName() != null
				&& !brokerSponsoredRequest.getOpportunityName().equals("")) {
			opportunityName = "%" + brokerSponsoredRequest.getOpportunityName() + "%";
		} else {
			opportunityName = brokerSponsoredRequest.getOpportunityName();
		}

		if (brokerSponsoredRequest.getBrokerage() != null && !brokerSponsoredRequest.getBrokerage().equals("")) {
			brokerage = "%" + brokerSponsoredRequest.getBrokerage() + "%";
		} else {
			brokerage = brokerSponsoredRequest.getBrokerage();
		}

		if (brokerSponsoredRequest.getBrokerName() != null && !brokerSponsoredRequest.getBrokerName().equals("")) {
			brokerName = "%" + brokerSponsoredRequest.getBrokerName() + "%";
		} else {
			brokerName = brokerSponsoredRequest.getBrokerName();
		}

		if (brokerSponsoredRequest.getSfdcOpportunityId() != null
				&& !brokerSponsoredRequest.getSfdcOpportunityId().equals("")) {
			sfdcOpportunityId = "%" + brokerSponsoredRequest.getSfdcOpportunityId() + "%";
		} else {
			sfdcOpportunityId = brokerSponsoredRequest.getSfdcOpportunityId();
		}
		if (brokerSponsoredRequest.getEmployer() != null && !brokerSponsoredRequest.getEmployer().equals("")) {
			employer = "%" + brokerSponsoredRequest.getEmployer() + "%";
		} else {
			employer = brokerSponsoredRequest.getEmployer();
		}

		Integer pageNumber = brokerSponsoredRequest.getPageNumber() > 0 ? brokerSponsoredRequest.getPageNumber() : 0;
		Integer pageLimit = brokerSponsoredRequest.getPageLimit() > 0 ? brokerSponsoredRequest.getPageLimit() : 20;
		// native query for searching broker sponsore and assigning parameters
		// respectively
		Page<Object[][]> brokerSponsore = opportunityRepository.getBrokerSponsore(opportunityName, opportunityName,
				brokerage, brokerage, brokerName, brokerName, brokerName, brokerName, employer, employer,
				sfdcOpportunityId, sfdcOpportunityId, getPageRequest(pageNumber, pageLimit));

		// loop for broker sponsore searched with native query and assigning
		// values
		// respectively

		List<ViewBrokerSponsore> viewBrokerSponsoreList = getBrokerSponsoreList(brokerSponsore);
		LOGGER.debug("Setting broker sponsore details for new broker sponsore object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.BROKER_SPONSORE);
		if (viewBrokerSponsoreList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewBrokerSponsoreList);
		response.setTotal(brokerSponsore.getTotalElements());

		LOGGER.info("searchBrokerSponsore method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewBrokerSponsore> getBrokerSponsoreList(Page<Object[][]> brokerSponsore) {
		GetMemberCountByEmployer memberCountByEmployer = getMemberCountByEmployer(brokerSponsore);
		List<ViewBrokerSponsore> viewBrokerSponsoreList = new ArrayList<>();
		for (Object[] objects : brokerSponsore) {
			ViewBrokerSponsore viewBrokerSponsore = new ViewBrokerSponsore();
			viewBrokerSponsore.setOpportunityName(((String) objects[0]));
			viewBrokerSponsore.setTotalCount((BigInteger) objects[1]);
			ViewMembersCount memberActiveCount = getMemberActiveCount(((BigInteger) objects[8]).longValue(),
					memberCountByEmployer.getViewMembersCountList());
			if (memberActiveCount == null) {
				viewBrokerSponsore.setTotalActiveCount(0l);
			} else {
				viewBrokerSponsore.setTotalActiveCount(memberActiveCount.getCount());
			}
			viewBrokerSponsore.setEmployer((String) objects[3]);
			viewBrokerSponsore.setBrokerage(((String) objects[4]));
			viewBrokerSponsore.setBrokerName((String) objects[5]);
			viewBrokerSponsore.setBrokerSponsoredId((BigInteger) objects[6]);
			viewBrokerSponsore.setSfdcId((String) objects[7]);
			viewBrokerSponsore.setOpportunityType(Constants.BROKER_SPONSORED);
			viewBrokerSponsore.setEmployerId((BigInteger) objects[8]);
			viewBrokerSponsore.setBrokerageId((BigInteger) objects[9]);
			viewBrokerSponsore.setBrokerId((BigInteger) objects[10]);
			viewBrokerSponsoreList.add(viewBrokerSponsore);
		}
		return viewBrokerSponsoreList;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	private GetMemberCountByEmployer getMemberCountByEmployer(Page<Object[][]> brokerSponsore) {
		List<Long> employersIds = new ArrayList<>();
		for (Object[] objects : brokerSponsore) {
			employersIds.add(((BigInteger) objects[8]).longValue());
		}
		MemberCountRequest memberCountRequest = new MemberCountRequest();
		memberCountRequest.setEmployerIds(employersIds);
		return userService.getMemberCountByEmployerId(memberCountRequest);
	}

	private ViewMembersCount getMemberActiveCount(Long employerId, List<ViewMembersCount> list) {
		return list.stream().filter(employer -> employer.getEmployerId().equals(employerId)).findFirst().orElse(null);
	}

	public ResponseEntity<ViewBrokerSponsored> getBrokerSponsoredDetails(Long brokerSponsoredId) {
		LOGGER.info("getBrokerSponsoredDetails method started..!");

		// checking whether broker sponsored Opportunity with given id present or not
		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository.findById(brokerSponsoredId);
		if (!subOpportunityOptional.isPresent() || !subOpportunityOptional.get().getOpportunitySubTypeMasterId()
				.getOpportunityChildName().equalsIgnoreCase(Constants.BROKER_SPONSORED)) {
			throw new RecordNotFoundException(ExceptionalMessages.BROKER_SPONSORED_NOT_FOUND);
		}
		SubOpportunity brokerSponsoredDetails = subOpportunityOptional.get();
		LOGGER.info("setting broker sponsored opportunity details to respective fields");
		ViewBrokerSponsored viewBrokerSponsored = new ViewBrokerSponsored();
		viewBrokerSponsored.setOpportunityName(brokerSponsoredDetails.getSubGroupOpportunityName());

		if (brokerSponsoredDetails.getOpportunityId() != null) {
			if (brokerSponsoredDetails.getOpportunityId().getBrokerCompanyId() != null) {
				viewBrokerSponsored.setBrokerage(
						brokerSponsoredDetails.getOpportunityId().getBrokerCompanyId().getBrokerCompanyName());
			}
			if (brokerSponsoredDetails.getOpportunityId().getIndividualBrokerId() != null) {
				viewBrokerSponsored.setBrokerName(
						brokerSponsoredDetails.getOpportunityId().getIndividualBrokerId().getFirstName() + " "
								+ brokerSponsoredDetails.getOpportunityId().getIndividualBrokerId().getLastName());
			}
		}
		viewBrokerSponsored.setSfdcId(brokerSponsoredDetails.getSfdcId());
		Optional<Employer> employerOptional = employerRepository
				.findById(brokerSponsoredDetails.getEmployerId().getId());
		if (employerOptional.isPresent()) {
			viewBrokerSponsored.setEmployer(employerOptional.get().getEmployerName());
			viewBrokerSponsored.setEmployerId(employerOptional.get().getId());
		}
		List<Long> employerIds = new ArrayList<>();
		if (employerOptional.isPresent()) {
			employerIds.add(employerOptional.get().getId());
		}

		MemberCountRequest memberCountRequest = new MemberCountRequest();
		memberCountRequest.setEmployerIds(employerIds);
		GetMemberCountByEmployer memberCountByEmployerId = userService.getMemberCountByEmployerId(memberCountRequest);
		if (memberCountByEmployerId != null) {
			memberCountByEmployerId.getViewMembersCountList().forEach(count -> {
				viewBrokerSponsored.setTotalActiveCount(count.getCount());
			});
		}
		viewBrokerSponsored.setTotalCount(brokerSponsoredDetails.getCount());
		viewBrokerSponsored.setOpportunityType(Constants.BROKER_SPONSORED);
		viewBrokerSponsored.setBrokerSponsoredId(brokerSponsoredId);
		LOGGER.info("getBrokerSponsoredDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewBrokerSponsored);
	}

	public ViewResponse createBrokerSponsored(AddBrokerSponsoredRequest request, Long orgId) {
		LOGGER.info("createBrokerSponsored method has started..!");
		if (StringUtils.isBlank(request.getOpportunityName())) {
			throw new BadRequestException(ExceptionalMessages.OPPORTUNITY_NAME_SIZE);
		}
		Optional<Opportunity> opportunityEntity = opportunityRepository
				.findByOpportunityNameAndOrganizationId(request.getOpportunityName(), orgId);
		if (opportunityEntity.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<Organization> organization = organizationRepository.findById(orgId);
		if (!organization.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(request.getOpportunityName(), organization.get());
		if (subOpportunityOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		LOGGER.info("Fetching employer with id {}", request.getEmployerId());
		Optional<Employer> employer = employerRepository.findById(request.getEmployerId());
		if (!employer.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
		}
		LOGGER.info("Fetched employer with id {}", request.getEmployerId());
		LOGGER.info("Fetching opportunity type master with type {} and organization id {}", Constants.BROKER_SPONSORED,
				orgId);
		OpportunitySubTypeMaster opportunityType = opportunitySubTypeMasterRepository
				.findByOpportunityChildNameAndOrganizationId(Constants.BROKER_SPONSORED, orgId);
		LOGGER.info("Fetched opportunity type master with type {} and organization id {}", Constants.BROKER_SPONSORED,
				orgId);
		LOGGER.info("Cheking employer is mapped to other opportunity");
		Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
		if (subOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
		}
		Optional<OpportunityTypeMaster> opportunityTypeOptional = opportunityTypeMasterRepository
				.findByOpportunityParentNameAndOrganizationId(Constants.GROUP, orgId);

		LOGGER.info("Cheking sub opportunity name has created already");
		Optional<SubOpportunity> blockOptional = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationIdAndOpportunitySubTypeMasterId(
						request.getOpportunityName(), employer.get().getOrganizationId(), opportunityType);
		if (blockOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.SUB_GROUP_OPPORTUNITY_EXISTS);
		}
		LOGGER.info("Cheking sfdc id is valid or not");
		if (!StringUtils.isBlank(request.getSfdcId())) {
			if (request.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<SubOpportunity> opportunity = subOpportunityRepository
					.findBySfdcIdAndOpportunitySubTypeMasterId(request.getSfdcId(), opportunityType);
			if (opportunity.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		LOGGER.info("Fetching individual broker info with id {}", request.getIndividualBrokerId());
		Optional<IndividualBroker> individualBroker = brokerRepository.findById(request.getIndividualBrokerId());
		if (!individualBroker.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_BROKER_NOT_FOUND);
		}
		LOGGER.info("Fetched individual broker info with id {}", request.getIndividualBrokerId());

		/*
		 * Optional<Opportunity> individualBrokerOpportunity = opportunityRepository
		 * .findByIndividualBrokerIdAndOrganizationId(individualBroker.get(), orgId); if
		 * (individualBrokerOpportunity.isPresent()) { throw new
		 * RecordExistsException(ExceptionalMessages.
		 * INDIVIDUAL_BROKER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY); }
		 */
		Opportunity opportunity = new Opportunity();
		opportunity.setCreatedAt(DateAndTimeUtil.now());
		opportunity.setUpdatedAt(DateAndTimeUtil.now());
		opportunity.setOrganizationId(orgId);
		opportunity.setIndividualBrokerId(individualBroker.get());
		if (opportunityTypeOptional.isPresent()) {
			opportunity.setOpportunityTypeMasterId(opportunityTypeOptional.get());
		}
		opportunity.setUserId(request.getUserId());
		opportunity.setStatus(StatusConstants.ACTIVE);
		if (individualBroker.get().getBrokerCompany() != null) {
			opportunity.setBrokerCompanyId(individualBroker.get().getBrokerCompany());
		}
		opportunityRepository.save(opportunity);
		SubOpportunity subOpportunity = new SubOpportunity();
		subOpportunity.setCreatedAt(DateAndTimeUtil.now());
		subOpportunity.setEmployerId(employer.get());
		subOpportunity.setOpportunityId(opportunity);
		subOpportunity.setOpportunitySubTypeMasterId(opportunityType);
		subOpportunity.setOrganizationId(employer.get().getOrganizationId());
		subOpportunity.setSfdcId(request.getSfdcId());
		subOpportunity.setStatus(StatusConstants.ACTIVE);
		subOpportunity.setSubGroupOpportunityName(request.getOpportunityName());
		subOpportunity.setCount(request.getTotalCount());
		subOpportunity.setUpdatedAt(DateAndTimeUtil.now());
		subOpportunity.setUserId(request.getUserId());
		subOpportunityRepository.save(subOpportunity);

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setId(subOpportunity.getId());
		response.setMessage(Constants.BROKER_SPONSORED_CREATED);
		LOGGER.info("createBrokerSponsored method has ended..!");
		return response;

	}

	public ViewResponse updateBrokerSponsored(UpdateBrokerSponsoredRequest request, Long orgId) {
		LOGGER.info("updateBrokerSponsored method has started..!");
		if (StringUtils.isBlank(request.getOpportunityName())) {
			throw new BadRequestException(ExceptionalMessages.OPPORTUNITY_NAME_SIZE);
		}
		Optional<Opportunity> opportunityEntity = opportunityRepository
				.findByOpportunityNameAndOrganizationId(request.getOpportunityName(), orgId);
		if (opportunityEntity.isPresent() && opportunityEntity.get().getId() != request.getBrokerSponsoredId()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<Organization> organization = organizationRepository.findById(orgId);
		if (!organization.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(request.getOpportunityName(), organization.get());
		if (subOpportunityOptional.isPresent()
				&& subOpportunityOptional.get().getId() != request.getBrokerSponsoredId()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		LOGGER.info("Fetching opportunity info with id {}", request.getBrokerSponsoredId());
		Optional<SubOpportunity> opportunityOptional = subOpportunityRepository
				.findById(request.getBrokerSponsoredId());
		if (!opportunityOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.BROKER_SPONSORED_NOT_FOUND);
		}
		LOGGER.info("Fetched opportunity info with id {}", request.getBrokerSponsoredId());
		SubOpportunity subOpportunity = opportunityOptional.get();
		if (request.getEmployerId() != subOpportunity.getEmployerId().getId()) {
			Optional<Employer> employer = employerRepository.findById(request.getEmployerId());
			if (!employer.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
			}
			Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
			if (subOptional.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
			}
			subOpportunity.setEmployerId(employer.get());
		}
		LOGGER.info("Fetching opportunity type master with type {} and organization id {}", Constants.BROKER_SPONSORED,
				orgId);
		OpportunitySubTypeMaster opportunityType = opportunitySubTypeMasterRepository
				.findByOpportunityChildNameAndOrganizationId(Constants.BROKER_SPONSORED, orgId);
		LOGGER.info("Fetched opportunity type master with type {} and organization id {}", Constants.BROKER_SPONSORED,
				orgId);

		Optional<OpportunityTypeMaster> opportunityTypeOptional = opportunityTypeMasterRepository
				.findByOpportunityParentNameAndOrganizationId(Constants.GROUP, orgId);

		LOGGER.info("Cheking sub opportunity name has created already");
		Optional<SubOpportunity> blockOptional = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationIdAndOpportunitySubTypeMasterId(
						request.getOpportunityName(), subOpportunity.getOrganizationId(), opportunityType);
		if (blockOptional.isPresent() && blockOptional.get().getId() != request.getBrokerSponsoredId()) {
			throw new RecordExistsException(ExceptionalMessages.SUB_GROUP_OPPORTUNITY_EXISTS);
		}
		LOGGER.info("Cheking sfdc id is valid or not");
		if (!StringUtils.isBlank(request.getSfdcId())
				&& !request.getSfdcId().equalsIgnoreCase(subOpportunity.getSfdcId())) {
			if (request.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<SubOpportunity> opportunity = subOpportunityRepository
					.findBySfdcIdAndOpportunitySubTypeMasterId(request.getSfdcId(), opportunityType);
			if (opportunity.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		if (request.getIndividualBrokerId() != subOpportunity.getOpportunityId().getIndividualBrokerId().getId()) {
			LOGGER.info("Fetching individual broker info with id {}", request.getIndividualBrokerId());
			Optional<IndividualBroker> individualBrokerOptional = brokerRepository
					.findById(request.getIndividualBrokerId());
			if (!individualBrokerOptional.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_BROKER_NOT_FOUND);
			}

			LOGGER.info("Fetched individual broker info with id {}", request.getIndividualBrokerId());
			/*
			 * Optional<Opportunity> individualBrokerOpportunity = opportunityRepository
			 * .findByIndividualBrokerIdAndOrganizationId(individualBrokerOptional.get(),
			 * orgId); if (individualBrokerOpportunity.isPresent()) { throw new
			 * RecordExistsException(
			 * ExceptionalMessages.INDIVIDUAL_BROKER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY); }
			 */

			subOpportunity.getOpportunityId().setUpdatedAt(DateAndTimeUtil.now());
			subOpportunity.getOpportunityId().setOrganizationId(orgId);
			subOpportunity.getOpportunityId().setIndividualBrokerId(individualBrokerOptional.get());
			if (opportunityTypeOptional.isPresent()) {
				subOpportunity.getOpportunityId().setOpportunityTypeMasterId(opportunityTypeOptional.get());
			}
			if (individualBrokerOptional.get().getBrokerCompany() != null) {
				subOpportunity.getOpportunityId().setBrokerCompanyId(individualBrokerOptional.get().getBrokerCompany());
			}
			subOpportunity.getOpportunityId().setUserId(request.getUserId());
			opportunityRepository.save(subOpportunity.getOpportunityId());
		}

		subOpportunity.setSfdcId(request.getSfdcId());
		subOpportunity.setSubGroupOpportunityName(request.getOpportunityName());
		subOpportunity.setCount(request.getTotalCount());
		subOpportunity.setUpdatedAt(DateAndTimeUtil.now());
		subOpportunity.setUserId(request.getUserId());
		subOpportunityRepository.save(subOpportunity);

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setId(subOpportunity.getId());
		response.setMessage(Constants.BROKER_SPONSORED_UPDATED);
		LOGGER.info("updateBrokerSponsored method has ended..!");
		return response;
	}

	public ResponseEntity<ViewResponse> searchEmployerDirect(EmployerDirectRequest employerDirectRequest) {
		LOGGER.info("searchEmployerDirect method started..!");

		String opportunityName = null;
		String contactNumber = null;
		String emailId = null;
		String employer = null;
		String sfdcId = null;
		String status = employerDirectRequest.getStatus();
		if (employerDirectRequest.getOpportunityName() != null
				&& !employerDirectRequest.getOpportunityName().equals("")) {
			opportunityName = "%" + employerDirectRequest.getOpportunityName() + "%";
		} else {
			opportunityName = employerDirectRequest.getOpportunityName();
		}

		if (employerDirectRequest.getContactNumber() != null && !employerDirectRequest.getContactNumber().equals("")) {
			contactNumber = "%" + employerDirectRequest.getContactNumber() + "%";
		} else {
			contactNumber = employerDirectRequest.getContactNumber();
		}

		if (employerDirectRequest.getEmailId() != null && !employerDirectRequest.getEmailId().equals("")) {
			emailId = "%" + employerDirectRequest.getEmailId() + "%";
		} else {
			emailId = employerDirectRequest.getEmailId();
		}

		if (employerDirectRequest.getSfdcId() != null && !employerDirectRequest.getSfdcId().equals("")) {
			sfdcId = "%" + employerDirectRequest.getSfdcId() + "%";
		} else {
			sfdcId = employerDirectRequest.getSfdcId();
		}
		if (employerDirectRequest.getEmployer() != null && !employerDirectRequest.getEmployer().equals("")) {
			employer = "%" + employerDirectRequest.getEmployer() + "%";
		} else {
			employer = employerDirectRequest.getEmployer();
		}

		Integer pageNumber = employerDirectRequest.getPageNumber() > 0 ? employerDirectRequest.getPageNumber() : 0;
		Integer pageLimit = employerDirectRequest.getPageLimit() > 0 ? employerDirectRequest.getPageLimit() : 20;
		// native query for searching employer direct and assigning parameters
		// respectively
		Page<Object[][]> employerDirect = opportunityRepository.getEmployerDirect(opportunityName, opportunityName,
				contactNumber, contactNumber, emailId, emailId, employer, employer, sfdcId, sfdcId, status, status,
				getPageRequest(pageNumber, pageLimit));

		// loop for employer direct searched with native query and assigning
		// values
		// respectively

		List<ViewEmployerDirect> viewEmployerDirectList = getEmployerDirectList(employerDirect);
		LOGGER.debug("Setting employer direct details for new employer direct object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.EMPLOYER_DIRECT_FECTED);
		if (viewEmployerDirectList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewEmployerDirectList);
		response.setTotal(employerDirect.getTotalElements());
		LOGGER.info("searchEmployerDirect method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewEmployerDirect> getEmployerDirectList(Page<Object[][]> employerDirect) {
		List<ViewEmployerDirect> viewEmployerDirectList = new ArrayList<>();
		for (Object[] objects : employerDirect) {
			ViewEmployerDirect viewEmployerDirect = new ViewEmployerDirect();
			viewEmployerDirect.setOpportunityName(((String) objects[0]));
			viewEmployerDirect.setEmployer((String) objects[1]);
			viewEmployerDirect.setEmailId(((String) objects[2]));
			viewEmployerDirect.setContactNumber((String) objects[3]);
			viewEmployerDirect.setSfdcId((String) objects[4]);
			viewEmployerDirect.setStatus((String) objects[5]);
			viewEmployerDirect.setEmployerDirectId((BigInteger) objects[6]);
			viewEmployerDirect.setEmployerId(((BigInteger) objects[7]).longValue());
			viewEmployerDirect.setOpportunityType(Constants.EMPLOYER_DIRECT);
			viewEmployerDirect.setTotalCount(((BigInteger) objects[8]).longValue());
			BigInteger countryCodeId = ((BigInteger) objects[9]);
			if (countryCodeId != null) {
				viewEmployerDirect.setCountryCodeId(countryCodeId.longValue());
			}
			viewEmployerDirectList.add(viewEmployerDirect);
		}
		return viewEmployerDirectList;
	}

	public ResponseEntity<ViewEmployerDirect> getEmployerDirectDetails(Long employerDirectId) {
		LOGGER.info("getEmployerDirectDetails method started..!");

		// checking whether employer direct with given id present or not
		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository.findById(employerDirectId);
		if (!subOpportunityOptional.isPresent() || !subOpportunityOptional.get().getOpportunitySubTypeMasterId()
				.getOpportunityChildName().equalsIgnoreCase(Constants.EMPLOYER_DIRECT)) {
			throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_DIRECT_NOT_FOUND);
		}
		SubOpportunity employerDirectDetails = subOpportunityOptional.get();
		LOGGER.info("setting employer direct opportunity details to respective fields");
		ViewEmployerDirect viewEmployerDirect = new ViewEmployerDirect();
		viewEmployerDirect.setOpportunityName(employerDirectDetails.getSubGroupOpportunityName());
		Optional<Employer> employerOptional = employerRepository
				.findById(employerDirectDetails.getEmployerId().getId());
		if (employerOptional.isPresent()) {
			viewEmployerDirect.setEmployerId(employerOptional.get().getId());
			viewEmployerDirect.setEmployer(employerOptional.get().getEmployerName());
			viewEmployerDirect.setContactNumber(employerOptional.get().getContactNumber());
			viewEmployerDirect.setEmailId(employerOptional.get().getEmail());
			viewEmployerDirect.setCountryCodeId(employerOptional.get().getCountryCodeId());
		}
		viewEmployerDirect.setSfdcId(employerDirectDetails.getSfdcId());
		viewEmployerDirect.setStatus(employerDirectDetails.getStatus());

		if (employerDirectDetails.getCount() == null) {
			viewEmployerDirect.setTotalCount(0);
		} else {
			viewEmployerDirect.setTotalCount(employerDirectDetails.getCount());
		}

		if (employerDirectDetails.getCount() == null) {
			viewEmployerDirect.setTotalCount(employerDirectDetails.getCount());
		}
		List<Long> employerIds = new ArrayList<>();
		if (employerOptional.isPresent()) {
			employerIds.add(employerOptional.get().getId());
		}
		MemberCountRequest memberCountRequest = new MemberCountRequest();
		memberCountRequest.setEmployerIds(employerIds);
		GetMemberCountByEmployer memberCountByEmployerId = userService.getMemberCountByEmployerId(memberCountRequest);
		if (memberCountByEmployerId != null) {
			memberCountByEmployerId.getViewMembersCountList().forEach(count -> {
				viewEmployerDirect.setActiveCount(count.getCount());
			});
		}
		viewEmployerDirect.setOpportunityType(Constants.EMPLOYER_DIRECT);
		Long employerId = employerDirectDetails.getId();
		viewEmployerDirect.setEmployerDirectId(BigInteger.valueOf(employerId));
		LOGGER.info("getEmployerDirectDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewEmployerDirect);
	}

	public ViewResponse addEmployerDirect(AddEmployerDirectRequest addEmployerDirectRequest, Long organizationId) {
		LOGGER.info("addEmployerDirect method started..!");
		if (StringUtils.isBlank(addEmployerDirectRequest.getOpportunityName())) {
			throw new BadRequestException(ExceptionalMessages.OPPORTUNITY_NAME_SIZE);
		}
		Optional<Opportunity> opportunityEntity = opportunityRepository
				.findByOpportunityNameAndOrganizationId(addEmployerDirectRequest.getOpportunityName(), organizationId);
		if (opportunityEntity.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<Organization> organization = organizationRepository.findById(organizationId);
		if (!organization.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<SubOpportunity> subOpportunityName = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(addEmployerDirectRequest.getOpportunityName(),
						organization.get());
		if (subOpportunityName.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<Employer> employer = employerRepository.findById(addEmployerDirectRequest.getEmployerId());
		if (!employer.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
		}
		if (!StringUtils.isBlank(addEmployerDirectRequest.getEmailId())
				&& !addEmployerDirectRequest.getEmailId().equalsIgnoreCase(employer.get().getEmail())) {
			Optional<Employer> employerEmail = employerRepository.findByEmail(addEmployerDirectRequest.getEmailId());
			if (employerEmail.isPresent() && addEmployerDirectRequest.getEmployerId() != employerEmail.get().getId()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
			}
		}
		OpportunitySubTypeMaster opportunityType = opportunitySubTypeMasterRepository
				.findByOpportunityChildNameAndOrganizationId(Constants.EMPLOYER_DIRECT, organizationId);
		LOGGER.info("Fetched opportunity type master with type {} and organization id {}", Constants.BROKER_SPONSORED,
				organizationId);
		LOGGER.info("Cheking employer is mapped to other opportunity");
		Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
		if (subOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
		}

		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOpportunitySubTypeMasterIdAndOrganizationId(
						addEmployerDirectRequest.getOpportunityName(), opportunityType,
						employer.get().getOrganizationId());
		if (subOpportunityOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMPLOYER_DIRECT_NAME);
		}

		SubOpportunity employerDirect = saveEmployerDirect(addEmployerDirectRequest, employer.get(), opportunityType);

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.EMPLOYER_DIRECT_CREATED);
		viewResponse.setId(employerDirect.getId());
		LOGGER.info("addEmployerDirect method has ended..!");
		return viewResponse;

	}

	private SubOpportunity saveEmployerDirect(AddEmployerDirectRequest addEmployerDirectRequest, Employer employer,
			OpportunitySubTypeMaster opportunityType) {
		LOGGER.debug("creating new object in sub opportunity table.!!");
		SubOpportunity subOpportunity = new SubOpportunity();
		subOpportunity.setCreatedAt(DateAndTimeUtil.now());
		subOpportunity.setUpdatedAt(DateAndTimeUtil.now());
		subOpportunity.setCount(addEmployerDirectRequest.getTotalCount());
		subOpportunity.setEmployerId(employer);
		subOpportunity.setOpportunitySubTypeMasterId(opportunityType);
		subOpportunity.setOrganizationId(employer.getOrganizationId());
		subOpportunity.setSfdcId(addEmployerDirectRequest.getSfdcId());
		subOpportunity.setStatus(StatusConstants.ACTIVE);
		subOpportunity.setSubGroupOpportunityName(addEmployerDirectRequest.getOpportunityName());
		subOpportunity.setUserId(employer.getUserId());

		subOpportunityRepository.save(subOpportunity);

		if ((!StringUtils.isBlank(addEmployerDirectRequest.getContactNumber())
				&& !addEmployerDirectRequest.getContactNumber().equalsIgnoreCase(employer.getContactNumber()))
				|| (!StringUtils.isBlank(addEmployerDirectRequest.getEmailId())
						&& !addEmployerDirectRequest.getEmailId().equalsIgnoreCase(employer.getEmail()))) {
			employer.setContactNumber(addEmployerDirectRequest.getContactNumber());
			employer.setEmail(addEmployerDirectRequest.getEmailId());
			if (addEmployerDirectRequest.getCountryCodeId() > 0
					&& (!StringUtils.isBlank(addEmployerDirectRequest.getContactNumber()) && !addEmployerDirectRequest
							.getContactNumber().equalsIgnoreCase(employer.getContactNumber()))) {
				checkCountryCode(addEmployerDirectRequest.getCountryCodeId(), employer.getOrganizationId().getId());
				employer.setCountryCodeId(addEmployerDirectRequest.getCountryCodeId());
			}
			employerRepository.save(employer);
		}

		return subOpportunity;
	}

	public ViewResponse updateEmployerDirect(UpdateEmployerDirectRequest updateEmployerDirectRequest, Long orgId) {
		LOGGER.info("updateEmployerDirect method has started..!");
		if (StringUtils.isBlank(updateEmployerDirectRequest.getOpportunityName())) {
			throw new BadRequestException(ExceptionalMessages.OPPORTUNITY_NAME_SIZE);
		}
		Optional<Opportunity> opportunityEntity = opportunityRepository
				.findByOpportunityNameAndOrganizationId(updateEmployerDirectRequest.getOpportunityName(), orgId);
		if (opportunityEntity.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<Organization> organization = organizationRepository.findById(orgId);
		if (!organization.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<SubOpportunity> subOpportunityName = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(updateEmployerDirectRequest.getOpportunityName(),
						organization.get());
		if (subOpportunityName.isPresent()
				&& subOpportunityName.get().getId() != updateEmployerDirectRequest.getEmployerDirectId()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		OpportunitySubTypeMaster opportunityType = opportunitySubTypeMasterRepository
				.findByOpportunityChildNameAndOrganizationId(Constants.EMPLOYER_DIRECT, orgId);
		LOGGER.info("Fetched opportunity type master with type {} and organization id {}", Constants.EMPLOYER_DIRECT,
				orgId);
		LOGGER.info("Fetching opportunity info with id {}", updateEmployerDirectRequest.getEmployerDirectId());
		Optional<SubOpportunity> opportunityOptional = subOpportunityRepository.findByIdAndOpportunitySubTypeMasterId(
				updateEmployerDirectRequest.getEmployerDirectId(), opportunityType);
		if (!opportunityOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMPLOYER_DIRECT_NOT_FOUND);
		}
		SubOpportunity subOpportunity = opportunityOptional.get();
		if (opportunityOptional.get().getEmployerId().getId() != updateEmployerDirectRequest.getEmployerId()) {
			Optional<Employer> employer = employerRepository.findById(updateEmployerDirectRequest.getEmployerId());
			if (!employer.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
			}
			Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
			if (subOptional.isPresent()
					&& !updateEmployerDirectRequest.getEmployerDirectId().equals(subOptional.get().getId())) {
				throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
			}
			subOpportunity.setEmployerId(employer.get());
		}

		if (!StringUtils.isBlank(updateEmployerDirectRequest.getEmailId()) && !updateEmployerDirectRequest.getEmailId()
				.equalsIgnoreCase(subOpportunity.getEmployerId().getEmail())) {
			Optional<Employer> employerEmail = employerRepository.findByEmail(updateEmployerDirectRequest.getEmailId());
			if (employerEmail.isPresent()
					&& updateEmployerDirectRequest.getEmployerId() != employerEmail.get().getId()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
			}
		}

		LOGGER.info("Fetched opportunity info with id {}", updateEmployerDirectRequest.getEmployerDirectId());

		LOGGER.info("Fetching opportunity type master with type {} and organization id {}", Constants.EMPLOYER_DIRECT,
				orgId);
		LOGGER.info("Fetching opportunity type master with type {} and organization id {}", Constants.EMPLOYER_DIRECT,
				orgId);

		LOGGER.info("Cheking opportunity name has created already");
		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOpportunitySubTypeMasterIdAndOrganizationId(
						updateEmployerDirectRequest.getOpportunityName(),
						opportunityOptional.get().getOpportunitySubTypeMasterId(),
						opportunityOptional.get().getOrganizationId());
		if (subOpportunityOptional.isPresent() && !updateEmployerDirectRequest.getOpportunityName()
				.equals(subOpportunityOptional.get().getSubGroupOpportunityName())) {
			throw new RecordExistsException(ExceptionalMessages.EMPLOYER_DIRECT_NAME);
		}

		subOpportunity.setCount(updateEmployerDirectRequest.getTotalCount());
		subOpportunity.setSubGroupOpportunityName(updateEmployerDirectRequest.getOpportunityName());
		if (updateEmployerDirectRequest.getSfdcId() != null && !updateEmployerDirectRequest.getSfdcId().isEmpty()) {
			subOpportunity.setSfdcId(updateEmployerDirectRequest.getSfdcId());
		}

		subOpportunityRepository.save(subOpportunity);

		boolean updated = false;
		if ((StringUtils.isBlank(updateEmployerDirectRequest.getContactNumber())
				&& !StringUtils.isBlank(subOpportunity.getEmployerId().getContactNumber()))
				|| (!StringUtils.isBlank(updateEmployerDirectRequest.getContactNumber()) && !updateEmployerDirectRequest
						.getContactNumber().equalsIgnoreCase(subOpportunity.getEmployerId().getContactNumber()))) {
			updated = true;
			subOpportunity.getEmployerId().setContactNumber(updateEmployerDirectRequest.getContactNumber());
		}
		if (updateEmployerDirectRequest.getCountryCodeId() > 0 && updateEmployerDirectRequest
				.getCountryCodeId() != subOpportunity.getEmployerId().getCountryCodeId()) {
			checkCountryCode(updateEmployerDirectRequest.getCountryCodeId(),
					subOpportunity.getEmployerId().getOrganizationId().getId());
			updated = true;
			subOpportunity.getEmployerId().setCountryCodeId(updateEmployerDirectRequest.getCountryCodeId());
		}
		if ((StringUtils.isBlank(updateEmployerDirectRequest.getEmailId())
				&& !StringUtils.isBlank(subOpportunity.getEmployerId().getEmail()))
				|| (!StringUtils.isBlank(updateEmployerDirectRequest.getContactNumber()) && !updateEmployerDirectRequest
						.getEmailId().equalsIgnoreCase(subOpportunity.getEmployerId().getEmail()))) {
			updated = true;
			subOpportunity.getEmployerId().setEmail(updateEmployerDirectRequest.getEmailId());
		}

		if(updated) {
			employerRepository.save(subOpportunity.getEmployerId());
		}

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setId(subOpportunity.getId());
		response.setMessage(Constants.EMPLOYER_DIRECT_UPDATED);
		LOGGER.info("updateEmployerDirect method has ended..!");
		return response;
	}

	private GetCountryCodeInfo checkCountryCode(long countryCodeId, long orgId) {
		GetCountryCodeInfo getCountryCodeInfo = userService.getCountryCode(countryCodeId, orgId);
		if (getCountryCodeInfo == null || (!getCountryCodeInfo.getStatusText().equalsIgnoreCase(Constants.SUCCESS))) {
			throw new RecordNotFoundException(ExceptionalMessages.COUNTRY_CODE_NOT_FOUND);
		}
		return getCountryCodeInfo;
	}

	public ResponseEntity<ViewResponse> searchExternalBrokerSponsored(
			ExternalUserBrokerSponsoredRequest brokerSponsoredRequest) {
		LOGGER.info("searchExternalBrokerSponsored method started..!");

		String opportunityName = null;
		String brokerage = null;
		String brokerName = null;
		String employer = null;
		String sfdcOpportunityId = null;
		if (brokerSponsoredRequest.getOpportunityName() != null
				&& !brokerSponsoredRequest.getOpportunityName().equals("")) {
			opportunityName = "%" + brokerSponsoredRequest.getOpportunityName() + "%";
		} else {
			opportunityName = brokerSponsoredRequest.getOpportunityName();
		}

		if (brokerSponsoredRequest.getBrokerage() != null && !brokerSponsoredRequest.getBrokerage().equals("")) {
			brokerage = "%" + brokerSponsoredRequest.getBrokerage() + "%";
		} else {
			brokerage = brokerSponsoredRequest.getBrokerage();
		}

		if (brokerSponsoredRequest.getBrokerName() != null && !brokerSponsoredRequest.getBrokerName().equals("")) {
			brokerName = "%" + brokerSponsoredRequest.getBrokerName() + "%";
		} else {
			brokerName = brokerSponsoredRequest.getBrokerName();
		}

		if (brokerSponsoredRequest.getSfdcOpportunityId() != null
				&& !brokerSponsoredRequest.getSfdcOpportunityId().equals("")) {
			sfdcOpportunityId = "%" + brokerSponsoredRequest.getSfdcOpportunityId() + "%";
		} else {
			sfdcOpportunityId = brokerSponsoredRequest.getSfdcOpportunityId();
		}
		if (brokerSponsoredRequest.getEmployer() != null && !brokerSponsoredRequest.getEmployer().equals("")) {
			employer = "%" + brokerSponsoredRequest.getEmployer() + "%";
		} else {
			employer = brokerSponsoredRequest.getEmployer();
		}

		Integer pageNumber = brokerSponsoredRequest.getPageNumber() > 0 ? brokerSponsoredRequest.getPageNumber() : 0;
		Integer pageLimit = brokerSponsoredRequest.getPageLimit() > 0 ? brokerSponsoredRequest.getPageLimit() : 20;
		// native query for searching broker sponsore and assigning parameters
		// respectively
		Page<Object[][]> brokerSponsore = opportunityRepository.getExternalUserBrokerSponsore(opportunityName,
				opportunityName, brokerage, brokerage, brokerName, brokerName, brokerName, brokerName, employer,
				employer, sfdcOpportunityId, sfdcOpportunityId, brokerSponsoredRequest.getExternalUserEmail(),
				getPageRequest(pageNumber, pageLimit));

		// loop for broker sponsore searched with native query and assigning
		// values
		// respectively

		List<ViewBrokerSponsore> viewBrokerSponsoreList = getExternalBrokerSponsoreList(brokerSponsore);
		LOGGER.debug("Setting broker sponsore details for new broker sponsore object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.BROKER_SPONSORE);
		if (viewBrokerSponsoreList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewBrokerSponsoreList);
		response.setTotal(brokerSponsore.getTotalElements());

		LOGGER.info("searchBrokerSponsore method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewBrokerSponsore> getExternalBrokerSponsoreList(Page<Object[][]> brokerSponsore) {
		GetMemberCountByEmployer memberCountByEmployer = getMemberCountByEmployer(brokerSponsore);
		List<ViewBrokerSponsore> viewBrokerSponsoreList = new ArrayList<>();
		for (Object[] objects : brokerSponsore) {
			ViewBrokerSponsore viewBrokerSponsore = new ViewBrokerSponsore();
			viewBrokerSponsore.setOpportunityName(((String) objects[0]));
			viewBrokerSponsore.setTotalCount((BigInteger) objects[1]);
			ViewMembersCount memberActiveCount = getMemberActiveCount(((BigInteger) objects[8]).longValue(),
					memberCountByEmployer.getViewMembersCountList());
			if (memberActiveCount == null) {
				viewBrokerSponsore.setTotalActiveCount(0l);
			} else {
				viewBrokerSponsore.setTotalActiveCount(memberActiveCount.getCount());
			}
			viewBrokerSponsore.setEmployer((String) objects[3]);
			viewBrokerSponsore.setBrokerage(((String) objects[4]));
			viewBrokerSponsore.setBrokerName((String) objects[5]);
			viewBrokerSponsore.setBrokerSponsoredId((BigInteger) objects[6]);
			viewBrokerSponsore.setSfdcId((String) objects[7]);
			viewBrokerSponsore.setOpportunityType(Constants.BROKER_SPONSORED);
			viewBrokerSponsore.setEmployerId((BigInteger) objects[8]);
			viewBrokerSponsore.setBrokerageId((BigInteger) objects[9]);
			viewBrokerSponsore.setBrokerId((BigInteger) objects[10]);
			viewBrokerSponsoreList.add(viewBrokerSponsore);
		}
		return viewBrokerSponsoreList;
	}

}
