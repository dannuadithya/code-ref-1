package com.billdog.entities.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "INDIVIDUAL_PROVIDER")
@Table(name = "individual_provider")
public class IndividualProvider extends BaseEntity {

	@Audited
	@Column(name = "email")
	private String email;

	@Audited
	@Column(name = "first_name")
	private String firstName;

	@Audited
	@Column(name = "last_name")
	private String lastName;

	@Audited
	@Column(name = "contact_number")
	private String contactNumber;

	@Audited
	@Column(name = "status")
	private String status;

	@Audited
	@Column(name = "sfdc_id")
	private String sfdcId;

	@Column(name = "SFDC_UPDATED_TIME")
	private LocalDateTime sfdcUpdatedTime;


	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "company_provider_id")
	private CompanyProvider companyProviderId;

	@Column(name = "country_code_Id")
	private Long countryCodeId;

	@Audited
	@Column(name = "USER_ID")
	private Long userId;

	@Audited
	@Column(name = "address")
	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(Long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public LocalDateTime getSfdcUpdatedTime() {
		return sfdcUpdatedTime;
	}

	public void setSfdcUpdatedTime(LocalDateTime sfdcUpdatedTime) {
		this.sfdcUpdatedTime = sfdcUpdatedTime;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public CompanyProvider getCompanyProviderId() {
		return companyProviderId;
	}

	public void setCompanyProviderId(CompanyProvider companyProviderId) {
		this.companyProviderId = companyProviderId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
