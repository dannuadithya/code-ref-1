package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.common.Constants;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.exception.InvalidAuthTokenException;
import com.billdog.entities.request.EmployerServiceRequest;
import com.billdog.entities.request.SaveMemberCountRequest;
import com.billdog.entities.request.SearchEmployerRequest;
import com.billdog.entities.request.UpdateEmployerRequest;
import com.billdog.entities.service.BrokerCompanyService;
import com.billdog.entities.service.EmployerService;
import com.billdog.entities.view.GetEmployerInfo;
import com.billdog.entities.view.MemberInfoResponse;
import com.billdog.entities.view.ViewEmployers;
import com.billdog.entities.view.ViewMemberResponse;
import com.billdog.entities.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class EmployerController {

	@Autowired
	BrokerCompanyService brokerCompanyService;

	@Autowired
	EmployerService employerService;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(EmployerController.class);

	public void isTokenValid(HttpServletRequest httpRequest, Long requestUserId, Long requestmemberId) {
		requestUserId = requestUserId == null ? 0l : requestUserId;
		requestmemberId = requestmemberId == null ? 0l : requestmemberId;
		try {
			long userId = 0;
			String type = httpRequest.getAttribute("type").toString();
			if (type.equals("USER")) {
				userId = Long.parseLong(httpRequest.getAttribute(Constants.USER_ID).toString());
				LOGGER.info("Requested User Id :{}", userId);
				if (userId != requestUserId) {
					throw new InvalidAuthTokenException(ExceptionalMessages.USER_SESSION_EXPIRED);
				}
			} else if (type.equals("MEMBER")) {
				Long memberId = Long.parseLong(httpRequest.getAttribute(Constants.MEMBER_ID).toString());
				LOGGER.info("Requested Member Id : {}", memberId);
				LOGGER.info("Based on AccessToken {}", memberId);
				if (!memberId.equals(requestmemberId)) {
					throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
				}
			} else {
				throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
			}

		} catch (Exception e) {
			if (!StringUtils.isBlank(e.getMessage())
					&& e.getMessage().equalsIgnoreCase(ExceptionalMessages.USER_SESSION_EXPIRED)) {
				throw new InvalidAuthTokenException(ExceptionalMessages.USER_SESSION_EXPIRED);
			} else {
				throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
			}

		}
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "employer saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/addEmployer", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addEmployerDetails(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody EmployerServiceRequest employerServiceRequest) {
		isTokenValid(httpRequest, employerServiceRequest.getUserId(), null);
		return employerService.addEmployer(employerServiceRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Employer details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Employer not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getEmployer", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewEmployers> getEmployerDetails(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam Long employerId) {
		isTokenValid(httpRequest, userId, null);
		return employerService.getEmployerDetails(employerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "employer updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/editEmployer", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> editEmployerDetails(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody UpdateEmployerRequest updateEmployerRequest) {
		isTokenValid(httpRequest, updateEmployerRequest.getUserId(), null);
		return employerService.editEmployerDetails(updateEmployerRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Employer search results fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/search-employer", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchEmployer(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody SearchEmployerRequest employerRequest) {
		isTokenValid(httpRequest, employerRequest.getUserId(), null);
		MemberInfoResponse infoResponse = getMemberInfo(httpRequest);
		return ResponseEntity.status(HttpStatus.OK)
				.body(employerService.searchEmployer(employerRequest, infoResponse.getOrganizationId()));
	}

	public MemberInfoResponse getMemberInfo(HttpServletRequest httpRequest) {
		MemberInfoResponse memberInfoResponse = new MemberInfoResponse();
		if (httpRequest.getAttribute("organizationId") != null) {
			memberInfoResponse.setOrganizationId(Long.parseLong(httpRequest.getAttribute("organizationId").toString()));
		}
		return memberInfoResponse;
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "employers fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "employers not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllEmployers", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getAllEmployers(@RequestHeader HttpHeaders headers,
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId) {
		isTokenValid(httpRequest, userId, null);
		LOGGER.info("Request url:: {} ", headers.getOrigin());
		return employerService.getAllEmployers(getMemberInfo(httpRequest).getOrganizationId());
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "employers fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "employers not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/sub-opportunity-employers", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getEmployersForSubOpportunity(@RequestHeader HttpHeaders headers,
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId) {
		isTokenValid(httpRequest, userId, null);
		LOGGER.info("Request url:: {} ", headers.getOrigin());
		return employerService.getEmployersForSubOpportunity(getMemberInfo(httpRequest).getOrganizationId());
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "employer info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "employers not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/employer-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<GetEmployerInfo> getEmployerInfo(@RequestParam Long employerId) {
		return employerService.getEmployerInfo(employerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "employers fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "employers not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/opportunity-employers", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getEmployersForOpportunity(@RequestHeader HttpHeaders headers,
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam String opportunityName) {
		isTokenValid(httpRequest, userId, null);
		return employerService.getEmployer(userId, opportunityName);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Employer search results fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/saveMemberCount", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> saveMemberCount(@RequestBody SaveMemberCountRequest saveMemberCountRequest) {
		return employerService.saveMemberCount(saveMemberCountRequest);
	}
}
