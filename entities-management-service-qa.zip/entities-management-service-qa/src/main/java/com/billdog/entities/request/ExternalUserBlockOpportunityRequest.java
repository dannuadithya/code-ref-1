package com.billdog.entities.request;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class ExternalUserBlockOpportunityRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String opportunityName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String brokerage;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String brokerName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcOpportunityId;
	private long userId;
	private int pageNumber;
	private int pageLimit;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String externalUserEmail;

	public String getExternalUserEmail() {
		return externalUserEmail;
	}

	public void setExternalUserEmail(String externalUserEmail) {
		this.externalUserEmail = externalUserEmail;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getBrokerage() {
		return brokerage;
	}

	public void setBrokerage(String brokerage) {
		this.brokerage = brokerage;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public String getSfdcOpportunityId() {
		return sfdcOpportunityId;
	}

	public void setSfdcOpportunityId(String sfdcOpportunityId) {
		this.sfdcOpportunityId = sfdcOpportunityId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getPageLimit() {
		return pageLimit;
	}

	public void setPageLimit(int pageLimit) {
		this.pageLimit = pageLimit;
	}

}
