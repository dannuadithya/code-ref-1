package com.billdog.entities.view;

public class ExternalUserBlockOpportunity {

	private String blockOpportunityName;

	public String getBlockOpportunityName() {
		return blockOpportunityName;
	}

	public void setBlockOpportunityName(String blockOpportunityName) {
		this.blockOpportunityName = blockOpportunityName;
	}

}
