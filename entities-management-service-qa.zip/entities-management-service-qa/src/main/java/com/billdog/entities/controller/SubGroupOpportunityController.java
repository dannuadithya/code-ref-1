package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.request.EditSubGroupOpportunityRequest;
import com.billdog.entities.request.SubGroupOpportunityRequest;
import com.billdog.entities.service.SubGroupOpportunityService;
import com.billdog.entities.view.ViewMemberResponse;
import com.billdog.entities.view.ViewResponse;
import com.billdog.entities.view.ViewSubGroupDetails;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SubGroupOpportunityController {

	@Autowired
	SubGroupOpportunityService subGroupOpportunityService;

	@Autowired
	EmployerController employerController;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SubGroupOpportunityController.class);


	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Sub Group Opportunity added successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/addSubGroupOpportunity", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addSubGroupOpportunity(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody SubGroupOpportunityRequest subGroupOpportunityRequest) {
		employerController.isTokenValid(httpRequest, subGroupOpportunityRequest.getUserId(), null);
		return subGroupOpportunityService.addSubGroupOpportunity(subGroupOpportunityRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Sub Group Opportunity updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/EditSubGroupOpportunity", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> editSubGroupOpportunity(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest,
			@Valid @RequestBody EditSubGroupOpportunityRequest editSubGroupOpportunityRequest) {
		employerController.isTokenValid(httpRequest, editSubGroupOpportunityRequest.getUserId(), null);
		return subGroupOpportunityService.editSubGroupOpportunity(editSubGroupOpportunityRequest);
	}
	
	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "sub group opportunity details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "sub group opportunity not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getSubGroupOpportunity", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewSubGroupDetails> getSubGroupOpportunityDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long subGroupId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return subGroupOpportunityService.getSubGroupOpportunityDetails(subGroupId);
	}

}