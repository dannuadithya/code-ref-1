package com.billdog.entities.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.billdog.entities.entity.BrokerCompany;
import com.billdog.entities.entity.Organization;

public interface BrokerCompanyRepository extends JpaRepository<BrokerCompany, Long> {

	Optional<BrokerCompany> findBySfdcId(String sfdcId);

	Optional<BrokerCompany> findByBrokerCompanyName(String brokerCompanyName);

	Optional<BrokerCompany> findByEmail(String email);

	@Query(value = "SELECT bc.broker_company_name,bc.contact_name,bc.email,bc.contact_number,bc.sfdc_id,bc.status,bc.country_code_Id,bc.id,bc.address\n"
			+ "FROM billdog_entity.broker_company bc\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ "			CASE WHEN COALESCE(?3,'') <> '' THEN bc.contact_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
			+ "			CASE WHEN COALESCE(?5,'') <> '' THEN bc.contact_number ELSE '' END LIKE COALESCE(?6,'') AND \n"
			+ "			CASE WHEN COALESCE(?7,'') <> '' THEN bc.email ELSE '' END LIKE COALESCE(?8,'') AND \n"
			+ "			CASE WHEN COALESCE(?9,'') <> '' THEN bc.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND\n"
			+ "			CASE WHEN COALESCE(?11,'') <> '' THEN bc.status ELSE '' END LIKE COALESCE(?12,'')\n"
			+ "			order by bc.created_at desc", countQuery = "SELECT bc.broker_company_name,bc.contact_name,bc.email,bc.contact_number,bc.sfdc_id,bc.status,bc.country_code_Id,bc.id,bc.address \n"
					+ "FROM billdog_entity.broker_company bc\n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ "			CASE WHEN COALESCE(?3,'') <> '' THEN bc.contact_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
					+ "			CASE WHEN COALESCE(?5,'') <> '' THEN bc.contact_number ELSE '' END LIKE COALESCE(?6,'') AND \n"
					+ "			CASE WHEN COALESCE(?7,'') <> '' THEN bc.email ELSE '' END LIKE COALESCE(?8,'') AND \n"
					+ "			CASE WHEN COALESCE(?9,'') <> '' THEN bc.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND\n"
					+ "			CASE WHEN COALESCE(?11,'') <> '' THEN bc.status ELSE '' END LIKE COALESCE(?12,'')\n"
					+ "			order by bc.created_at desc", nativeQuery = true)
	Page<Object[][]> getBrokerCompanies(String brokerCompanyName, String brokerCompanyName2, String contactName,
			String contactName2, String contactNo, String contactNo2, String email, String email2, String sfdcId,
			String sfdcId2, String status, String status2, PageRequest pageRequest);

	List<BrokerCompany> findByOrganizationIdAndStatus(Organization organization, String active);

	@Query(value = "select  bca.id , bca.revType  ,bca.updated_at , bca.broker_company_name ,  bca.contact_number , bca.contact_name , \n"
			+ "       bca.email ,bca.sfdc_id , bca.status ,bca.user_id , bca.rev,bca.address   \n"
			+ "from broker_company_aud bca join broker_company bc on bc.id= bca.id\n"
			+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN bca.broker_company_name ELSE '' END LIKE COALESCE(?2,'')\n"
			+ "and date(bca.updated_at) BETWEEN ?3 AND ?4 and bca.revType in ?5 and bc.organization_id=?6\n"
			+ "order by bca.updated_at desc,bca.rev desc", countQuery = "select  bca.id , bca.revType  ,bca.updated_at , bca.broker_company_name ,  bca.contact_number , bca.contact_name , \n"
					+ "       bca.email ,bca.sfdc_id , bca.status ,bca.user_id , bca.rev,bca.address   \n"
					+ "from broker_company_aud bca join broker_company bc on bc.id= bca.id\n"
					+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN bca.broker_company_name ELSE '' END LIKE COALESCE(?2,'')\n"
					+ "and date(bca.updated_at) BETWEEN ?3 AND ?4 and bca.revType in ?5 and bc.organization_id=?6\n"
					+ "order by bca.updated_at desc,bca.rev desc", nativeQuery = true)
	Page<Object[]> getBrokerCompanyAuditInfo(String name, String name2, String string, String endDate,
			List<Long> revtypes, long orgId, PageRequest pageRequest);

	@Query(value = "select  id , revType  ,updated_at , broker_company_name ,  contact_number , contact_name ,\n"
			+ "       email ,sfdc_id , status ,user_id , rev,address   from broker_company_aud\n"
			+ "where id=?1 order by rev desc", countQuery = "select  id , revType  ,updated_at , broker_company_name ,  contact_number , contact_name ,\n"
					+ "       email ,sfdc_id , status ,user_id , rev,address   from broker_company_aud\n"
					+ "where  id=?1 order by rev desc", nativeQuery = true)
	Page<Object[]> getBrokerCompanyAuditInfoById(Long id, PageRequest pageRequest);

	@Query(value = "select  id , revType  ,updated_at , broker_company_name ,  contact_number , contact_name ,\n"
			+ "       email ,sfdc_id , status ,user_id , rev,address   from broker_company_aud\n"
			+ "where  id=?1 and rev<?2 order by rev desc limit 1", countQuery = "select  id , revType  ,updated_at , broker_company_name ,  contact_number , contact_name ,\n"
					+ "       email ,sfdc_id , status ,user_id , rev,address   from broker_company_aud\n"
					+ "where  id=?1 and rev<?2 order by rev desc limit 1", nativeQuery = true)
	List<Object[]> getBrokerCompanyAuditInfoByIdAndNav(long id, long nav);

}
