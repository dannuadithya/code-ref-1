package com.billdog.entities.view;

public class ViewInsuranceCompanyInfo {
	private long insuranceCompanyId;
	private String insuranceCompanyName;
	private String insuranceCompanyPhone;
	private String insuranceCompanyAddress;

	public long getInsuranceCompanyId() {
		return insuranceCompanyId;
	}

	public void setInsuranceCompanyId(long insuranceCompanyId) {
		this.insuranceCompanyId = insuranceCompanyId;
	}

	public String getInsuranceCompanyName() {
		return insuranceCompanyName;
	}

	public void setInsuranceCompanyName(String insuranceCompanyName) {
		this.insuranceCompanyName = insuranceCompanyName;
	}

	public String getInsuranceCompanyPhone() {
		return insuranceCompanyPhone;
	}

	public void setInsuranceCompanyPhone(String insuranceCompanyPhone) {
		this.insuranceCompanyPhone = insuranceCompanyPhone;
	}

	public String getInsuranceCompanyAddress() {
		return insuranceCompanyAddress;
	}

	public void setInsuranceCompanyAddress(String insuranceCompanyAddress) {
		this.insuranceCompanyAddress = insuranceCompanyAddress;
	}

}
