package com.billdog.entities.view;

public class ViewSubGroupDetails {

	private String subGroupOpportunityName;
	private String brokerage;
	private String broker;
	private String employer;
	private String sfdcId;
	private long activeCount;
	private long totalCount;
	private String opportunityType;
	private Long employerId;
	private Long subGroupOpportunityId;

	public String getSubGroupOpportunityName() {
		return subGroupOpportunityName;
	}

	public void setSubGroupOpportunityName(String subGroupOpportunityName) {
		this.subGroupOpportunityName = subGroupOpportunityName;
	}

	public String getBrokerage() {
		return brokerage;
	}

	public void setBrokerage(String brokerage) {
		this.brokerage = brokerage;
	}

	public String getBroker() {
		return broker;
	}

	public void setBroker(String broker) {
		this.broker = broker;
	}

	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public Long getActiveCount() {
		return activeCount;
	}

	public void setActiveCount(Long activeCount) {
		this.activeCount = activeCount;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public Long getSubGroupOpportunityId() {
		return subGroupOpportunityId;
	}

	public void setSubGroupOpportunityId(Long subGroupOpportunityId) {
		this.subGroupOpportunityId = subGroupOpportunityId;
	}

}
