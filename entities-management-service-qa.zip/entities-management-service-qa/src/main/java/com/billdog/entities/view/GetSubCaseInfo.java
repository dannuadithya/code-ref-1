package com.billdog.entities.view;

import java.util.List;

public class GetSubCaseInfo {

	private String message;
	private String status;
	private List<ViewInsuranceCompanyInfo> insuranceCompanies;
	private List<ViewCompanyProviderInfo> companyProviders;
	private List<ViewIndividualProviderInfo> individualProviders;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<ViewInsuranceCompanyInfo> getInsuranceCompanies() {
		return insuranceCompanies;
	}

	public void setInsuranceCompanies(List<ViewInsuranceCompanyInfo> insuranceCompanies) {
		this.insuranceCompanies = insuranceCompanies;
	}

	public List<ViewCompanyProviderInfo> getCompanyProviders() {
		return companyProviders;
	}

	public void setCompanyProviders(List<ViewCompanyProviderInfo> companyProviders) {
		this.companyProviders = companyProviders;
	}

	public List<ViewIndividualProviderInfo> getIndividualProviders() {
		return individualProviders;
	}

	public void setIndividualProviders(List<ViewIndividualProviderInfo> individualProviders) {
		this.individualProviders = individualProviders;
	}


}
