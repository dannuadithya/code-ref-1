package com.billdog.entities.view;

public class  UpdateIndividualBrokerResponse {

	private String statusText;
	private String message;

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
