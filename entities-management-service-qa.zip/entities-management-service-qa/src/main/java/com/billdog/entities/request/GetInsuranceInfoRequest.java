package com.billdog.entities.request;

public class GetInsuranceInfoRequest {

	private long insuranceCompanyId;
	private long companyProviderId;
	private long individulProviderId;

	public long getInsuranceCompanyId() {
		return insuranceCompanyId;
	}

	public void setInsuranceCompanyId(long insuranceCompanyId) {
		this.insuranceCompanyId = insuranceCompanyId;
	}

	public long getCompanyProviderId() {
		return companyProviderId;
	}

	public void setCompanyProviderId(long companyProviderId) {
		this.companyProviderId = companyProviderId;
	}

	public long getIndividulProviderId() {
		return individulProviderId;
	}

	public void setIndividulProviderId(long individulProviderId) {
		this.individulProviderId = individulProviderId;
	}

	
	
}
