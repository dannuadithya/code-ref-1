package com.billdog.entities.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class AddEmployerDirectRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter opportunity name")
	@Size(min = 4, max = 44, message = "Opportunity name must be 4 to 44 characters")
	private String opportunityName;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter sfdcId")
	@Size(max = 100, message = "SfdcId cannot exceed 100 characters")
	private String sfdcId;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter contact Number")
	@Size(min = 10, max = 10, message = "contact Number must be 10 digits")
	@Pattern(regexp = "^(0|[1-9][0-9]*)$", message = "Invalid contact number")
	private String contactNumber;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Email(message = "Invalid email format")
	private String emailId;

	@NotNull(message = "User id must not be null")
	private Long userId;

	@NotNull(message = "Please select Employer")
	private Long employerId;

	@NotNull(message = "Please enter total count")
	private long totalCount;

	private Long countryCodeId;

	public Long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(Long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

}
