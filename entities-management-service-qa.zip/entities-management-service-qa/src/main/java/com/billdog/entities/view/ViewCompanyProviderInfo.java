package com.billdog.entities.view;

public class ViewCompanyProviderInfo {
	private long companyProviderId;
	private String companyProviderName;
	private String companyProviderPhone;
	private String companyProviderAddress;

	public long getCompanyProviderId() {
		return companyProviderId;
	}

	public void setCompanyProviderId(long companyProviderId) {
		this.companyProviderId = companyProviderId;
	}

	public String getCompanyProviderName() {
		return companyProviderName;
	}

	public void setCompanyProviderName(String companyProviderName) {
		this.companyProviderName = companyProviderName;
	}

	public String getCompanyProviderPhone() {
		return companyProviderPhone;
	}

	public void setCompanyProviderPhone(String companyProviderPhone) {
		this.companyProviderPhone = companyProviderPhone;
	}

	public String getCompanyProviderAddress() {
		return companyProviderAddress;
	}

	public void setCompanyProviderAddress(String companyProviderAddress) {
		this.companyProviderAddress = companyProviderAddress;
	}

}
