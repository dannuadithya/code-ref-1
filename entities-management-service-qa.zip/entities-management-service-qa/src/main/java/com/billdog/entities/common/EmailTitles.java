package com.billdog.entities.common;

public enum EmailTitles {

	CREATE_CASE, UPDATE_CASE

}
