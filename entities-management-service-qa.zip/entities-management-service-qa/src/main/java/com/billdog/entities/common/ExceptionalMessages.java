package com.billdog.entities.common;

public class ExceptionalMessages {

	public static final String ORGANIZATION_NOT_FOUND = "Something went wrong. Please try again";
	public static final String INSURANCE_COMPANY_EXIST = "Insurance company with this name already exists";
	public static final String CONTACT_NUMBER = "Contact number should be numbers";
	public static final String INSURANCE_COMPANY_NAME = "Insurance company name should be 2 Characters Minimum, 55 Characters maximum";
	public static final String CONTACT_NUMBER_RESTRICTION = "Invalid contact number";
	public static final String SFDC_VALIDATION = "SFDC ID cannot exceed 100 characters";
	public static final String CONTACT_NUMBER_NAME = "Contact person name should be 2 Characters Minimum, 40 Characters maximum";
	public static final String VERIFY_MEMBER_TOKEN = "Verify member token api not found";
	public static final String VERIFY_USER_TOKEN = "Verify user token api not found";
	public static final String VERIFY_TOKEN_ISSUE = "Facing technical issue while verifying token";
	public static final String VERIFY_USER_TOKEN_BAD_REQUEST = "Please provide valid inputs to verify user token";
	public static final String VERIFY_MEMBER_TOKEN_BAD_REQUEST = "Please provide valid request to Verify member token api not found";
	public static final String USER_SERVICE_UNAVAILABLE = "User service unavilable, please try after sometime";
	public static final String INVALID_TOKEN = "INVALID TOKEN";
	public static final String INSURANCE_COMPANY_NOT_FOUND = "Insurance company not found";
	public static final String INDIVIDUAL_PROVIDER_NOT_FOUND = "Individual provider not found";
	public static final String MOBILE_NUMER = "Contact number should contains 10 digits";
	public static final String CARRIER_TYPE_NOT_FOUND = "Carrier type not found";
	public static final String COUNTRY_CODE_NOT_FOUND = "Country code not found";
	public static final String USER_SERVICE_NOT_FOUND = "user service url not found!!";
	public static final String USER_SERVICE_BAD_REQUEST = "Please provide valid inputs to user service!!";
	public static final String USER_SERVICE_ISSUE = "Facing issue with Entity service, please try after sometime!!";
	public static final String COUNTRY_CODE = "Country code not found ";
	public static final String COMPANY_PROVIDER_EMAIL_EXITS = "Entered email already exists.";
	public static final String COMPANY_PROVIDER_NOT_FOUND = "Company provider not found";
	public static final String SFDC_EXISTS = "SFDC ID already exists";
	public static final String TOKEN_EXPIRED = "TOKEN EXPIRED";
	public static final String TOKEN_MISSING = "AUTH TOKEN MISSING";
	public static final String SESSION_EXPIRED = "Session Expired. Please Login";
	public static final String COMPANY_PROVIDER_NAME = "Entered company provider name already exists";
	public static final String PROVIDE_VALID_EMAIL = "Please provide valid email";
	public static final String ROLE_NOT_FOUND = "Role not found ";
	public static final String CONTACT_NAME = "contact name must be 2 to 20 characters";
	public static final String BROKER_COMPANY_NAME = "Broker company name already exists";
	public static final String EMAIL_ALREADY_EXISTS = "Email already Exists";
	public static final String INDIVIDUAL_BROKER_EMAIL = "Email already registered as Individual broker";
	public static final String BROKER_COMPANY_NOT_FOUND = "Broker company not found";

	public static final String INDIVIDUAL_BROKER_NOT_FOUND = "Individual broker not found";
	public static final String EMAIL_EXISTS_AS_BROKER_COMPANY = "Email already registered as Broker Company";
	public static final String EMPLOYER_NAME = "Employer name already exists";
	public static final String EMPLOYER_NOT_FOUND = "Employer not found";
	public static final String ADDRESS = "Address should not exceed more than 60 characters";
	public static final String BLOCK_OPPORTUNITY_NOT_FOUND = "Block opportunity not found";
	public static final String BLOCK_OPPORTUNITY_EXISTS = "Opportunity Name already exists";

	public static final String SUB_GROUP_OPPORTUNITY_EXISTS = "Sub group opportunity name already exists";
	public static final String BLOCK_OPPORTUNITY_NAME = "Opportunity name should be in between <Minimum> and <Maximum> characters";
	public static final String SUB_GROUP_NAME = "Block sub group name already exists";
	public static final String COUNT = "Count should not exeed 5 digits";
	public static final String SUB_GROUP_NOT_FOUND = "Sub group opportunity not found";
	public static final String EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY = "Employer selected is already mapped to another opportunity";
	public static final String INDIVIDUAL_BROKER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY = "Broker selected is already mapped to another opportunity";
	public static final String SOMETHING_WENT_WRONG = "Something went wrong. Please try again";
	public static final String BROKER_SPONSORED_NOT_FOUND = "Broker sponsored not found";
	public static final String EMPLOYER_UNIQUE = "Employer should be unique";
	public static final String OPPORTUNITY_NOT_FOUND = "Opportunity not found";
	public static final String EMPLOYER_DIRECT_NOT_FOUND = "Employer direct not found";
	public static final String EMPLOYER_DIRECT_NAME = "Opportunity with this name already exists";
	public static final String OPPORTUNITY_NAME = "Opportunity name already exists in other opportunities.";
	public static final String EMAIL_NOT_FOUND = "Email not found";
	public static final String PLEASE_PROVIDE_MODULE = "Please provide module name";
	public static final String MODULE_NOT_FOUND = "Module not found";
	public static final String EMPLOYER_NAME_SIZE = "employer name must be 2 to 30 characters.";
	public static final String OPPORTUNITY_NAME_SIZE = "Opportunity name must be 2 to 30 characters.";
	public static final String SUB_OPPORTUNITY_NAME_SIZE = "Sub group opportunity name must be 2 to 30 characters.";
	public static final String BROKER_COMPANY_NAME_SIZE = "Broker company name must be 2 to 30 characters.";
	public static final String COMPANY_PROVIDER_NAME_SIZE = "Company provider name must be 2 to 30 characters.";
	public static final String FIRST_NAME_SIZE = "First name must be 2 to 30 characters.";
	public static final String LAST_NAME_SIZE = "Last name must be 2 to 30 characters.";

	public static final String USER_SESSION_EXPIRED = "Session expired, please log in";
}
