package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.request.AuditRequest;
import com.billdog.entities.service.AuditService;
import com.billdog.entities.service.EmployerAuditService;
import com.billdog.entities.service.OpportunityAuditService;
import com.billdog.entities.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AuditController {

	@Autowired
	AuditService auditService;

	@Autowired
	EmployerAuditService employerAuditService;

	@Autowired
	EmployerController employerController;

	@Autowired
	BlockOpportunityController blockOpportunityController;

	@Autowired
	OpportunityAuditService opportunityAuditService;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider audit info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/audit-modules", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getAuditModules(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {

		employerController.isTokenValid(httpRequest, userId, null);
		return auditService.getEntityModules();
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Entities audit info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/audit-info", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> getAuditModules(@RequestBody AuditRequest request) {
		return auditService.getEntityAuditInfo(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Entities audit info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/audit-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> getAuditInfoById(@RequestParam Long recordId,
			@RequestParam String moduleName, @RequestParam(required = false) Integer pageNumber,
			@RequestParam(required = false) Integer pageLimit) {

		return auditService.getEntityAuditInfoById(recordId, moduleName, pageNumber, pageLimit);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider audit info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/opportunity-audit-info", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getopportunityAudit(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestBody AuditRequest request) {
		employerController.isTokenValid(httpRequest, request.getUserId(), null);
		return opportunityAuditService.getOpportunityAuditInfo(request);
	}

//	@ApiResponses(value = {
//			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider audit info fetched successfully"),
//			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
//	@GetMapping(value = "/get-opportunity-audit-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
//	@EnableTokenAuthorisation
//	public ResponseEntity<ViewResponse> getopportunityAuditInfoById(
//			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
//			@RequestParam Long userId, @RequestParam Long recordId, @RequestParam String moduleName) {
//		blockOpportunityController.isTokenValid(httpRequest, userId, null);
//		return opportunityAuditService.getOpportunityAuditInfoById(recordId, moduleName);
//	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider audit info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/audit-time", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getAuditTimeperiods(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {

		employerController.isTokenValid(httpRequest, userId, null);
		return auditService.getAuditTimeperiods();
	}

}
