package com.billdog.entities.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.Employer;
import com.billdog.entities.entity.IndividualBroker;
import com.billdog.entities.entity.Opportunity;
import com.billdog.entities.entity.OpportunitySubTypeMaster;
import com.billdog.entities.entity.OpportunityTypeMaster;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.entity.SubOpportunity;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.RecordExistsException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.BrokerCompanyRepository;
import com.billdog.entities.repository.EmployerRepository;
import com.billdog.entities.repository.IndividualBrokerRepository;
import com.billdog.entities.repository.OpportunityRepository;
import com.billdog.entities.repository.OpportunitySubTypeMasterRepository;
import com.billdog.entities.repository.OpportunityTypeMasterRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.repository.SubOpportunityRepository;
import com.billdog.entities.request.BlockOpportunityRequest;
import com.billdog.entities.request.CreateBlockOpportunityRequest;
import com.billdog.entities.request.CreateSubGroupOpportunity;
import com.billdog.entities.request.ExternalUserBlockOpportunityRequest;
import com.billdog.entities.request.MemberCountRequest;
import com.billdog.entities.request.UpdateBlockOpportunityRequest;
import com.billdog.entities.request.UpdateSubGroupOpportunityRequest;
import com.billdog.entities.view.BlockOpportunityListView;
import com.billdog.entities.view.GetMemberCountByEmployer;
import com.billdog.entities.view.SubGroupOpportunityView;
import com.billdog.entities.view.ViewBlockOpportunity;
import com.billdog.entities.view.ViewMembersCount;
import com.billdog.entities.view.ViewResponse;

@Service
public class BlockOpportunityService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(BlockOpportunityService.class);

	@Autowired
	OpportunityRepository opportunityRepository;

	@Autowired
	BrokerCompanyRepository brokerCompanyRepository;

	@Autowired
	IndividualBrokerRepository brokerRepository;

	@Autowired
	SubOpportunityRepository subOpportunityRepository;

	@Autowired
	EmployerRepository employerRepository;

	@Autowired
	OpportunitySubTypeMasterRepository opportunitySubTypeMasterRepository;
	@Autowired
	OpportunityTypeMasterRepository opportunityTypeMasterRepository;

	@Autowired
	UserService userService;

	@Autowired
	OrganizationRepository organizationRepository;

	public ResponseEntity<ViewResponse> searchBlockOpportunity(BlockOpportunityRequest blockOpportunityRequest,
			Long orgId) {
		LOGGER.info("searchBlockOpportunity method started..!");

		String opportunityName = null;
		String brokerage = null;
		String brokerName = null;
		String sfdcOpportunityId = null;
		if (blockOpportunityRequest.getOpportunityName() != null
				&& !blockOpportunityRequest.getOpportunityName().equals("")) {
			opportunityName = "%" + blockOpportunityRequest.getOpportunityName() + "%";
		} else {
			opportunityName = blockOpportunityRequest.getOpportunityName();
		}

		if (blockOpportunityRequest.getBrokerage() != null && !blockOpportunityRequest.getBrokerage().equals("")) {
			brokerage = "%" + blockOpportunityRequest.getBrokerage() + "%";
		} else {
			brokerage = blockOpportunityRequest.getBrokerage();
		}

		if (blockOpportunityRequest.getBrokerName() != null && !blockOpportunityRequest.getBrokerName().equals("")) {
			brokerName = "%" + blockOpportunityRequest.getBrokerName() + "%";
		} else {
			brokerName = blockOpportunityRequest.getBrokerName();
		}

		if (blockOpportunityRequest.getSfdcOpportunityId() != null
				&& !blockOpportunityRequest.getSfdcOpportunityId().equals("")) {
			sfdcOpportunityId = "%" + blockOpportunityRequest.getSfdcOpportunityId() + "%";
		} else {
			sfdcOpportunityId = blockOpportunityRequest.getSfdcOpportunityId();
		}

		Integer pageNumber = blockOpportunityRequest.getPageNumber() > 0 ? blockOpportunityRequest.getPageNumber() : 0;
		Integer pageLimit = blockOpportunityRequest.getPageLimit() > 0 ? blockOpportunityRequest.getPageLimit() : 20;
		// native query for searching block opportunity and assigning parameters
		// respectively
		Page<Object[][]> blockOpportunity = opportunityRepository.getBlockOpportunities(opportunityName,
				opportunityName, brokerage, brokerage, brokerName, brokerName, brokerName, brokerName,
				sfdcOpportunityId, sfdcOpportunityId, Constants.BLOCK, orgId, getPageRequest(pageNumber, pageLimit));

		// loop for block opportunity searched with native query and assigning
		// values
		// respectively

		List<ViewBlockOpportunity> viewBlockOpportunityList = getBlockOpportunityList(blockOpportunity);
		LOGGER.debug("Setting block Opportunity details for new block Opportunity object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.BLOCK_OPPORTUNITY);
		if (viewBlockOpportunityList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewBlockOpportunityList);
		response.setTotal(blockOpportunity.getTotalElements());

		LOGGER.info("searchBlockOpportunity method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewBlockOpportunity> getBlockOpportunityList(Page<Object[][]> blockOpportunity) {
		GetMemberCountByEmployer getMemberCountByEmployer = getMemberCountByEmployerByObject(blockOpportunity);
		List<ViewBlockOpportunity> viewBlockOpportunityList = new ArrayList<>();
		for (Object[] objects : blockOpportunity) {
			ViewBlockOpportunity viewBlockOpportunity = new ViewBlockOpportunity();
			viewBlockOpportunity.setOpportunityName(((String) objects[0]));
			if (((String) objects[1]) != null) {
				viewBlockOpportunity.setBrokerage(((String) objects[1]));
			} else {
				viewBlockOpportunity.setBrokerage(Constants.INDEPENDENT);
			}
			viewBlockOpportunity.setBrokerName((String) objects[2]);
			Long blockOpportunityId = ((BigInteger) objects[3]).longValue();
			Long activeCounts = getActiveCounts(((BigInteger) objects[3]).longValue(),
					getMemberCountByEmployer.getViewMembersCountList());
			if (activeCounts == null) {
				viewBlockOpportunity.setActiveMembers(0l);
			} else {
				viewBlockOpportunity.setActiveMembers(activeCounts);
			}
			BigInteger totalCount = subOpportunityRepository.getTotalCount(blockOpportunityId);
			if (totalCount == null) {
				viewBlockOpportunity.setTotalMembers(0l);
			} else {
				viewBlockOpportunity.setTotalMembers(totalCount.longValue());
			}
			viewBlockOpportunity.setBlockOpportunityId(((BigInteger) objects[3]));
			if (((BigInteger) objects[5]) != null) {
				viewBlockOpportunity.setBrokerCompanyId(((BigInteger) objects[5]).longValue());
			} else {
				viewBlockOpportunity.setBrokerCompanyId(0l);
			}
			viewBlockOpportunity.setIdividualBrokerId(((BigInteger) objects[6]));
			viewBlockOpportunity.setSfdcId((String) objects[7]);
			Optional<Opportunity> opportunityOptional = opportunityRepository
					.findById(((BigInteger) objects[3]).longValue());
			if (opportunityOptional.isPresent()) {
				Page<SubOpportunity> subGroupOpportunities = subOpportunityRepository
						.getSubOpportunities(opportunityOptional.get(),getPageRequest(0, 10));
				viewBlockOpportunity.setSubGroupOpportunities(getSubGroup(subGroupOpportunities.getContent()));
			}
			viewBlockOpportunityList.add(viewBlockOpportunity);
		}
		return viewBlockOpportunityList;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public ResponseEntity<BlockOpportunityListView> getBlockOpportunityDetails(Long blockOpportunityId, int pageNumber,int pageLimit) {
		LOGGER.info("getBlockOpportunityDetails method started..!");

		// checking whether block Opportunity with given id present or not
		Optional<Opportunity> opportunityOptional = opportunityRepository.findById(blockOpportunityId);
		if (!opportunityOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.BLOCK_OPPORTUNITY_NOT_FOUND);
		}
		Opportunity blockOpportunityDetails = opportunityOptional.get();
		LOGGER.info("setting block opportunity details to respective fields");
		BlockOpportunityListView blockOpportunityListView = new BlockOpportunityListView();
		blockOpportunityListView.setOpportunityName(blockOpportunityDetails.getOpportunityName());
		if (blockOpportunityDetails.getBrokerCompanyId() != null) {
			blockOpportunityListView.setBrokerage(blockOpportunityDetails.getBrokerCompanyId().getBrokerCompanyName());
			blockOpportunityListView.setBrokerCompanyId(blockOpportunityDetails.getBrokerCompanyId().getId());
		} else {
			blockOpportunityListView.setBrokerage(Constants.INDEPENDENT);
		}
		if (blockOpportunityDetails.getIndividualBrokerId() != null) {
			String name = "";
			if (!StringUtils.isBlank(blockOpportunityDetails.getIndividualBrokerId().getFirstName())) {
				name = blockOpportunityDetails.getIndividualBrokerId().getFirstName();
			}
			if (!StringUtils.isBlank(blockOpportunityDetails.getIndividualBrokerId().getLastName())) {
				name = name + " " + blockOpportunityDetails.getIndividualBrokerId().getLastName();
			}
			blockOpportunityListView.setBrokerName(name);
			blockOpportunityListView.setIndividualBrokerId(blockOpportunityDetails.getIndividualBrokerId().getId());
		}
		blockOpportunityListView.setOpportunityId(blockOpportunityDetails.getId());
		blockOpportunityListView.setSfdcId(blockOpportunityDetails.getSfdcId());
		Page<SubOpportunity> subGroupOpportunities = subOpportunityRepository
				.getSubOpportunities(opportunityOptional.get(),getPageRequest(pageNumber,pageLimit));
		List<SubGroupOpportunityView> subGroupOpportunityViewList = getSubGroup(subGroupOpportunities.getContent());
		blockOpportunityListView.setSubGroupOpportunities(subGroupOpportunityViewList);
		blockOpportunityListView.setTotal(subGroupOpportunities.getTotalElements());
		LOGGER.info("getBlockOpportunityDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(blockOpportunityListView);
	}

	private List<SubGroupOpportunityView> getSubGroup(List<SubOpportunity> subGroupOpportunities) {
		List<SubGroupOpportunityView> subGroupOpportunityViewList = new ArrayList<>();
		GetMemberCountByEmployer getMemberCountByEmployer = getMemberCountByEmployer(subGroupOpportunities);
		if (!subGroupOpportunities.isEmpty()) {
			subGroupOpportunities.stream().forEach(subGroup -> {
				SubGroupOpportunityView subGroupOpportunityView = new SubGroupOpportunityView();
				subGroupOpportunityView.setEmployer(subGroup.getEmployerId().getEmployerName());
				subGroupOpportunityView.setEmployerId(subGroup.getEmployerId().getId());
				subGroupOpportunityView.setSubGroupOpportunityId(subGroup.getId());
				subGroupOpportunityView.setSubGroupOpportunityName(subGroup.getSubGroupOpportunityName());
				subGroupOpportunityView.setTotalCount(subGroup.getCount());
				subGroupOpportunityView.setSfdcId(subGroup.getSfdcId());
				ViewMembersCount memberActiveCount = getMemberActiveCount(subGroup.getEmployerId().getId(),
						getMemberCountByEmployer.getViewMembersCountList());
				if (memberActiveCount != null) {
					subGroupOpportunityView.setActiveCount(memberActiveCount.getCount());
				}
				subGroupOpportunityView.setOpportunityType(subGroup.getOpportunitySubTypeMasterId()
						.getOpportunityTypeMasterId().getOpportunityParentName());
				subGroupOpportunityViewList.add(subGroupOpportunityView);
			});
		}

		return subGroupOpportunityViewList;
	}

	private GetMemberCountByEmployer getMemberCountByEmployer(List<SubOpportunity> subGroupOpportunities) {
		MemberCountRequest memberCountRequest = new MemberCountRequest();
		memberCountRequest.setEmployerIds(getEmployerIds(subGroupOpportunities));
		GetMemberCountByEmployer memberCountByEmployerId = userService.getMemberCountByEmployerId(memberCountRequest);
		return memberCountByEmployerId;
	}

	private GetMemberCountByEmployer getMemberCountByEmployerByObject(Page<Object[][]> blockOpportunity) {
		List<Long> employerIds = new ArrayList<>();
		for (Object[] object : blockOpportunity) {
			List<Long> employerId = subOpportunityRepository.getEmployerCount(((BigInteger) object[3]).longValue());
			employerIds.addAll(employerId);
		}
		MemberCountRequest memberCountRequest = new MemberCountRequest();
		memberCountRequest.setEmployerIds(employerIds);
		GetMemberCountByEmployer memberCountByEmployerId = userService.getMemberCountByEmployerId(memberCountRequest);
		return memberCountByEmployerId;
	}

	private Long getActiveCounts(Long blockId, List<ViewMembersCount> viewMembersCountList) {
		ViewMembersCount viewMembersCount = new ViewMembersCount();
		List<Long> employerIds = subOpportunityRepository.getEmployerCount(blockId);
		employerIds.forEach(employerId -> {
			ViewMembersCount memberActiveCount = getMemberActiveCount(employerId, viewMembersCountList);
			if (memberActiveCount != null) {
				Long count = viewMembersCount.getCount() != null ? viewMembersCount.getCount() : 0;
				viewMembersCount.setCount(count + memberActiveCount.getCount());
			}
		});

		return viewMembersCount.getCount();

	}

	private List<Long> getEmployerIds(List<SubOpportunity> subGroupOpportunities) {
		List<Long> employerIds = new ArrayList<>();
		subGroupOpportunities.forEach(employers -> {
			Long employerId = employers.getEmployerId().getId();
			employerIds.add(employerId);
		});
		return employerIds;
	}

	private ViewMembersCount getMemberActiveCount(Long employerId, List<ViewMembersCount> list) {
		return list.stream().filter(employer -> employer.getEmployerId().equals(employerId)).findFirst().orElse(null);
	}

	public ViewResponse createBlockOpportunity(CreateBlockOpportunityRequest blockOpportunityRequest, Long orgId) {
		LOGGER.info("createBlockOpportunity method has started..!");
		LOGGER.info("Checking opportunity name is already exists in the system");
		if (!StringUtils.isBlank(blockOpportunityRequest.getOpportunityName())) {
			Optional<Opportunity> opportunityEntity = opportunityRepository
					.findByOpportunityNameAndOrganizationId(blockOpportunityRequest.getOpportunityName(), orgId);
			if (opportunityEntity.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
			}
		} else {
			throw new BadRequestException(ExceptionalMessages.OPPORTUNITY_NAME_SIZE);
		}

		Optional<Organization> organization = organizationRepository.findById(orgId);
		if (!organization.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<SubOpportunity> subOpportunityName = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(blockOpportunityRequest.getOpportunityName(),
						organization.get());
		if (subOpportunityName.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<OpportunityTypeMaster> opportunityTypeOptional = opportunityTypeMasterRepository
				.findByOpportunityParentNameAndOrganizationId(Constants.BLOCK, orgId);
		OpportunityTypeMaster opportunityType = new OpportunityTypeMaster();
		if (opportunityTypeOptional.isPresent()) {
			opportunityType = opportunityTypeOptional.get();
		}
		Optional<Opportunity> blockOptional = opportunityRepository
				.findByOpportunityNameAndOrganizationIdAndOpportunityTypeMasterId(
						blockOpportunityRequest.getOpportunityName(), orgId, opportunityType);

		if (blockOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.BLOCK_OPPORTUNITY_EXISTS);
		}
		LOGGER.info("Checked opportunity name is already exists in the system");
		if (!StringUtils.isBlank(blockOpportunityRequest.getSfdcId())) {
			if (blockOpportunityRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<Opportunity> opportunity = opportunityRepository.findBySfdcId(blockOpportunityRequest.getSfdcId());
			if (opportunity.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
			}
		}

		Optional<IndividualBroker> individualBroker = brokerRepository
				.findById(blockOpportunityRequest.getIndividualBrokerId());
		if (!individualBroker.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_BROKER_NOT_FOUND);
		}

		Optional<Opportunity> individualBrokerOpportunity = opportunityRepository
				.findByIndividualBrokerIdAndOrganizationIdAndOpportunityTypeMasterId(individualBroker.get(), orgId,
						opportunityType);
		if (individualBrokerOpportunity.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.INDIVIDUAL_BROKER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
		}

		getEmployers(blockOpportunityRequest.getSubGroupOpportunityList(), orgId);
		Opportunity opportunity = new Opportunity();
		opportunity.setCreatedAt(DateAndTimeUtil.now());
		if (individualBroker.get().getBrokerCompany() != null) {
			opportunity.setBrokerCompanyId(individualBroker.get().getBrokerCompany());
		}
		opportunity.setOpportunityTypeMasterId(opportunityType);

		opportunity.setOrganizationId(orgId);
		opportunity.setIndividualBrokerId(individualBroker.get());
		opportunity.setOpportunityName(blockOpportunityRequest.getOpportunityName());
		opportunity.setOrganizationId(orgId);
		opportunity.setSfdcId(blockOpportunityRequest.getSfdcId());
		opportunity.setStatus(StatusConstants.ACTIVE);
		opportunity.setUpdatedAt(DateAndTimeUtil.now());
		opportunity.setUserId(blockOpportunityRequest.getUserId());
		opportunityRepository.save(opportunity);
		OpportunitySubTypeMaster subGroupOpportunity = opportunitySubTypeMasterRepository
				.findByOpportunityChildNameAndOrganizationId(Constants.SUB_GROUP, opportunity.getOrganizationId());

		blockOpportunityRequest.getSubGroupOpportunityList().forEach(opportunityRequst -> {
			if (StringUtils.isBlank(opportunityRequst.getSubGroupOpportunityName())) {
				throw new BadRequestException(ExceptionalMessages.SUB_OPPORTUNITY_NAME_SIZE);
			}
			Optional<Employer> employer = employerRepository.findById(opportunityRequst.getEmployerId());
			if (!employer.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
			}
			Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
			if (subOptional.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
			}
			SubOpportunity subOpportunity = saveSubOpportunities(opportunityRequst, opportunity, employer.get(),
					blockOpportunityRequest.getUserId(), subGroupOpportunity, organization.get());
			subOpportunityRepository.save(subOpportunity);
		});

		ViewResponse response = new ViewResponse();
		response.setMessage(Constants.BLOCK_OPPORTUNITY_CREATED);
		response.setStatusText(Constants.SUCCESS);
		LOGGER.info("createBlockOpportunity method has ended..!");
		return response;
	}

	private Employer getEmployer(List<Employer> employers, Long employerId) {
		return employers.stream().filter(employer -> employer.getId() == employerId).findFirst().orElse(null);
	}

	private List<Employer> getEmployers(List<CreateSubGroupOpportunity> subGroupOpportunityList, Long orgId) {
		List<Employer> employers = new ArrayList<>();
		List<Long> employerIds = new ArrayList<>();
		OpportunitySubTypeMaster opportunityType = opportunitySubTypeMasterRepository
				.findByOpportunityChildNameAndOrganizationId(Constants.SUB_GROUP, orgId);
		subGroupOpportunityList.forEach(subGroupOpportunity -> {
			if (employerIds.contains(subGroupOpportunity.getEmployerId())) {
				throw new RecordExistsException(ExceptionalMessages.EMPLOYER_UNIQUE);
			} else {
				Optional<Employer> employer = employerRepository.findById(subGroupOpportunity.getEmployerId());
				if (!employer.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
				}

				Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
				if (subOptional.isPresent()) {
					throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
				}

				Optional<SubOpportunity> blockOptional = subOpportunityRepository
						.findBySubGroupOpportunityNameAndOrganizationIdAndOpportunitySubTypeMasterId(
								subGroupOpportunity.getSubGroupOpportunityName(), employer.get().getOrganizationId(),
								opportunityType);
				if (blockOptional.isPresent()) {
					throw new RecordExistsException(ExceptionalMessages.SUB_GROUP_OPPORTUNITY_EXISTS);
				}
				Optional<SubOpportunity> opportunity = subOpportunityRepository
						.findBySfdcIdAndOpportunitySubTypeMasterId(subGroupOpportunity.getSfdcId(), opportunityType);
				if (opportunity.isPresent()) {
					throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
				}
				employers.add(employer.get());
				employerIds.add(employer.get().getId());
			}
		});
		return employers;
	}

	private SubOpportunity saveSubOpportunities(CreateSubGroupOpportunity subGroupOpportunity,
			Opportunity blockOpportunity, Employer employer, Long userId, OpportunitySubTypeMaster subTypeMaster,
			Organization organization) {

		Optional<Opportunity> opportunityEntity = opportunityRepository.findByOpportunityNameAndOrganizationId(
				subGroupOpportunity.getSubGroupOpportunityName(), subGroupOpportunity.getOrganizationId());
		if (opportunityEntity.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<SubOpportunity> subOpportunityName = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(subGroupOpportunity.getSubGroupOpportunityName(),
						organization);
		if (subOpportunityName.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		SubOpportunity groupOpportunity = new SubOpportunity();
		groupOpportunity.setOpportunityId(blockOpportunity);
		groupOpportunity.setCount(subGroupOpportunity.getTotalCount());
		groupOpportunity.setCreatedAt(DateAndTimeUtil.now());
		groupOpportunity.setEmployerId(employer);
		groupOpportunity.setOrganizationId(employer.getOrganizationId());
		groupOpportunity.setSfdcId(subGroupOpportunity.getSfdcId());
		groupOpportunity.setUserId(userId);
		groupOpportunity.setCount(subGroupOpportunity.getTotalCount());
		groupOpportunity.setStatus(StatusConstants.ACTIVE);
		groupOpportunity.setSubGroupOpportunityName(subGroupOpportunity.getSubGroupOpportunityName());
		groupOpportunity.setUpdatedAt(DateAndTimeUtil.now());
		groupOpportunity.setOpportunitySubTypeMasterId(subTypeMaster);
		return groupOpportunity;
	}

	public ViewResponse updateBlockOpportunity(UpdateBlockOpportunityRequest blockOpportunityRequest) {
		if (StringUtils.isBlank(blockOpportunityRequest.getOpportunityName())) {
			throw new BadRequestException(ExceptionalMessages.OPPORTUNITY_NAME_SIZE);
		}
		Optional<Opportunity> opportunityOptional = opportunityRepository
				.findById(blockOpportunityRequest.getBlockOpportunityId());
		if (!opportunityOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.BLOCK_OPPORTUNITY_NOT_FOUND);
		}

		Optional<Opportunity> opportunityEntity = opportunityRepository.findByOpportunityNameAndOrganizationId(
				blockOpportunityRequest.getOpportunityName(), opportunityOptional.get().getOrganizationId());
		if (opportunityEntity.isPresent()
				&& opportunityEntity.get().getId() != blockOpportunityRequest.getBlockOpportunityId()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<Organization> organization = organizationRepository
				.findById(opportunityOptional.get().getOrganizationId());
		if (!organization.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<SubOpportunity> subOpportunityName = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(blockOpportunityRequest.getOpportunityName(),
						organization.get());
		if (subOpportunityName.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}
		Opportunity blockOpportunity = opportunityOptional.get();

		if (!StringUtils.isBlank(blockOpportunityRequest.getOpportunityName()) && !blockOpportunity.getOpportunityName()
				.equalsIgnoreCase(blockOpportunityRequest.getOpportunityName())) {

			LOGGER.info("Checking opportunity name is already exists in the system");
			Optional<Opportunity> blockOptional = opportunityRepository.findByOpportunityNameAndOrganizationId(
					blockOpportunityRequest.getOpportunityName(), blockOpportunity.getOrganizationId());
			if (blockOptional.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.BLOCK_OPPORTUNITY_EXISTS);
			}
			LOGGER.info("Checked opportunity name is already exists in the system");
		}

		if (!StringUtils.isBlank(blockOpportunityRequest.getSfdcId()) && blockOpportunity.getSfdcId() != null
				&& !blockOpportunity.getSfdcId().equalsIgnoreCase(blockOpportunityRequest.getSfdcId())) {
			if (blockOpportunityRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<Opportunity> opportunity = opportunityRepository.findBySfdcId(blockOpportunityRequest.getSfdcId());
			if (opportunity.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		boolean blockUpdated = false;

		OpportunitySubTypeMaster subGroupOpportunity = opportunitySubTypeMasterRepository
				.findByOpportunityChildNameAndOrganizationId(Constants.SUB_GROUP, blockOpportunity.getOrganizationId());

		List<SubOpportunity> subGroupOpportunityList = new ArrayList<>();
		blockOpportunityRequest.getGroupOpportunityRequest().forEach(subGroupOpportunityRequest -> {
			if (StringUtils.isBlank(subGroupOpportunityRequest.getSubGroupOpportunityName())) {
				throw new BadRequestException(ExceptionalMessages.SUB_OPPORTUNITY_NAME_SIZE);
			}
			SubOpportunity groupOpportunity = new SubOpportunity();
			Optional<SubOpportunity> subGroupOptional = subOpportunityRepository
					.findByIdAndOpportunityId(subGroupOpportunityRequest.getSubGroupOpportunityId(), blockOpportunity);

			if (subGroupOptional.isPresent()) {
				groupOpportunity = subGroupOptional.get();
				boolean subGroupUpdated = false;

				if (!StringUtils.isBlank(subGroupOpportunityRequest.getSfdcId())
						&& !subGroupOpportunityRequest.getSfdcId().equalsIgnoreCase(groupOpportunity.getSfdcId())) {
					Optional<SubOpportunity> opportunity = subOpportunityRepository
							.findBySfdcIdAndOpportunitySubTypeMasterId(subGroupOpportunityRequest.getSfdcId(),
									subGroupOpportunity);
					if (opportunity.isPresent()) {
						throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
					}
				}

				if (!groupOpportunity.getSubGroupOpportunityName()
						.equalsIgnoreCase(subGroupOpportunityRequest.getSubGroupOpportunityName())) {
					Optional<SubOpportunity> blockOptional = subOpportunityRepository
							.findBySubGroupOpportunityNameAndOrganizationId(
									subGroupOpportunityRequest.getSubGroupOpportunityName(),
									groupOpportunity.getOrganizationId());
					if (blockOptional.isPresent()
							&& blockOptional.get().getId() != subGroupOpportunityRequest.getSubGroupOpportunityId()) {
						throw new RecordExistsException(ExceptionalMessages.SUB_GROUP_OPPORTUNITY_EXISTS);
					}
				}
				if (groupOpportunity.getEmployerId().getId() != subGroupOpportunityRequest.getEmployerId()) {
					Optional<Employer> employer = employerRepository
							.findById(subGroupOpportunityRequest.getEmployerId());
					if (!employer.isPresent()) {
						throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
					}
					if (subGroupOpportunityRequest.getEmployerId() != groupOpportunity.getEmployerId().getId()) {
						Optional<SubOpportunity> subOptional = subOpportunityRepository
								.findByEmployerId(employer.get());
						if (subOptional.isPresent()) {
							throw new RecordExistsException(
									ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
						}
					}
					userService.updateEmployer(blockOpportunityRequest.getUserId(), employer.get().getId(),
							groupOpportunity.getEmployerId().getId());
					groupOpportunity.setEmployerId(employer.get());
					subGroupUpdated = true;
				}
				if (!StringUtils.isBlank(subGroupOpportunityRequest.getSubGroupOpportunityName())
						&& !subGroupOpportunityRequest.getSubGroupOpportunityName()
								.equalsIgnoreCase(groupOpportunity.getSubGroupOpportunityName())) {
					subGroupUpdated = true;
					groupOpportunity
							.setSubGroupOpportunityName(subGroupOpportunityRequest.getSubGroupOpportunityName());
				}
				if (!StringUtils.isBlank(subGroupOpportunityRequest.getSfdcId())
						&& !subGroupOpportunityRequest.getSfdcId().equalsIgnoreCase(groupOpportunity.getSfdcId())) {
					subGroupUpdated = true;
					groupOpportunity.setSfdcId(subGroupOpportunityRequest.getSfdcId());
				}
				if (subGroupOpportunityRequest.getTotalCount() > 0
						&& groupOpportunity.getCount() != subGroupOpportunityRequest.getTotalCount()) {
					subGroupUpdated = true;
					groupOpportunity.setCount(subGroupOpportunityRequest.getTotalCount());
				}
				if (subGroupUpdated) {
					groupOpportunity.setUpdatedAt(DateAndTimeUtil.now());
					groupOpportunity.setUserId(blockOpportunityRequest.getUserId());
					subGroupOpportunityList.add(groupOpportunity);
				}
			} else {
				groupOpportunity = new SubOpportunity();
				Optional<Employer> employer = employerRepository.findById(subGroupOpportunityRequest.getEmployerId());
				if (!employer.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
				}
				Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
				if (subOptional.isPresent()) {
					throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
				}

				Optional<SubOpportunity> blockOptional = subOpportunityRepository
						.findBySubGroupOpportunityNameAndOrganizationIdAndOpportunitySubTypeMasterId(
								subGroupOpportunityRequest.getSubGroupOpportunityName(),
								employer.get().getOrganizationId(), subGroupOpportunity);
				if (blockOptional.isPresent()) {
					throw new RecordExistsException(ExceptionalMessages.SUB_GROUP_OPPORTUNITY_EXISTS);
				}
				Optional<SubOpportunity> opportunity = subOpportunityRepository
						.findBySfdcIdAndOpportunitySubTypeMasterId(subGroupOpportunityRequest.getSfdcId(),
								subGroupOpportunity);
				if (opportunity.isPresent()) {
					throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
				}

				groupOpportunity.setEmployerId(employer.get());
				groupOpportunity.setOpportunityId(blockOpportunity);
				groupOpportunity.setCount(subGroupOpportunityRequest.getTotalCount());
				groupOpportunity.setCreatedAt(DateAndTimeUtil.now());
				groupOpportunity.setEmployerId(employer.get());
				groupOpportunity.setOrganizationId(employer.get().getOrganizationId());
				groupOpportunity.setSfdcId(subGroupOpportunityRequest.getSfdcId());
				groupOpportunity.setOpportunitySubTypeMasterId(subGroupOpportunity);
				groupOpportunity.setStatus(StatusConstants.ACTIVE);
				groupOpportunity.setSubGroupOpportunityName(subGroupOpportunityRequest.getSubGroupOpportunityName());
				groupOpportunity.setUpdatedAt(DateAndTimeUtil.now());
				groupOpportunity.setUserId(blockOpportunityRequest.getUserId());
				subGroupOpportunityList.add(groupOpportunity);
			}
		});


		if (blockOpportunityRequest.getIndividualBrokerId() != blockOpportunity.getIndividualBrokerId().getId()) {
			Optional<IndividualBroker> individualBroker = brokerRepository
					.findById(blockOpportunityRequest.getIndividualBrokerId());
			if (!individualBroker.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_BROKER_NOT_FOUND);
			}
			Optional<Opportunity> individualBrokerOpportunity = opportunityRepository
					.findByIndividualBrokerIdAndOrganizationIdAndOpportunityTypeMasterId(individualBroker.get(),
							blockOpportunity.getOrganizationId(), blockOpportunity.getOpportunityTypeMasterId());
			if (individualBrokerOpportunity.isPresent()) {
				throw new RecordExistsException(
						ExceptionalMessages.INDIVIDUAL_BROKER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
			}
			if (individualBroker.get().getBrokerCompany() != null) {
				blockOpportunity.setBrokerCompanyId(individualBroker.get().getBrokerCompany());
			}
			blockUpdated = true;
			blockOpportunity.setIndividualBrokerId(individualBroker.get());
		}
		if (!StringUtils.isBlank(blockOpportunityRequest.getOpportunityName()) && !blockOpportunityRequest
				.getOpportunityName().equalsIgnoreCase(blockOpportunity.getOpportunityName())) {
			blockUpdated = true;
			blockOpportunity.setOpportunityName(blockOpportunityRequest.getOpportunityName());
		}
		if (!StringUtils.isBlank(blockOpportunityRequest.getSfdcId())
				&& !blockOpportunityRequest.getSfdcId().equalsIgnoreCase(blockOpportunity.getSfdcId())) {
			blockUpdated = true;
			blockOpportunity.setSfdcId(blockOpportunityRequest.getSfdcId());
		}
		if (blockUpdated) {
			blockOpportunity.setUpdatedAt(DateAndTimeUtil.now());
			blockOpportunity.setUserId(blockOpportunityRequest.getUserId());
			opportunityRepository.save(blockOpportunity);
		}

		if (subGroupOpportunityList != null && !subGroupOpportunityList.isEmpty()) {
			subOpportunityRepository.saveAll(subGroupOpportunityList);
		}

		ViewResponse response = new ViewResponse();
		response.setMessage(Constants.BLOCK_OPPORTUNITY_UPDATED);
		response.setStatusText(Constants.SUCCESS);
		return response;
	}

	private SubOpportunity getSubGroupOpportunity(UpdateSubGroupOpportunityRequest subGroupOpportunity,
			Opportunity blockOpportunity, Long userId, OpportunitySubTypeMaster subTypeMaster) {
		if (StringUtils.isBlank(subGroupOpportunity.getSubGroupOpportunityName())) {
			throw new BadRequestException(ExceptionalMessages.SUB_OPPORTUNITY_NAME_SIZE);
		}
		SubOpportunity groupOpportunity = new SubOpportunity();
		Optional<SubOpportunity> subGroupOptional = subOpportunityRepository
				.findByIdAndOpportunityId(subGroupOpportunity.getSubGroupOpportunityId(), blockOpportunity);

		if (subGroupOptional.isPresent()) {
			groupOpportunity = subGroupOptional.get();
			if (groupOpportunity.getEmployerId().getId() != subGroupOpportunity.getEmployerId()) {

				Optional<Employer> employer = employerRepository.findById(subGroupOpportunity.getEmployerId());
				if (!employer.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
				}
				if (subGroupOpportunity.getEmployerId() != groupOpportunity.getEmployerId().getId()) {
					Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
					if (subOptional.isPresent()) {
						throw new RecordExistsException(
								ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
					}
				}
				userService.updateEmployer(userId, employer.get().getId(), groupOpportunity.getEmployerId().getId());
				groupOpportunity.setEmployerId(employer.get());
			}
			if (!StringUtils.isBlank(subGroupOpportunity.getSfdcId())
					&& !subGroupOpportunity.getSfdcId().equalsIgnoreCase(groupOpportunity.getSfdcId())) {
				Optional<SubOpportunity> opportunity = subOpportunityRepository
						.findBySfdcIdAndOpportunitySubTypeMasterId(subGroupOpportunity.getSfdcId(), subTypeMaster);
				if (opportunity.isPresent()) {
					throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
				}
			}

			if (!groupOpportunity.getSubGroupOpportunityName()
					.equalsIgnoreCase(subGroupOpportunity.getSubGroupOpportunityName())) {
				Optional<SubOpportunity> blockOptional = subOpportunityRepository
						.findBySubGroupOpportunityNameAndOrganizationId(
								subGroupOpportunity.getSubGroupOpportunityName(), groupOpportunity.getOrganizationId());
				if (blockOptional.isPresent()
						&& blockOptional.get().getId() != subGroupOpportunity.getSubGroupOpportunityId()) {
					throw new RecordExistsException(ExceptionalMessages.SUB_GROUP_OPPORTUNITY_EXISTS);
				}
			}
			groupOpportunity.setSubGroupOpportunityName(subGroupOpportunity.getSubGroupOpportunityName());
			groupOpportunity.setSfdcId(subGroupOpportunity.getSfdcId());
			groupOpportunity.setCount(subGroupOpportunity.getTotalCount());
			groupOpportunity.setUpdatedAt(DateAndTimeUtil.now());
			groupOpportunity.setOpportunitySubTypeMasterId(subTypeMaster);
			groupOpportunity.setUserId(userId);

		} else {
			groupOpportunity = new SubOpportunity();
			Optional<Employer> employer = employerRepository.findById(subGroupOpportunity.getEmployerId());
			if (!employer.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
			}
			Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
			if (subOptional.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
			}

			Optional<SubOpportunity> blockOptional = subOpportunityRepository
					.findBySubGroupOpportunityNameAndOrganizationIdAndOpportunitySubTypeMasterId(
							subGroupOpportunity.getSubGroupOpportunityName(), employer.get().getOrganizationId(),
							subTypeMaster);
			if (blockOptional.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.SUB_GROUP_OPPORTUNITY_EXISTS);
			}
			Optional<SubOpportunity> opportunity = subOpportunityRepository
					.findBySfdcIdAndOpportunitySubTypeMasterId(subGroupOpportunity.getSfdcId(), subTypeMaster);
			if (opportunity.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.SFDC_EXISTS);
			}

			groupOpportunity.setEmployerId(employer.get());
			groupOpportunity.setOpportunityId(blockOpportunity);
			groupOpportunity.setCount(subGroupOpportunity.getTotalCount());
			groupOpportunity.setCreatedAt(DateAndTimeUtil.now());
			groupOpportunity.setEmployerId(employer.get());
			groupOpportunity.setOrganizationId(employer.get().getOrganizationId());
			groupOpportunity.setSfdcId(subGroupOpportunity.getSfdcId());
			groupOpportunity.setOpportunitySubTypeMasterId(subTypeMaster);
			groupOpportunity.setStatus(StatusConstants.ACTIVE);
			groupOpportunity.setSubGroupOpportunityName(subGroupOpportunity.getSubGroupOpportunityName());
			groupOpportunity.setUpdatedAt(DateAndTimeUtil.now());
			groupOpportunity.setUserId(userId);
		}
		return groupOpportunity;
	}

	public ResponseEntity<ViewResponse> searchExternalUserBlockOpportunity(
			ExternalUserBlockOpportunityRequest blockOpportunityRequest) {
		LOGGER.info("searchBlockOpportunity method started..!");

		String opportunityName = null;
		String brokerage = null;
		String brokerName = null;
		String sfdcOpportunityId = null;
		if (blockOpportunityRequest.getOpportunityName() != null
				&& !blockOpportunityRequest.getOpportunityName().equals("")) {
			opportunityName = "%" + blockOpportunityRequest.getOpportunityName() + "%";
		} else {
			opportunityName = blockOpportunityRequest.getOpportunityName();
		}

		if (blockOpportunityRequest.getBrokerage() != null && !blockOpportunityRequest.getBrokerage().equals("")) {
			brokerage = "%" + blockOpportunityRequest.getBrokerage() + "%";
		} else {
			brokerage = blockOpportunityRequest.getBrokerage();
		}

		if (blockOpportunityRequest.getBrokerName() != null && !blockOpportunityRequest.getBrokerName().equals("")) {
			brokerName = "%" + blockOpportunityRequest.getBrokerName() + "%";
		} else {
			brokerName = blockOpportunityRequest.getBrokerName();
		}

		if (blockOpportunityRequest.getSfdcOpportunityId() != null
				&& !blockOpportunityRequest.getSfdcOpportunityId().equals("")) {
			sfdcOpportunityId = "%" + blockOpportunityRequest.getSfdcOpportunityId() + "%";
		} else {
			sfdcOpportunityId = blockOpportunityRequest.getSfdcOpportunityId();
		}

		Integer pageNumber = blockOpportunityRequest.getPageNumber() > 0 ? blockOpportunityRequest.getPageNumber() : 0;
		Integer pageLimit = blockOpportunityRequest.getPageLimit() > 0 ? blockOpportunityRequest.getPageLimit() : 20;
		// native query for searching block opportunity and assigning parameters
		// respectively
		Page<Object[][]> blockOpportunity = opportunityRepository.getExternalUserBlockOpportunities(opportunityName,
				opportunityName, brokerage, brokerage, brokerName, brokerName, brokerName, brokerName,
				sfdcOpportunityId, sfdcOpportunityId, Constants.BLOCK, blockOpportunityRequest.getExternalUserEmail(),
				getPageRequest(pageNumber, pageLimit));

		// loop for block opportunity searched with native query and assigning
		// values
		// respectively

		List<ViewBlockOpportunity> viewBlockOpportunityList = getExternalUserBlockOpportunityList(blockOpportunity);
		LOGGER.debug("Setting block Opportunity details for new block Opportunity object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.BLOCK_OPPORTUNITY);
		if (viewBlockOpportunityList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewBlockOpportunityList);
		response.setTotal(blockOpportunity.getTotalElements());

		LOGGER.info("searchBlockOpportunity method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewBlockOpportunity> getExternalUserBlockOpportunityList(Page<Object[][]> blockOpportunity) {
		GetMemberCountByEmployer getMemberCountByEmployer = getMemberCountByEmployerByObject(blockOpportunity);
		List<ViewBlockOpportunity> viewBlockOpportunityList = new ArrayList<>();
		for (Object[] objects : blockOpportunity) {
			ViewBlockOpportunity viewBlockOpportunity = new ViewBlockOpportunity();
			viewBlockOpportunity.setOpportunityName(((String) objects[0]));
			viewBlockOpportunity.setBrokerage(((String) objects[1]));
			viewBlockOpportunity.setBrokerName((String) objects[2]);
			Long blockOpportunityId = ((BigInteger) objects[3]).longValue();
			Long activeCounts = getActiveCounts(((BigInteger) objects[3]).longValue(),
					getMemberCountByEmployer.getViewMembersCountList());
			if (activeCounts == null) {
				viewBlockOpportunity.setActiveMembers(0l);
			} else {
				viewBlockOpportunity.setActiveMembers(activeCounts);
			}
			BigInteger totalCount = subOpportunityRepository.getTotalCount(blockOpportunityId);
			if (totalCount == null) {
				viewBlockOpportunity.setTotalMembers(0l);
			} else {
				viewBlockOpportunity.setTotalMembers(totalCount.longValue());
			}
			viewBlockOpportunity.setBlockOpportunityId(((BigInteger) objects[3]));
			viewBlockOpportunity.setBrokerCompanyId(((BigInteger) objects[5]).longValue());
			viewBlockOpportunity.setIdividualBrokerId(((BigInteger) objects[6]));
			viewBlockOpportunity.setSfdcId((String) objects[7]);
			Optional<Opportunity> opportunityOptional = opportunityRepository
					.findById(((BigInteger) objects[3]).longValue());
			if (opportunityOptional.isPresent()) {
				Page<SubOpportunity> subGroupOpportunities = subOpportunityRepository
						.getSubOpportunities(opportunityOptional.get(),getPageRequest(0, 10));
				viewBlockOpportunity.setSubGroupOpportunities(getSubGroup(subGroupOpportunities.getContent()));
			}
			viewBlockOpportunityList.add(viewBlockOpportunity);
		}
		return viewBlockOpportunityList;
	}

}
