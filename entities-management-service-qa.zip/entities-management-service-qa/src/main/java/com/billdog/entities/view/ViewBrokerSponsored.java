package com.billdog.entities.view;

public class ViewBrokerSponsored {

	private String opportunityName;
	private String brokerage;
	private String brokerName;
	private String employer;
	private Long totalCount;
	private Long totalActiveCount;
	private String sfdcId;
	private String opportunityType;
	private Long employerId;
	private Long brokerSponsoredId;

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getBrokerage() {
		return brokerage;
	}

	public void setBrokerage(String brokerage) {
		this.brokerage = brokerage;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public Long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Long totalCount) {
		this.totalCount = totalCount;
	}

	public Long getTotalActiveCount() {
		return totalActiveCount;
	}

	public void setTotalActiveCount(Long totalActiveCount) {
		this.totalActiveCount = totalActiveCount;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public Long getBrokerSponsoredId() {
		return brokerSponsoredId;
	}

	public void setBrokerSponsoredId(Long brokerSponsoredId) {
		this.brokerSponsoredId = brokerSponsoredId;
	}

}
