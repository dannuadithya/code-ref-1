package com.billdog.entities.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UpdateBrokerSponsoredRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter opportunity name")
	@Size(min = 4, max = 44, message = "Opportunity name must be 4 to 44 characters")
	private String opportunityName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcId;
	@NotNull(message = "Please select Individual Broker")
	private Long individualBrokerId;
	@NotNull(message = "User id must not be null")
	private Long userId;
	private long totalCount;
	@NotNull(message = "Please provide Broker sponsored id")
	private Long brokerSponsoredId;

	@NotNull(message = "Please select Employer")
	private Long employerId;

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public Long getIndividualBrokerId() {
		return individualBrokerId;
	}

	public void setIndividualBrokerId(Long individualBrokerId) {
		this.individualBrokerId = individualBrokerId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public long getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(long totalCount) {
		this.totalCount = totalCount;
	}

	public Long getBrokerSponsoredId() {
		return brokerSponsoredId;
	}

	public void setBrokerSponsoredId(Long brokerSponsoredId) {
		this.brokerSponsoredId = brokerSponsoredId;
	}

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

}
