package com.billdog.entities.request;

import java.util.List;

public class MemberCountRequest {

	private List<Long> employerIds;

	public List<Long> getEmployerIds() {
		return employerIds;
	}

	public void setEmployerIds(List<Long> employerIds) {
		this.employerIds = employerIds;
	}

}
