package com.billdog.entities.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "OPPURTUNITIES")
@Table(name = "opportunities")
public class Opportunity extends BaseEntity {

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "opportunity_type_master_Id")
	private OpportunityTypeMaster opportunityTypeMasterId;

	@Audited
	@Column(name = "opportunity_name")
	private String opportunityName;

	@Audited
	@Column(name = "status")
	private String status;

	@Audited
	@Column(name = "sfdc_id")
	private String sfdcId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "broker_company_id")
	private BrokerCompany brokerCompanyId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "individual_broker_id")
	private IndividualBroker individualBrokerId;

	@Column(name = "organization_Id")
	private Long organizationId;

	@Audited
	@Column(name = "USER_ID")
	private Long userId;

	public OpportunityTypeMaster getOpportunityTypeMasterId() {
		return opportunityTypeMasterId;
	}

	public void setOpportunityTypeMasterId(OpportunityTypeMaster opportunityTypeMasterId) {
		this.opportunityTypeMasterId = opportunityTypeMasterId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public BrokerCompany getBrokerCompanyId() {
		return brokerCompanyId;
	}

	public void setBrokerCompanyId(BrokerCompany brokerCompanyId) {
		this.brokerCompanyId = brokerCompanyId;
	}

	public IndividualBroker getIndividualBrokerId() {
		return individualBrokerId;
	}

	public void setIndividualBrokerId(IndividualBroker individualBrokerId) {
		this.individualBrokerId = individualBrokerId;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
