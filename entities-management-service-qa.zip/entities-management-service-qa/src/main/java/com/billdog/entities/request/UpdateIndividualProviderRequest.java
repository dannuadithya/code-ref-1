package com.billdog.entities.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UpdateIndividualProviderRequest {

	private long individualProviderId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter first name")
	@Size(min = 2, max = 30, message = "first name must be 2 to 30 characters")
	private String firstName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter last name")
	@Size(min = 2, max = 30, message = "last name must be 2 to 30 characters")
	private String lastName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	// @Pattern(regexp = "^(0|[1-9][0-9]*)$", message = "Invalid contact number")
	private String contactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String email;

	private long companyProviderId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcId;

	private long userId;
	private long countryCodeId;

	@NotNull(message = "Please enter Status")
	private String status;

	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getCompanyProviderId() {
		return companyProviderId;
	}

	public void setCompanyProviderId(long companyProviderId) {
		this.companyProviderId = companyProviderId;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public long getIndividualProviderId() {
		return individualProviderId;
	}

	public void setIndividualProviderId(long individualProviderId) {
		this.individualProviderId = individualProviderId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
