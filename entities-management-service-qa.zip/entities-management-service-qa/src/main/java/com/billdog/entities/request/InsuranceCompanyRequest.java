package com.billdog.entities.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class InsuranceCompanyRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter insurance company name")
	@Size(min = 2, max = 55, message = "insurance company name must be 2 to 55 characters")
	private String insuranceCompanyName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactPersonName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Email(message = "Invalid email format")
	private String email;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcId;
	@NotNull(message = "organization id must not be null")
	private long organizationId;
	private long userId;
	private long countryCodeId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(long organizationId) {
		this.organizationId = organizationId;
	}

	public String getInsuranceCompanyName() {
		return insuranceCompanyName;
	}

	public void setInsuranceCompanyName(String insuranceCompanyName) {
		this.insuranceCompanyName = insuranceCompanyName;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

}
