package com.billdog.entities.view;

public class BrokerCompanyInfo {

	private long brokerCompanyId;
	private String brokerCompanyAffiliation;

	public long getBrokerCompanyId() {
		return brokerCompanyId;
	}

	public void setBrokerCompanyId(long brokerCompanyId) {
		this.brokerCompanyId = brokerCompanyId;
	}

	public String getBrokerCompanyAffiliation() {
		return brokerCompanyAffiliation;
	}

	public void setBrokerCompanyAffiliation(String brokerCompanyAffiliation) {
		this.brokerCompanyAffiliation = brokerCompanyAffiliation;
	}


}
