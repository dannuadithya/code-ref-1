package com.billdog.entities.common;

public class AuditConstants {

	public static final String CONTACT_NUMBER = "Contact number: ";
	public static final String CONTACT_PERSON_NAME = "Contact person name: ";
	public static final String ADDRESS = "Address: ";
	public static final String EMAIL_ID = "Email id: ";

	public static final String SFDC_ID = "Sfdc id: ";
	public static final String STATUS = "Status: ";

	public static final String BROKER_COMPANY_NAME = "Broker company name: ";

	public static final String FIRST_NAME = "First name: ";
	public static final String LAST_NAME = "Last name: ";

	public static final String EMPLOYER_NAME = "Employer name: ";
	public static final String COMPANY_PROVIDER_NAME = "Company provider name: ";
	public static final String INSURANCE_COMPANY_NAME = "Insurance company name: ";

}
