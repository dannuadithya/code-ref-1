package com.billdog.entities.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.GroupOpportunities;
import com.billdog.entities.entity.Opportunity;
import com.billdog.entities.entity.OpportunitySubTypeMaster;
import com.billdog.entities.entity.OpportunityTypeMaster;
import com.billdog.entities.entity.SubOpportunity;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.GroupOpportunitiesRepository;
import com.billdog.entities.repository.OpportunityRepository;
import com.billdog.entities.repository.OpportunitySubTypeMasterRepository;
import com.billdog.entities.repository.OpportunityTypeMasterRepository;
import com.billdog.entities.repository.SubOpportunityRepository;
import com.billdog.entities.request.BlockConversionRequest;
import com.billdog.entities.view.ViewOpportunityTypes;
import com.billdog.entities.view.ViewResponse;

@Service
public class BlockConversionService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(BlockConversionService.class);

	@Autowired
	OpportunityRepository opportunityRepository;

	@Autowired
	SubOpportunityRepository subOpportunityRepository;

	@Autowired
	GroupOpportunitiesRepository groupOpportunitiesRepository;

	@Autowired
	OpportunitySubTypeMasterRepository opportunitySubTypeMasterRepository;

	@Autowired
	OpportunityTypeMasterRepository opportunityTypeMasterRepository;

	@Autowired
	UserService userService;

	public ViewResponse getAllOpportunities() {
		LOGGER.info("getAllOpportunities method started..!");

		List<ViewOpportunityTypes> opportunitySubTypeList = new ArrayList<>();
		// fetching all opportunities
		List<OpportunitySubTypeMaster> opportunitySubTypeMaster = opportunitySubTypeMasterRepository
				.findAllByIsBlockConversion(true);
		if (!opportunitySubTypeMaster.isEmpty()) {
			opportunitySubTypeMaster.forEach(opportunitySubType -> {
				ViewOpportunityTypes viewOpportunityTypes = new ViewOpportunityTypes();
				viewOpportunityTypes.setOpportunityId(opportunitySubType.getId());
				viewOpportunityTypes.setOpportunityName(opportunitySubType.getOpportunityChildName());
				opportunitySubTypeList.add(viewOpportunityTypes);
			});
		}
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.OPPORTUNITIES);
		viewResponse.setData(opportunitySubTypeList);
		viewResponse.setTotal(opportunitySubTypeMaster.size());
		LOGGER.info("getAllOpportunities method has ended..!");
		return viewResponse;
	}

	public ViewResponse getOpportunitiesByOpportunityId(Long opportunityId) {
		LOGGER.info("getOpportunitiesByOpportunityId method started..!");

		List<ViewOpportunityTypes> opportunitySubTypeList = new ArrayList<>();
		// checking all opportunities
		Optional<OpportunitySubTypeMaster> opportunitySubTypeMaster = opportunitySubTypeMasterRepository
				.findById(opportunityId);
		if (!opportunitySubTypeMaster.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.OPPORTUNITY_NOT_FOUND);
		}
		LOGGER.info("Opportunity fetched with Id {}" + opportunitySubTypeMaster.get().getId());
		List<GroupOpportunities> groupOpportunities = groupOpportunitiesRepository
				.findByOpportunityTypeMasterId(opportunitySubTypeMaster.get());
		if (!groupOpportunities.isEmpty()) {
			groupOpportunities.forEach(opportunitySubType -> {
				ViewOpportunityTypes viewOpportunityTypes = new ViewOpportunityTypes();
				viewOpportunityTypes.setOpportunityId(opportunitySubType.getId());
				viewOpportunityTypes.setOpportunityName(opportunitySubType.getOpportunityName());
				opportunitySubTypeList.add(viewOpportunityTypes);
			});
		}
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.OPPORTUNITIES);
		viewResponse.setData(opportunitySubTypeList);
		viewResponse.setTotal(groupOpportunities.size());
		LOGGER.info("getOpportunitiesByOpportunityId method has ended..!");
		return viewResponse;
	}

	public ViewResponse getAllBlockOpportunities() {
		LOGGER.info("getAllBlockOpportunities method started..!");

		List<ViewOpportunityTypes> opportunitySubTypeList = new ArrayList<>();

		Optional<OpportunityTypeMaster> opportunityTypeMaster = opportunityTypeMasterRepository
				.findByOpportunityParentName(Constants.BLOCK);
		if (!opportunityTypeMaster.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.OPPORTUNITY_NOT_FOUND);
		}
		LOGGER.info("Opportunity fetched with " + Constants.BLOCK);
		// fetching all block opportunities
		List<Opportunity> opportunitySubTypeMaster = opportunityRepository
				.findAllByOpportunityTypeMasterId(opportunityTypeMaster.get());
		if (!opportunitySubTypeMaster.isEmpty()) {
			opportunitySubTypeMaster.forEach(opportunitySubType -> {
				ViewOpportunityTypes viewOpportunityTypes = new ViewOpportunityTypes();
				viewOpportunityTypes.setOpportunityId(opportunitySubType.getId());
				viewOpportunityTypes.setOpportunityName(opportunitySubType.getOpportunityName());
				opportunitySubTypeList.add(viewOpportunityTypes);
			});
		}
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.OPPORTUNITIES);
		viewResponse.setData(opportunitySubTypeList);
		viewResponse.setTotal(opportunitySubTypeMaster.size());
		LOGGER.info("getAllBlockOpportunities method has ended..!");
		return viewResponse;
	}

	public ViewResponse getAllBrokerSponsored() {
		LOGGER.info("getAllBrokerSponsored method started..!");

		List<ViewOpportunityTypes> opportunitySubTypeList = new ArrayList<>();

		Optional<OpportunitySubTypeMaster> opportunitySubTypeMaster = opportunitySubTypeMasterRepository
				.findByOpportunityChildName(Constants.BROKER_SPONSORED);
		if (!opportunitySubTypeMaster.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.BROKER_SPONSORED_NOT_FOUND);
		}
		LOGGER.info("Opportunity fetched with " + Constants.BROKER_SPONSORED);
		// fetching all broker sponsored
		List<SubOpportunity> subOpportunityOpportunities = subOpportunityRepository
				.findAllByOpportunitySubTypeMasterId(opportunitySubTypeMaster.get());
		if (!subOpportunityOpportunities.isEmpty()) {
			subOpportunityOpportunities.forEach(opportunitySubType -> {
				ViewOpportunityTypes viewOpportunityTypes = new ViewOpportunityTypes();
				viewOpportunityTypes.setOpportunityId(opportunitySubType.getId());
				viewOpportunityTypes.setOpportunityName(opportunitySubType.getSubGroupOpportunityName());
				opportunitySubTypeList.add(viewOpportunityTypes);
			});
		}
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.BROKER_SPONSORED_FECTED);
		viewResponse.setData(opportunitySubTypeList);
		viewResponse.setTotal(subOpportunityOpportunities.size());
		LOGGER.info("getAllBrokerSponsored method has ended..!");
		return viewResponse;
	}

	public ResponseEntity<ViewResponse> blockConversion(BlockConversionRequest blockConversionRequest, Long orgId) {
		LOGGER.info("blockConversion method started..!");

		// checking whether opportunity is present or not
		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository
				.findById(blockConversionRequest.getOpportunityId());
		if (!subOpportunityOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.OPPORTUNITY_NOT_FOUND);
		}
		LOGGER.info("Opportunity fetched with {} Id " + subOpportunityOptional.get().getId());
		SubOpportunity subOpportunity = subOpportunityOptional.get();

		convertToBrokerSponsered(blockConversionRequest, subOpportunity, orgId);

		convertToDirectToEmployer(blockConversionRequest, subOpportunity);

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.BLOCK_CONVERSION);
		LOGGER.info("blockConversion method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	private void convertToBrokerSponsered(BlockConversionRequest blockConversionRequest, SubOpportunity subOpportunity,
			Long orgId) {
		LOGGER.info("converting to Broker sponsored");
		if (blockConversionRequest.getConversionTo().equalsIgnoreCase(Constants.BROKER_SPONSORED)) {
			Optional<OpportunitySubTypeMaster> opportunitySubTypeMaster = opportunitySubTypeMasterRepository
					.findByOpportunityChildName(Constants.BROKER_SPONSORED);
			if (!opportunitySubTypeMaster.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.BROKER_SPONSORED_NOT_FOUND);
			}
			LOGGER.info("Opportunity fetched with " + Constants.BROKER_SPONSORED);
			if (blockConversionRequest.getOpportunityName() != null) {
				// checking whether name with opportunity exists
				Optional<SubOpportunity> opportunityOptional = subOpportunityRepository
						.findBySubGroupOpportunityNameAndOpportunitySubTypeMasterId(
								blockConversionRequest.getOpportunityName(), opportunitySubTypeMaster.get());
				if (opportunityOptional.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.OPPORTUNITY_NAME);
				}
			}
			Optional<Opportunity> opportunityOptional = opportunityRepository
					.findById(subOpportunity.getOpportunityId().getId());
			if (opportunityOptional.isPresent()) {
				LOGGER.info("Opportunity fetched with {} Id " + opportunityOptional.get().getId());
				Opportunity opportunity = new Opportunity();
				opportunity.setCreatedAt(DateAndTimeUtil.now());
				opportunity.setUpdatedAt(DateAndTimeUtil.now());
				opportunity.setOpportunityName(null);
				opportunity.setBrokerCompanyId(opportunityOptional.get().getBrokerCompanyId());
				opportunity.setIndividualBrokerId(opportunityOptional.get().getIndividualBrokerId());
				Optional<OpportunityTypeMaster> opportunityTypeOptional = opportunityTypeMasterRepository
						.findByOpportunityParentNameAndOrganizationId(Constants.GROUP, orgId);
				if (opportunityTypeOptional.isPresent()) {
					LOGGER.info("Opportunity fetched with " + Constants.GROUP);
					opportunity.setOpportunityTypeMasterId(opportunityTypeOptional.get());
				}
				opportunity.setOrganizationId(opportunityOptional.get().getOrganizationId());
				opportunity.setStatus(StatusConstants.ACTIVE);
				opportunity.setUserId(blockConversionRequest.getUserId());
				opportunity.setSfdcId(null);
				opportunityRepository.save(opportunity);
				LOGGER.info("Opportunity saved with Id {}" + opportunity.getId());

				subOpportunity.setOpportunitySubTypeMasterId(opportunitySubTypeMaster.get());
				subOpportunity.setOpportunityId(opportunity);
				if (blockConversionRequest.getOpportunityName() != null
						&& !blockConversionRequest.getOpportunityName().isEmpty()) {
					subOpportunity.setSubGroupOpportunityName(blockConversionRequest.getOpportunityName());
				}
				subOpportunity.setUpdatedAt(DateAndTimeUtil.now());
				subOpportunityRepository.save(subOpportunity);
				LOGGER.info("Opportunity updated with Id {}" + subOpportunity.getId());
			}
		}

	}

	private void convertToDirectToEmployer(BlockConversionRequest blockConversionRequest,
			SubOpportunity subOpportunity) {
		LOGGER.info("converting to Direct to employer");
		if (blockConversionRequest.getConversionTo().equalsIgnoreCase(Constants.EMPLOYER_DIRECT)) {
			Optional<OpportunitySubTypeMaster> opportunitySubTypeMaster = opportunitySubTypeMasterRepository
					.findByOpportunityChildName(Constants.EMPLOYER_DIRECT);
			if (!opportunitySubTypeMaster.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_DIRECT_NOT_FOUND);
			}
			LOGGER.info("Opportunity fetched with " + Constants.EMPLOYER_DIRECT);
			if (blockConversionRequest.getOpportunityName() != null) {
				// checking whether opportunity name exists
				Optional<SubOpportunity> opportunityOptional = subOpportunityRepository
						.findBySubGroupOpportunityNameAndOpportunitySubTypeMasterId(
								blockConversionRequest.getOpportunityName(), opportunitySubTypeMaster.get());
				if (opportunityOptional.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.OPPORTUNITY_NAME);
				}
				if (blockConversionRequest.getOpportunityName() != null
						&& !blockConversionRequest.getOpportunityName().isEmpty()) {
					subOpportunity.setSubGroupOpportunityName(blockConversionRequest.getOpportunityName());
				}

			}
			subOpportunity.setUpdatedAt(DateAndTimeUtil.now());
			subOpportunity.setOpportunityId(null);
			subOpportunity.setOpportunitySubTypeMasterId(opportunitySubTypeMaster.get());
			subOpportunityRepository.save(subOpportunity);
			LOGGER.info("Opportunity updated with Id {} " + subOpportunity.getId());
		}

	}

}
