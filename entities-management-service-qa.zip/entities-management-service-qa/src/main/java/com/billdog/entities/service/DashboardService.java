package com.billdog.entities.service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.entity.CompanyProvider;
import com.billdog.entities.entity.IndividualProvider;
import com.billdog.entities.entity.InsuranceCompany;
import com.billdog.entities.repository.CompanyProviderRepository;
import com.billdog.entities.repository.IndividualProviderRepository;
import com.billdog.entities.repository.InsuranceCompanyRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.view.DashboardAnalyticalView;

@Service
public class DashboardService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(DashboardService.class);

	@Autowired
	InsuranceCompanyRepository insuranceCompanyRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	UserService userService;

	@Autowired
	CompanyProviderRepository companyProviderRepository;

	@Autowired
	IndividualProviderRepository individualProviderRepository;

	/**
	 * @param insuranceCompanyRequest
	 * @param organization
	 * @return
	 */
	public ResponseEntity<DashboardAnalyticalView> dashboardAnalytical() {
		LOGGER.info("dashboardAnalytical method started..!");

		DashboardAnalyticalView dashboardAnalyticalView = new DashboardAnalyticalView();
		List<CompanyProvider> companyProvider = companyProviderRepository.findAll();
		if (!companyProvider.isEmpty()) {
			dashboardAnalyticalView.setCompanyProviderCount(companyProvider.size());
		}
		List<InsuranceCompany> insuranceCompany = insuranceCompanyRepository.findAll();
		if (!companyProvider.isEmpty()) {
			dashboardAnalyticalView.setInsuranceCompanyCount(insuranceCompany.size());
		}

		List<IndividualProvider> individualProvider = individualProviderRepository.findAll();
		if (!companyProvider.isEmpty()) {
			dashboardAnalyticalView.setIndividualProviderCount(individualProvider.size());
		}
		Long memberCount = insuranceCompanyRepository.getSumOfMember();
		Long familyMemberCount = insuranceCompanyRepository.getSumOfMemberFamily();

		dashboardAnalyticalView.setTotalServingMember(memberCount + familyMemberCount);

		LocalDate currentMonthFirstDate = LocalDate.now().withDayOfMonth(1);
		LocalDate lastMonthFirstDate = YearMonth.now().minusMonths(1).atDay(1);
		LocalDate lastMonthTodayDate = LocalDate.now().minusMonths(1);

		LocalDate localDate = LocalDate.now();

		Long familyMemberCount1 = insuranceCompanyRepository.getSumOfMembers(currentMonthFirstDate.toString(),
				localDate.toString());
		Long family1 = insuranceCompanyRepository.getSumOfFamilyMembers(currentMonthFirstDate.toString(),
				localDate.toString());

		Long memberFamilyThisMonth = familyMemberCount1 + family1;

		Long familyMemberCount2 = insuranceCompanyRepository.getSumOfMembers(lastMonthFirstDate.toString(),
				lastMonthTodayDate.toString());
		Long family2 = insuranceCompanyRepository.getSumOfFamilyMembers(lastMonthFirstDate.toString(),
				lastMonthTodayDate.toString());

		Long memberFamilyPreMonth = familyMemberCount2 + family2;

		if (memberFamilyThisMonth != 0) {
			Long difference = memberFamilyThisMonth - memberFamilyPreMonth;
			Double MemberPercentage = (difference.doubleValue() / memberFamilyThisMonth.doubleValue())
					* Constants.HUNDRED;

			dashboardAnalyticalView.setTotalServingMemberGrowth(MemberPercentage);
		} else {
			dashboardAnalyticalView.setTotalServingMemberGrowth(null);
		}

		Long firstOfMonthToCurrentDate = companyProviderRepository
				.getSumOfCompanyProvider(currentMonthFirstDate.toString(), LocalDate.now().toString());

		Long firstOfPreMonthToPreDate = companyProviderRepository.getSumOfCompanyProvider(lastMonthFirstDate.toString(),
				lastMonthTodayDate.toString());

		if (firstOfMonthToCurrentDate != 0) {
			Long differenceOfTwoMonths = firstOfMonthToCurrentDate - firstOfPreMonthToPreDate;

			Double companyProvidePercentage = (differenceOfTwoMonths.doubleValue()
					/ firstOfMonthToCurrentDate.doubleValue()) * Constants.HUNDRED;

			dashboardAnalyticalView.setCompanyProviderGrowth(companyProvidePercentage);
		} else {
			dashboardAnalyticalView.setCompanyProviderGrowth(null);
		}

		Long individualFirstOfMonthToCurrentDate = individualProviderRepository
				.getSumOfIndividualProvider(currentMonthFirstDate.toString(), LocalDate.now().toString());

		Long individualFirstOfPreMonthToPreDate = individualProviderRepository
				.getSumOfIndividualProvider(lastMonthFirstDate.toString(), lastMonthTodayDate.toString());

		if (individualFirstOfMonthToCurrentDate != 0) {
			Long individualDifferenceOfTwoMonths = individualFirstOfMonthToCurrentDate
					- individualFirstOfPreMonthToPreDate;

			Double individualProviderPercentage = (individualDifferenceOfTwoMonths.doubleValue()
					/ individualFirstOfMonthToCurrentDate.doubleValue()) * Constants.HUNDRED;

			dashboardAnalyticalView.setIndividualProviderGrowth(individualProviderPercentage);
		} else {
			dashboardAnalyticalView.setIndividualProviderGrowth(null);
		}

		Long InsuranceFirstOfMonthToCurrentDate = insuranceCompanyRepository
				.getSumOfInsuranceCompany(currentMonthFirstDate.toString(), LocalDate.now().toString());

		Long InsuranceFirstOfPreMonthToPreDate = insuranceCompanyRepository
				.getSumOfInsuranceCompany(lastMonthFirstDate.toString(), lastMonthTodayDate.toString());

		if (InsuranceFirstOfMonthToCurrentDate != 0) {
			Long InsuranceDifferenceOfTwoMonths = InsuranceFirstOfMonthToCurrentDate
					- InsuranceFirstOfPreMonthToPreDate;

			Double InsuranceCompanyPercentage = (InsuranceDifferenceOfTwoMonths.doubleValue()
					/ InsuranceFirstOfMonthToCurrentDate.doubleValue()) * Constants.HUNDRED;

			dashboardAnalyticalView.setInsuranceCompanyGrowth(InsuranceCompanyPercentage);
		} else {
			dashboardAnalyticalView.setInsuranceCompanyGrowth(null);
		}

		LOGGER.info("dashboardAnalytical method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(dashboardAnalyticalView);
	}

}
