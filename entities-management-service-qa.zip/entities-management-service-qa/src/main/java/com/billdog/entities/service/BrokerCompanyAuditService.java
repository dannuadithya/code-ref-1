package com.billdog.entities.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.AuditConstants;
import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.RecordsTime;
import com.billdog.entities.repository.BrokerCompanyRepository;
import com.billdog.entities.request.AuditRequest;
import com.billdog.entities.view.GetUsers;
import com.billdog.entities.view.ViewAuditResponse;
import com.billdog.entities.view.ViewResponse;
import com.billdog.entities.view.ViewUserInfo;

@Service
public class BrokerCompanyAuditService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(BrokerCompanyAuditService.class);

	@Autowired
	BrokerCompanyRepository brokerCompanyRepository;

	@Autowired
	AuditService auditService;

	@Autowired
	EmployerAuditService employerAuditService;

	public ResponseEntity<ViewResponse> getBrokerCompanyAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {
		LOGGER.info("getBrokerCompanyAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = auditService.getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (!StringUtils.isBlank(auditRequest.getTimePeriod())
				&& auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.CUSTOM.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}


		Page<Object[]> brokerCompanyList = brokerCompanyRepository.getBrokerCompanyAuditInfo(name, name,
				startDate, endDate, revtypes, auditRequest.getOrganizationId(),
				getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getData(brokerCompanyList.getContent());
		if (brokerCompanyList.getTotalElements() > pageLimit) {
			response.setTotalElements(brokerCompanyList.getTotalElements());
		}

		LOGGER.info("getBrokerCompanyAuditInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getBrokerCompanyAuditInfoById(Long id, Integer pageNumber, Integer pageLimit) {
		LOGGER.info("getBrokerCompanyAuditInfoById method started");
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null && pageLimit > 0 ? pageLimit : 20;
		Page<Object[]> brokerCompanyList = brokerCompanyRepository.getBrokerCompanyAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));

		ViewResponse response = getData(brokerCompanyList.getContent());
		if (brokerCompanyList.getTotalElements() > pageLimit) {
			response.setTotalElements(brokerCompanyList.getTotalElements());
		}

		LOGGER.info("getBrokerCompanyAuditInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getData(List<Object[]> brokerCompanyList) {
		List<ViewAuditResponse> auditResponses = new ArrayList<>();
		GetUsers usersInfoList = getUsersInfoList(brokerCompanyList);
		brokerCompanyList.forEach(item -> {
			ViewAuditResponse auditResponse = new ViewAuditResponse();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> empObj = brokerCompanyRepository.getBrokerCompanyAuditInfoByIdAndNav(
						((BigInteger) item[0]).longValue(), ((Integer) item[10]).longValue());
				if (empObj != null && !empObj.isEmpty()) {
					for (Object[] item2 : empObj) {
						auditResponse = setValues(item, item2, auditResponse, usersInfoList.getData());
					}
				}
				if (auditResponse != null && (!StringUtils.isBlank(auditResponse.getOldValue())
						|| !StringUtils.isBlank(auditResponse.getNewValue()))) {
					auditResponses.add(auditResponse);
				} else {
					auditResponse.setNewValue(Constants.NO_CHANGE);
					auditResponse.setOldValue(Constants.NO_CHANGE);
					auditResponses.add(auditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				auditResponse = setCreatedBrokerCompany(item, auditResponse, usersInfoList.getData());
				if (auditResponse != null && !StringUtils.isBlank(auditResponse.getNewValue())) {
					auditResponses.add(auditResponse);
				}
			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(brokerCompanyList.size());
		response.setMessage(Constants.BROKER_COMPANY_AUDIT_LIST_FETCHED);
		if (auditResponses.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(auditResponses);
		return response;
	}

	private GetUsers getUsersInfoList(List<Object[]> users) {
		List<Long> userIds = new ArrayList<>();
		users.forEach(user -> {
			if (user[9] != null) {
				userIds.add(((BigInteger) user[9]).longValue());
			}
		});
		return employerAuditService.getUsersList(userIds);
	}

	private ViewAuditResponse setValues(Object[] item, Object[] item2, ViewAuditResponse auditResponse,
			List<ViewUserInfo> usersInfo) {
		boolean updated = false;
		String oldValue = null;
		String newValue = null;

		Timestamp updatedAt = (Timestamp) item[2];


		if (!StringUtils.isBlank((String) item[3]) && !StringUtils.isBlank((String) item2[3])
				&& !((String) item[3]).equalsIgnoreCase((String) item2[3])) {
			updated = true;
			oldValue = AuditConstants.BROKER_COMPANY_NAME + item2[3];
			newValue = AuditConstants.BROKER_COMPANY_NAME + item[3];
		}
		if (!StringUtils.isBlank((String) item[3]) && StringUtils.isBlank((String) item2[3])) {
			updated = true;
			newValue = AuditConstants.BROKER_COMPANY_NAME + item[3];
		}
		if (StringUtils.isBlank((String) item[3]) && !StringUtils.isBlank((String) item2[3])) {
			updated = true;
			oldValue = AuditConstants.BROKER_COMPANY_NAME + item2[3];
		}

		if (!StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])
				&& !((String) item[4]).equalsIgnoreCase((String) item2[4])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.CONTACT_NUMBER + item2[4]
					: AuditConstants.CONTACT_NUMBER + item2[4];
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_NUMBER + item[4]
					: AuditConstants.CONTACT_NUMBER + item[4];
		}
		if (!StringUtils.isBlank((String) item[4]) && StringUtils.isBlank((String) item2[4])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_NUMBER + item[4]
					: AuditConstants.CONTACT_NUMBER + item[4];
		}
		if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[4])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.CONTACT_NUMBER + item2[4]
					: AuditConstants.CONTACT_NUMBER + item2[4];
		}

		if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])
				&& !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item2[5]
					: AuditConstants.CONTACT_PERSON_NAME + item2[5];
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item[5]
					: AuditConstants.CONTACT_PERSON_NAME + item[5];
		}
		if (!StringUtils.isBlank((String) item[5]) && StringUtils.isBlank((String) item2[5])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item[5]
					: AuditConstants.CONTACT_PERSON_NAME + item[5];
		}
		if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item2[5]
					: AuditConstants.CONTACT_PERSON_NAME + item2[5];
		}

		if (!StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])
				&& !((String) item[6]).equalsIgnoreCase((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.EMAIL_ID + item2[6]
					: AuditConstants.EMAIL_ID + item2[6];
			newValue = newValue != null ? newValue + ", " + AuditConstants.EMAIL_ID + item[6]
					: AuditConstants.EMAIL_ID + item[6];
		}
		if (!StringUtils.isBlank((String) item[6]) && StringUtils.isBlank((String) item2[6])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.EMAIL_ID + item[6]
					: AuditConstants.EMAIL_ID + item[6];
		}
		if (StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.EMAIL_ID + item2[6]
					: AuditConstants.EMAIL_ID + item2[6];
		}
		if (!StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])
				&& !((String) item[7]).equalsIgnoreCase((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.SFDC_ID + item2[7]
					: AuditConstants.SFDC_ID + item2[7];
			newValue = newValue != null ? newValue + ", " + AuditConstants.SFDC_ID + item[7]
					: AuditConstants.SFDC_ID + item[7];
		}
		if (!StringUtils.isBlank((String) item[7]) && StringUtils.isBlank((String) item2[7])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.SFDC_ID + item[7]
					: AuditConstants.SFDC_ID + item[7];
		}
		if (StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.SFDC_ID + item2[7]
					: AuditConstants.SFDC_ID + item2[7];
		}
		if (!StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])
				&& !((String) item[8]).equalsIgnoreCase((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.STATUS + item2[8]
					: AuditConstants.STATUS + item2[8];
			newValue = newValue != null ? newValue + ", " + AuditConstants.STATUS + item[8]
					: AuditConstants.STATUS + item[8];
		}
		if (!StringUtils.isBlank((String) item[8]) && StringUtils.isBlank((String) item2[8])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.STATUS + item[8]
					: AuditConstants.STATUS + item[8];
		}
		if (StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.STATUS + item2[8]
					: AuditConstants.STATUS + item2[8];
		}

		if (!StringUtils.isBlank((String) item[11]) && !StringUtils.isBlank((String) item2[11])
				&& !((String) item[11]).equalsIgnoreCase((String) item2[11])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.ADDRESS + item2[11]
					: AuditConstants.ADDRESS + item2[11];
			newValue = newValue != null ? newValue + ", " + AuditConstants.ADDRESS + item[11]
					: AuditConstants.ADDRESS + item[11];
		}
		if (!StringUtils.isBlank((String) item[11]) && StringUtils.isBlank((String) item2[11])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.ADDRESS + item[11]
					: AuditConstants.ADDRESS + item[11];
		}
		if (StringUtils.isBlank((String) item[11]) && !StringUtils.isBlank((String) item2[11])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.ADDRESS + item2[11]
					: AuditConstants.ADDRESS + item2[11];
		}
		if (updated) {
			auditResponse.setRecordId(((BigInteger) item[0]).longValue());
			if (item[9] != null) {
				ViewUserInfo userInfo = employerAuditService.getUserInfo(((BigInteger) item[9]).longValue(),
						usersInfo);
				auditResponse.setUpdatedById(item[9] != null ? ((BigInteger) item[9]).longValue() : 0);
				if (!StringUtils.isBlank(userInfo.getName())) {
					auditResponse.setModifiedBy(userInfo.getName());
				}
			}
			auditResponse.setMemberOrUser(Constants.USER);
			auditResponse.setAction(getAction(item[1]));
			auditResponse.setOldValue(oldValue);
			auditResponse.setNewValue(newValue);
			auditResponse.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
									+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			return auditResponse;
		}
		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		if (item[9] != null) {
			ViewUserInfo userInfo = employerAuditService.getUserInfo(((BigInteger) item[9]).longValue(), usersInfo);
			auditResponse.setUpdatedById(item[9] != null ? ((BigInteger) item[9]).longValue() : 0);
			if (!StringUtils.isBlank(userInfo.getName())) {
				auditResponse.setModifiedBy(userInfo.getName());
			}
		}
		auditResponse.setMemberOrUser(Constants.USER);
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		return auditResponse;
	}

	private String getAction(Object item) {
		String action = null;
		int actionValue = ((Byte) item);
		if (actionValue == 0) {
			action = Constants.CREATED;
		}
		if (actionValue == 1) {
			action = Constants.UPDATED;
		}
		if (actionValue == 2) {
			action = Constants.DELETED;
		}
		return action;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	private ViewAuditResponse setCreatedBrokerCompany(Object[] item, ViewAuditResponse auditResponse,
			List<ViewUserInfo> usersInfo) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];

		if (item[3] != null && !StringUtils.isBlank((String) item[3])) {
			newValue = AuditConstants.BROKER_COMPANY_NAME + item[3];
		}
		if (item[4] != null && !StringUtils.isBlank((String) item[4])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_NUMBER + item[4]
					: AuditConstants.CONTACT_NUMBER + item[4];
		}
		if (item[5] != null && !StringUtils.isBlank((String) item[5])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item[5]
					: AuditConstants.CONTACT_PERSON_NAME + item[5];
		}
		if (item[6] != null && !StringUtils.isBlank((String) item[6])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.EMAIL_ID + item[6]
					: AuditConstants.EMAIL_ID + item[6];
		}
		if (item[7] != null && !StringUtils.isBlank((String) item[7])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.SFDC_ID + item[7]
					: AuditConstants.SFDC_ID + item[7];
		}
		if (item[8] != null && !StringUtils.isBlank((String) item[8])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.STATUS + item[8]
					: AuditConstants.STATUS + item[8];
		}

		if (item[11] != null && !StringUtils.isBlank((String) item[11])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.ADDRESS + item[11]
					: AuditConstants.ADDRESS + item[11];
		}

		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		if (item[9] != null) {
			ViewUserInfo userInfo = employerAuditService.getUserInfo(((BigInteger) item[9]).longValue(), usersInfo);
			auditResponse.setUpdatedById(item[9] != null ? ((BigInteger) item[9]).longValue() : 0);
			if (!StringUtils.isBlank(userInfo.getName())) {
				auditResponse.setModifiedBy(userInfo.getName());
			}
		}
		auditResponse.setMemberOrUser(Constants.USER);
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		auditResponse.setNewValue(newValue);
		return auditResponse;

	}

}
