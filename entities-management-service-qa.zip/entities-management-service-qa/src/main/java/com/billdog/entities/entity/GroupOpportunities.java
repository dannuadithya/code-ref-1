package com.billdog.entities.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "GROUP_OPPORTUNITIES")
@Table(name = "group_opportunities", indexes = { @Index(name = "id_index", columnList = "ID", unique = true) })
public class GroupOpportunities extends BaseEntity {

	@Column(name = "opportunity_name")
	private String opportunityName;

	@ManyToOne
	@JoinColumn(name = "opportunity_sub_type_Id")
	private OpportunitySubTypeMaster opportunityTypeMasterId;

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public OpportunitySubTypeMaster getOpportunityTypeMasterId() {
		return opportunityTypeMasterId;
	}

	public void setOpportunityTypeMasterId(OpportunitySubTypeMaster opportunityTypeMasterId) {
		this.opportunityTypeMasterId = opportunityTypeMasterId;
	}

}
