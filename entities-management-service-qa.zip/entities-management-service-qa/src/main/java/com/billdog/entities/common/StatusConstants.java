package com.billdog.entities.common;

public class StatusConstants {

	public static final String ACTIVE = "Active";
	public static final String ENROLLED = "Enrolled";
	public static final String INACTIVE = "Inactive";


}
