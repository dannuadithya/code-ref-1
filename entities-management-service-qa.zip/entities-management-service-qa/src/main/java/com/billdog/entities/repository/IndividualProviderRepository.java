package com.billdog.entities.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.history.RevisionRepository;

import com.billdog.entities.entity.CompanyProvider;
import com.billdog.entities.entity.IndividualProvider;

public interface IndividualProviderRepository
		extends JpaRepository<IndividualProvider, Long>, RevisionRepository<IndividualProvider, Long, Integer> {

	Optional<IndividualProvider> findBySfdcId(String sfdcId);

	@Query(value = "SELECT ip.first_name, ip.last_name,cp.company_name, ip.email,ip.contact_number,ip.sfdc_id,ip.status,cp.id as companyProviderId, ip.id individual_provider_id,ip.country_code_Id,ip.address FROM individual_provider ip\n"
			+ "join company_provider cp on cp.id= ip.company_provider_id where \n"
			+ "((CASE WHEN COALESCE(?1,'') <> '' THEN ip.first_name ELSE '' END LIKE COALESCE(?2,'') or\n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN ip.last_name ELSE '' END LIKE COALESCE(?4,'')) and \n"
			+ "CASE WHEN COALESCE(?5,-999) <> -999 THEN ip.company_provider_id ELSE -999 END = COALESCE(?6,-999) \n"
			+ "AND CASE WHEN COALESCE(?7,'') <> '' THEN ip.email ELSE '' END LIKE COALESCE(?8,'') \n"
			+ "AND CASE WHEN COALESCE(?9,'') <> '' THEN ip.contact_number ELSE '' END LIKE COALESCE(?10,'') \n"
			+ "AND  CASE WHEN COALESCE(?11,'') <> '' THEN ip.sfdc_id ELSE '' END LIKE COALESCE(?12,'') \n"
			+ "AND CASE WHEN COALESCE(?13,'') <> '' THEN ip.status ELSE '' END LIKE COALESCE(?14,'')) and ip.organization_id=?15 order by ip.created_at desc", countQuery = "SELECT ip.first_name, ip.last_name,cp.company_name, ip.email,ip.contact_number,ip.sfdc_id,ip.status,cp.id as companyProviderId, ip.id individual_provider_id,ip.country_code_Id,ip.address FROM individual_provider ip\n"
					+ "join company_provider cp on cp.id= ip.company_provider_id where \n"
					+ "((CASE WHEN COALESCE(?1,'') <> '' THEN ip.first_name ELSE '' END LIKE COALESCE(?2,'') or\n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN ip.last_name ELSE '' END LIKE COALESCE(?4,'')) and \n"
					+ "CASE WHEN COALESCE(?5,-999) <> -999 THEN ip.company_provider_id ELSE -999 END = COALESCE(?6,-999) \n"
					+ "AND CASE WHEN COALESCE(?7,'') <> '' THEN ip.email ELSE '' END LIKE COALESCE(?8,'') \n"
					+ "AND CASE WHEN COALESCE(?9,'') <> '' THEN ip.contact_number ELSE '' END LIKE COALESCE(?10,'') \n"
					+ "AND  CASE WHEN COALESCE(?11,'') <> '' THEN ip.sfdc_id ELSE '' END LIKE COALESCE(?12,'') \n"
					+ "AND CASE WHEN COALESCE(?13,'') <> '' THEN ip.status ELSE '' END LIKE COALESCE(?14,'')) and ip.organization_id=?15 order by ip.created_at desc", nativeQuery = true)
	Page<Object[][]> getProviders(String name, String name2, String name3, String name4, CompanyProvider provider1,
			CompanyProvider provider2, String email, String email2, String contactNo, String contactNo2, String sfdcId,
			String sfdcId2, String status, String status2, Long ordId, PageRequest pageRequest);

	@Query(value = "SELECT count(*) FROM individual_provider\n"
			+ "where date(created_at) between ?1 and ?2", nativeQuery = true)
	Long getSumOfIndividualProvider(String string, String string2);

	List<IndividualProvider> findByCompanyProviderId(CompanyProvider companyProviderId);

	@Query(value = "select ip.id, ip.revType, ip.updated_at, ip.address, ip.first_name, ip.last_name,  ip.contact_number,\n"
			+ "       ip.email, ip.sfdc_id, ip.status, ip.user_id, ip.company_provider_id , cp.company_name, rev from individual_provider_aud ip\n"
			+ "join company_provider cp on cp.id = ip.company_provider_id\n"
			+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN ip.first_name ELSE '' END LIKE COALESCE(?2,'')\n"
			+ "and CASE WHEN COALESCE(?3,'') <> '' THEN ip.last_name ELSE '' END LIKE COALESCE(?4,'')\n"
			+ "and date(ip.updated_at) BETWEEN ?5\n" + "AND ?6 and ip.revType in ?7 and cp.organization_id=?8 \n"
			+ "order by ip.updated_at desc,ip.rev desc", countQuery = "select ip.id, ip.revType, ip.updated_at, ip.address, ip.first_name, ip.last_name,  ip.contact_number,\n"
					+ "       ip.email, ip.sfdc_id, ip.status, ip.user_id, ip.company_provider_id , cp.company_name, rev from individual_provider_aud ip\n"
					+ "join company_provider cp on cp.id = ip.company_provider_id\n"
					+ "where  (CASE WHEN COALESCE(?1,'') <> '' THEN ip.first_name ELSE '' END LIKE COALESCE(?2,'')\n"
					+ " or CASE WHEN COALESCE(?3,'') <> '' THEN ip.last_name ELSE '' END LIKE COALESCE(?4,''))\n"
					+ "and date(ip.updated_at) BETWEEN ?5\n"
					+ "AND ?6 and ip.revType in ?7 and cp.organization_id=?8 \n"
					+ "order by ip.updated_at desc,ip.rev desc", nativeQuery = true)
	Page<Object[]> getIndividualProviderAuditInfo(String name, String name2, String name3, String name4, String string,
			String endDate, List<Long> revtypes, long orgId, PageRequest pageRequest);

	@Query(value = "select ip.id, ip.revType, ip.updated_at, ip.address, ip.first_name, ip.last_name,  ip.contact_number,\n"
			+ "ip.email, ip.sfdc_id, ip.status, ip.user_id, ip.company_provider_id , cp.company_name, rev from individual_provider_aud ip\n"
			+ "join company_provider cp on cp.id = ip.company_provider_id\n" + "where  ip.id=?1 \n"
			+ "order by ip.rev desc", countQuery = "select ip.id, ip.revType, ip.updated_at, ip.address, ip.first_name, ip.last_name,  ip.contact_number,\n"
					+ "ip.email, ip.sfdc_id, ip.status, ip.user_id, ip.company_provider_id , cp.company_name, rev from individual_provider_aud ip\n"
					+ "join company_provider cp on cp.id = ip.company_provider_id\n" + "where  ip.id=?1 \n"
					+ "order by ip.rev desc", nativeQuery = true)
	Page<Object[]> getIndividualProvidersAuditInfoById(Long id, PageRequest pageRequest);

	@Query(value = "select ip.id, ip.revType, ip.updated_at, ip.address, ip.first_name, ip.last_name,  ip.contact_number,\n"
			+ "ip.email, ip.sfdc_id, ip.status, ip.user_id, ip.company_provider_id , cp.company_name, rev from individual_provider_aud ip\n"
			+ "join company_provider cp on cp.id = ip.company_provider_id where  ip.id=?1  and ip.rev<?2 \n"
			+ "order by ip.rev desc limit 1", countQuery = "select ip.id, ip.revType, ip.updated_at, ip.address, ip.first_name, ip.last_name,  ip.contact_number,\n"
					+ "ip.email, ip.sfdc_id, ip.status, ip.user_id, ip.company_provider_id , cp.company_name, rev from individual_provider_aud ip\n"
					+ "join company_provider cp on cp.id = ip.company_provider_id where  ip.id=?1 and ip.rev<?2 \n"
					+ "order by ip.rev desc limit 1", nativeQuery = true)
	List<Object[]> getIndividualProvidersAuditInfoByIdAndRev(long longValue, long longValue2);

}
