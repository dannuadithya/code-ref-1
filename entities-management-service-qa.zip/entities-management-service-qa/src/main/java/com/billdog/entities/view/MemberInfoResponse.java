package com.billdog.entities.view;

public class MemberInfoResponse {

	private String status;
	private String message;
	private Boolean valid;
	private Long id;
	private Long userId;
	private String memberId;
	private Long organizationId;
	private String memberStatus;
	private String memberEmail;
	private String memberName;
	private String fromEmail;
	private String organizationContact;
	private String organizationName;
	private String tokenExpiredAt;
	private String tokenMessage;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Boolean getValid() {
		return valid;
	}

	public void setValid(Boolean valid) {
		this.valid = valid;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public String getMemberStatus() {
		return memberStatus;
	}

	public void setMemberStatus(String memberStatus) {
		this.memberStatus = memberStatus;
	}

	public String getMemberEmail() {
		return memberEmail;
	}

	public void setMemberEmail(String memberEmail) {
		this.memberEmail = memberEmail;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getOrganizationContact() {
		return organizationContact;
	}

	public void setOrganizationContact(String organizationContact) {
		this.organizationContact = organizationContact;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

	public String getTokenExpiredAt() {
		return tokenExpiredAt;
	}

	public void setTokenExpiredAt(String tokenExpiredAt) {
		this.tokenExpiredAt = tokenExpiredAt;
	}

	public String getTokenMessage() {
		return tokenMessage;
	}

	public void setTokenMessage(String tokenMessage) {
		this.tokenMessage = tokenMessage;
	}

}
