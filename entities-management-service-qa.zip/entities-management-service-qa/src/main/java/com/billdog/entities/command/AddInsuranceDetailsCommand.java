package com.billdog.entities.command;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.entity.InsuranceCompany;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.exception.InValidInputException;
import com.billdog.entities.exception.RecordExistsException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.InsuranceCompanyRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.request.InsuranceCompanyRequest;
import com.billdog.entities.service.AddInsuranceCompanyService;
import com.billdog.entities.view.ViewResponse;

@Service
public class AddInsuranceDetailsCommand implements Command<InsuranceCompanyRequest, ResponseEntity<ViewResponse>> {

	@Autowired
	AddInsuranceCompanyService addInsuranceCompanyService;

	@Autowired
	InsuranceCompanyRepository insuranceCompanyRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Override
	public ResponseEntity<ViewResponse> excute(InsuranceCompanyRequest insuranceCompanyRequest) {

		if (insuranceCompanyRequest.getContactNumber() != null
				&& !insuranceCompanyRequest.getContactNumber().isEmpty()) {
			if (!StringUtils.isNumeric(insuranceCompanyRequest.getContactNumber())) {
				throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER);
			}
		}

		if (insuranceCompanyRequest.getContactNumber() != null
				&& !insuranceCompanyRequest.getContactNumber().isEmpty()) {
			if (insuranceCompanyRequest.getContactNumber().length() <= 9
					|| insuranceCompanyRequest.getContactNumber().length() > 10) {
				throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
			}

		}
		if (insuranceCompanyRequest.getSfdcId() != null && !insuranceCompanyRequest.getSfdcId().isEmpty()) {
			if (insuranceCompanyRequest.getSfdcId().length() > 100) {
				throw new InValidInputException(ExceptionalMessages.SFDC_VALIDATION);
			}

		}

		if (insuranceCompanyRequest.getContactPersonName() != null
				&& !insuranceCompanyRequest.getContactPersonName().isEmpty()) {
			if (insuranceCompanyRequest.getContactPersonName().length() == 1
					|| insuranceCompanyRequest.getContactPersonName().length() > 40) {
				throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_NAME);
			}

		}

		Optional<Organization> organization = organizationRepository
				.findById(insuranceCompanyRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.ORGANIZATION_NOT_FOUND + insuranceCompanyRequest.getOrganizationId());
		}
		Optional<InsuranceCompany> insuranceCompanyEntity = insuranceCompanyRepository
				.findByName(insuranceCompanyRequest.getInsuranceCompanyName());
		if (insuranceCompanyEntity.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.INSURANCE_COMPANY_EXIST);
		}
		if (insuranceCompanyRequest.getAddress() != null && !insuranceCompanyRequest.getAddress().isEmpty()
				&& insuranceCompanyRequest.getAddress().length() > 60) {
			throw new InValidInputException(ExceptionalMessages.ADDRESS);
		}

		return ResponseEntity.status(HttpStatus.OK)
				.body(addInsuranceCompanyService.addInsuranceDetails(insuranceCompanyRequest, organization.get()));

	}
}