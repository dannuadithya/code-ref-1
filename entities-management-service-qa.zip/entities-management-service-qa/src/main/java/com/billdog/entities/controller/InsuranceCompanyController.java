package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.command.AddInsuranceDetailsCommand;
import com.billdog.entities.command.EditInsuranceDetailsCommand;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.request.EditInsuranceCompanyRequest;
import com.billdog.entities.request.InsuranceCompanyRequest;
import com.billdog.entities.request.InsuranceCompanySearchRequest;
import com.billdog.entities.request.VerifySubCaseRequest;
import com.billdog.entities.service.AddInsuranceCompanyService;
import com.billdog.entities.service.DashboardService;
import com.billdog.entities.view.DashboardAnalyticalView;
import com.billdog.entities.view.GetCarrierInfo;
import com.billdog.entities.view.ViewInsuranceCompany;
import com.billdog.entities.view.ViewMemberResponse;
import com.billdog.entities.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class InsuranceCompanyController {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(InsuranceCompanyController.class);

	@Autowired
	AddInsuranceDetailsCommand addInsuranceDetailsCommand;

	@Autowired
	AddInsuranceCompanyService addInsuranceCompanyService;

	@Autowired
	EditInsuranceDetailsCommand editInsuranceDetailsCommand;

	@Autowired
	DashboardService dashboardService;

	@Autowired
	EmployerController employerController;


	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Insurance company saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/addInsuranceCompany", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addInsuranceCompanyDetails(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody InsuranceCompanyRequest insuranceCompanyRequest) {
		employerController.isTokenValid(httpRequest, insuranceCompanyRequest.getUserId(), null);
		return addInsuranceDetailsCommand.excute(insuranceCompanyRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "carrier type fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "carrier type not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getCarrierType", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getCarrierType(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam(required = false) Long userId,
			@RequestParam(required = false) Long memberId, @RequestParam Long organizationId) {
		employerController.isTokenValid(httpRequest, userId, memberId);
		return addInsuranceCompanyService.getCarrier(userId, memberId, organizationId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "carrier type fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "carrier type not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/carrierTypeInfo", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<GetCarrierInfo> getCarrierType(@RequestParam Long carrierTypeId,
			@RequestParam Long organizationId) {
		return addInsuranceCompanyService.getCarrierById(carrierTypeId, organizationId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Insurance company saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchInsuranceCompany", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchInsuranceCompany(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest,
			@Valid @RequestBody InsuranceCompanySearchRequest insuranceCompanySearchRequest) {
		employerController.isTokenValid(httpRequest, insuranceCompanySearchRequest.getUserId(), null);
		return addInsuranceCompanyService.searchInsurance(insuranceCompanySearchRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Insurance company updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/editInsuranceCompany", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> editInsuranceCompany(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest,
			@Valid @RequestBody EditInsuranceCompanyRequest editInsuranceCompanyRequest) {
		employerController.isTokenValid(httpRequest, editInsuranceCompanyRequest.getUserId(), null);
		return editInsuranceDetailsCommand.excute(editInsuranceCompanyRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "insurance details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "insurance type not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/insuranceDetails", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewInsuranceCompany> getInsuranceDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long insuranceCompanyId) {
		return addInsuranceCompanyService.getInsuranceCompany(userId, insuranceCompanyId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Dashboard analytical details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "insurance type not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/dashboardAnalytical", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<DashboardAnalyticalView> dashboardAnalyticalDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return dashboardService.dashboardAnalytical();
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Insurance company saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/verify-sub-case-request", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> verifySubCaseRequest(@RequestBody VerifySubCaseRequest verifySubCaseRequest) {
		return addInsuranceCompanyService.verifySubCaseRequest(verifySubCaseRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Insurance company saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/insurace-company-list", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getInsuranceCompaniesList(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam Long organizationId) {
		return addInsuranceCompanyService.getInsuranceCompaniesList(organizationId);
	}
	/*
	 * @ApiResponses(value = {
	 * 
	 * @ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class,
	 * message = "Insurance company saved successfully"),
	 * 
	 * @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response =
	 * ErrorResponse.class, message = "Invalid parameters") })
	 * 
	 * @PostMapping(value = "/get-sub-case", consumes =
	 * MediaType.APPLICATION_JSON_UTF8_VALUE, produces =
	 * MediaType.APPLICATION_JSON_UTF8_VALUE) public ResponseEntity<ViewResponse>
	 * getSubCase(
	 * 
	 * @RequestBody VerifySubCaseRequest verifySubCaseRequest) { return
	 * addInsuranceCompanyService.verifySubCaseRequest(verifySubCaseRequest); }
	 */
}
