package com.billdog.entities.repository;

import com.billdog.entities.request.ExternalUserUpdateRequest;
import com.billdog.entities.request.GetUsersRequest;
import com.billdog.entities.request.MemberCountRequest;
import com.billdog.entities.view.GetCountryCodeInfo;
import com.billdog.entities.view.GetMemberCountByEmployer;
import com.billdog.entities.view.GetRoleList;
import com.billdog.entities.view.GetUsers;
import com.billdog.entities.view.MemberInfoResponse;
import com.billdog.entities.view.UpdateExternalUserView;
import com.billdog.entities.view.ViewResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface UserRepository {

	@GET("/user/v1/member-token")
	public Call<MemberInfoResponse> verifyMemberToken(@Query("memberId") Long memberId);

	@GET("/user/v1/user-token")
	public Call<MemberInfoResponse> verifyUserToken(@Query("userId") Long userId);

	@GET("/user/v1/member-info")
	public Call<MemberInfoResponse> getMemberDetials(@Query("userId") Long userId, @Query("memberId") Long memberId);

	@GET("/user/v1/getCountryCode")
	public Call<GetCountryCodeInfo> getCountryCode(@Query("countryCodeId") Long countryCodeId,
			@Query("organizationId") Long organizationId);

	@GET("/user/v1/{userId}/roles")
	public Call<GetRoleList> getRole(@Path(value = "userId") Long userId);

	@PUT("/user/v1/update-member-employer")
	public Call<ViewResponse> updateEmployer(@Query("userId") Long userId, @Query("newEmployerId") Long newEmployerId,
			@Query("oldEmployerId") Long oldEmployerId);

	@POST("/user/v1/member-employer-count")
	public Call<GetMemberCountByEmployer> getMemberCountByEmployerId(@Body MemberCountRequest memberCountRequest);

	@POST("/user/v1/users-info")
	public Call<GetUsers> getUsersInfo(@Body GetUsersRequest request);

	@PUT("/user/v1/updateExternalUser")
	public Call<UpdateExternalUserView> updateExternalUserEmail(@Body ExternalUserUpdateRequest externalUserUpdateRequest);

}
