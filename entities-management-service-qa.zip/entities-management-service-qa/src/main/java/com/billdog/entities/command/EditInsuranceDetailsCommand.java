package com.billdog.entities.command;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.entity.InsuranceCompany;
import com.billdog.entities.exception.InValidInputException;
import com.billdog.entities.exception.RecordExistsException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.InsuranceCompanyRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.request.EditInsuranceCompanyRequest;
import com.billdog.entities.service.AddInsuranceCompanyService;
import com.billdog.entities.view.ViewResponse;

@Service
public class EditInsuranceDetailsCommand implements Command<EditInsuranceCompanyRequest, ResponseEntity<ViewResponse>> {

	@Autowired
	AddInsuranceCompanyService addInsuranceCompanyService;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	InsuranceCompanyRepository insuranceCompanyRepository;

	@Override
	public ResponseEntity<ViewResponse> excute(EditInsuranceCompanyRequest editInsuranceCompanyRequest) {

		if (editInsuranceCompanyRequest.getInsuranceCompanyName() != null
				&& !editInsuranceCompanyRequest.getInsuranceCompanyName().isEmpty()) {
			if (editInsuranceCompanyRequest.getInsuranceCompanyName().length() < 2
					|| editInsuranceCompanyRequest.getInsuranceCompanyName().length() > 55) {
				throw new InValidInputException(ExceptionalMessages.INSURANCE_COMPANY_NAME);
			}
		}

		Optional<InsuranceCompany> insuranceCompanyEntity = insuranceCompanyRepository
				.findByName(editInsuranceCompanyRequest.getInsuranceCompanyName());
		if (insuranceCompanyEntity.isPresent()
				&& editInsuranceCompanyRequest.getInsuranceCompanyId() != insuranceCompanyEntity.get().getId()) {
			throw new RecordExistsException(ExceptionalMessages.INSURANCE_COMPANY_EXIST);
		}
		if (editInsuranceCompanyRequest.getContactNumber() != null
				&& !editInsuranceCompanyRequest.getContactNumber().isEmpty()) {
			if (!StringUtils.isNumeric(editInsuranceCompanyRequest.getContactNumber())) {
				throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER);
			}
		}

		if (editInsuranceCompanyRequest.getContactNumber() != null
				&& !editInsuranceCompanyRequest.getContactNumber().isEmpty()) {
			if (editInsuranceCompanyRequest.getContactNumber().length() <= 9
					|| editInsuranceCompanyRequest.getContactNumber().length() > 10) {
				throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
			}

		}
		if (editInsuranceCompanyRequest.getSfdcId() != null && !editInsuranceCompanyRequest.getSfdcId().isEmpty()) {
			if (editInsuranceCompanyRequest.getSfdcId().length() > 100) {
				throw new InValidInputException(ExceptionalMessages.SFDC_VALIDATION);
			}

		}
		if (editInsuranceCompanyRequest.getContactPersonName() != null
				&& !editInsuranceCompanyRequest.getContactPersonName().isEmpty()) {
			if (editInsuranceCompanyRequest.getContactPersonName().length() == 1
					|| editInsuranceCompanyRequest.getContactPersonName().length() > 40) {
				throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_NAME);
			}
		}

		if (editInsuranceCompanyRequest.getAddress() != null && !editInsuranceCompanyRequest.getAddress().isEmpty()
				&& editInsuranceCompanyRequest.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}

		return ResponseEntity.status(HttpStatus.OK)
				.body(addInsuranceCompanyService.editInsuranceCompany(editInsuranceCompanyRequest));

	}
}
