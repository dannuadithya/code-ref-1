package com.billdog.entities.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.history.RevisionRepository;

import com.billdog.entities.entity.CompanyProvider;
import com.billdog.entities.entity.Organization;

public interface CompanyProviderRepository
		extends JpaRepository<CompanyProvider, Long>, RevisionRepository<CompanyProvider, Long, Integer> {


	Optional<CompanyProvider> findByEmail(String email);

	@Query(value = "SELECT cp.company_name,cp.contact_person_name,cp.email,cp.contact_number,cp.sfdc_id,cp.status,cp.id as companyProviderId,cp.country_code_Id,cp.address\n"
			+ "	FROM company_provider cp\n"
			+ "	where CASE WHEN COALESCE(?1,'') <> '' THEN cp.company_name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ "	CASE WHEN COALESCE(?3,'') <> '' THEN cp.contact_person_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
			+ "	CASE WHEN COALESCE(?7,'') <> '' THEN cp.email ELSE '' END LIKE COALESCE(?8,'') AND \n"
			+ "	CASE WHEN COALESCE(?5,'') <> '' THEN cp.contact_number ELSE '' END LIKE COALESCE(?6,'') AND \n"
			+ "	CASE WHEN COALESCE(?9,'') <> '' THEN cp.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND \n"
			+ "	CASE WHEN COALESCE(?11,'') <> '' THEN cp.status ELSE '' END LIKE COALESCE(?12,'')\n"
			+ "	order by cp.created_at desc", countQuery = "SELECT cp.company_name,cp.contact_person_name,cp.email,cp.contact_number,cp.sfdc_id,cp.status,cp.id as companyProviderId,cp.country_code_Id,cp.address\n"
					+ "	FROM company_provider cp\n"
					+ "	where CASE WHEN COALESCE(?1,'') <> '' THEN cp.company_name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ "	CASE WHEN COALESCE(?3,'') <> '' THEN cp.contact_person_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
					+ "	CASE WHEN COALESCE(?7,'') <> '' THEN cp.email ELSE '' END LIKE COALESCE(?8,'') AND \n"
					+ "	CASE WHEN COALESCE(?5,'') <> '' THEN cp.contact_number ELSE '' END LIKE COALESCE(?6,'') AND \n"
					+ "	CASE WHEN COALESCE(?9,'') <> '' THEN cp.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND \n"
					+ "	CASE WHEN COALESCE(?11,'') <> '' THEN cp.status ELSE '' END LIKE COALESCE(?12,'')\n"
					+ "	order by cp.created_at desc", nativeQuery = true)

	Page<Object[][]> getCompanyProvider(String companyName, String companyName2, String contactPerson,
			String contactPerson2, String contactNo, String contactNo2, String email, String email2, String sfdcId,
			String sfdcId2, String status, String status2, PageRequest pageRequest);

	Optional<CompanyProvider> findBySfdcId(String sfdcId);

	Optional<CompanyProvider> findByCompanyName(String companyProviderName);

	List<CompanyProvider> findByOrganizationIdAndStatus(Organization organization, String active);
	
	@Query(value = "SELECT count(*) FROM company_provider\n" + 
			"where date(created_at) between ?1 and ?2", nativeQuery = true)
	Long getSumOfCompanyProvider(String string, String string2);

	@Query(value = "select cpa.id, cpa.revType,cpa.updated_at, cpa.address, cpa.company_name,  cpa.contact_number,\n"
			+ "       cpa.contact_person_name,\n"
			+ "       cpa.email,cpa.sfdc_id, cpa.status,cpa.user_id , cpa.rev from company_provider_aud cpa join company_provider cp\n"
			+ "on cp.id= cpa.id\n"
			+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN cpa.company_name ELSE '' END LIKE COALESCE(?2,'')\n"
			+ "and date(cpa.updated_at) BETWEEN ?3 AND ?4 and cpa.revType in ?5 and cp.organization_id=?6 order by cpa.updated_at desc,cpa.rev desc", countQuery = "select cpa.id, cpa.revType,cpa.updated_at, cpa.address, cpa.company_name,  cpa.contact_number,\n"
					+ "       cpa.contact_person_name,\n"
					+ "       cpa.email,cpa.sfdc_id, cpa.status,cpa.user_id , cpa.rev from company_provider_aud cpa join company_provider cp\n"
					+ "on cp.id= cpa.id\n"
					+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN cpa.company_name ELSE '' END LIKE COALESCE(?2,'')\n"
					+ "and date(cpa.updated_at) BETWEEN ?3 AND ?4 and cpa.revType in ?5 and cp.organization_id=?6 order by cpa.updated_at desc,cpa.rev desc", nativeQuery = true)
	Page<Object[]> getCompanyProviderAuditInfo(String name, String name2, String fromDate, String toDate,
			List<Long> revtypes, long orgId, PageRequest pageRequest);

	@Query(value = "select id, revType, updated_at, address, company_name,\n" + 
			"       contact_number, contact_person_name,\n" + 
			"       email,sfdc_id, status,user_id,rev from company_provider_aud\n" +
			"where id=?1 order by updated_at desc,rev desc", countQuery = "select id, revType, updated_at, address, company_name,\n"
					+
					"       contact_number, contact_person_name,\n" + 
					"       email,sfdc_id, status,user_id,rev from company_provider_aud\n"
					+ 
					"where id=?1 order by updated_at desc,rev desc", nativeQuery = true)
	Page<Object[]> getCompanyProviderAuditInfoById(long id, PageRequest pageRequest);

	@Query(value = "select id, revType,updated_at, address, company_name,  contact_number, contact_person_name,\n"
			+ "       email,sfdc_id, status,user_id , rev from company_provider_aud \n"
			+ "where id=?1 and rev<?2 order by rev desc limit 1", countQuery = "select id, revType,updated_at, address, company_name,  contact_number, contact_person_name,\n"
					+ "       email,sfdc_id, status,user_id , rev from company_provider_aud \n"
					+ "where id=?1 and rev<?2 order by rev desc limit 1", nativeQuery = true)
	List<Object[]> getCompanyProviderAuditInfoByIdAndRev(long id, long rev);

	

}
