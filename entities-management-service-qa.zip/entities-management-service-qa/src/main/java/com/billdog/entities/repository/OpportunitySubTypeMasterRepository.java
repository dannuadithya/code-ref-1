package com.billdog.entities.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.entities.entity.OpportunitySubTypeMaster;

@Repository
public interface OpportunitySubTypeMasterRepository extends JpaRepository<OpportunitySubTypeMaster, Long> {

	OpportunitySubTypeMaster findByOpportunityChildNameAndOrganizationId(String subGroup, Long organizationId);

	List<OpportunitySubTypeMaster> findAllByIsBlockConversion(boolean b);

	Optional<OpportunitySubTypeMaster> findByOpportunityChildName(String brokerSponsored);

}