package com.billdog.entities.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.CompanyProvider;
import com.billdog.entities.entity.IndividualProvider;
import com.billdog.entities.entity.InsuranceCompany;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.CompanyProviderRepository;
import com.billdog.entities.repository.IndividualProviderRepository;
import com.billdog.entities.repository.InsuranceCompanyRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.request.CompanyProviderRequest;
import com.billdog.entities.request.GetSubCaseInfoRequest;
import com.billdog.entities.request.SearchCompanyProviderRequest;
import com.billdog.entities.request.UpdateCompanyProvider;
import com.billdog.entities.view.CompanyProviderInfo;
import com.billdog.entities.view.GetCountryCodeInfo;
import com.billdog.entities.view.GetSubCaseInfo;
import com.billdog.entities.view.ViewCompanyProvider;
import com.billdog.entities.view.ViewCompanyProviderInfo;
import com.billdog.entities.view.ViewIndividualProviderInfo;
import com.billdog.entities.view.ViewInsuranceCompanyInfo;
import com.billdog.entities.view.ViewResponse;

@Service
public class CompanyProviderService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CompanyProviderService.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	UserService userService;

	@Autowired
	AddInsuranceCompanyService addInsuranceCompanyService;

	@Autowired
	CompanyProviderRepository companyProviderRepository;

	@Autowired
	IndividualProviderRepository individualProviderRepository;

	@Autowired
	InsuranceCompanyRepository insuranceCompanyRepository;

	public ResponseEntity<ViewResponse> addCompanyProvider(CompanyProviderRequest companyProviderRequest) {
		LOGGER.info("addCompanyProvider method started..!");
		if (StringUtils.isBlank(companyProviderRequest.getCompanyProviderName())) {
			throw new BadRequestException(ExceptionalMessages.COMPANY_PROVIDER_NAME_SIZE);
		}
		Optional<Organization> organization = organizationRepository
				.findById(companyProviderRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.ORGANIZATION_NOT_FOUND + companyProviderRequest.getOrganizationId());
		}
		Optional<CompanyProvider> companyProviderEntity = companyProviderRepository
				.findByCompanyName(companyProviderRequest.getCompanyProviderName());
		if (companyProviderEntity.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.COMPANY_PROVIDER_NAME);
		}
		if (companyProviderRequest.getSfdcId() != null && !companyProviderRequest.getSfdcId().isEmpty()) {
			if (companyProviderRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<CompanyProvider> companyProvider = companyProviderRepository
					.findBySfdcId(companyProviderRequest.getSfdcId());
			if (companyProvider.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		if (companyProviderRequest.getAddress() != null && !companyProviderRequest.getAddress().isEmpty()
				&& companyProviderRequest.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}

		saveCompanyProvider(companyProviderRequest, organization.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.COMPANY_PROVIDER_CREATED);
		LOGGER.info("addInsuranceDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void saveCompanyProvider(CompanyProviderRequest companyProviderRequest, Organization organization) {
		LOGGER.debug("creating new object in company provider table.!!");
		CompanyProvider companyProvider = new CompanyProvider();
		companyProvider.setCreatedAt(DateAndTimeUtil.now());
		companyProvider.setUpdatedAt(DateAndTimeUtil.now());
		companyProvider.setCompanyName(WordUtils.capitalizeFully(companyProviderRequest.getCompanyProviderName()));
		companyProvider.setContactPersonName(WordUtils.capitalizeFully(companyProviderRequest.getContactPersonName()));
		companyProvider.setEmail(companyProviderRequest.getEmail());
		companyProvider.setContactNumber(companyProviderRequest.getContactNumber());
		companyProvider.setAddress(companyProviderRequest.getAddress());
		if (companyProviderRequest.getSfdcId() != null && !companyProviderRequest.getSfdcId().isEmpty()) {
			companyProvider.setSfdcId(companyProviderRequest.getSfdcId());
			companyProvider.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		companyProvider.setOrganizationId(organization);
		companyProvider.setStatus(StatusConstants.ACTIVE);
		companyProvider.setUserId(companyProviderRequest.getUserId());
		if (companyProviderRequest.getCountryCodeId() > 0) {
			checkCountryCode(companyProviderRequest.getCountryCodeId(), organization.getId());
			companyProvider.setCountryCodeId(companyProviderRequest.getCountryCodeId());
		}
		companyProviderRepository.save(companyProvider);
	}

	public GetCountryCodeInfo checkCountryCode(long countryCodeId, long orgId) {
		GetCountryCodeInfo getCountryCodeInfo = userService.getCountryCode(countryCodeId, orgId);
		if (getCountryCodeInfo == null || (!getCountryCodeInfo.getStatusText().equalsIgnoreCase(Constants.SUCCESS))) {
			throw new RecordNotFoundException(ExceptionalMessages.COUNTRY_CODE_NOT_FOUND + countryCodeId);
		}
		return getCountryCodeInfo;
	}

	public ResponseEntity<ViewResponse> searchCompanyProvider(
			SearchCompanyProviderRequest searchCompanyProviderRequest) {
		LOGGER.info("searchCompanyProvider method started..!");

		String companyName = null;
		String contactPerson = null;
		String contactNo = null;
		String email = null;
		String sfdcId = null;
		String status = null;
		if (searchCompanyProviderRequest.getCompanyName() != null
				&& !searchCompanyProviderRequest.getCompanyName().equals("")) {
			companyName = "%" + searchCompanyProviderRequest.getCompanyName() + "%";
		} else {
			companyName = searchCompanyProviderRequest.getCompanyName();
		}

		if (searchCompanyProviderRequest.getContactNo() != null
				&& !searchCompanyProviderRequest.getContactNo().equals("")) {
			contactNo = "%" + searchCompanyProviderRequest.getContactNo() + "%";
		} else {
			contactNo = searchCompanyProviderRequest.getContactNo();
		}

		if (searchCompanyProviderRequest.getContactPerson() != null
				&& !searchCompanyProviderRequest.getContactPerson().equals("")) {
			contactPerson = "%" + searchCompanyProviderRequest.getContactPerson() + "%";
		} else {
			contactPerson = searchCompanyProviderRequest.getContactPerson();
		}

		if (searchCompanyProviderRequest.getEmailId() != null
				&& !searchCompanyProviderRequest.getEmailId().equals("")) {
			email = "%" + searchCompanyProviderRequest.getEmailId() + "%";
		} else {
			email = searchCompanyProviderRequest.getEmailId();
		}

		if (searchCompanyProviderRequest.getSfdcId() != null && !searchCompanyProviderRequest.getSfdcId().equals("")) {
			sfdcId = "%" + searchCompanyProviderRequest.getSfdcId() + "%";
		} else {
			sfdcId = searchCompanyProviderRequest.getSfdcId();
		}

		status = searchCompanyProviderRequest.getStatus();

		Integer pageNumber = searchCompanyProviderRequest.getPageNumber() > 0
				? searchCompanyProviderRequest.getPageNumber()
				: 0;
		Integer pageLimit = searchCompanyProviderRequest.getPageLimit() > 0
				? searchCompanyProviderRequest.getPageLimit()
				: 20;
		// native query for searching company provider and assigning parameters
		// respectively
		Page<Object[][]> companyProvider = companyProviderRepository.getCompanyProvider(companyName, companyName,
				contactPerson, contactPerson, contactNo, contactNo, email, email, sfdcId, sfdcId, status, status,
				getPageRequest(pageNumber, pageLimit));

		// for loop for users searched with native query and assigning values
		// respectively

		List<ViewCompanyProvider> viewCompanyProviderList = getCompanyProviderList(companyProvider);
		LOGGER.debug("Setting member details for new member object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.COMPANY_PROVIDER_FETCHED);
		if (viewCompanyProviderList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewCompanyProviderList);
		response.setTotal(companyProvider.getTotalElements());

		LOGGER.info("searchCompanyProvider method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewCompanyProvider> getCompanyProviderList(Page<Object[][]> companyProvider) {
		List<ViewCompanyProvider> viewCompanyProviderList = new ArrayList<>();
		for (Object[] objects : companyProvider) {
			ViewCompanyProvider viewCompanyProvider = new ViewCompanyProvider();
			viewCompanyProvider.setCompanyName(((String) objects[0]));
			viewCompanyProvider.setContactPerson(((String) objects[1]));
			viewCompanyProvider.setContactNo((String) objects[3]);
			viewCompanyProvider.setEmailId((String) objects[2]);
			if ((String) objects[4] == null) {
				viewCompanyProvider.setSfdcId("");
			} else {
				viewCompanyProvider.setSfdcId((String) objects[4]);
			}

			viewCompanyProvider.setStatus((String) objects[5]);
			viewCompanyProvider.setCompanyProviderId(((BigInteger) objects[6]).longValue());
			if ((BigInteger) objects[7] != null) {
				viewCompanyProvider.setCountryCodeId(((BigInteger) objects[7]).longValue());
			}
			viewCompanyProvider.setAddress((String) objects[8]);
			viewCompanyProviderList.add(viewCompanyProvider);
		}
		return viewCompanyProviderList;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public ResponseEntity<ViewResponse> editCompanyProvider(UpdateCompanyProvider updateCompanyProvider) {
		LOGGER.info("editCompanyProvider method started..!");
		if (StringUtils.isBlank(updateCompanyProvider.getCompanyProviderName())) {
			throw new BadRequestException(ExceptionalMessages.COMPANY_PROVIDER_NAME_SIZE);
		}
		// checking whether company provider with given id present or not
		Optional<CompanyProvider> companyProvider = companyProviderRepository
				.findById(updateCompanyProvider.getCompanyProviderId());
		if (!companyProvider.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.COMPANY_PROVIDER_NOT_FOUND + updateCompanyProvider.getCompanyProviderId());
		}
//		if (companyProvider.get().getEmail().equalsIgnoreCase(updateCompanyProvider.getEmail())) {
//			throw new NoRecordFoundException(ExceptionalMessages.COMPANY_PROVIDER_EMAIL_EXITS);
//		}
		if (updateCompanyProvider.getSfdcId() != null && !updateCompanyProvider.getSfdcId().isEmpty()) {
			if (updateCompanyProvider.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<CompanyProvider> companyProviderEntity = companyProviderRepository
					.findBySfdcId(updateCompanyProvider.getSfdcId());
			if (companyProviderEntity.isPresent()
					&& updateCompanyProvider.getCompanyProviderId() != companyProviderEntity.get().getId()) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
			}
		}

		Optional<CompanyProvider> companyProviderEntity = companyProviderRepository
				.findByCompanyName(updateCompanyProvider.getCompanyProviderName());
		if (companyProviderEntity.isPresent()
				&& updateCompanyProvider.getCompanyProviderId() != companyProviderEntity.get().getId()) {
			throw new RecordNotFoundException(ExceptionalMessages.COMPANY_PROVIDER_NAME);
		}

		if (updateCompanyProvider.getAddress() != null && !updateCompanyProvider.getAddress().isEmpty()
				&& updateCompanyProvider.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}
		LOGGER.info("setting company provider details to respective fields");
		saveEditInsuranceDetails(updateCompanyProvider, companyProvider.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.COMPANY_PROVIDER_UPDATED);
		LOGGER.info("editCompanyProvider method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void saveEditInsuranceDetails(UpdateCompanyProvider updateCompanyProvider,
			CompanyProvider companyProvider) {

		companyProvider.setUpdatedAt(DateAndTimeUtil.now());
		companyProvider.setCompanyName(WordUtils.capitalizeFully(updateCompanyProvider.getCompanyProviderName()));
		companyProvider.setContactPersonName(WordUtils.capitalizeFully(updateCompanyProvider.getContactPersonName()));
		companyProvider.setEmail(updateCompanyProvider.getEmail());
		companyProvider.setContactNumber(updateCompanyProvider.getContactNumber());
		companyProvider.setSfdcId(updateCompanyProvider.getSfdcId());
		if (updateCompanyProvider.getSfdcId() != null && !updateCompanyProvider.getSfdcId().isEmpty()) {
			companyProvider.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		if (updateCompanyProvider.getStatus() != null && !updateCompanyProvider.getStatus().isEmpty()) {
			companyProvider.setStatus(updateCompanyProvider.getStatus());
		}
		if (updateCompanyProvider.getCountryCodeId() > 0) {
			checkCountryCode(updateCompanyProvider.getCountryCodeId(), companyProvider.getOrganizationId().getId());
			companyProvider.setCountryCodeId(updateCompanyProvider.getCountryCodeId());
		}
		companyProvider.setUserId(updateCompanyProvider.getUserId());
		companyProvider.setAddress(updateCompanyProvider.getAddress());
		companyProviderRepository.save(companyProvider);
	}

	public ResponseEntity<ViewCompanyProvider> getCompanyProvider(Long companyProviderId) {
		LOGGER.info("getCompanyProvider method started..!");

		// checking whether company provider with given id present or not
		Optional<CompanyProvider> companyProvider = companyProviderRepository.findById(companyProviderId);
		if (!companyProvider.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.COMPANY_PROVIDER_NOT_FOUND);
		}
		CompanyProvider companyProviderDetails = companyProvider.get();
		LOGGER.info("setting company provider details to respective fields");
		ViewCompanyProvider viewCompanyProvider = new ViewCompanyProvider();
		viewCompanyProvider.setCompanyName(companyProviderDetails.getCompanyName());
		viewCompanyProvider.setContactPerson(companyProviderDetails.getContactPersonName());
		viewCompanyProvider.setContactNo(companyProviderDetails.getContactNumber());
		viewCompanyProvider.setEmailId(companyProviderDetails.getEmail());
		if (companyProviderDetails.getSfdcId() != null) {
			viewCompanyProvider.setSfdcId(companyProviderDetails.getSfdcId());
		}
		viewCompanyProvider.setStatus(companyProviderDetails.getStatus());
		viewCompanyProvider.setCountryCodeId(companyProviderDetails.getCountryCodeId());
		viewCompanyProvider.setCompanyProviderId(companyProviderDetails.getId());
		viewCompanyProvider.setAddress(companyProviderDetails.getAddress());

		LOGGER.info("getCompanyProvider method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewCompanyProvider);
	}

	public ResponseEntity<ViewResponse> getCompanyProviderList(Long orgId) {
		LOGGER.info("getCompanyProviderList method started..!");
		Optional<Organization> orgOptional = organizationRepository.findById(orgId);
		if (!orgOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		LOGGER.info("Fetching all company provides with organization id:: {}", orgId);
		List<CompanyProvider> companyProviderList = companyProviderRepository
				.findByOrganizationIdAndStatus(orgOptional.get(), StatusConstants.ACTIVE);
		List<CompanyProviderInfo> companyProviderInfoList = new ArrayList<>();
		companyProviderList.forEach(companyProvider -> {
			CompanyProviderInfo companyProviderInfo = new CompanyProviderInfo();
			companyProviderInfo.setCompanyProviderId(companyProvider.getId());
			companyProviderInfo.setCompanyProviderName(companyProvider.getCompanyName());
			companyProviderInfoList.add(companyProviderInfo);
		});
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.COMPANY_PROVIDER_LIST_FETCHED);
		if (companyProviderInfoList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(companyProviderInfoList);
		LOGGER.info("getCompanyProviderList method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getCompanyProvidersList(Long orgId) {
		LOGGER.info("getCompanyProviderList method started..!");
		Optional<Organization> orgOptional = organizationRepository.findById(orgId);
		if (!orgOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		LOGGER.info("Fetching all company provides with organization id:: {}", orgId);
		List<CompanyProvider> companyProviderList = companyProviderRepository
				.findByOrganizationIdAndStatus(orgOptional.get(), StatusConstants.ACTIVE);
		List<ViewCompanyProviderInfo> companyProviderInfoList = new ArrayList<>();
		companyProviderList.forEach(companyProvider -> {
			ViewCompanyProviderInfo companyProviderInfo = new ViewCompanyProviderInfo();
			companyProviderInfo.setCompanyProviderAddress(companyProvider.getAddress());
			companyProviderInfo.setCompanyProviderId(companyProvider.getId());
			companyProviderInfo.setCompanyProviderName(companyProvider.getCompanyName());
			companyProviderInfo.setCompanyProviderPhone(companyProvider.getContactNumber());
			companyProviderInfoList.add(companyProviderInfo);
		});
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.COMPANY_PROVIDER_LIST_FETCHED);
		if (companyProviderInfoList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(companyProviderInfoList);
		LOGGER.info("getCompanyProviderList method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private String getName(String firstName, String lastName) {
		String name = "";
		if (firstName != null) {
			name = name + firstName;
		}
		if (lastName != null) {
			name = name + " " + lastName;
		}
		return name;
	}

	public ResponseEntity<GetSubCaseInfo> getSubCaseRelatedList(GetSubCaseInfoRequest request) {
		LOGGER.info("getSubCaseRelatedList method started..!");
		List<CompanyProvider> companyProvidersList = companyProviderRepository
				.findAllById(request.getCompanyProviderIds());

		List<InsuranceCompany> insuranceCompaniesList = insuranceCompanyRepository
				.findAllById(request.getInsuranceCompanyIds());

		List<IndividualProvider> individualProvidersList = individualProviderRepository
				.findAllById(request.getIndividualProviderIds());

		List<ViewCompanyProviderInfo> companyProviders = new ArrayList<>();
		List<ViewIndividualProviderInfo> individualProviders = new ArrayList<>();
		List<ViewInsuranceCompanyInfo> insuranceCompanies = new ArrayList<>();

		companyProvidersList.forEach(companyProvider -> {
			ViewCompanyProviderInfo companyProviderInfo = new ViewCompanyProviderInfo();
			companyProviderInfo.setCompanyProviderAddress(companyProvider.getAddress());
			companyProviderInfo.setCompanyProviderId(companyProvider.getId());
			companyProviderInfo.setCompanyProviderName(companyProvider.getCompanyName());
			companyProviderInfo.setCompanyProviderPhone(companyProvider.getContactNumber());
			companyProviders.add(companyProviderInfo);
		});
		individualProvidersList.forEach(individualProvider -> {
			ViewIndividualProviderInfo individualProviderInfo = new ViewIndividualProviderInfo();
			individualProviderInfo.setIndividualProviderId(individualProvider.getId());
			individualProviderInfo.setIndividualProviderName(
					getName(individualProvider.getFirstName(), individualProvider.getLastName()));
			individualProviders.add(individualProviderInfo);
		});
		insuranceCompaniesList.forEach(insuranceCompany -> {
			ViewInsuranceCompanyInfo induranceCompanyInfo = new ViewInsuranceCompanyInfo();
			induranceCompanyInfo.setInsuranceCompanyAddress(insuranceCompany.getAddress());
			induranceCompanyInfo.setInsuranceCompanyId(insuranceCompany.getId());
			induranceCompanyInfo.setInsuranceCompanyName(insuranceCompany.getName());
			induranceCompanyInfo.setInsuranceCompanyPhone(insuranceCompany.getContactNumber());
			insuranceCompanies.add(induranceCompanyInfo);
		});

		GetSubCaseInfo subCaseInfo = new GetSubCaseInfo();
		subCaseInfo.setCompanyProviders(companyProviders);
		subCaseInfo.setIndividualProviders(individualProviders);
		subCaseInfo.setInsuranceCompanies(insuranceCompanies);
		subCaseInfo.setStatus(Constants.SUCCESS);
		subCaseInfo.setMessage("Data fetched successfully..!");
		LOGGER.info("getSubCaseRelatedList method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(subCaseInfo);
	}

}
