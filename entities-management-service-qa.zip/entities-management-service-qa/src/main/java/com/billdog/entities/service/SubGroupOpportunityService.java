package com.billdog.entities.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.Employer;
import com.billdog.entities.entity.Opportunity;
import com.billdog.entities.entity.OpportunitySubTypeMaster;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.entity.SubOpportunity;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.RecordExistsException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.BrokerCompanyRepository;
import com.billdog.entities.repository.EmployerRepository;
import com.billdog.entities.repository.IndividualBrokerRepository;
import com.billdog.entities.repository.OpportunityRepository;
import com.billdog.entities.repository.OpportunitySubTypeMasterRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.repository.SubOpportunityRepository;
import com.billdog.entities.request.EditSubGroupOpportunityRequest;
import com.billdog.entities.request.MemberCountRequest;
import com.billdog.entities.request.SubGroupOpportunityRequest;
import com.billdog.entities.view.GetMemberCountByEmployer;
import com.billdog.entities.view.ViewMembersCount;
import com.billdog.entities.view.ViewResponse;
import com.billdog.entities.view.ViewSubGroupDetails;

@Service
public class SubGroupOpportunityService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(SubGroupOpportunityService.class);

	@Autowired
	OpportunityRepository opportunityRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	UserService userService;

	@Autowired
	EmployerRepository employerRepository;

	@Autowired
	SubOpportunityRepository subOpportunityRepository;

	@Autowired
	OpportunitySubTypeMasterRepository opportunitySubTypeMasterRepository;

	@Autowired
	BrokerCompanyRepository brokerCompanyRepository;

	@Autowired
	IndividualBrokerRepository brokerRepository;

	public ResponseEntity<ViewResponse> addSubGroupOpportunity(SubGroupOpportunityRequest subGroupOpportunityRequest) {
		LOGGER.info("addSubGroupOpportunity method started..!");
		if (StringUtils.isBlank(subGroupOpportunityRequest.getSubGroupopportunityName())) {
			throw new BadRequestException(ExceptionalMessages.SUB_OPPORTUNITY_NAME_SIZE);
		}
		Optional<Organization> organization = organizationRepository
				.findById(subGroupOpportunityRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<Opportunity> opportunityEntity = opportunityRepository.findByOpportunityNameAndOrganizationId(
				subGroupOpportunityRequest.getSubGroupopportunityName(),
				subGroupOpportunityRequest.getOrganizationId());
		if (opportunityEntity.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<SubOpportunity> subOpportunityName = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(subGroupOpportunityRequest.getSubGroupopportunityName(),
						organization.get());
		if (subOpportunityName.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		Optional<SubOpportunity> blockOptional = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(subGroupOpportunityRequest.getSubGroupopportunityName(),
						organization.get());
		if (blockOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.SUB_GROUP_OPPORTUNITY_EXISTS);
		}
		Optional<Employer> employerOptional = employerRepository.findById(subGroupOpportunityRequest.getEmployerId());
		if (!employerOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
		}

		Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employerOptional.get());
		if (subOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
		}

		long count = 0, num = subGroupOpportunityRequest.getTotalcount();

		for (; num != 0; num /= 10, ++count) {
		}
		if (count > 5) {
			throw new RecordNotFoundException(ExceptionalMessages.COUNT);
		}

		saveSubGroupOpportunity(subGroupOpportunityRequest, employerOptional.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.SUB_GROUP_OPPRUTUNITY);
		LOGGER.info("addSubGroupOpportunity method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void saveSubGroupOpportunity(SubGroupOpportunityRequest subGroupOpportunityRequest, Employer employer) {
		LOGGER.debug("creating new object in Sub Group Opportunity table.!!");
		SubOpportunity subGroupOpportunity = new SubOpportunity();
		subGroupOpportunity.setCreatedAt(DateAndTimeUtil.now());
		subGroupOpportunity.setUpdatedAt(DateAndTimeUtil.now());
		subGroupOpportunity.setSubGroupOpportunityName(
				WordUtils.capitalizeFully(subGroupOpportunityRequest.getSubGroupopportunityName()));
		Optional<Opportunity> blockOpportunity = opportunityRepository
				.findById(subGroupOpportunityRequest.getBlockOpportunityId());
		if (!blockOpportunity.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.BLOCK_OPPORTUNITY_NOT_FOUND);
		}
		OpportunitySubTypeMaster subGroupTypeOpportunity = opportunitySubTypeMasterRepository
				.findByOpportunityChildNameAndOrganizationId(Constants.SUB_GROUP, employer.getOrganizationId().getId());
		if (subGroupTypeOpportunity != null) {
			subGroupOpportunity.setOpportunitySubTypeMasterId(subGroupTypeOpportunity);
		}
		subGroupOpportunity.setOpportunityId(blockOpportunity.get());
		subGroupOpportunity.setCount(subGroupOpportunityRequest.getTotalcount());
		subGroupOpportunity.setEmployerId(employer);
		subGroupOpportunity.setOrganizationId(employer.getOrganizationId());
		subGroupOpportunity.setSfdcId(subGroupOpportunityRequest.getSfdcId());
		subGroupOpportunity.setStatus(StatusConstants.ACTIVE);
		subGroupOpportunity.setUserId(subGroupOpportunityRequest.getUserId());
		subOpportunityRepository.save(subGroupOpportunity);
	}

	public ResponseEntity<ViewResponse> editSubGroupOpportunity(
			EditSubGroupOpportunityRequest editSubGroupOpportunityRequest) {
		LOGGER.info("editSubGroupOpportunity method started..!");
		if (StringUtils.isBlank(editSubGroupOpportunityRequest.getSubGroupopportunityName())) {
			throw new BadRequestException(ExceptionalMessages.SUB_OPPORTUNITY_NAME_SIZE);
		}
		Optional<SubOpportunity> subGroupOpportunityoptional = subOpportunityRepository
				.findById(editSubGroupOpportunityRequest.getSubGroupOpportunityId());
		if (!subGroupOpportunityoptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.SUB_GROUP_NOT_FOUND);
		}

		/*
		 * Optional<Opportunity> opportunityEntity =
		 * opportunityRepository.findByOpportunityNameAndOrganizationId(
		 * editSubGroupOpportunityRequest.getSubGroupopportunityName(),
		 * subGroupOpportunityoptional.get().getOrganizationId().getId()); if
		 * (opportunityEntity.isPresent()) { throw new
		 * RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME); }
		 */

		Optional<SubOpportunity> subOpportunityName = subOpportunityRepository
				.findBySubGroupOpportunityNameAndOrganizationId(
						editSubGroupOpportunityRequest.getSubGroupopportunityName(),
						subGroupOpportunityoptional.get().getOrganizationId());
		if (subOpportunityName.isPresent()
				&& subOpportunityName.get().getId() != editSubGroupOpportunityRequest.getSubGroupOpportunityId()) {
			throw new RecordExistsException(ExceptionalMessages.OPPORTUNITY_NAME);
		}

		long count = 0, num = editSubGroupOpportunityRequest.getTotalCount();

		for (; num != 0; num /= 10, ++count) {
		}
		if (count > 5) {
			throw new RecordNotFoundException(ExceptionalMessages.COUNT);
		}

		updateSubGroupOpportunity(editSubGroupOpportunityRequest, subGroupOpportunityoptional.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.SUB_GROUP_OPPRUTUNITY_UPDATED);
		LOGGER.info("editSubGroupOpportunity method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void updateSubGroupOpportunity(EditSubGroupOpportunityRequest editSubGroupOpportunityRequest,
			SubOpportunity subGroupOpportunity) {
		LOGGER.debug("updating object in Sub Group Opportunity table.!!");
		subGroupOpportunity.setUpdatedAt(DateAndTimeUtil.now());
		subGroupOpportunity.setSubGroupOpportunityName(
				WordUtils.capitalizeFully(editSubGroupOpportunityRequest.getSubGroupopportunityName()));
		subGroupOpportunity.setCount(editSubGroupOpportunityRequest.getTotalCount());
		if (subGroupOpportunity.getEmployerId().getId() != editSubGroupOpportunityRequest.getEmployerId()) {
			Optional<Employer> employer = employerRepository.findById(editSubGroupOpportunityRequest.getEmployerId());
			if (!employer.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
			}
			Optional<SubOpportunity> subOptional = subOpportunityRepository.findByEmployerId(employer.get());
			if (subOptional.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.EMPLOYER_EXISTS_OTHER_SUB_GROUP_OPPORTUNITY);
			}
			subGroupOpportunity.setEmployerId(employer.get());
		}

		subGroupOpportunity.setSfdcId(editSubGroupOpportunityRequest.getSfdcId());
		if (editSubGroupOpportunityRequest.getStatus() != null) {
			subGroupOpportunity.setStatus(editSubGroupOpportunityRequest.getStatus());
		}
		subGroupOpportunity.setUserId(editSubGroupOpportunityRequest.getUserId());
		subOpportunityRepository.save(subGroupOpportunity);
	}

	public ResponseEntity<ViewSubGroupDetails> getSubGroupOpportunityDetails(Long subGroupId) {
		LOGGER.info("getSubGroupOpportunityDetails method started..!");

		// checking whether sub group Opportunity with given id present or not
		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository.findById(subGroupId);
		if (!subOpportunityOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.SUB_GROUP_NOT_FOUND);
		}
		SubOpportunity subOpportunityDetails = subOpportunityOptional.get();
		GetMemberCountByEmployer getMemberCountByEmployer = getMemberCountByEmployer(
				subOpportunityDetails.getEmployerId().getId());
		LOGGER.info("setting sub group opportunity details to respective fields");
		ViewSubGroupDetails viewSubGroupDetails = new ViewSubGroupDetails();
		viewSubGroupDetails.setSubGroupOpportunityName(subOpportunityDetails.getSubGroupOpportunityName());
		if (subOpportunityDetails.getOpportunityId().getBrokerCompanyId() != null) {
			viewSubGroupDetails.setBrokerage(
					subOpportunityDetails.getOpportunityId().getBrokerCompanyId().getBrokerCompanyName());
		}
		if (subOpportunityDetails.getOpportunityId().getIndividualBrokerId() != null) {
			viewSubGroupDetails
					.setBroker(subOpportunityDetails.getOpportunityId().getIndividualBrokerId().getFirstName() + " "
							+ subOpportunityDetails.getOpportunityId().getIndividualBrokerId().getLastName());
		}
		if (subOpportunityDetails.getEmployerId() != null) {
			viewSubGroupDetails.setEmployer(subOpportunityDetails.getEmployerId().getEmployerName());
			viewSubGroupDetails.setEmployerId(subOpportunityDetails.getEmployerId().getId());
		}
		ViewMembersCount memberActiveCount = getMemberActiveCount(subOpportunityDetails.getEmployerId().getId(),
				getMemberCountByEmployer.getViewMembersCountList());
		if (memberActiveCount != null) {
			viewSubGroupDetails.setActiveCount(memberActiveCount.getCount());
		}
		viewSubGroupDetails.setSfdcId(subOpportunityDetails.getSfdcId());
		if (subOpportunityDetails.getCount() != null) {
			viewSubGroupDetails.setTotalCount(subOpportunityDetails.getCount());
		}
		viewSubGroupDetails.setSubGroupOpportunityId(subGroupId);
		viewSubGroupDetails.setOpportunityType(subOpportunityDetails.getOpportunitySubTypeMasterId()
				.getOpportunityTypeMasterId().getOpportunityParentName());
		LOGGER.info("getBlockOpportunityDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewSubGroupDetails);
	}

	private ViewMembersCount getMemberActiveCount(long employerId, List<ViewMembersCount> viewMembersCountList) {
		return viewMembersCountList.stream().filter(employer -> employer.getEmployerId() == employerId).findFirst()
				.orElse(null);
	}

	private GetMemberCountByEmployer getMemberCountByEmployer(Long employerId) {
		List<Long> employerIds = new ArrayList<>();
		employerIds.add(employerId);
		MemberCountRequest memberCountRequest = new MemberCountRequest();
		memberCountRequest.setEmployerIds(employerIds);
		return userService.getMemberCountByEmployerId(memberCountRequest);
	}

}
