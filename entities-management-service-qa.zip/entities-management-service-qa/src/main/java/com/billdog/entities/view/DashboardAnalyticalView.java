package com.billdog.entities.view;

public class DashboardAnalyticalView {

	private int companyProviderCount;
	private int individualProviderCount;
	private int insuranceCompanyCount;
	private long totalServingMember;
	private Double companyProviderGrowth;
	private Double individualProviderGrowth;
	private Double insuranceCompanyGrowth;
	private Double totalServingMemberGrowth;

	public int getCompanyProviderCount() {
		return companyProviderCount;
	}

	public void setCompanyProviderCount(int companyProviderCount) {
		this.companyProviderCount = companyProviderCount;
	}

	public int getIndividualProviderCount() {
		return individualProviderCount;
	}

	public void setIndividualProviderCount(int individualProviderCount) {
		this.individualProviderCount = individualProviderCount;
	}

	public int getInsuranceCompanyCount() {
		return insuranceCompanyCount;
	}

	public void setInsuranceCompanyCount(int insuranceCompanyCount) {
		this.insuranceCompanyCount = insuranceCompanyCount;
	}

	public long getTotalServingMember() {
		return totalServingMember;
	}

	public void setTotalServingMember(long totalServingMember) {
		this.totalServingMember = totalServingMember;
	}

	public Double getCompanyProviderGrowth() {
		return companyProviderGrowth;
	}

	public void setCompanyProviderGrowth(Double companyProviderGrowth) {
		this.companyProviderGrowth = companyProviderGrowth;
	}

	public Double getIndividualProviderGrowth() {
		return individualProviderGrowth;
	}

	public void setIndividualProviderGrowth(Double individualProviderGrowth) {
		this.individualProviderGrowth = individualProviderGrowth;
	}

	public Double getInsuranceCompanyGrowth() {
		return insuranceCompanyGrowth;
	}

	public void setInsuranceCompanyGrowth(Double insuranceCompanyGrowth) {
		this.insuranceCompanyGrowth = insuranceCompanyGrowth;
	}

	public Double getTotalServingMemberGrowth() {
		return totalServingMemberGrowth;
	}

	public void setTotalServingMemberGrowth(Double totalServingMemberGrowth) {
		this.totalServingMemberGrowth = totalServingMemberGrowth;
	}

}
