package com.billdog.entities.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.billdog.entities.entity.Employer;
import com.billdog.entities.entity.Organization;

public interface EmployerRepository extends JpaRepository<Employer, Long> {

	Optional<Employer> findByEmployerName(String employerName);

	Optional<Employer> findByEmail(String email);

	Optional<Employer> findBySfdcId(String sfdcId);

	@Query(value = "SELECT e.employer_name,e.contact_name,e.email,e.contact_number,e.sfdc_id,e.status,e.country_code_Id,e.id, e.address FROM employer e where CASE WHEN\n"
			+ " COALESCE(?1,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?2,'') And CASE WHEN COALESCE(?3,'') <> '' THEN e.contact_name \n"
			+ "ELSE '' END LIKE COALESCE(?4,'') AND CASE WHEN COALESCE(?5,'') <> '' THEN e.contact_number ELSE '' END LIKE COALESCE(?6,'') AND \n"
			+ "CASE WHEN COALESCE(?7,'') <> '' THEN e.email ELSE '' END LIKE COALESCE(?8,'') AND CASE WHEN COALESCE(?9,'') <> '' THEN e.sfdc_id \n"
			+ "ELSE '' END LIKE COALESCE(?10,'') AND CASE WHEN COALESCE(?11,'') <> '' THEN e.status ELSE '' END LIKE COALESCE(?12,'') and e.organization_id=?13 \n"
			+ "order by e.created_at desc", countQuery = "SELECT e.employer_name,e.contact_name,e.email,e.contact_number,e.sfdc_id,e.status,e.country_code_Id,e.id, e.address FROM employer e where CASE WHEN\n"
					+ " COALESCE(?1,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?2,'') And CASE WHEN COALESCE(?3,'') <> '' THEN e.contact_name \n"
					+ "ELSE '' END LIKE COALESCE(?4,'') AND CASE WHEN COALESCE(?5,'') <> '' THEN e.contact_number ELSE '' END LIKE COALESCE(?6,'') AND \n"
					+ "CASE WHEN COALESCE(?7,'') <> '' THEN e.email ELSE '' END LIKE COALESCE(?8,'') AND CASE WHEN COALESCE(?9,'') <> '' THEN e.sfdc_id \n"
					+ "ELSE '' END LIKE COALESCE(?10,'') AND CASE WHEN COALESCE(?11,'') <> '' THEN e.status ELSE '' END LIKE COALESCE(?12,'') and e.organization_id=?13 \n"
					+ "order by e.created_at desc", nativeQuery = true)
	Page<Object[][]> getEmployer(String employerName, String employerName2, String contactName, String contactName2,
			String contactNo, String contactNo2, String email, String email2, String sfdcId, String sfdcId2,
			String status, String status2, long orgId, PageRequest pageRequest);

	List<Employer> findAllByStatus(String active);

	List<Employer> findByStatusAndIdNotIn(String active, List<Long> employerIds);

	List<Employer> findByStatusAndOrganizationId(String active, Organization organization);

	@Query(value = "select ea.id, ea.revtype, ea.updated_at, ea.address, ea.contact_name, ea.contact_number,ea.employer_name, ea.sfdc_id,\n"
			+ "       ea.status, ea.user_id, ea.email,rev  from employer_aud ea join employer e on e.id = ea.id\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN ea.employer_name ELSE '' END LIKE COALESCE(?2,'')\n"
			+ "and date(ea.updated_at) BETWEEN ?3 AND ?4 and ea.revtype in ?5 and e.organization_id=?6  order by ea.updated_at desc,ea.rev desc", countQuery = "select ea.id, ea.revtype, ea.updated_at, ea.address, ea.contact_name, ea.contact_number,ea.employer_name, ea.sfdc_id,\n"
					+ "       ea.status, ea.user_id, ea.email,rev  from employer_aud ea join employer e on e.id = ea.id\n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN ea.employer_name ELSE '' END LIKE COALESCE(?2,'')\n"
					+ "and date(ea.updated_at) BETWEEN ?3 AND ?4 and ea.revtype in ?5 and e.organization_id=?6  order by ea.updated_at desc,ea.rev desc", nativeQuery = true)
	Page<Object[]> getEmployerAuditInfo(String name, String name2, String fromDate, String toDate, List<Long> revtypes,
			long orgId, PageRequest pageRequest);

	@Query(value = "select id, revtype, updated_at, address, contact_name, contact_number,employer_name, sfdc_id, status, user_id, email,rev \n"
			+ "from employer_aud where id =?1 and rev<?2 order by rev desc limit 1 ", countQuery = "select id, revtype, updated_at, address, contact_name, contact_number,employer_name, sfdc_id, status, user_id, email \n"
					+ "from employer_aud where id =?1 and rev<?2 order by rev desc limit 1 ", nativeQuery = true)
	List<Object[]> getEmployerAuditInfoByIdAndRev(long id, long rev);

	@Query(value = "select id, revtype, updated_at, address, contact_name, contact_number,employer_name, sfdc_id, status, user_id, email,rev \n"
			+ "from employer_aud where id=?1 order by rev desc", countQuery = "select id, revtype, updated_at, address, contact_name, contact_number,employer_name, sfdc_id, status, user_id, email,rev \n"
					+ "from employer_aud where id=?1 order by rev desc", nativeQuery = true)
	Page<Object[]> getEmployerAuditInfoById(Long id, PageRequest pageRequest);

}
