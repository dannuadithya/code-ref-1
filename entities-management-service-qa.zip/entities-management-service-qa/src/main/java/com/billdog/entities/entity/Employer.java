package com.billdog.entities.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity(name = "EMPLOYER")
@Table(name = "employer")
public class Employer extends BaseEntity {

	@Audited
	@Column(name = "employer_name")
	private String employerName;

	@Audited
	@Column(name = "email")
	private String email;

	@Audited
	@Column(name = "contact_name")
	private String contactName;

	@Audited
	@Column(name = "contact_number")
	private String contactNumber;

	@Audited
	@Column(name = "status")
	private String status;

	@Audited
	@Column(name = "sfdc_id")
	private String sfdcId;

	@Column(name = "sfdc_updated_at")
	private LocalDateTime sfdcUpdatedTime;

	@ManyToOne
	@JoinColumn(name = "organization_Id")
	private Organization organizationId;

	@Column(name = "country_code_Id")
	private Long countryCodeId;

	@Audited
	@Column(name = "address")
	private String address;

	@Audited
	@Column(name = "USER_ID")
	private Long userId;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public LocalDateTime getSfdcUpdatedTime() {
		return sfdcUpdatedTime;
	}

	public void setSfdcUpdatedTime(LocalDateTime sfdcUpdatedTime) {
		this.sfdcUpdatedTime = sfdcUpdatedTime;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public Long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(Long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
