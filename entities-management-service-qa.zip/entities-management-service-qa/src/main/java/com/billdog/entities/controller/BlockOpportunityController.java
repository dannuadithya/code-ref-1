package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.request.BlockOpportunityRequest;
import com.billdog.entities.request.CreateBlockOpportunityRequest;
import com.billdog.entities.request.ExternalUserBlockOpportunityRequest;
import com.billdog.entities.request.UpdateBlockOpportunityRequest;
import com.billdog.entities.service.BlockOpportunityService;
import com.billdog.entities.view.BlockOpportunityListView;
import com.billdog.entities.view.MemberInfoResponse;
import com.billdog.entities.view.ViewMemberResponse;
import com.billdog.entities.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class BlockOpportunityController {

	@Autowired
	BlockOpportunityService blockOpportunityService;

	@Autowired
	EmployerController employerController;


	public MemberInfoResponse getMemberInfo(HttpServletRequest httpRequest) {
		MemberInfoResponse memberInfoResponse = new MemberInfoResponse();
		if (httpRequest.getAttribute("organizationId") != null) {
			memberInfoResponse.setOrganizationId(Long.parseLong(httpRequest.getAttribute("organizationId").toString()));
		}
		return memberInfoResponse;
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Block opportunity fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchBlockOpportunity", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchBlockOpportunity(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody BlockOpportunityRequest blockOpportunityRequest) {
		employerController.isTokenValid(httpRequest, blockOpportunityRequest.getUserId(), null);
		return blockOpportunityService.searchBlockOpportunity(blockOpportunityRequest,
				getMemberInfo(httpRequest).getOrganizationId());
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Block opportunity details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Block opportunity not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getBlockOpportunity", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<BlockOpportunityListView> getBlockOpportunityDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long blockOpportunityId,
			@RequestParam(required = false) Integer pageNumber, @RequestParam(required = false) Integer pageLimit) {

		employerController.isTokenValid(httpRequest, userId, null);
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		return blockOpportunityService.getBlockOpportunityDetails(blockOpportunityId,pageNumber,pageLimit);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Block opportunity created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/block-opportunity", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> createBlockOpportunity(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody CreateBlockOpportunityRequest blockOpportunityRequest) {
		employerController.isTokenValid(httpRequest, blockOpportunityRequest.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK).body(blockOpportunityService
				.createBlockOpportunity(blockOpportunityRequest, getMemberInfo(httpRequest).getOrganizationId()));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Block opportunity updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/block-opportunity", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateBlockOpportunity(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody UpdateBlockOpportunityRequest blockOpportunityRequest) {
		employerController.isTokenValid(httpRequest, blockOpportunityRequest.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK)
				.body(blockOpportunityService.updateBlockOpportunity(blockOpportunityRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Block opportunity fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchExBlockOpportunity", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchExternalUserBlockOpportunity(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody ExternalUserBlockOpportunityRequest blockOpportunityRequest) {
		employerController.isTokenValid(httpRequest, blockOpportunityRequest.getUserId(), null);
		return blockOpportunityService.searchExternalUserBlockOpportunity(blockOpportunityRequest);
	}

}