package com.billdog.entities.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class EditInsuranceCompanyRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String insuranceCompanyName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactPersonName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Email(message = "Invalid email format")
	private String email;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcId;
	@NotNull(message = "userId must not be null")
	private long userId;
	@NotNull(message = "Please select Insurance Company")
	private long insuranceCompanyId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String status;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String address;
	private long countryCodeId;
	public String getInsuranceCompanyName() {
		return insuranceCompanyName;
	}
	public void setInsuranceCompanyName(String insuranceCompanyName) {
		this.insuranceCompanyName = insuranceCompanyName;
	}
	public String getContactPersonName() {
		return contactPersonName;
	}
	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getSfdcId() {
		return sfdcId;
	}
	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getInsuranceCompanyId() {
		return insuranceCompanyId;
	}

	public void setInsuranceCompanyId(long insuranceCompanyId) {
		this.insuranceCompanyId = insuranceCompanyId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

}
