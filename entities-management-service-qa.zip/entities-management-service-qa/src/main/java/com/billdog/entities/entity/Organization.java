package com.billdog.entities.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;


@Entity(name = "ORGANIZATION")
@Table(name = "organization", indexes = { @Index(name = "id_index", columnList = "ID", unique = true) })
public class Organization extends BaseEntity{

	@Column(name = "NAME")
	private String name;
	
	@Column(name = "STATUS")
	private String status;

	@Column(name = "PHONE_NUMBER")
	private String phoneNumber;	

	@Column(name = "FAX_NUMBER")
	private String faxNumber;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "DOMAIN_URL")
	private String domainUrl;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomainUrl() {
		return domainUrl;
	}

	public void setDomainUrl(String domainUrl) {
		this.domainUrl = domainUrl;
	}
	

}
