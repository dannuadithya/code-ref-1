package com.billdog.entities.request;

import java.util.List;

public class GetSubCaseInfoRequest {

	private long userId;
	private List<Long> insuranceCompanyIds;
	private List<Long> companyProviderIds;
	private List<Long> individualProviderIds;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public List<Long> getInsuranceCompanyIds() {
		return insuranceCompanyIds;
	}

	public void setInsuranceCompanyIds(List<Long> insuranceCompanyIds) {
		this.insuranceCompanyIds = insuranceCompanyIds;
	}

	public List<Long> getCompanyProviderIds() {
		return companyProviderIds;
	}

	public void setCompanyProviderIds(List<Long> companyProviderIds) {
		this.companyProviderIds = companyProviderIds;
	}

	public List<Long> getIndividualProviderIds() {
		return individualProviderIds;
	}

	public void setIndividualProviderIds(List<Long> individualProviderIds) {
		this.individualProviderIds = individualProviderIds;
	}

}
