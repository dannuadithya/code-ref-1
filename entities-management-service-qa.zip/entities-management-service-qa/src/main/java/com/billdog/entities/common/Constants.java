package com.billdog.entities.common;

public class Constants {

	public static final char DOT = '.';
	public static final char SLASH = '/';

	public static final String FAILED = "FAILED";
	public static final String SUCCESS = "SUCCESS";
	public static final String INSURANCE_DETAILS = "Insurance company added successfully";
	public static final String CARRIER_TYPE_FETCHED = "Carrier details fetched successfully";
	public static final String INSURANCE_DETAILS_FETCHED = "Insurance company fetched successfully";
	public static final String NO_RESULTS_FOUND = "No result found";
	public static final String INSURANCE_DETAILS_UPDATED = "Insurance company updated successfully";
	public static final String COMPANY_PROVIDER_CREATED = "Company provider added successfully";
	public static final String COMPANY_PROVIDER_FETCHED = "Company provider fetched successfully";
	public static final String COMPANY_PROVIDER_UPDATED = "Company provider updated successfully";
	public static final String INDIVIDUAL_PROVIDER_ADDED = "Individual provider added successfully";
	public static final String INDIVIDUAL_PROVIDER_UPDATED = "Individual provider info updated successfully";
	public static final String COMPANY_PROVIDER_LIST_FETCHED = "Company provider list fetched successfully";
	public static final String BROKER_COMPANY_LIST_FETCHED = "Broker companies list fetched successfully";

	public static final String INDIVIDUAL_PROVIDER_LIST_FETCHED = "Individual provider list fetched successfully";

	public static final String INDIVIDUAL_BROKER_LIST_FETCHED = "Individual brokers list fetched successfully";
	public static final long HUNDRED = 100;
	public static final String BROKER_COMPANY_CREATED = "Broker company added successfully";
	public static final String BROKER_COMPANY = "Broker company fetched successfully";
	public static final String INDIVIDUAL_BROKER_ADDED = "Individual Broker added successfully";
	public static final String INDIVIDUAL_BROKER_UPDATED = "Individual broker info updated successfully";
	public static final String INDEPENDENT = "Independent";
	public static final String BROKER_COMPANY_UPDATED = "Broker company updated successfully";
	public static final String EMPLOYER_SAVED = "Employer created successfully";
	public static final String EMPLOYER_UPDATED = "Employer details updated successfully";
	public static final String EMPLOYER_LIST_FETCHED = "Employer info fetched successfully";
	public static final String EMPLOYER_AUDIT_LIST_FETCHED = "Employer audit info fetched successfully";
	public static final String AUDIT_MODULE_LIST_FETCHED = "Audit modules fetched successfully";
	public static final String AUDIT_TIME_PERIOD_LIST_FETCHED = "Audit time period info fetched successfully";

	public static final String SUB_CASE_REQUEST_VERIFIED = "Sub case request verified successfully";
	public static final String BLOCK_OPPORTUNITY = "Block opportunity fetched successfully";
	public static final String BLOCK_OPPORTUNITY_CREATED = "Block Opportunity created successfully";
	public static final String BLOCK_OPPORTUNITY_UPDATED = "Block Opportunity updated successfully";
	public static final int MAX_OPPORTUNITY_NAME_LENGTH = 100;
	public static final int MIN_OPPORTUNITY_NAME_LENGTH = 2;
	public static final String SUB_GROUP_OPPRUTUNITY = "Sub Group Opportunity Created Successfully";
	public static final String SUB_GROUP_OPPRUTUNITY_UPDATED = "Sub Group Opportunity updated Successfully";
	public static final String BLOCK = "Block opportunity";
	public static final String GROUP = "Group opportunity";
	public static final String SUB_GROUP = "Sub group opportunity";
	public static final String BROKER_SPONSORE = "Broker sponsored fetched Successfully";
	public static final String BROKER_SPONSORED_CREATED = "Broker sponsored created successfully";
	public static final String BROKER_SPONSORED_UPDATED = "Broker sponsored updated successfully";
	public static final String EMPLOYER_DIRECT_FECTED = "Employer direct fetched Successfully";
	public static final String EMPLOYER_DIRECT = "Employer Direct";
	public static final String BROKER_SPONSORED = "Broker sponsored";
	public static final String EMPLOYER_DIRECT_CREATED = "Employer Direct opportunity created successfully";
	public static final String EMPLOYER_DIRECT_UPDATED = "Employer Direct Opportunity details updated successfully";
	public static final String OPPORTUNITIES = "Opportunities fetched successfully";
	public static final String BROKER_SPONSORED_FECTED = "Broker sponsored fetched successfully";
	public static final String BLOCK_CONVERSION = "Opportunity converted successfully";
	public static final String EXTERNAL_USER_DETAILS = "External user details fetched successfully";
	public static final String EXTERNAL_USER_DETAILS_UPDATED = "External user details updated successfully";
	public static final String OPPORTUNITY_NOT_FOUND = "Opportunity not found";
	public static final String EMPLOYER_NOT_FOUND = "Employer not found";
	public static final String TOTAL_ACTIVE_COUNT = "Total active count saved successfully";
	public static final String UPDATED = "Updated";
	public static final String CREATED = "Created";
	public static final String DELETED = "Deleted";
	public static final String INDIVIDUAL_BROKER_AUDIT_LIST_FETCHED = "Individual Broker audit info fetched successfully";
	public static final String INDIVIDUAL_PROVIDER_AUDIT_LIST_FETCHED = "Individual Provider audit info fetched successfully";
	public static final String INSURANCE_COMPANY_AUDIT_LIST_FETCHED = "Insurance Company audit info fetched successfully";
	public static final String BROKER_COMPANY_AUDIT_LIST_FETCHED = "Broker Company audit info fetched successfully";
	public static final String COMPANY_PROVIDER_AUDIT_LIST_FETCHED = "Company Provider audit info fetched successfully";
	public static final String OPPORTUNITY_AUDIT_FETCHED = "Opportunity audit fetched successfully";
	public static final String USER = "User";
	public static final String MODIFIED = "Modified";
	public static final String MEMBER = "Member";


	public static final String USER_ID = "id";
	public static final String MEMBER_ID = "id";
	public static final String NO_VALUE = "No value present";
	public static final String NO_CHANGE = "No records were modified in this transaction";
	public static final String EXTERNAL = "External";
}
