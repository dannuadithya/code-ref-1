package com.billdog.entities.request;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UpdateBlockOpportunityRequest {

	private long blockOpportunityId;
	private long individualBrokerId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotNull(message = "Please enter opportunity name")
	@Size(min = 2, max = 100, message = "Opportunity name should be in between 2 and 100 characters")
	private String opportunityName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Size(max = 100, message = "sfdcId should not exceed 100 characters")
	private String sfdcId;
	@NotNull(message = "Please provide user id")
	private Long userId;

	@Valid
	private List<UpdateSubGroupOpportunityRequest> groupOpportunityRequest;

	public long getBlockOpportunityId() {
		return blockOpportunityId;
	}

	public void setBlockOpportunityId(long blockOpportunityId) {
		this.blockOpportunityId = blockOpportunityId;
	}

	public long getIndividualBrokerId() {
		return individualBrokerId;
	}

	public void setIndividualBrokerId(long individualBrokerId) {
		this.individualBrokerId = individualBrokerId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public List<UpdateSubGroupOpportunityRequest> getGroupOpportunityRequest() {
		return groupOpportunityRequest;
	}

	public void setGroupOpportunityRequest(List<UpdateSubGroupOpportunityRequest> groupOpportunityRequest) {
		this.groupOpportunityRequest = groupOpportunityRequest;
	}

}
