package com.billdog.entities.view;

import java.math.BigInteger;

public class ViewBrokerSponsore {

	private String opportunityName;
	private String brokerage;
	private String brokerName;
	private String employer;
	private BigInteger totalCount;
	private Long totalActiveCount;
	private BigInteger brokerSponsoredId;

	private BigInteger employerId;
	private String sfdcId;
	private String opportunityType;
	private BigInteger brokerId;
	private BigInteger brokerageId;

	public BigInteger getBrokerId() {
		return brokerId;
	}

	public void setBrokerId(BigInteger brokerId) {
		this.brokerId = brokerId;
	}

	public BigInteger getBrokerageId() {
		return brokerageId;
	}

	public void setBrokerageId(BigInteger brokerageId) {
		this.brokerageId = brokerageId;
	}

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public BigInteger getBrokerSponsoredId() {
		return brokerSponsoredId;
	}

	public void setBrokerSponsoredId(BigInteger brokerSponsoredId) {
		this.brokerSponsoredId = brokerSponsoredId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getBrokerage() {
		return brokerage;
	}

	public void setBrokerage(String brokerage) {
		this.brokerage = brokerage;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public BigInteger getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(BigInteger totalCount) {
		this.totalCount = totalCount;
	}

	public Long getTotalActiveCount() {
		return totalActiveCount;
	}

	public void setTotalActiveCount(Long totalActiveCount) {
		this.totalActiveCount = totalActiveCount;
	}

	public BigInteger getEmployerId() {
		return employerId;
	}

	public void setEmployerId(BigInteger employerId) {
		this.employerId = employerId;
	}

}
