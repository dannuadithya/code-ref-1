package com.billdog.entities.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.billdog.entities.entity.BrokerCompany;
import com.billdog.entities.entity.IndividualBroker;
import com.billdog.entities.entity.Opportunity;
import com.billdog.entities.entity.OpportunityTypeMaster;

public interface OpportunityRepository extends JpaRepository<Opportunity, Long> {

	@Query(value = "SELECT o.opportunity_name,bc.broker_company_name,concat(ib.first_name,' ',ib.last_name) as individual_broker_name,o.id,otm.opportunity_parent_name,  o.broker_company_id, o.individual_broker_id,o.sfdc_id\n"
			+ "FROM opportunities o\n" + " left join broker_company bc on bc.id = o.broker_company_id\n"
			+ "left join individual_broker ib on ib.id = o.individual_broker_id\n"
			+ "left join opportunity_type_master otm on otm.id= o.opportunity_type_master_Id\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN o.opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ " CASE WHEN COALESCE(?3,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
			+ " (CASE WHEN COALESCE(?5,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?6,'') or\n"
			+ " CASE WHEN COALESCE(?7,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?8,'')) AND\n"
			+ " CASE WHEN COALESCE(?9,'') <> '' THEN o.sfdc_id ELSE '' END LIKE COALESCE(?10,'') and otm.opportunity_parent_name =?11 and o.organization_id =?12\n"
			+ " order by o.created_at desc", countQuery = "SELECT o.opportunity_name,bc.broker_company_name,concat(ib.first_name,' ',ib.last_name) as individual_broker_name,o.id,otm.opportunity_parent_name, o.broker_company_id, o.individual_broker_id,o.sfdc_id \n"
					+ "FROM opportunities o\n" + " left join broker_company bc on bc.id = o.broker_company_id\n"
					+ "left join individual_broker ib on ib.id = o.individual_broker_id\n"
					+ "left join opportunity_type_master otm on otm.id= o.opportunity_type_master_Id\n"
					+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN o.opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ " CASE WHEN COALESCE(?3,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
					+ " (CASE WHEN COALESCE(?5,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?6,'') or\n"
					+ " CASE WHEN COALESCE(?7,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?8,'')) AND\n"
					+ " CASE WHEN COALESCE(?9,'') <> '' THEN o.sfdc_id ELSE '' END LIKE COALESCE(?10,'') and otm.opportunity_parent_name =?11 and o.organization_id =?12 \n"
					+ " order by o.created_at desc", nativeQuery = true)
	Page<Object[][]> getBlockOpportunities(String opportunityName, String opportunityName2, String brokerage,
			String brokerage2, String brokerName, String brokerName2, String brokerName3, String brokerName4,
			String sfdcOpportunityId, String sfdcOpportunityId2, String block, Long orgId, PageRequest pageRequest);

	Optional<Opportunity> findBySfdcId(String sfdcId);

	Optional<Opportunity> findByOpportunityName(String name);

	Optional<Opportunity> findByOpportunityNameAndOrganizationId(String opportunityName, Long orgId);

	Optional<Opportunity> findByOpportunityNameAndOrganizationIdAndOpportunityTypeMasterId(String opportunityName,
			Long orgId, OpportunityTypeMaster opportunityType);

	@Query(value = "SELECT so.sub_group_opportunity_name,so.count as total_acount,so.total_active_count,e.employer_name,bc.broker_company_name,concat(ib.first_name,' ',ib.last_name) as individual_broker_name,so.id,so.sfdc_id, e.id as employer_Id,bc.id as brokerCompanyId , ib.id as individualBrokerId \n"
			+ "FROM sub_opportunity so\n" + "join employer e on e.id = so.employer_Id\n"
			+ "left join opportunities o on o.id = so.opportunity_id\n"
			+ "left join broker_company bc on bc.id = o.broker_company_id\n"
			+ "left join individual_broker ib on ib.id = o.individual_broker_id \n"
			+ "join opportunity_sub_type_master tm on tm.id = so.oppurtunity_sub_type_master_id\n"
			+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN so.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
			+ "(CASE WHEN COALESCE(?5,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?6,'') or\n"
			+ "CASE WHEN COALESCE(?7,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?8,'')) AND\n"
			+ "CASE WHEN COALESCE(?9,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?10,'') AND\n"
			+ "CASE WHEN COALESCE(?11,'') <> '' THEN so.sfdc_id ELSE '' END LIKE COALESCE(?12,'')) and tm.opportunity_child_name = 'Broker sponsored'\n"
			+ "order by so.created_at desc", countQuery = "SELECT so.sub_group_opportunity_name,so.count as total_acount,so.total_active_count,e.employer_name,bc.broker_company_name,concat(ib.first_name,' ',ib.last_name) as individual_broker_name,so.id,so.sfdc_id, e.id as employer_Id,bc.id as brokerCompanyId , ib.id as individualBrokerId\n"
					+ "FROM sub_opportunity so\n" + "join employer e on e.id = so.employer_Id\n"
					+ "left join opportunities o on o.id = so.opportunity_id\n"
					+ "left join broker_company bc on bc.id = o.broker_company_id\n"
					+ "left join individual_broker ib on ib.id = o.individual_broker_id \n"
					+ "join opportunity_sub_type_master tm on tm.id = so.oppurtunity_sub_type_master_id\n"
					+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN so.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
					+ "(CASE WHEN COALESCE(?5,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?6,'') or\n"
					+ "CASE WHEN COALESCE(?7,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?8,'')) AND\n"
					+ "CASE WHEN COALESCE(?9,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?10,'') AND\n"
					+ "CASE WHEN COALESCE(?11,'') <> '' THEN so.sfdc_id ELSE '' END LIKE COALESCE(?12,'')) and tm.opportunity_child_name = 'Broker sponsored' \n"
					+ "order by so.created_at desc", nativeQuery = true)
	Page<Object[][]> getBrokerSponsore(String opportunityName, String opportunityName2, String brokerage,
			String brokerage2, String brokerName, String brokerName2, String brokerName3, String brokerName4,
			String employer, String employer2, String sfdcOpportunityId, String sfdcOpportunityId2,
			PageRequest pageRequest);

	@Query(value = "SELECT so.sub_group_opportunity_name,e.employer_name,e.email,e.contact_number,so.sfdc_id,so.status,so.id,e.id as employerId,so.count,e.country_code_Id \n"
			+ "FROM sub_opportunity so\n" + "join employer e on e.id = so.employer_Id\n"
			+ "left join opportunities o on o.id = so.opportunity_id\n"
			+ "join opportunity_sub_type_master tm on tm.id = so.oppurtunity_sub_type_master_id\n"
			+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN so.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN e.contact_number ELSE '' END LIKE COALESCE(?4,'') AND\n"
			+ "CASE WHEN COALESCE(?5,'') <> '' THEN e.email ELSE '' END LIKE COALESCE(?6,'') AND\n"
			+ "CASE WHEN COALESCE(?7,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?8,'') AND\n"
			+ "CASE WHEN COALESCE(?9,'') <> '' THEN so.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND\n"
			+ "CASE WHEN COALESCE(?11,'') <> '' THEN so.status ELSE '' END LIKE COALESCE(?12,'')) and tm.opportunity_child_name = 'Employer Direct'\n"
			+ "order by so.created_at desc", countQuery = "SELECT so.sub_group_opportunity_name,e.employer_name,e.email,e.contact_number,so.sfdc_id,so.status,so.id,e.id as employerId,so.count,e.country_code_Id \n"
					+ "FROM sub_opportunity so\n" + "join employer e on e.id = so.employer_Id\n"
					+ "left join opportunities o on o.id = so.opportunity_id\n"
					+ "join opportunity_sub_type_master tm on tm.id = so.oppurtunity_sub_type_master_id\n"
					+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN so.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN e.contact_number ELSE '' END LIKE COALESCE(?4,'') AND\n"
					+ "CASE WHEN COALESCE(?5,'') <> '' THEN e.email ELSE '' END LIKE COALESCE(?6,'') AND\n"
					+ "CASE WHEN COALESCE(?7,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?8,'') AND\n"
					+ "CASE WHEN COALESCE(?9,'') <> '' THEN so.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND\n"
					+ "CASE WHEN COALESCE(?11,'') <> '' THEN so.status ELSE '' END LIKE COALESCE(?12,'')) and tm.opportunity_child_name = 'Employer Direct'\n"
					+ "order by so.created_at desc", nativeQuery = true)

	Page<Object[][]> getEmployerDirect(String opportunityName, String opportunityName2, String contactNumber,
			String contactNumber2, String emailId, String emailId2, String employer, String employer2, String sfdcId,
			String sfdcId2, String status, String status2, PageRequest pageRequest);

	@Query(value = "select distinct(individual_broker_id) from opportunities where organization_Id =?1", nativeQuery = true)
	List<Long> getIndividualBrokerIds(Long orgId);

	Optional<Opportunity> findByIndividualBrokerIdAndOrganizationIdAndOpportunityTypeMasterId(
			IndividualBroker individualBroker, Long orgId, OpportunityTypeMaster opportunityType);

	List<Opportunity> findAllByOpportunityTypeMasterId(OpportunityTypeMaster opportunityTypeMaster);

	List<Opportunity> findByBrokerCompanyId(BrokerCompany brokerCompany);

	List<Opportunity> findByBrokerCompanyIdAndOpportunityTypeMasterId(BrokerCompany brokerCompany,
			OpportunityTypeMaster opportunityTypeMaster);

	List<Opportunity> findByIndividualBrokerIdAndOpportunityTypeMasterId(IndividualBroker individualBroker,
			OpportunityTypeMaster opportunityTypeMaster);

	@Query(value = "select ou.id,ou.revtype,ou.updated_at,ou.user_id,ou.opportunity_name,ou.sfdc_id,ou.status,ou.broker_company_id,\n"
			+ "ou.individual_broker_id,ou.opportunity_type_master_Id,ou.rev,bc.broker_company_name,concat(ib.first_name ,' ' ,ib.last_name),im.opportunity_child_name\n"
			+ "from billdog_entity.opportunities_aud ou\n"
			+ "join opportunity_type_master otm on otm.id = ou.opportunity_type_master_Id\n"
			+ "left join broker_company bc on bc.id = ou.broker_company_id\n"
			+ "left join individual_broker ib on ib.id = ou.individual_broker_id\n"
			+ "left join opportunity_sub_type_master im on im.id =ou.opportunity_type_master_Id\n"
			+ "left join opportunities op on op.id = ou.id\n" + "join organization o on o.id = op.organization_id\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN ou.opportunity_name ELSE '' END LIKE COALESCE(?2,'') \n"
			+ "and date(ou.updated_at) BETWEEN ?3 AND ?4 and revtype in ?5 and otm.opportunity_parent_name = 'Block opportunity' and op.organization_id = ?6\n"
			+ "order by ou.updated_at desc", countQuery = "select ou.id,ou.revtype,ou.updated_at,ou.user_id,ou.opportunity_name,ou.sfdc_id,ou.status,ou.broker_company_id,\n"
					+ "ou.individual_broker_id,ou.opportunity_type_master_Id,ou.rev,bc.broker_company_name,concat(ib.first_name ,' ' ,ib.last_name),im.opportunity_child_name\n"
					+ "from billdog_entity.opportunities_aud ou\n"
					+ "join opportunity_type_master otm on otm.id = ou.opportunity_type_master_Id\n"
					+ "left join broker_company bc on bc.id = ou.broker_company_id\n"
					+ "left join individual_broker ib on ib.id = ou.individual_broker_id\n"
					+ "left join opportunity_sub_type_master im on im.id =ou.opportunity_type_master_Id\n"
					+ "left join opportunities op on op.id = ou.id\n"
					+ "join organization o on o.id = op.organization_id\n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN ou.opportunity_name ELSE '' END LIKE COALESCE(?2,'') \n"
					+ "and date(ou.updated_at) BETWEEN ?3 AND ?4 and revtype in ?5 and otm.opportunity_parent_name = 'Block opportunity' and op.organization_id = ?6\n"
					+ "order by ou.updated_at desc", nativeQuery = true)
	Page<Object[]> getOpportunityAuditInfo(String name, String name2, String string, String endDate,
			List<Long> revtypes, long organizationId, PageRequest pageRequest);

	@Query(value = "select ou.id,ou.revtype,ou.updated_at,ou.user_id,ou.opportunity_name,ou.sfdc_id,ou.status,ou.broker_company_id,\n"
			+ "ou.individual_broker_id,ou.opportunity_type_master_Id,ou.rev,bc.broker_company_name,concat(ib.first_name ,' ' ,ib.last_name),im.opportunity_child_name\n"
			+ "from billdog_entity.opportunities_aud ou\n"
			+ "join opportunity_type_master otm on otm.id = ou.opportunity_type_master_Id\n"
			+ "left join broker_company bc on bc.id = ou.broker_company_id\n"
			+ "left join individual_broker ib on ib.id = ou.individual_broker_id\n"
			+ "left join opportunity_sub_type_master im on im.id =ou.opportunity_type_master_Id\n"
			+ "where ou.id =?1 and ou.rev<?2 and otm.opportunity_parent_name = 'Block opportunity' limit 1", countQuery = "select ou.id,ou.revtype,ou.updated_at,ou.user_id,ou.opportunity_name,ou.sfdc_id,ou.status,ou.broker_company_id,\n"
					+ "ou.individual_broker_id,ou.opportunity_type_master_Id,ou.rev,bc.broker_company_name,concat(ib.first_name ,' ' ,ib.last_name),im.opportunity_child_name\n"
					+ "from billdog_entity.opportunities_aud ou\n"
					+ "join opportunity_type_master otm on otm.id = ou.opportunity_type_master_Id\n"
					+ "left join broker_company bc on bc.id = ou.broker_company_id\n"
					+ "left join individual_broker ib on ib.id = ou.individual_broker_id\n"
					+ "left join opportunity_sub_type_master im on im.id =ou.opportunity_type_master_Id\n"
					+ "where ou.id =?1 and ou.rev<?2 and otm.opportunity_parent_name = 'Block opportunity' limit 1", nativeQuery = true)
	List<Object[]> getBlockOppAuditInfoByIdAndRev(long longValue, long longValue2);

	@Query(value = "select ou.id,ou.revtype,ou.updated_at,ou.user_id,ou.opportunity_name,ou.sfdc_id,ou.status,ou.broker_company_id,\n"
			+ "       ou.individual_broker_id,ou.opportunity_type_master_Id,ou.rev,bc.broker_company_name,\n"
			+ "       concat(ib.first_name ,' ' ,ib.last_name),otm.opportunity_parent_name\n"
			+ "from opportunities_aud ou\n"
			+ " join opportunity_type_master otm on otm.id = ou.opportunity_type_master_Id\n"
			+ " left join broker_company bc on bc.id = ou.broker_company_id\n"
			+ "    left join individual_broker ib on ib.id = ou.individual_broker_id where ou.id=?1\n"
			+ "    and otm.opportunity_parent_name = 'Block opportunity'  order by ou.rev desc", countQuery = "select ou.id,ou.revtype,ou.updated_at,ou.user_id,ou.opportunity_name,ou.sfdc_id,ou.status,ou.broker_company_id,\n"
					+ "       ou.individual_broker_id,ou.opportunity_type_master_Id,ou.rev,bc.broker_company_name,\n"
					+ "       concat(ib.first_name ,' ' ,ib.last_name),otm.opportunity_parent_name\n"
					+ "from opportunities_aud ou\n"
					+ " join opportunity_type_master otm on otm.id = ou.opportunity_type_master_Id\n"
					+ " left join broker_company bc on bc.id = ou.broker_company_id\n"
					+ "    left join individual_broker ib on ib.id = ou.individual_broker_id where ou.id=?1\n"
					+ "    and otm.opportunity_parent_name = 'Block opportunity'  order by ou.rev desc", nativeQuery = true)
	Page<Object[]> getBlockOppAuditInfoById(Long id, PageRequest pageRequest);

	@Query(value = "SELECT o.opportunity_name,bc.broker_company_name,concat(ib.first_name,' ',ib.last_name) as individual_broker_name,o.id,otm.opportunity_parent_name,  o.broker_company_id, o.individual_broker_id,o.sfdc_id\n"
			+ "FROM opportunities o\n" + "join broker_company bc on bc.id = o.broker_company_id\n"
			+ "join individual_broker ib on ib.id = o.individual_broker_id\n"
			+ "join opportunity_type_master otm on otm.id= o.opportunity_type_master_Id\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN o.opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ " CASE WHEN COALESCE(?3,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
			+ " (CASE WHEN COALESCE(?5,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?6,'') or\n"
			+ " CASE WHEN COALESCE(?7,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?8,'')) AND\n"
			+ " CASE WHEN COALESCE(?9,'') <> '' THEN o.sfdc_id ELSE '' END LIKE COALESCE(?10,'') and otm.opportunity_parent_name =?11 and ib.email = ?12\n"
			+ " order by o.created_at desc", countQuery = "SELECT o.opportunity_name,bc.broker_company_name,concat(ib.first_name,' ',ib.last_name) as individual_broker_name,o.id,otm.opportunity_parent_name, o.broker_company_id, o.individual_broker_id,o.sfdc_id \n"
					+ "FROM opportunities o\n" + "join broker_company bc on bc.id = o.broker_company_id\n"
					+ "join individual_broker ib on ib.id = o.individual_broker_id\n"
					+ "join opportunity_type_master otm on otm.id= o.opportunity_type_master_Id\n"
					+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN o.opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ " CASE WHEN COALESCE(?3,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
					+ " (CASE WHEN COALESCE(?5,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?6,'') or\n"
					+ " CASE WHEN COALESCE(?7,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?8,'')) AND\n"
					+ " CASE WHEN COALESCE(?9,'') <> '' THEN o.sfdc_id ELSE '' END LIKE COALESCE(?10,'') and otm.opportunity_parent_name =?11 and ib.email = ?12\n"
					+ " order by o.created_at desc", nativeQuery = true)
	Page<Object[][]> getExternalUserBlockOpportunities(String opportunityName, String opportunityName2,
			String brokerage, String brokerage2, String brokerName, String brokerName2, String brokerName3,
			String brokerName4, String sfdcOpportunityId, String sfdcOpportunityId2, String block,
			String externalUserEmail, PageRequest pageRequest);

	@Query(value = "SELECT so.sub_group_opportunity_name,so.count as total_acount,so.total_active_count,e.employer_name,bc.broker_company_name,concat(ib.first_name,' ',ib.last_name) as individual_broker_name,so.id,so.sfdc_id, e.id as employer_Id,bc.id as brokerCompanyId , ib.id as individualBrokerId \n"
			+ "FROM sub_opportunity so\n" + "join employer e on e.id = so.employer_Id\n"
			+ "left join opportunities o on o.id = so.opportunity_id\n"
			+ "left join broker_company bc on bc.id = o.broker_company_id\n"
			+ "left join individual_broker ib on ib.id = o.individual_broker_id \n"
			+ "join opportunity_sub_type_master tm on tm.id = so.oppurtunity_sub_type_master_id\n"
			+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN so.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
			+ "(CASE WHEN COALESCE(?5,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?6,'') or\n"
			+ "CASE WHEN COALESCE(?7,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?8,'')) AND\n"
			+ "CASE WHEN COALESCE(?9,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?10,'') AND\n"
			+ "CASE WHEN COALESCE(?11,'') <> '' THEN so.sfdc_id ELSE '' END LIKE COALESCE(?12,'')) and tm.opportunity_child_name = 'Broker sponsored' and ib.email = ?13\n"
			+ "order by so.created_at desc", countQuery = "SELECT so.sub_group_opportunity_name,so.count as total_acount,so.total_active_count,e.employer_name,bc.broker_company_name,concat(ib.first_name,' ',ib.last_name) as individual_broker_name,so.id,so.sfdc_id, e.id as employer_Id,bc.id as brokerCompanyId , ib.id as individualBrokerId\n"
					+ "FROM sub_opportunity so\n" + "join employer e on e.id = so.employer_Id\n"
					+ "left join opportunities o on o.id = so.opportunity_id\n"
					+ "left join broker_company bc on bc.id = o.broker_company_id\n"
					+ "left join individual_broker ib on ib.id = o.individual_broker_id \n"
					+ "join opportunity_sub_type_master tm on tm.id = so.oppurtunity_sub_type_master_id\n"
					+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN so.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN bc.broker_company_name ELSE '' END LIKE COALESCE(?4,'') AND\n"
					+ "(CASE WHEN COALESCE(?5,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?6,'') or\n"
					+ "CASE WHEN COALESCE(?7,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?8,'')) AND\n"
					+ "CASE WHEN COALESCE(?9,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?10,'') AND\n"
					+ "CASE WHEN COALESCE(?11,'') <> '' THEN so.sfdc_id ELSE '' END LIKE COALESCE(?12,'')) and tm.opportunity_child_name = 'Broker sponsored' and ib.email = ?13\n"
					+ "order by so.created_at desc", nativeQuery = true)
	Page<Object[][]> getExternalUserBrokerSponsore(String opportunityName, String opportunityName2, String brokerage,
			String brokerage2, String brokerName, String brokerName2, String brokerName3, String brokerName4,
			String employer, String employer2, String sfdcOpportunityId, String sfdcOpportunityId2,
			String externalUserEmail, PageRequest pageRequest);

	@Query(value = "SELECT so.sub_group_opportunity_name,e.employer_name,e.email,e.contact_number,so.sfdc_id,so.status,so.id,e.id as employerId,so.count,e.country_code_Id \n"
			+ "FROM sub_opportunity so\n" + "join employer e on e.id = so.employer_Id\n"
			+ "left join opportunities o on o.id = so.opportunity_id\n"
			+ "join opportunity_sub_type_master tm on tm.id = so.oppurtunity_sub_type_master_id\n"
			+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN so.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN e.contact_number ELSE '' END LIKE COALESCE(?4,'') AND\n"
			+ "CASE WHEN COALESCE(?5,'') <> '' THEN e.email ELSE '' END LIKE COALESCE(?6,'') AND\n"
			+ "CASE WHEN COALESCE(?7,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?8,'') AND\n"
			+ "CASE WHEN COALESCE(?9,'') <> '' THEN so.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND\n"
			+ "CASE WHEN COALESCE(?11,'') <> '' THEN so.status ELSE '' END LIKE COALESCE(?12,'')) and tm.opportunity_child_name = 'Employer Direct' and ib.email = ?13\n"
			+ "order by so.created_at desc", countQuery = "SELECT so.sub_group_opportunity_name,e.employer_name,e.email,e.contact_number,so.sfdc_id,so.status,so.id,e.id as employerId,so.count,e.country_code_Id \n"
					+ "FROM sub_opportunity so\n" + "join employer e on e.id = so.employer_Id\n"
					+ "left join opportunities o on o.id = so.opportunity_id\n"
					+ "join opportunity_sub_type_master tm on tm.id = so.oppurtunity_sub_type_master_id\n"
					+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN so.sub_group_opportunity_name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN e.contact_number ELSE '' END LIKE COALESCE(?4,'') AND\n"
					+ "CASE WHEN COALESCE(?5,'') <> '' THEN e.email ELSE '' END LIKE COALESCE(?6,'') AND\n"
					+ "CASE WHEN COALESCE(?7,'') <> '' THEN e.employer_name ELSE '' END LIKE COALESCE(?8,'') AND\n"
					+ "CASE WHEN COALESCE(?9,'') <> '' THEN so.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND\n"
					+ "CASE WHEN COALESCE(?11,'') <> '' THEN so.status ELSE '' END LIKE COALESCE(?12,'')) and tm.opportunity_child_name = 'Employer Direct' and ib.email = ?13\n"
					+ "order by so.created_at desc", nativeQuery = true)

	Page<Object[][]> getExternalEmployerDirect(String opportunityName, String opportunityName2, String contactNumber,
			String contactNumber2, String emailId, String emailId2, String employer, String employer2, String sfdcId,
			String sfdcId2, String status, String status2, String externalUserEmail, PageRequest pageRequest);

}
