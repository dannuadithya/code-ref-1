package com.billdog.entities.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.AuditConstants;
import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.OpportunityAuditModules;
import com.billdog.entities.common.RecordsTime;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.repository.OpportunityRepository;
import com.billdog.entities.repository.SubOpportunityRepository;
import com.billdog.entities.request.AuditRequest;
import com.billdog.entities.request.GetUsersRequest;
import com.billdog.entities.view.GetUsers;
import com.billdog.entities.view.ViewAuditResponse;
import com.billdog.entities.view.ViewResponse;
import com.billdog.entities.view.ViewUserInfo;

@Service
public class OpportunityAuditService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AuditService.class);

	@Autowired
	OpportunityRepository opportunityRepository;

	@Autowired
	SubOpportunityRepository subOpportunityRepository;

	@Autowired
	AuditService auditService;

	@Autowired
	UserService userService;

	public ResponseEntity<ViewResponse> getOpportunityAuditInfo(AuditRequest auditRequest) {
		LOGGER.info("getMemberAuditInfo method ended");
		List<Long> revtypes = getRevtypes(auditRequest);
		if (StringUtils.isBlank(auditRequest.getModuleName())) {
			throw new BadRequestException(ExceptionalMessages.PLEASE_PROVIDE_MODULE);
		}
		if (auditRequest.getModuleName().equalsIgnoreCase(OpportunityAuditModules.Block_Opportunity.toString())) {
			return getOpportunityAuditInfo(auditRequest, revtypes);
		}

		if (auditRequest.getModuleName().equalsIgnoreCase(OpportunityAuditModules.Sub_Group_Opportunity.toString())) {
			return getSubOpportunityAuditInfo(auditRequest, revtypes);
		}

		if (auditRequest.getModuleName().equalsIgnoreCase(OpportunityAuditModules.Broker_Sponsored.toString())) {
			return getBrokerSponsoredAuditInfo(auditRequest, revtypes);
		}

		if (auditRequest.getModuleName().equalsIgnoreCase(OpportunityAuditModules.Employer_Direct.toString())) {
			return getEmployerDirectAuditInfo(auditRequest, revtypes);
		}

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.NO_RESULTS_FOUND);
		LOGGER.info("getMemberAuditInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getEmployerDirectAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getEmployerDirectAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = auditService.getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (!StringUtils.isBlank(auditRequest.getTimePeriod())
				&& auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.CUSTOM.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}
		Page<Object[]> subOppObjects = subOpportunityRepository.getEmployerDirectAuditInfo(name, name, startDate,
				endDate, revtypes, auditRequest.getOrganizationId(),
				getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getEmployerDirectData(subOppObjects.getContent());
		response.setTotalElements(subOppObjects.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getEmployerDirectData(List<Object[]> subOppObjects) {
		List<ViewAuditResponse> viewAuditResponses = new ArrayList<>();
		GetUsers usersInfoList = getUsersInfoList(subOppObjects);
		subOppObjects.forEach(item -> {
			ViewAuditResponse viewAuditResponse = new ViewAuditResponse();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> employerDirectOppObj = subOpportunityRepository.getEmployerDirectAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[11]).longValue());
				if (employerDirectOppObj != null && !employerDirectOppObj.isEmpty()) {
					for (Object[] item2 : employerDirectOppObj) {
						viewAuditResponse = setSubBlockOppValues(item, item2, viewAuditResponse,
								usersInfoList.getData());
					}
				}
				if (viewAuditResponse != null && (!StringUtils.isBlank(viewAuditResponse.getOldValue())
						|| !StringUtils.isBlank(viewAuditResponse.getNewValue()))) {
					viewAuditResponses.add(viewAuditResponse);
				} else {
					viewAuditResponse.setNewValue(Constants.NO_CHANGE);
					viewAuditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditResponses.add(viewAuditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				viewAuditResponse = setCreatedBlockSubOpp(item, viewAuditResponse, usersInfoList.getData());
				if (viewAuditResponse != null && !StringUtils.isBlank(viewAuditResponse.getNewValue())) {
					viewAuditResponses.add(viewAuditResponse);
				}

			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(subOppObjects.size());
		response.setData(viewAuditResponses);
		response.setMessage(Constants.OPPORTUNITY_AUDIT_FETCHED);
		if (subOppObjects.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getBlockOpportunityData method ended");
		return response;
	}

	public ResponseEntity<ViewResponse> getBrokerSponsoredAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getBrokerSponsoredAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		LocalDateTime startDate = getDate(auditRequest.getTimePeriod());
		String endDate = LocalDate.now().toString();
		Page<Object[]> subOppObjects = subOpportunityRepository.getBrokerSponsoredAuditInfo(name, name,
				startDate.toString(), endDate, revtypes, auditRequest.getOrganizationId(),
				getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getBrokerSposnoredData(subOppObjects.getContent());
		response.setTotalElements(subOppObjects.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getBrokerSposnoredData(List<Object[]> subOppObjects) {
		List<ViewAuditResponse> viewAuditResponses = new ArrayList<>();
		GetUsers usersInfoList = getUsersInfoList(subOppObjects);
		subOppObjects.forEach(item -> {
			ViewAuditResponse viewAuditResponse = new ViewAuditResponse();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> subOppOppObj = subOpportunityRepository.getBrokerSponsoredAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[11]).longValue());
				if (subOppOppObj != null && !subOppOppObj.isEmpty()) {
					for (Object[] item2 : subOppOppObj) {
						viewAuditResponse = setSubBlockOppValues(item, item2, viewAuditResponse,
								usersInfoList.getData());
					}
				}
				if (viewAuditResponse != null && (!StringUtils.isBlank(viewAuditResponse.getOldValue())
						|| !StringUtils.isBlank(viewAuditResponse.getNewValue()))) {
					viewAuditResponses.add(viewAuditResponse);
				} else {
					viewAuditResponse.setNewValue(Constants.NO_CHANGE);
					viewAuditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditResponses.add(viewAuditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				viewAuditResponse = setCreatedBlockSubOpp(item, viewAuditResponse, usersInfoList.getData());
				if (viewAuditResponse != null && !StringUtils.isBlank(viewAuditResponse.getNewValue())) {
					viewAuditResponses.add(viewAuditResponse);
				}

			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(subOppObjects.size());
		response.setData(viewAuditResponses);
		response.setMessage(Constants.OPPORTUNITY_AUDIT_FETCHED);
		if (subOppObjects.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getBlockOpportunityData method ended");
		return response;
	}

	public ResponseEntity<ViewResponse> getSubOpportunityAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getSubOpportunityAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = auditService.getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (!StringUtils.isBlank(auditRequest.getTimePeriod())
				&& auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.CUSTOM.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}
		Page<Object[]> subOppObjects = subOpportunityRepository.getSubOpportunityAuditInfo(name, name,
				startDate.toString(), endDate, revtypes, auditRequest.getOrganizationId(),
				getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getSubOpportunityData(subOppObjects.getContent());
		response.setTotalElements(subOppObjects.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getSubOpportunityData(List<Object[]> subOppObjects) {
		List<ViewAuditResponse> viewAuditResponses = new ArrayList<>();
		GetUsers usersInfoList = getUsersInfoList(subOppObjects);
		subOppObjects.forEach(item -> {
			ViewAuditResponse viewAuditResponse = new ViewAuditResponse();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> subOppOppObj = subOpportunityRepository.getSubOppAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[11]).longValue());
				if (subOppOppObj != null && !subOppOppObj.isEmpty()) {
					for (Object[] item2 : subOppOppObj) {
						viewAuditResponse = setSubBlockOppValues(item, item2, viewAuditResponse,
								usersInfoList.getData());
					}
				}
				if (viewAuditResponse != null && (!StringUtils.isBlank(viewAuditResponse.getOldValue())
						|| !StringUtils.isBlank(viewAuditResponse.getNewValue()))) {
					viewAuditResponses.add(viewAuditResponse);
				} else {
					viewAuditResponse.setNewValue(Constants.NO_CHANGE);
					viewAuditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditResponses.add(viewAuditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				viewAuditResponse = setCreatedBlockSubOpp(item, viewAuditResponse, usersInfoList.getData());
				if (viewAuditResponse != null && !StringUtils.isBlank(viewAuditResponse.getNewValue())) {
					viewAuditResponses.add(viewAuditResponse);
				}

			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(subOppObjects.size());
		response.setData(viewAuditResponses);
		response.setMessage(Constants.OPPORTUNITY_AUDIT_FETCHED);
		if (subOppObjects.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getBlockOpportunityData method ended");
		return response;
	}

	private ViewAuditResponse setCreatedBlockSubOpp(Object[] item, ViewAuditResponse auditResponse,
			List<ViewUserInfo> list) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];

		if (item[4] != null) {
			newValue = newValue != null ? newValue + ", count: " + item[4] : "count: " + item[4];
		}
		if (item[5] != null && !StringUtils.isBlank((String) item[5])) {
			newValue = newValue != null ? newValue + ", sfdc id: " + item[5] : "sfdc id: " + item[5];
		}

		if (item[6] != null && !StringUtils.isBlank((String) item[6])) {
			newValue = newValue != null ? newValue + ", status: " + item[6] : "status: " + item[6];
		}
		if (item[7] != null && !StringUtils.isBlank((String) item[7])) {
			newValue = newValue != null ? newValue + ", sub group opportunity name: " + item[7]
					: "sub group opportunity name: " + item[7];
		}

		if (item[12] != null && !StringUtils.isBlank((String) item[12])) {
			newValue = newValue != null ? newValue + ", employer: " + item[12] : "employer: " + item[12];
		}

		if (item[13] != null && !StringUtils.isBlank((String) item[13])) {
			newValue = newValue != null ? newValue + ", opportunity: " + item[13] : "opportunity: " + item[13];
		}

		if (item[10] != null) {
			newValue = newValue != null ? newValue + ", total active count: " + item[10]
					: "total active count: " + item[10];
		}

		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		if (item[3] != null) {
			ViewUserInfo userInfo = getUserInfo(((BigInteger) item[3]).longValue(), list);
			auditResponse.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
			if (!StringUtils.isBlank(userInfo.getName())) {
				auditResponse.setModifiedBy(userInfo.getName());
			}
		}
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		auditResponse.setNewValue(newValue);
		auditResponse.setMemberOrUser("User");
		return auditResponse;

	}

	private ViewAuditResponse setSubBlockOppValues(Object[] item, Object[] item2, ViewAuditResponse viewAuditResponse,
			List<ViewUserInfo> list) {
		boolean updated = false;
		String oldValue = null;
		String newValue = null;

		Timestamp updatedAt = (Timestamp) item[2];

		if (item[4] != null && !((BigInteger) item[4]).equals(item2[4])) {
			LOGGER.info("count modified from {} to {}", item2[4], item[4]);
			updated = true;
			oldValue = oldValue != null ? oldValue + ", count: " + item2[4] : "count: " + item2[4];
			newValue = newValue != null ? newValue + ", count: " + item[4] : "count: " + item[4];
		}

		if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])
				&& !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.SFDC_ID + item2[5]
					: AuditConstants.SFDC_ID + item2[5];
			newValue = newValue != null ? newValue + ", " + AuditConstants.SFDC_ID + item[5]
					: AuditConstants.SFDC_ID + item[5];
		}
		if (!StringUtils.isBlank((String) item[5]) && StringUtils.isBlank((String) item2[5])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.SFDC_ID + item[5]
					: AuditConstants.SFDC_ID + item[5];
		}
		if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.SFDC_ID + item2[5]
					: AuditConstants.SFDC_ID + item2[5];
		}

		if (!StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])
				&& !((String) item[6]).equalsIgnoreCase((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.STATUS + item2[6]
					: AuditConstants.STATUS + item2[6];
			newValue = newValue != null ? newValue + ", " + AuditConstants.STATUS + item[6]
					: AuditConstants.STATUS + item[6];
		}
		if (!StringUtils.isBlank((String) item[6]) && StringUtils.isBlank((String) item2[6])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.STATUS + item[6]
					: AuditConstants.STATUS + item[6];
		}
		if (StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.STATUS + item2[6]
					: AuditConstants.STATUS + item2[6];
		}

		if (!StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])
				&& !((String) item[7]).equalsIgnoreCase((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "sub group opportunity name: " + item2[7]
					: "sub group opportunity name: " + item2[7];
			newValue = newValue != null ? newValue + ", " + "sub group opportunity name: " + item[7]
					: "sub group opportunity name: " + item[7];
		}
		if (!StringUtils.isBlank((String) item[7]) && StringUtils.isBlank((String) item2[7])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "sub group opportunity name: " + item[7]
					: "sub group opportunity name: " + item[7];
		}
		if (StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "sub group opportunity name: " + item2[7]
					: "sub group opportunity name: " + item2[7];
		}

		if (!StringUtils.isBlank((String) item[12]) && !StringUtils.isBlank((String) item2[12])
				&& !((String) item[12]).equalsIgnoreCase((String) item2[12])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "employer: " + item2[12] : "employer: " + item2[12];
			newValue = newValue != null ? newValue + ", " + "employer: " + item[12] : "employer: " + item[12];
		}
		if (!StringUtils.isBlank((String) item[12]) && StringUtils.isBlank((String) item2[12])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "employer: " + item[12] : "employer: " + item[12];
		}
		if (StringUtils.isBlank((String) item[12]) && !StringUtils.isBlank((String) item2[12])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "employer: " + item2[12] : "employer: " + item2[12];
		}

		if (!StringUtils.isBlank((String) item[13]) && !StringUtils.isBlank((String) item2[13])
				&& !((String) item[12]).equalsIgnoreCase((String) item2[12])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "opportunity: " + item2[13] : "opportunity: " + item2[13];
			newValue = newValue != null ? newValue + ", " + "opportunity: " + item[13] : "opportunity: " + item[13];
		}
		if (!StringUtils.isBlank((String) item[13]) && StringUtils.isBlank((String) item2[13])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "opportunity: " + item[13] : "opportunity: " + item[13];
		}
		if (StringUtils.isBlank((String) item[13]) && !StringUtils.isBlank((String) item2[13])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "opportunity: " + item2[13] : "opportunity: " + item2[13];
		}
		if (item[10] != null && !((BigInteger) item[10]).equals(item2[10])) {
			LOGGER.info("total active count modified from {} to {}", item2[10], item[10]);
			updated = true;
			oldValue = oldValue != null ? oldValue + ", total active count: " + item2[10]
					: "total active count: " + item2[10];
			newValue = newValue != null ? newValue + ", total active count: " + item[10]
					: "total active count: " + item[10];
		}

		if (updated) {
			viewAuditResponse.setRecordId(((BigInteger) item[0]).longValue());
			viewAuditResponse.setMemberOrUser("User");
			if (item[3] != null) {
				ViewUserInfo userInfo = getUserInfo(((BigInteger) item[3]).longValue(), list);
				viewAuditResponse.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
				if (!StringUtils.isBlank(userInfo.getName())) {
					viewAuditResponse.setModifiedBy(userInfo.getName());
				}
			}
			viewAuditResponse.setAction(Constants.UPDATED);
			viewAuditResponse.setOldValue(oldValue);
			viewAuditResponse.setNewValue(newValue);
			viewAuditResponse.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
									+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			return viewAuditResponse;
		}
		viewAuditResponse.setRecordId(((BigInteger) item[0]).longValue());
		viewAuditResponse.setAction(getAction(item[1]));
		viewAuditResponse.setMemberOrUser(Constants.USER);
		if (item[3] != null) {
			ViewUserInfo userInfo = getUserInfo(((BigInteger) item[3]).longValue(), list);
			viewAuditResponse.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
			if (!StringUtils.isBlank(userInfo.getName())) {
				viewAuditResponse.setModifiedBy(userInfo.getName());
			}
		}
		viewAuditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		return viewAuditResponse;
	}

	public ResponseEntity<ViewResponse> getOpportunityAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getOpportunityAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = auditService.getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (!StringUtils.isBlank(auditRequest.getTimePeriod())
				&& auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.CUSTOM.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}
		Page<Object[]> blockOppObjects = opportunityRepository.getOpportunityAuditInfo(name, name, startDate.toString(),
				endDate, revtypes, auditRequest.getOrganizationId(),
				getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getBlockOpportunityData(blockOppObjects.getContent());
		response.setTotalElements(blockOppObjects.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getBlockOpportunityData(List<Object[]> blockOppObjects) {
		List<ViewAuditResponse> viewAuditResponses = new ArrayList<>();
		GetUsers usersInfoList = getUsersInfoList(blockOppObjects);
		blockOppObjects.forEach(item -> {
			ViewAuditResponse viewAuditResponse = new ViewAuditResponse();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> blockOppObj = opportunityRepository.getBlockOppAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[10]).longValue());
				if (blockOppObj != null && !blockOppObj.isEmpty()) {
					for (Object[] item2 : blockOppObj) {
						viewAuditResponse = setBlockOppValues(item, item2, viewAuditResponse, usersInfoList.getData());
					}
				}
				if (viewAuditResponse != null && (!StringUtils.isBlank(viewAuditResponse.getOldValue())
						|| !StringUtils.isBlank(viewAuditResponse.getNewValue()))) {
					viewAuditResponses.add(viewAuditResponse);
				} else {
					viewAuditResponse.setNewValue(Constants.NO_CHANGE);
					viewAuditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditResponses.add(viewAuditResponse);
				}

			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				viewAuditResponse = setCreatedBlockOpp(item, viewAuditResponse, usersInfoList.getData());
				if (viewAuditResponse != null && !StringUtils.isBlank(viewAuditResponse.getNewValue())) {
					viewAuditResponses.add(viewAuditResponse);
				}
			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(blockOppObjects.size());
		response.setData(viewAuditResponses);
		response.setMessage(Constants.OPPORTUNITY_AUDIT_FETCHED);
		if (blockOppObjects.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getBlockOpportunityData method ended");
		return response;
	}

	private GetUsers getUsersInfoList(List<Object[]> users) {
		List<Long> userIds = new ArrayList<>();
		users.forEach(user -> {
			if (user[3] != null) {
				userIds.add(((BigInteger) user[3]).longValue());
			}
		});
		return getUsersList(userIds);
	}

	public GetUsers getUsersList(List<Long> userIds) {
		GetUsersRequest request = new GetUsersRequest();
		request.setUserIds(userIds);
		return userService.getUsersInfo(request);
	}

	private ViewAuditResponse setCreatedBlockOpp(Object[] item, ViewAuditResponse auditResponse,
			List<ViewUserInfo> list) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];

		if (item[4] != null && !StringUtils.isBlank((String) item[4])) {
			newValue = newValue != null ? newValue + ", opportunity name: " + item[4] : "opportunity name: " + item[4];
		}
		if (item[5] != null && !StringUtils.isBlank((String) item[5])) {
			newValue = newValue != null ? newValue + ", sfdc id: " + item[5] : "sfdc id: " + item[5];
		}

		if (item[6] != null && !StringUtils.isBlank((String) item[6])) {
			newValue = newValue != null ? newValue + ", status: " + item[6] : "status: " + item[6];
		}

		if (item[11] != null && !StringUtils.isBlank((String) item[11])) {
			newValue = newValue != null ? newValue + ", broker company: " + item[11] : "broker company: " + item[11];
		}

		if (item[12] != null && !StringUtils.isBlank((String) item[12])) {
			newValue = newValue != null ? newValue + ", individual broker: " + item[12]
					: "individual broker: " + item[12];
		}

		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		if (item[3] != null) {
			ViewUserInfo userInfo = getUserInfo(((BigInteger) item[3]).longValue(), list);
			auditResponse.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
			if (!StringUtils.isBlank(userInfo.getName())) {
				auditResponse.setModifiedBy(userInfo.getName());
			}
		}
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		auditResponse.setNewValue(newValue);
		auditResponse.setMemberOrUser("User");
		return auditResponse;

	}

	private ViewAuditResponse setBlockOppValues(Object[] item, Object[] item2, ViewAuditResponse viewAuditResponse,
			List<ViewUserInfo> list) {
		boolean updated = false;
		String oldValue = null;
		String newValue = null;

		Timestamp updatedAt = (Timestamp) item[2];

		if (!StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])
				&& !((String) item[4]).equalsIgnoreCase((String) item2[4])) {
			LOGGER.info("opportunity name modified from {} to {}", item2[4], item[4]);
			updated = true;
			oldValue = oldValue != null ? oldValue + ", opportunity name: " + item2[4]
					: "opportunity name: " + item2[4];
			newValue = newValue != null ? newValue + ", opportunity name: " + item[4] : "opportunity name: " + item[4];
		}

		if (!StringUtils.isBlank((String) item[4]) && StringUtils.isBlank((String) item2[4])) {
			updated = true;
			newValue = "opportunity name: " + item[4];
		}
		if (StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])) {
			updated = true;
			oldValue = "opportunity name: " + item2[4];
		}

		if (item[5] != null && !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
			LOGGER.info("sfdc id modified from {} to {}", item2[5], item[5]);
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "sfdc id: " + item2[5] : "sfdc id: " + item2[5];
			newValue = newValue != null ? newValue + ", " + "sfdc id: " + item[5] : "sfdc id: " + item[5];
		}
		if (!StringUtils.isBlank((String) item[5]) && StringUtils.isBlank((String) item2[5])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "sfdc id: " + item[5] : "sfdc id: " + item[5];
		}
		if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "sfdc id: " + item2[5] : "sfdc id: " + item2[5];
		}

		if (item[6] != null && !((String) item[6]).equalsIgnoreCase((String) item2[6])) {
			LOGGER.info("status modified from {} to {}", item2[6], item[6]);
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "status: " + item2[6] : "status: " + item2[6];
			newValue = newValue != null ? newValue + ", " + "status: " + item[6] : "status: " + item[6];
		}
		if (!StringUtils.isBlank((String) item[6]) && StringUtils.isBlank((String) item2[6])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "status: " + item[6] : "status: " + item[6];
		}
		if (StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "status: " + item2[6] : "status: " + item2[6];
		}

		if (item[11] != null && !((String) item[11]).equalsIgnoreCase((String) item2[11])) {
			LOGGER.info("broker company modified from {} to {}", item2[11], item[11]);
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "broker company: " + item2[11]
					: "broker company: " + item2[11];
			newValue = newValue != null ? newValue + ", " + "broker company: " + item[11]
					: "broker company: " + item[11];
		}
		if (!StringUtils.isBlank((String) item[11]) && StringUtils.isBlank((String) item2[11])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "broker company: " + item[11]
					: "broker company: " + item[11];
		}
		if (StringUtils.isBlank((String) item[11]) && !StringUtils.isBlank((String) item2[11])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "broker company: " + item2[11]
					: "broker company: " + item2[11];
		}

		if (item[12] != null && !((String) item[12]).equalsIgnoreCase((String) item2[12])) {
			LOGGER.info("broker company modified from {} to {}", item2[12], item[12]);
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "individual broker: " + item2[12]
					: "individual broker: " + item2[12];
			newValue = newValue != null ? newValue + ", " + "individual broker: " + item[12]
					: "individual broker: " + item[12];
		}
		if (!StringUtils.isBlank((String) item[12]) && StringUtils.isBlank((String) item2[12])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "individual broker: " + item[12]
					: "individual broker: " + item[12];
		}
		if (StringUtils.isBlank((String) item[12]) && !StringUtils.isBlank((String) item2[12])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "individual broker: " + item2[12]
					: "individual broker: " + item2[12];
		}

		if (updated) {
			viewAuditResponse.setRecordId(((BigInteger) item[0]).longValue());
			viewAuditResponse.setMemberOrUser("User");
			if (item[3] != null) {
				ViewUserInfo userInfo = getUserInfo(((BigInteger) item[3]).longValue(), list);
				viewAuditResponse.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
				if (!StringUtils.isBlank(userInfo.getName())) {
					viewAuditResponse.setModifiedBy(userInfo.getName());
				}
			}
			viewAuditResponse.setAction(Constants.UPDATED);
			viewAuditResponse.setOldValue(oldValue);
			viewAuditResponse.setNewValue(newValue);
			viewAuditResponse.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
									+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			return viewAuditResponse;
		}
		viewAuditResponse.setMemberOrUser("User");
		viewAuditResponse.setRecordId(((BigInteger) item[0]).longValue());
		viewAuditResponse.setAction(getAction(item[1]));
		if (item[3] != null) {
			ViewUserInfo userInfo = getUserInfo(((BigInteger) item[3]).longValue(), list);
			viewAuditResponse.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
			if (!StringUtils.isBlank(userInfo.getName())) {
				viewAuditResponse.setModifiedBy(userInfo.getName());
			}
		}
		viewAuditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		return viewAuditResponse;
	}

	public ViewUserInfo getUserInfo(long userId, List<ViewUserInfo> usersInfo) {
		return usersInfo.stream().filter(user -> user.getId() == userId).findFirst().orElse(null);
	}

	private String getAction(Object item) {
		String action = null;
		int actionValue = ((Byte) item);
		if (actionValue == 0) {
			action = Constants.CREATED;
		}
		if (actionValue == 1) {
			action = Constants.UPDATED;
		}
		if (actionValue == 2) {
			action = Constants.DELETED;
		}
		return action;
	}

	public List<Long> getRevtypes(AuditRequest auditRequest) {
		List<Long> revtypes = new ArrayList<>();
		if (StringUtils.isBlank(auditRequest.getType()) || auditRequest.getType().equalsIgnoreCase("All")) {
			revtypes.add(0l);
			revtypes.add(1l);
			revtypes.add(2l);
		}
		if (auditRequest.getType().equalsIgnoreCase(Constants.CREATED)) {
			revtypes.add(0l);
		}
		if (auditRequest.getType().equalsIgnoreCase(Constants.UPDATED)) {
			revtypes.add(1l);
		}
		return revtypes;
	}

	public LocalDateTime getDate(String time) {
		LocalDate date = LocalDate.now();
		if (time.equalsIgnoreCase(RecordsTime.LAST_WEEK.toString().replace("_", " "))) {
			date = LocalDate.now().minusDays(7);
		} else if (time.equalsIgnoreCase(RecordsTime.LAST_MONTH.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(1);
		} else if (time.equalsIgnoreCase(RecordsTime.LAST_3_MONTHS.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(3);
		} else if (time.equalsIgnoreCase(RecordsTime.LAST_6_MONTHS.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(6);
		} else if (time.equalsIgnoreCase(RecordsTime.LAST_YEAR.toString().replace("_", " "))) {
			date = LocalDate.now().minusYears(1);
		} else {
			date = LocalDate.of(2020, 01, 01);
		}
		return date.atTime(00, 00);
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

//	public ResponseEntity<ViewResponse> getOpportunityAuditInfoById(Long recordId, String moduleName) {
//
//		if (moduleName.equalsIgnoreCase(OpportunityAuditModules.Block_Opportunity.toString())) {
//			return getBlockOppAuditInfoById(recordId);
//		}
//
//		if (moduleName.equalsIgnoreCase(OpportunityAuditModules.Sub_Group_Opportunity.toString())) {
//			return getSubOppAuditInfoById(recordId);
//		}
//
//		if (moduleName.equalsIgnoreCase(OpportunityAuditModules.Broker_Sponsored.toString())) {
//			return getBrokerSponsoredAuditInfoById(recordId);
//		}
//
//		if (moduleName.equalsIgnoreCase(OpportunityAuditModules.Employer_Direct.toString())) {
//			return getEmployerDirectAuditInfoById(recordId);
//		}
//
//		ViewResponse response = new ViewResponse();
//		response.setStatusText(Constants.SUCCESS);
//		response.setMessage(Constants.NO_RESULTS_FOUND);
//		LOGGER.info("getMemberAudit method ended");
//		return ResponseEntity.status(HttpStatus.OK).body(response);
//	}

	public ResponseEntity<ViewResponse> getBlockOppAuditInfoById(Long id, Integer pageNumber, Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null && pageLimit > 0 ? pageLimit : 20;
		Page<Object[]> blockOppObj = opportunityRepository.getBlockOppAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));

		ViewResponse response = getBlockOpportunityData(blockOppObj.getContent());
		if (blockOppObj.getTotalElements() > pageLimit) {
			response.setTotalElements(blockOppObj.getTotalElements());
		}

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getSubOppAuditInfoById(Long id, Integer pageNumber, Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null && pageLimit > 0 ? pageLimit : 20;
		Page<Object[]> blockOppObj = subOpportunityRepository.getSubOppAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));

		ViewResponse response = getSubOpportunityData(blockOppObj.getContent());
		if (blockOppObj.getTotalElements() > pageLimit) {
			response.setTotalElements(blockOppObj.getTotalElements());
		}

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getBrokerSponsoredAuditInfoById(Long id, Integer pageNumber,
			Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null && pageLimit > 0 ? pageLimit : 20;
		Page<Object[]> blockOppObj = subOpportunityRepository.getBrokerSponsoredAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));

		ViewResponse response = getBrokerSposnoredData(blockOppObj.getContent());
		if (blockOppObj.getTotalElements() > pageLimit) {
			response.setTotalElements(blockOppObj.getTotalElements());
		}

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getEmployerDirectAuditInfoById(Long id, Integer pageNumber, Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null && pageLimit > 0 ? pageLimit : 20;
		Page<Object[]> blockOppObj = subOpportunityRepository.getEmployerDirectAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));

		ViewResponse response = getEmployerDirectData(blockOppObj.getContent());
		if (blockOppObj.getTotalElements() > pageLimit) {
			response.setTotalElements(blockOppObj.getTotalElements());
		}

		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

}
