package com.billdog.entities.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.Employer;
import com.billdog.entities.entity.OpportunitySubTypeMaster;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.entity.SubOpportunity;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.EmployerRepository;
import com.billdog.entities.repository.OpportunitySubTypeMasterRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.repository.SubOpportunityRepository;
import com.billdog.entities.request.EmployerServiceRequest;
import com.billdog.entities.request.SaveMemberCountRequest;
import com.billdog.entities.request.SearchEmployerRequest;
import com.billdog.entities.request.UpdateEmployerRequest;
import com.billdog.entities.view.GetEmployerInfo;
import com.billdog.entities.view.ViewEmployer;
import com.billdog.entities.view.ViewEmployerList;
import com.billdog.entities.view.ViewEmployers;
import com.billdog.entities.view.ViewResponse;

@Service
public class EmployerService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(EmployerService.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	UserService userService;

	@Autowired
	EmployerRepository employerRepository;

	@Autowired
	CompanyProviderService companyProviderService;

	@Autowired
	SubOpportunityRepository subOpportunityRepository;

	@Autowired
	OpportunitySubTypeMasterRepository opportunitySubTypeMasterRepository;

	public ResponseEntity<ViewResponse> addEmployer(EmployerServiceRequest employerServiceRequest) {
		LOGGER.info("addEmployer method started..!");

		Optional<Organization> organization = organizationRepository
				.findById(employerServiceRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		requestValidate(employerServiceRequest);
		saveEmployer(employerServiceRequest, organization.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.EMPLOYER_SAVED);
		LOGGER.info("addEmployer method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void saveEmployer(EmployerServiceRequest employerServiceRequest, Organization organization) {
		LOGGER.debug("creating new object in employer table.!!");
		Employer employer = new Employer();
		employer.setCreatedAt(DateAndTimeUtil.now());
		employer.setUpdatedAt(DateAndTimeUtil.now());
		employer.setEmployerName(WordUtils.capitalizeFully(employerServiceRequest.getEmployerName()));
		employer.setContactName(WordUtils.capitalizeFully(employerServiceRequest.getContactName()));
		employer.setEmail(employerServiceRequest.getEmail());
		employer.setContactNumber(employerServiceRequest.getContactNumber());
		if (employerServiceRequest.getSfdcId() != null && !employerServiceRequest.getSfdcId().isEmpty()) {
			employer.setSfdcId(employerServiceRequest.getSfdcId());
			employer.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		employer.setAddress(employerServiceRequest.getAddress());
		employer.setOrganizationId(organization);
		employer.setStatus(StatusConstants.ACTIVE);
		if (employerServiceRequest.getCountryCodeId() > 0) {
			companyProviderService.checkCountryCode(employerServiceRequest.getCountryCodeId(), organization.getId());
			employer.setCountryCodeId(employerServiceRequest.getCountryCodeId());
		}
		employer.setUserId(employerServiceRequest.getUserId());
		employerRepository.save(employer);
	}

	private void requestValidate(EmployerServiceRequest employerServiceRequest) {

		if (!StringUtils.isBlank(employerServiceRequest.getEmployerName())) {
			Optional<Employer> employer = employerRepository
					.findByEmployerName(employerServiceRequest.getEmployerName());
			if (employer.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NAME);
			}
		} else {
			throw new BadRequestException(ExceptionalMessages.EMPLOYER_NAME_SIZE);
		}

		if (employerServiceRequest.getEmail() != null && !employerServiceRequest.getEmail().isEmpty()) {
			Optional<Employer> employerEmail = employerRepository.findByEmail(employerServiceRequest.getEmail());
			if (employerEmail.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
			}
		}

		if (employerServiceRequest.getSfdcId() != null && !employerServiceRequest.getSfdcId().isEmpty()) {
			if (employerServiceRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<Employer> employerSfdc = employerRepository.findBySfdcId(employerServiceRequest.getSfdcId());
			if (employerSfdc.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		if (employerServiceRequest.getContactName() != null && !employerServiceRequest.getContactName().isEmpty()
				&& (employerServiceRequest.getContactName().length() < 2
						|| employerServiceRequest.getContactName().length() > 20)) {

			throw new RecordNotFoundException(ExceptionalMessages.CONTACT_NAME);

		}

		if (employerServiceRequest.getContactNumber() != null && !employerServiceRequest.getContactNumber().isEmpty()
				&& !StringUtils.isNumeric(employerServiceRequest.getContactNumber())) {
			throw new RecordNotFoundException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (employerServiceRequest.getContactNumber() != null && !employerServiceRequest.getContactNumber().isEmpty()
				&& employerServiceRequest.getContactNumber().length() != 10) {
			throw new RecordNotFoundException(ExceptionalMessages.MOBILE_NUMER);
		}
		if (employerServiceRequest.getAddress() != null && !employerServiceRequest.getAddress().isEmpty()
				&& employerServiceRequest.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}
	}

	public ResponseEntity<ViewEmployers> getEmployerDetails(Long employerId) {
		LOGGER.info("getEmployerDetails method started..!");

		// checking whether broker company with given id present or not
		Optional<Employer> employer = employerRepository.findById(employerId);
		if (!employer.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
		}
		Employer employerDetails = employer.get();
		LOGGER.info("setting employer details to respective fields");
		ViewEmployers viewEmployers = new ViewEmployers();
		viewEmployers.setEmployerName(employerDetails.getEmployerName());
		viewEmployers.setContactName(employerDetails.getContactName());
		viewEmployers.setContactNo(employerDetails.getContactNumber());
		viewEmployers.setEmailId(employerDetails.getEmail());
		if (employerDetails.getSfdcId() != null) {
			viewEmployers.setSfdcId(employerDetails.getSfdcId());
		}
		viewEmployers.setStatus(employerDetails.getStatus());
		viewEmployers.setCountryCodeId(employerDetails.getCountryCodeId());
		viewEmployers.setAddress(employerDetails.getAddress());
		viewEmployers.setEmployerId(employerId);
		LOGGER.info("getEmployerDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewEmployers);
	}

	public ResponseEntity<ViewResponse> editEmployerDetails(UpdateEmployerRequest updateEmployerRequest) {
		LOGGER.info("editEmployerDetails method started..!");
		if (StringUtils.isBlank(updateEmployerRequest.getEmployerName())) {
			throw new BadRequestException(ExceptionalMessages.EMPLOYER_NAME_SIZE);
		}
		if (!StringUtils.isBlank(updateEmployerRequest.getContactName())
				&& (updateEmployerRequest.getContactName().length() < 2
						|| updateEmployerRequest.getContactName().length() > 20)) {
			throw new RecordNotFoundException(ExceptionalMessages.CONTACT_NAME);

		}

		if (!StringUtils.isBlank(updateEmployerRequest.getContactNumber())
				&& !StringUtils.isNumeric(updateEmployerRequest.getContactNumber())) {
			throw new RecordNotFoundException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (!StringUtils.isBlank(updateEmployerRequest.getContactNumber())
				&& updateEmployerRequest.getContactNumber().length() != 10) {
			throw new RecordNotFoundException(ExceptionalMessages.MOBILE_NUMER);
		}

		LOGGER.debug("fetching object in employer table.!!");
		Optional<Employer> employerEntity = employerRepository.findById(updateEmployerRequest.getEmployerId());
		if (!employerEntity.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
		}

		Optional<Employer> employer = employerRepository.findByEmployerName(updateEmployerRequest.getEmployerName());
		if (employer.isPresent() && updateEmployerRequest.getEmployerId() != employer.get().getId()) {
			throw new RecordNotFoundException(ExceptionalMessages.EMPLOYER_NAME);
		}
		if (!StringUtils.isBlank(updateEmployerRequest.getEmail())) {
			Optional<Employer> employerEmail = employerRepository.findByEmail(updateEmployerRequest.getEmail());
			if (employerEmail.isPresent() && !updateEmployerRequest.getEmail().isEmpty()
					&& updateEmployerRequest.getEmployerId() != employerEmail.get().getId()) {
				throw new RecordNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXISTS);
			}
		}
		if (!StringUtils.isBlank(updateEmployerRequest.getSfdcId())) {
			if (updateEmployerRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<Employer> employerSfdc = employerRepository.findBySfdcId(updateEmployerRequest.getSfdcId());
			if (employerSfdc.isPresent() && updateEmployerRequest.getEmployerId() != employerSfdc.get().getId()) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
			}
		}

		if (!StringUtils.isBlank(updateEmployerRequest.getAddress())
				&& updateEmployerRequest.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}

		LOGGER.info("setting employer details to respective fields");
		updateEmployer(updateEmployerRequest, employerEntity.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.EMPLOYER_UPDATED);
		LOGGER.info("editEmployerDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void updateEmployer(UpdateEmployerRequest updateEmployerRequest, Employer employer) {

		employer.setCreatedAt(DateAndTimeUtil.now());
		employer.setUpdatedAt(DateAndTimeUtil.now());
		employer.setEmployerName(WordUtils.capitalizeFully(updateEmployerRequest.getEmployerName()));
		employer.setContactName(WordUtils.capitalizeFully(updateEmployerRequest.getContactName()));
		employer.setEmployerName(WordUtils.capitalizeFully(updateEmployerRequest.getEmployerName()));
		employer.setContactName(WordUtils.capitalizeFully(updateEmployerRequest.getContactName()));
		employer.setEmail(updateEmployerRequest.getEmail());
		employer.setContactNumber(updateEmployerRequest.getContactNumber());
		if (!StringUtils.isBlank(updateEmployerRequest.getSfdcId())
				&& !employer.getSfdcId().equalsIgnoreCase(updateEmployerRequest.getSfdcId())) {
			employer.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		employer.setSfdcId(updateEmployerRequest.getSfdcId());
		employer.setAddress(updateEmployerRequest.getAddress());
		if (updateEmployerRequest.getStatus() != null) {
			employer.setStatus(updateEmployerRequest.getStatus());
		}
		if (updateEmployerRequest.getCountryCodeId() > 0) {
			companyProviderService.checkCountryCode(updateEmployerRequest.getCountryCodeId(),
					employer.getOrganizationId().getId());
			employer.setCountryCodeId(updateEmployerRequest.getCountryCodeId());
		}
		employer.setUserId(updateEmployerRequest.getUserId());
		employer.setAddress(updateEmployerRequest.getAddress());

		employerRepository.save(employer);

	}

	public ViewResponse searchEmployer(SearchEmployerRequest employerRequest, long orgId) {
		LOGGER.info("searchEmployer method started..!");

		String employerName = null;
		String contactName = null;
		String contactNo = null;
		String email = null;
		String sfdcId = null;
		String status = null;
		if (employerRequest.getEmployerName() != null && !employerRequest.getEmployerName().equals("")) {
			employerName = "%" + employerRequest.getEmployerName() + "%";
		} else {
			employerName = employerRequest.getEmployerName();
		}

		if (employerRequest.getContactNumber() != null && !employerRequest.getContactNumber().equals("")) {
			contactNo = "%" + employerRequest.getContactNumber() + "%";
		} else {
			contactNo = employerRequest.getContactNumber();
		}

		if (employerRequest.getContactName() != null && !employerRequest.getContactName().equals("")) {
			contactName = "%" + employerRequest.getContactName() + "%";
		} else {
			contactName = employerRequest.getContactName();
		}

		if (employerRequest.getEmailId() != null && !employerRequest.getEmailId().equals("")) {
			email = "%" + employerRequest.getEmailId() + "%";
		} else {
			email = employerRequest.getEmailId();
		}

		if (employerRequest.getSfdcId() != null && !employerRequest.getSfdcId().equals("")) {
			sfdcId = "%" + employerRequest.getSfdcId() + "%";
		} else {
			sfdcId = employerRequest.getSfdcId();
		}

		status = employerRequest.getStatus();

		Integer pageNumber = employerRequest.getPageNumber() > 0 ? employerRequest.getPageNumber() : 0;
		Integer pageLimit = employerRequest.getPageLimit() > 0 ? employerRequest.getPageLimit() : 20;
		// native query for searching employer and assigning parameters
		// respectively
		Page<Object[][]> employerList = employerRepository.getEmployer(employerName, employerName, contactName,
				contactName, contactNo, contactNo, email, email, sfdcId, sfdcId, status, status, orgId,
				getPageRequest(pageNumber, pageLimit));

		List<ViewEmployer> viewEmployerList = getEmployerList(employerList);
		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.EMPLOYER_LIST_FETCHED);
		if (viewEmployerList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewEmployerList);
		response.setTotal(employerList.getTotalElements());

		LOGGER.info("searchEmployer method end..!");
		return response;

	}

	private List<ViewEmployer> getEmployerList(Page<Object[][]> brokerCompany) {
		List<ViewEmployer> viewEmployerList = new ArrayList<>();
		for (Object[] objects : brokerCompany) {
			ViewEmployer viewEmployer = new ViewEmployer();
			viewEmployer.setEmployerName(((String) objects[0]));
			viewEmployer.setContactName(((String) objects[1]));
			viewEmployer.setContactNumber((String) objects[3]);
			viewEmployer.setEmailId((String) objects[2]);
			if ((String) objects[4] == null) {
				viewEmployer.setSfdcId("");
			} else {
				viewEmployer.setSfdcId((String) objects[4]);
			}
			viewEmployer.setStatus((String) objects[5]);
			if ((BigInteger) objects[6] != null) {
				viewEmployer.setCountryCodeId(((BigInteger) objects[6]).longValue());
			}
			viewEmployer.setEmployerId(((BigInteger) objects[7]).longValue());
			viewEmployer.setAddress((String) objects[8]);

			viewEmployerList.add(viewEmployer);
		}
		return viewEmployerList;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public ResponseEntity<ViewResponse> getAllEmployers(Long orgId) {

		LOGGER.info("getAllEmployers strated..");
		// creating array list for ViewEmployer
		List<ViewEmployerList> viewEmployerList = new ArrayList<>();
		Optional<Organization> organization = organizationRepository.findById(orgId);
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		// fetching all employers which are in active status
		List<Employer> employers = employerRepository.findByStatusAndOrganizationId(StatusConstants.ACTIVE,
				organization.get());

		LOGGER.debug("fetching list of employers which are in active status..");

		if (!employers.isEmpty()) {
			// looping through arrayList
			employers.stream().forEach(employer -> {
				ViewEmployerList viewEmployer = new ViewEmployerList();
				viewEmployer.setEmployerId(employer.getId());
				viewEmployer.setEmployerName(employer.getEmployerName());
				viewEmployerList.add(viewEmployer);
			});
		}
		// Giving successful response
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.EMPLOYER_LIST_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewEmployerList);
		LOGGER.info("getAllEmployers ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewResponse> getEmployersForSubOpportunity(Long orgId) {

		LOGGER.info("getAllEmployers strated..");
		// creating array list for ViewEmployer
		List<ViewEmployerList> viewEmployerList = new ArrayList<>();
		Optional<Organization> organization = organizationRepository.findById(orgId);
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		List<Long> employerIds = new ArrayList<>();
		employerIds = subOpportunityRepository.getEmployerIds(organization.get());
		if (employerIds.isEmpty()) {
			employerIds.add(0l);
		}
		// fetching all employers which are in active status
		LOGGER.debug("fetching list of employers which are in active status..");
		List<Employer> employers = employerRepository.findByStatusAndIdNotIn(StatusConstants.ACTIVE, employerIds);

		if (!employers.isEmpty()) {
			// looping through arrayList
			employers.stream().forEach(employer -> {
				ViewEmployerList viewEmployer = new ViewEmployerList();
				viewEmployer.setEmployerId(employer.getId());
				viewEmployer.setEmployerName(employer.getEmployerName());
				viewEmployerList.add(viewEmployer);
			});
		}
		// Giving successful response
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.EMPLOYER_LIST_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewEmployerList);
		LOGGER.info("getAllEmployers ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<GetEmployerInfo> getEmployerInfo(Long employerId) {
		Optional<Employer> employerOptional = employerRepository.findById(employerId);
		GetEmployerInfo employerInfo = new GetEmployerInfo();
		if (employerOptional.isPresent()) {
			employerInfo.setStatusText(Constants.SUCCESS);
			employerInfo.setEmployerName(employerOptional.get().getEmployerName());
			employerInfo.setEmployerId(employerId);
			Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository
					.findByEmployerId(employerOptional.get());
			if (subOpportunityOptional.isPresent() && subOpportunityOptional.get().getOpportunityId() != null) {
				employerInfo.setIndividualBrokerId(
						subOpportunityOptional.get().getOpportunityId().getIndividualBrokerId().getId());
				employerInfo.setIndividualBrokerName(subOpportunityOptional.get().getOpportunityId()
						.getIndividualBrokerId().getFirstName() + ' '
						+ subOpportunityOptional.get().getOpportunityId().getIndividualBrokerId().getLastName());
				employerInfo.setBrokerContactNumber(
						subOpportunityOptional.get().getOpportunityId().getIndividualBrokerId().getContactNumber());
			}
		} else {
			employerInfo.setStatusText(Constants.FAILED);
		}
		return ResponseEntity.status(HttpStatus.OK).body(employerInfo);
	}

	public ResponseEntity<ViewResponse> getEmployer(Long userId, String opportunityName) {

		if (opportunityName.equalsIgnoreCase("Block Opportunity")) {
			opportunityName = "Sub group opportunity";
		}
		Optional<OpportunitySubTypeMaster> opportunitySubTypeRepository = opportunitySubTypeMasterRepository
				.findByOpportunityChildName(opportunityName);
		if (!opportunitySubTypeRepository.isPresent()) {
			throw new RecordNotFoundException(Constants.OPPORTUNITY_NOT_FOUND);
		}
		List<GetEmployerInfo> getEmployerInfoList = new ArrayList<>();
		List<SubOpportunity> subOpportunities = subOpportunityRepository
				.findByOpportunitySubTypeMasterId(opportunitySubTypeRepository.get());
		subOpportunities.forEach(opportunities -> {
			GetEmployerInfo getEmployerInfo = new GetEmployerInfo();
			getEmployerInfo.setEmployerId(opportunities.getEmployerId().getId());
			getEmployerInfo.setEmployerName(opportunities.getEmployerId().getEmployerName());
			getEmployerInfoList.add(getEmployerInfo);
		});
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.EMPLOYER_LIST_FETCHED);
		viewResponse.setData(getEmployerInfoList);

		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewResponse> saveMemberCount(SaveMemberCountRequest saveMemberCountRequest) {

		Optional<Employer> employer = employerRepository.findById(saveMemberCountRequest.getEmployerId());
		if (!employer.isPresent()) {
			throw new RecordNotFoundException(Constants.EMPLOYER_NOT_FOUND);
		}
		Optional<SubOpportunity> subOpportunityOptional = subOpportunityRepository.findByEmployerId(employer.get());
		if (!subOpportunityOptional.isPresent()) {
			throw new RecordNotFoundException(Constants.EMPLOYER_NOT_FOUND);
		}
		subOpportunityOptional.get().setTotalActiveCount(saveMemberCountRequest.getTotalActiveCount());
		subOpportunityRepository.save(subOpportunityOptional.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.TOTAL_ACTIVE_COUNT);
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}
}
