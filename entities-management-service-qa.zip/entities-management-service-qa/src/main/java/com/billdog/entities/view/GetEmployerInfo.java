package com.billdog.entities.view;

public class GetEmployerInfo {
	private long employerId;
	private String employerName;
	private String statusText;
	private Long individualBrokerId;
	private String individualBrokerName;
	private String brokerContactNumber;

	public String getBrokerContactNumber() {
		return brokerContactNumber;
	}

	public void setBrokerContactNumber(String brokerContactNumber) {
		this.brokerContactNumber = brokerContactNumber;
	}

	public Long getIndividualBrokerId() {
		return individualBrokerId;
	}

	public void setIndividualBrokerId(Long individualBrokerId) {
		this.individualBrokerId = individualBrokerId;
	}

	public String getIndividualBrokerName() {
		return individualBrokerName;
	}

	public void setIndividualBrokerName(String individualBrokerName) {
		this.individualBrokerName = individualBrokerName;
	}

	public long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(long employerId) {
		this.employerId = employerId;
	}

	public String getEmployerName() {
		return employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

}
