package com.billdog.entities.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;

@Entity(name = "INSURANCE_COMPANY")
@Table(name = "insurance_company")
public class InsuranceCompany extends BaseEntity {

	@Audited
	@Column(name = "name")
	private String name;

	@Audited
	@Column(name = "email")
	private String email;

	@Audited
	@Column(name = "CONTACT_PERSON_NAME")
	private String contactPersonName;

	@Audited
	@Column(name = "contact_number")
	private String contactNumber;

	@Audited
	@Column(name = "status")
	private String status;

	@Audited
	@Column(name = "sfdc_id")
	private String sfdcId;

	@Column(name = "SFDC_UPDATED_TIME")
	private LocalDateTime sfdcUpdatedTime;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Column(name = "COUNTRY_CODE_ID")
	private Long countryCodeId;

	@Audited
	@Column(name = "address")
	private String address;

	@Audited
	@Column(name = "USER_ID")
	private Long userId;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(Long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getContactPersonName() {
		return contactPersonName;
	}

	public void setContactPersonName(String contactPersonName) {
		this.contactPersonName = contactPersonName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public LocalDateTime getSfdcUpdatedTime() {
		return sfdcUpdatedTime;
	}

	public void setSfdcUpdatedTime(LocalDateTime sfdcUpdatedTime) {
		this.sfdcUpdatedTime = sfdcUpdatedTime;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
