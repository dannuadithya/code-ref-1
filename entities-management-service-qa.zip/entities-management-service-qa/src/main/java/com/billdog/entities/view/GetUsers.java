package com.billdog.entities.view;

import java.util.List;

public class GetUsers {

	private String status;
	private String message;
	private List<ViewUserInfo> data;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<ViewUserInfo> getData() {
		return data;
	}

	public void setData(List<ViewUserInfo> data) {
		this.data = data;
	}


}
