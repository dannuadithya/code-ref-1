package com.billdog.entities.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UpdateBrokerCompanyRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter broker company name")
	@Size(min = 2, max = 30, message = "broker company name must be 2 to 30 characters")
	private String brokerCompanyName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Email(message = "Invalid email format")
	private String email;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcId;
	private long userId;
	private long countryCodeId;
	private long brokerCompanyId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String status;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getBrokerCompanyId() {
		return brokerCompanyId;
	}

	public void setBrokerCompanyId(long brokerCompanyId) {
		this.brokerCompanyId = brokerCompanyId;
	}

	public String getBrokerCompanyName() {
		return brokerCompanyName;
	}

	public void setBrokerCompanyName(String brokerCompanyName) {
		this.brokerCompanyName = brokerCompanyName;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

}
