package com.billdog.entities.view;

public class ViewIndividualBrokerInfo {

	private String individualBrokerName;
	private long individualBrokerId;

	public String getIndividualBrokerName() {
		return individualBrokerName;
	}

	public void setIndividualBrokerName(String individualBrokerName) {
		this.individualBrokerName = individualBrokerName;
	}

	public long getIndividualBrokerId() {
		return individualBrokerId;
	}

	public void setIndividualBrokerId(long individualBrokerId) {
		this.individualBrokerId = individualBrokerId;
	}

}
