package com.billdog.entities.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.history.RevisionRepository;

import com.billdog.entities.entity.InsuranceCompany;
import com.billdog.entities.entity.Organization;

public interface InsuranceCompanyRepository
		extends JpaRepository<InsuranceCompany, Long>, RevisionRepository<InsuranceCompany, Long, Integer> {

	Optional<InsuranceCompany> findByName(String insuranceCompanyName);

	List<InsuranceCompany> findByOrganizationIdAndStatus(Organization organization, String active);

	@Query(value = "SELECT ic.name,ic.CONTACT_PERSON_NAME,ic.contact_number,ic.email,ic.sfdc_id,ic.status,ic.id as insuranceId,ic.country_code_id,ic.address\n"
			+ "FROM insurance_company ic\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN ic.name ELSE '' END LIKE COALESCE(?2,'') And \n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN ic.CONTACT_PERSON_NAME ELSE '' END LIKE COALESCE(?4,'') AND \n"
			+ "CASE WHEN COALESCE(?5,'') <> '' THEN ic.contact_number ELSE '' END LIKE COALESCE(?6,'') AND \n"
			+ "CASE WHEN COALESCE(?7,'') <> '' THEN ic.email ELSE '' END LIKE COALESCE(?8,'') AND \n"
			+ "CASE WHEN COALESCE(?9,'') <> '' THEN ic.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND \n"
			+ "CASE WHEN COALESCE(?11,'') <> '' THEN ic.status ELSE '' END LIKE COALESCE(?12,'')\n"
			+ "order by ic.created_at desc\n"
			+ "", countQuery = "SELECT ic.name,ic.CONTACT_PERSON_NAME,ic.contact_number,ic.email,ic.sfdc_id,ic.status,ic.id as insuranceId,ic.address\n"
					+ "FROM insurance_company ic\n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN ic.name ELSE '' END LIKE COALESCE(?2,'') And \n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN ic.CONTACT_PERSON_NAME ELSE '' END LIKE COALESCE(?4,'') AND \n"
					+ "CASE WHEN COALESCE(?5,'') <> '' THEN ic.contact_number ELSE '' END LIKE COALESCE(?6,'') AND \n"
					+ "CASE WHEN COALESCE(?7,'') <> '' THEN ic.email ELSE '' END LIKE COALESCE(?8,'') AND \n"
					+ "CASE WHEN COALESCE(?9,'') <> '' THEN ic.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND \n"
					+ "CASE WHEN COALESCE(?11,'') <> '' THEN ic.status ELSE '' END LIKE COALESCE(?12,'')\n"
					+ "order by ic.created_at desc\n" + "", nativeQuery = true)

	Page<Object[][]> getInsuranceDetails(String insuranceCompanyName, String insuranceCompanyName2,
			String contactPerson, String contactPerson2, String contactNo, String contactNo2, String email,
			String email2, String sfdcId, String sfdcId2, String status, String status2, PageRequest pageRequest);

	Optional<InsuranceCompany> findByIdAndOrganizationIdAndStatus(Long carrierId, Organization organization,
			String active);

	@Query(value = "select count(*) as member_count from billdog_user.member", nativeQuery = true)
	Long getSumOfMember();

	@Query(value = "select count(*) as member_count from billdog_user.member_family", nativeQuery = true)
	Long getSumOfMemberFamily();

	@Query(value = "SELECT count(*) FROM insurance_company\n" + 
			"where date(created_at) between ?1 and ?2", nativeQuery = true)
	Long getSumOfInsuranceCompany(String string, String string2);
	
	@Query(value = "SELECT count(*) FROM billdog_user.member\n" + 
			"where date(created_at) between ?1 and ?2", nativeQuery = true)
	Long getSumOfMembers(String string, String string2);
	
	@Query(value = "SELECT count(*) FROM billdog_user.member_family\n" + 
			"where date(created_at) between ?1 and ?2", nativeQuery = true)
	Long getSumOfFamilyMembers(String string, String string2);

	@Query(value = "select ica.id, ica.revType,ica.updated_at, ica.address, ica.name,  ica.contact_number, ica.contact_person_name,\n"
			+ "       ica.email,ica.sfdc_id, ica.status,ica.user_id, ica.rev   from insurance_company_aud ica\n"
			+ "join insurance_company ic on ic.id= ica.id\n"
			+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN ica.name ELSE '' END LIKE COALESCE(?2,'')\n"
			+ "and date(ica.updated_at) BETWEEN ?3 AND ?4 and ica.revType in ?5 and ic.organization_id=?6\n"
			+ "order by ica.updated_at desc,ica.rev desc", countQuery = "select ica.id, ica.revType,ica.updated_at, ica.address, ica.name,  ica.contact_number, ica.contact_person_name,\n"
					+ "       ica.email,ica.sfdc_id, ica.status,ica.user_id, ica.rev   from insurance_company_aud ica\n"
					+ "join insurance_company ic on ic.id= ica.id\n"
					+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN ica.name ELSE '' END LIKE COALESCE(?2,'')\n"
					+ "and date(ica.updated_at) BETWEEN ?3 AND ?4 and ica.revType in ?5 and ic.organization_id=?6\n"
					+ "order by ica.updated_at desc,ica.rev desc", nativeQuery = true)
	Page<Object[]> getInsuranceCompanyAuditInfo(String name, String name2, String string, String endDate,
			List<Long> revtypes, long orgId, PageRequest pageRequest);

	@Query(value = "select id, revType,updated_at, address, name,  contact_number, contact_person_name,\n"
			+ "       email,sfdc_id, status,user_id, rev   from insurance_company_aud\n"
			+ "where  id=?1 order by rev desc", countQuery = "select id, revType,updated_at, address, name,  contact_number, contact_person_name,\n"
					+ "       email,sfdc_id, status,user_id, rev   from insurance_company_aud\n"
					+ "where id=?1 order by rev desc", nativeQuery = true)
	Page<Object[]> getInsuranceCompanyAuditInfoById(Long id, PageRequest pageRequest);
	
	
	@Query(value = "select id, revType,updated_at, address, name,  contact_number, contact_person_name,\n"
			+ "       email,sfdc_id, status,user_id, rev   from insurance_company_aud\n"
			+ "where  id=?1 and rev<?2 order by rev desc limit 1", countQuery = "select id, revType,updated_at, address, name,  contact_number, contact_person_name,\n"
					+ "       email,sfdc_id, status,user_id, rev   from insurance_company_aud\n"
					+ "where id=?1 and rev<?2 order by rev desc limit 1", nativeQuery = true)
	List<Object[]> getInsuranceCompanyAuditInfoByIdAndNav(Long id, Long rev);

}
