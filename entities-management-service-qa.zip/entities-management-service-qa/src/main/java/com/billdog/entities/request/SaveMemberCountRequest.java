package com.billdog.entities.request;

public class SaveMemberCountRequest {

	private Long employerId;
	private Long totalActiveCount;

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public Long getTotalActiveCount() {
		return totalActiveCount;
	}

	public void setTotalActiveCount(Long totalActiveCount) {
		this.totalActiveCount = totalActiveCount;
	}

}
