package com.billdog.entities.common;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

//TODO time zone correction to (UTC)
@Component
public class DateAndTimeUtil {

	private static final Logger logger = LoggerFactory.getLogger(DateAndTimeUtil.class);

	public static String TIMEZONE;

	@Value("${timezone}")
	public void setTimezone(String timezone) {
		TIMEZONE = timezone;
	}

	public static LocalDateTime now() {
		logger.info("Timezone from properties: " + DateAndTimeUtil.TIMEZONE);
		return LocalDateTime.now(ZoneId.of(DateAndTimeUtil.TIMEZONE));
	}

	// converts date yyyy-mm-dd to mm-dd-yyyy
	public static String convertLocalDateToString(LocalDate localDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
		return formatter.format(localDate);
	}

	public static String getTime(LocalTime time) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
		return formatter.format(time);
	}
}
