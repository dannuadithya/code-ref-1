package com.billdog.entities.view;

public class ViewIndividualBroker {

	private long individualBrokerId;
	private String firstName;
	private String lastName;
	private String emailId;
	private String contactNumber;
	private long countryCodeId;
	private long brokerCompanyId;
	private String sfdcId;
	private String status;
	private String brokerCompanyAffiliation;
	private String brokerName;
	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getIndividualBrokerId() {
		return individualBrokerId;
	}

	public void setIndividualBrokerId(long individualBrokerId) {
		this.individualBrokerId = individualBrokerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public long getBrokerCompanyId() {
		return brokerCompanyId;
	}

	public void setBrokerCompanyId(long brokerCompanyId) {
		this.brokerCompanyId = brokerCompanyId;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getBrokerCompanyAffiliation() {
		return brokerCompanyAffiliation;
	}

	public void setBrokerCompanyAffiliation(String brokerCompanyAffiliation) {
		this.brokerCompanyAffiliation = brokerCompanyAffiliation;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

}
