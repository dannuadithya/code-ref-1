package com.billdog.entities.request;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class SearchIndividualBrokerRequest {
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String brokerName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String status;
	private Long brokerCompanyId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactNo;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String emailId;
	private long userId;
	private int pageNumber;
	private int pageLimit;
	private boolean independent;
	public String getBrokerName() {
		return brokerName;
	}
	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

	public Long getBrokerCompanyId() {
		return brokerCompanyId;
	}

	public void setBrokerCompanyId(Long brokerCompanyId) {
		this.brokerCompanyId = brokerCompanyId;
	}
	public String getSfdcId() {
		return sfdcId;
	}
	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getUserId() {
		return userId;
	}
	public void setUserId(long userId) {
		this.userId = userId;
	}
	public int getPageNumber() {
		return pageNumber;
	}
	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}
	public int getPageLimit() {
		return pageLimit;
	}
	public void setPageLimit(int pageLimit) {
		this.pageLimit = pageLimit;
	}
	public boolean isIndependent() {
		return independent;
	}
	public void setIndependent(boolean independent) {
		this.independent = independent;
	}


}
