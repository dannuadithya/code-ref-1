package com.billdog.entities.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.InternalServerException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.exception.ServiceUnavailableException;
import com.billdog.entities.repository.UserRepository;
import com.billdog.entities.request.ExternalUserUpdateRequest;
import com.billdog.entities.request.GetUsersRequest;
import com.billdog.entities.request.MemberCountRequest;
import com.billdog.entities.view.GetCountryCodeInfo;
import com.billdog.entities.view.GetMemberCountByEmployer;
import com.billdog.entities.view.GetRoleList;
import com.billdog.entities.view.GetUsers;
import com.billdog.entities.view.MemberInfoResponse;
import com.billdog.entities.view.UpdateExternalUserView;
import com.billdog.entities.view.ViewResponse;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Component
public class UserService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(UserService.class);

	@Value("${userservice.baseurl}")
	private String userBaseUrl;

	private UserRepository getUserRepository(String token) {
		OkHttpClient.Builder userHttpClient;
		if (StringUtils.isNotBlank(token)) {
			userHttpClient = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
				@Override
				public Response intercept(Chain chain) throws IOException {
					Request request = chain.request().newBuilder().addHeader("authorization", token).build();
					return chain.proceed(request);
				}
			});
		} else {
			userHttpClient = new OkHttpClient.Builder();
		}
		Retrofit retrofit = new Retrofit.Builder().baseUrl(userBaseUrl)
				.addConverterFactory(GsonConverterFactory.create())
				.client(userHttpClient.connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build())
				.build();
		return retrofit.create(UserRepository.class);
	}

	public MemberInfoResponse verifyUserToken(String token, Long userId) {
		LOGGER.info("verifyUserToken method started..!");
		UserRepository userRepository = getUserRepository(token);
		Call<MemberInfoResponse> callSync = userRepository.verifyUserToken(userId);

		try {
			retrofit2.Response<MemberInfoResponse> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new RecordNotFoundException(ExceptionalMessages.VERIFY_USER_TOKEN);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.VERIFY_USER_TOKEN_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.VERIFY_TOKEN_ISSUE);
				}

			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public MemberInfoResponse verifyMemberToken(String token, Long memberId) {
		LOGGER.info("verifyMemberToken method started..!");
		UserRepository userRepository = getUserRepository(token);
		Call<MemberInfoResponse> callSync = userRepository.verifyMemberToken(memberId);

		try {
			retrofit2.Response<MemberInfoResponse> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				}
				throw new BadRequestException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public MemberInfoResponse getMemberInfo(Long userId, Long memberId) {
		LOGGER.info("getMemberInfo method started..!");
		UserRepository userRepository = getUserRepository(null);
		Call<MemberInfoResponse> callSync = userRepository.getMemberDetials(userId, memberId);

		try {
			retrofit2.Response<MemberInfoResponse> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				}
				throw new BadRequestException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public GetCountryCodeInfo getCountryCode(long countryCodeId, long organizationId) {
		LOGGER.info("country code method started..!");
		UserRepository userRepository = getUserRepository(null);
		Call<GetCountryCodeInfo> callSync = userRepository.getCountryCode(countryCodeId, organizationId);

		try {
			retrofit2.Response<GetCountryCodeInfo> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				}
				throw new BadRequestException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public GetRoleList getRole(long userId, String authorization) {
		LOGGER.info("getRole method started..!");
		UserRepository userRepository = getUserRepository(authorization);
		Call<GetRoleList> callSync = userRepository.getRole(userId);

		try {
			retrofit2.Response<GetRoleList> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				}
				throw new BadRequestException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse updateEmployer(Long userId, Long newEmployerId, Long oldEmployerId) {
		LOGGER.info("getRole method started..!");
		UserRepository userRepository = getUserRepository(null);
		Call<ViewResponse> callSync = userRepository.updateEmployer(userId, newEmployerId, oldEmployerId);

		try {
			retrofit2.Response<ViewResponse> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				}
				throw new BadRequestException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public GetMemberCountByEmployer getMemberCountByEmployerId(MemberCountRequest memberCountRequest) {
		LOGGER.info("getMemberCountByEmployerId method started..!");
		UserRepository userRepository = getUserRepository(null);
		Call<GetMemberCountByEmployer> callSync = userRepository.getMemberCountByEmployerId(memberCountRequest);

		try {
			retrofit2.Response<GetMemberCountByEmployer> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				}
				throw new BadRequestException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public GetUsers getUsersInfo(GetUsersRequest request) {
		LOGGER.info("getUsersInfo method started..!");
		UserRepository userRepository = getUserRepository(null);
		Call<GetUsers> callSync = userRepository.getUsersInfo(request);

		try {
			retrofit2.Response<GetUsers> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				}
				throw new BadRequestException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public UpdateExternalUserView updateExternalUserEmail(ExternalUserUpdateRequest externalUserUpdateRequest) {
		LOGGER.info("updateExternalUserEmail method started..!");
		UserRepository userRepository = getUserRepository(null);
		Call<UpdateExternalUserView> callSync = userRepository.updateExternalUserEmail(externalUserUpdateRequest);

		try {
			retrofit2.Response<UpdateExternalUserView> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");
				return response.body();
			} else {
				if (response.code() == 404) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					LOGGER.info(ExceptionalMessages.USER_SERVICE_UNAVAILABLE);
				}
				throw new BadRequestException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling user service, Cause:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}
}
