package com.billdog.entities.view;

public class IndividualProviderInfo {

	private String firstName;
	private String lastName;
	private String status;
	private String emailId;
	private String sfdcId;
	private String contactNo;
	private String companyProviderName;
	private long companyProviderId;
	private long individualProviderId;
	private long countryCodeId;
	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getCompanyProviderName() {
		return companyProviderName;
	}

	public void setCompanyProviderName(String companyProviderName) {
		this.companyProviderName = companyProviderName;
	}

	public long getCompanyProviderId() {
		return companyProviderId;
	}

	public void setCompanyProviderId(long companyProviderId) {
		this.companyProviderId = companyProviderId;
	}

	public long getIndividualProviderId() {
		return individualProviderId;
	}

	public void setIndividualProviderId(long individualProviderId) {
		this.individualProviderId = individualProviderId;
	}

}
