package com.billdog.entities.request;

import java.util.List;

public class GetUsersRequest {

	private List<Long> userIds;

	public List<Long> getUserIds() {
		return userIds;
	}

	public void setUserIds(List<Long> userIds) {
		this.userIds = userIds;
	}

}
