package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.request.AddIndividualBrokerRequest;
import com.billdog.entities.request.SearchIndividualBrokerRequest;
import com.billdog.entities.request.UpdateIndividualBrokerRequest;
import com.billdog.entities.service.IndividualBrokerService;
import com.billdog.entities.view.MemberInfoResponse;
import com.billdog.entities.view.UpdateIndividualBrokerResponse;
import com.billdog.entities.view.ViewIndividualBroker;
import com.billdog.entities.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class IndividualBrokerController {

	@Autowired
	IndividualBrokerService individualBrokerService;

	@Autowired
	EmployerController employerController;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(IndividualBrokerController.class);


	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/add-individual-broker", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addIndividualBroker(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody AddIndividualBrokerRequest addIndividualBrokerRequest) {
		employerController.isTokenValid(httpRequest, addIndividualBrokerRequest.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK)
				.body(individualBrokerService.addIndividualBroker(addIndividualBrokerRequest, authorization));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual broker search results fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/individual-broker", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchIndividualBrokers(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody SearchIndividualBrokerRequest individualBrokerRequest) {
		employerController.isTokenValid(httpRequest, individualBrokerRequest.getUserId(), null);
		MemberInfoResponse infoResponse = getMemberInfo(httpRequest);
		return ResponseEntity.status(HttpStatus.OK).body(individualBrokerService
				.searchIndividualBroker(individualBrokerRequest, infoResponse.getOrganizationId()));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual broker details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/individual-broker", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewIndividualBroker> getIndividualBrokerInfo(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long individualBrokerId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return ResponseEntity.status(HttpStatus.OK)
				.body(individualBrokerService.getIndividualBroker(individualBrokerId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual broker search results fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/individual-broker", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<UpdateIndividualBrokerResponse> updateIndividualBroker(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody UpdateIndividualBrokerRequest request) {
		employerController.isTokenValid(httpRequest, request.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK).body(individualBrokerService.updateIndividualBroker(request));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual broker details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/individual-broker-list", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getIndividualBrokers(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId,
			@RequestParam(required = false) Long brokerCompanyId, @RequestParam(required = false) Boolean independent) {
		employerController.isTokenValid(httpRequest, userId, null);
		MemberInfoResponse infoResponse = getMemberInfo(httpRequest);
		return ResponseEntity.status(HttpStatus.OK).body(individualBrokerService
				.getIndividualBrokersByBrokerCompany(brokerCompanyId, infoResponse.getOrganizationId(), independent,
						false));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual broker details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/opportunity-individual-broker", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getIndividualBrokersForOpportunity(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam(required = false) Long brokerCompanyId,
			@RequestParam(required = false) Boolean independent) {
		employerController.isTokenValid(httpRequest, userId, null);
		MemberInfoResponse infoResponse = getMemberInfo(httpRequest);
		return ResponseEntity.status(HttpStatus.OK).body(individualBrokerService.getIndividualBrokersByBrokerCompany(
				brokerCompanyId, infoResponse.getOrganizationId(), independent, true));
	}

	public MemberInfoResponse getMemberInfo(HttpServletRequest httpRequest) {
		MemberInfoResponse memberInfoResponse = new MemberInfoResponse();
		if (httpRequest.getAttribute("organizationId") != null) {
			memberInfoResponse.setOrganizationId(Long.parseLong(httpRequest.getAttribute("organizationId").toString()));
		}
		return memberInfoResponse;
	}
}
