package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.request.CompanyProviderRequest;
import com.billdog.entities.request.GetSubCaseInfoRequest;
import com.billdog.entities.request.SearchCompanyProviderRequest;
import com.billdog.entities.request.UpdateCompanyProvider;
import com.billdog.entities.service.CompanyProviderService;
import com.billdog.entities.view.GetSubCaseInfo;
import com.billdog.entities.view.ViewCompanyProvider;
import com.billdog.entities.view.ViewMemberResponse;
import com.billdog.entities.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class CompanyProviderController {

	@Autowired
	CompanyProviderService companyProviderService;

	@Autowired
	EmployerController employerController;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CompanyProviderController.class);


	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "company provider saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/addCompanyProvider", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addCompanyProviderDetails(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody CompanyProviderRequest companyProviderRequest) {
		employerController.isTokenValid(httpRequest, companyProviderRequest.getUserId(), null);
		return companyProviderService.addCompanyProvider(companyProviderRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "company provider fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchCompanyProvider", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchCompanyProvider(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest,
			@Valid @RequestBody SearchCompanyProviderRequest searchCompanyProviderRequest) {
		employerController.isTokenValid(httpRequest, searchCompanyProviderRequest.getUserId(), null);
		return companyProviderService.searchCompanyProvider(searchCompanyProviderRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "company provider updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/editCompanyProvider", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> editCompanyProvider(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody UpdateCompanyProvider updateCompanyProvider) {
		employerController.isTokenValid(httpRequest, updateCompanyProvider.getUserId(), null);
		return companyProviderService.editCompanyProvider(updateCompanyProvider);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "company provider details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "company provider not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getCompanyProvider", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewCompanyProvider> getCompanyProviderDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long companyProviderId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return companyProviderService.getCompanyProvider(companyProviderId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "company provider details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "company provider not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/company-providers", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> getCompanyProviderList(@RequestParam Long organizationId) {
		return companyProviderService.getCompanyProviderList(organizationId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "company providers list fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "company provider not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/company-provider-list", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getCompanyProvidersList(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam Long organizationId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return companyProviderService.getCompanyProvidersList(organizationId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "company providers list fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "company provider not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/sub-case-info", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<GetSubCaseInfo> getSubCaseRelatedList(@RequestBody GetSubCaseInfoRequest request) {
		return companyProviderService.getSubCaseRelatedList(request);
	}

}
