package com.billdog.entities.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.entities.authorization.EnableTokenAuthorisation;
import com.billdog.entities.exception.ErrorResponse;
import com.billdog.entities.request.AddBrokerSponsoredRequest;
import com.billdog.entities.request.AddEmployerDirectRequest;
import com.billdog.entities.request.BrokerSponsoredRequest;
import com.billdog.entities.request.EmployerDirectRequest;
import com.billdog.entities.request.ExternalUserBrokerSponsoredRequest;
import com.billdog.entities.request.UpdateBrokerSponsoredRequest;
import com.billdog.entities.request.UpdateEmployerDirectRequest;
import com.billdog.entities.service.GroupOpportunityService;
import com.billdog.entities.view.ViewBrokerSponsored;
import com.billdog.entities.view.ViewEmployerDirect;
import com.billdog.entities.view.ViewMemberResponse;
import com.billdog.entities.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class GroupOpportunityController {

	@Autowired
	GroupOpportunityService groupOpportunityService;

	@Autowired
	BlockOpportunityController blockOpportunityController;

	@Autowired
	EmployerController employerController;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GroupOpportunityController.class);


	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Broker sponsored fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchBrokerSponsored", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchBrokerSponsored(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody BrokerSponsoredRequest brokerSponsoredRequest) {
		employerController.isTokenValid(httpRequest, brokerSponsoredRequest.getUserId(), null);
		return groupOpportunityService.searchBrokerSponsored(brokerSponsoredRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Broker sponsored fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchExBrokerSponsored", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchExternalUserBrokerSponsored(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody ExternalUserBrokerSponsoredRequest brokerSponsoredRequest) {
		employerController.isTokenValid(httpRequest, brokerSponsoredRequest.getUserId(), null);
		return groupOpportunityService.searchExternalBrokerSponsored(brokerSponsoredRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Broker sponsored opportunity details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Broker sponsored opportunity not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getBrokerSponsored", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewBrokerSponsored> getBrokerSponsoredDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long brokerSponsoredId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return groupOpportunityService.getBrokerSponsoredDetails(brokerSponsoredId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Broker sponsored fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/broker-sponsored", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addBrokerSponsored(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody AddBrokerSponsoredRequest request) {
		employerController.isTokenValid(httpRequest, request.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK).body(groupOpportunityService.createBrokerSponsored(request,
				blockOpportunityController.getMemberInfo(httpRequest).getOrganizationId()));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Broker sponsored fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/broker-sponsored", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateBrokerSponsored(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody UpdateBrokerSponsoredRequest request) {
		employerController.isTokenValid(httpRequest, request.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK).body(groupOpportunityService.updateBrokerSponsored(request,
				blockOpportunityController.getMemberInfo(httpRequest).getOrganizationId()));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Employer direct fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchEmployerDirect", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchEmployerDirect(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody EmployerDirectRequest employerDirectRequest) {
		employerController.isTokenValid(httpRequest, employerDirectRequest.getUserId(), null);
		return groupOpportunityService.searchEmployerDirect(employerDirectRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Employer direct details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Employer direct not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getEmployerDirect", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewEmployerDirect> getEmployerDirectDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long employerDirectId) {
		employerController.isTokenValid(httpRequest, userId, null);
		return groupOpportunityService.getEmployerDirectDetails(employerDirectId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Employer direct fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/employer-direct", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addEmployerDirect(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody AddEmployerDirectRequest addEmployerDirectRequest) {
		employerController.isTokenValid(httpRequest, addEmployerDirectRequest.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK).body(groupOpportunityService.addEmployerDirect(
				addEmployerDirectRequest, blockOpportunityController.getMemberInfo(httpRequest).getOrganizationId()));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Employer direct fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/employer-direct", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateEmployerDirect(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest,
			@Valid @RequestBody UpdateEmployerDirectRequest updateEmployerDirectRequest) {
		employerController.isTokenValid(httpRequest, updateEmployerDirectRequest.getUserId(), null);
		return ResponseEntity.status(HttpStatus.OK)
				.body(groupOpportunityService.updateEmployerDirect(updateEmployerDirectRequest,
						blockOpportunityController.getMemberInfo(httpRequest).getOrganizationId()));
	}
}