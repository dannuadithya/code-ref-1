package com.billdog.entities.exception;

public class EmailLimitExceededException extends BadRequestException {


	private static final long serialVersionUID = 1L;

	public EmailLimitExceededException(String message) {
		super(message);
	}

}