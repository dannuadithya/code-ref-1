package com.billdog.entities.view;

public class ViewIndividualProviderInfo {
	private long individualProviderId;
	private String individualProviderName;

	public long getIndividualProviderId() {
		return individualProviderId;
	}

	public void setIndividualProviderId(long individualProviderId) {
		this.individualProviderId = individualProviderId;
	}

	public String getIndividualProviderName() {
		return individualProviderName;
	}

	public void setIndividualProviderName(String individualProviderName) {
		this.individualProviderName = individualProviderName;
	}

}
