package com.billdog.entities.view;

import java.math.BigInteger;

public class ViewInsuranceCompany {

	private String insuranceCompanyName;
	private String contactPerson;
	private String contactNo;
	private String emailId;
	private String sfdcId;
	private String status;
	private BigInteger insuranceId;
	private BigInteger countryCodeId;
	private String address;

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public BigInteger getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(BigInteger countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

	public BigInteger getInsuranceId() {
		return insuranceId;
	}

	public void setInsuranceId(BigInteger insuranceId) {
		this.insuranceId = insuranceId;
	}

	public String getInsuranceCompanyName() {
		return insuranceCompanyName;
	}

	public void setInsuranceCompanyName(String insuranceCompanyName) {
		this.insuranceCompanyName = insuranceCompanyName;
	}

	public String getContactPerson() {
		return contactPerson;
	}

	public void setContactPerson(String contactPerson) {
		this.contactPerson = contactPerson;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
