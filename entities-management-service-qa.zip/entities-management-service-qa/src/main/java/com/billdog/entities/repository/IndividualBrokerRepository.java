package com.billdog.entities.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.billdog.entities.entity.BrokerCompany;
import com.billdog.entities.entity.IndividualBroker;
import com.billdog.entities.entity.Organization;

@Repository
public interface IndividualBrokerRepository extends JpaRepository<IndividualBroker, Long> {

	Optional<IndividualBroker> findBySfdcId(String sfdcId);

	@Query(value = "SELECT ib.first_name, ib.last_name,bc.broker_company_name, ib.email,ib.contact_number,ib.sfdc_id,ib.status,bc.id as broker_company_id, ib.id individual_broker_id,ib.country_code_Id,ib.address \n"
			+ "FROM individual_broker ib left join broker_company bc on bc.id= ib.broker_company_id \n"
			+ "where  ((CASE WHEN COALESCE(?1,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?2,'') or CASE WHEN COALESCE(?3,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?4,'')) and \n"
			+ " CASE WHEN COALESCE(?5,'') <> '' THEN ib.email ELSE '' END LIKE COALESCE(?6,'') AND\n"
			+ " CASE WHEN COALESCE(?7,'') <> '' THEN ib.contact_number ELSE '' END LIKE COALESCE(?8,'')  AND  CASE WHEN COALESCE(?9,'') <> '' THEN ib.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND \n"
			+ "CASE WHEN COALESCE(?11,'') <> '' THEN ib.status ELSE '' END LIKE COALESCE(?12,'')) and ib.organization_id =?13 and ib.independent=?14 order by ib.created_at desc", countQuery = "SELECT ib.first_name, ib.last_name,bc.broker_company_name, ib.email,ib.contact_number,ib.sfdc_id,ib.status,bc.id as broker_company_id, ib.id individual_broker_id,ib.country_code_Id,ib.address \n"
					+ "FROM individual_broker ib left join  broker_company bc on bc.id= ib.broker_company_id \n"
					+ "where  ((CASE WHEN COALESCE(?1,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?2,'') or CASE WHEN COALESCE(?3,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?4,'')) and \n"
					+ " CASE WHEN COALESCE(?5,'') <> '' THEN ib.email ELSE '' END LIKE COALESCE(?6,'') AND\n"
					+ " CASE WHEN COALESCE(?7,'') <> '' THEN ib.contact_number ELSE '' END LIKE COALESCE(?8,'')  AND  CASE WHEN COALESCE(?9,'') <> '' THEN ib.sfdc_id ELSE '' END LIKE COALESCE(?10,'') AND \n"
					+ "CASE WHEN COALESCE(?11,'') <> '' THEN ib.status ELSE '' END LIKE COALESCE(?12,''))  and ib.organization_id =?13 and ib.independent=?14 order by ib.created_at desc", nativeQuery = true)
	Page<Object[][]> getIndividualBrokers(String name, String name2, String name3, String name4, String email,
			String email2, String contactNo, String contactNo2, String sfdcId, String sfdcId2, String status,
			String status2, long orgId, boolean independent, PageRequest pageRequest);

	@Query(value = "SELECT ib.first_name, ib.last_name,bc.broker_company_name, ib.email,ib.contact_number,ib.sfdc_id,ib.status,bc.id as broker_company_id, ib.id individual_broker_id,ib.country_code_Id,ib.address \n"
			+ "FROM individual_broker ib left join broker_company bc on bc.id= ib.broker_company_id \n"
			+ "where  ((CASE WHEN COALESCE(?1,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?2,'') or CASE WHEN COALESCE(?3,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?4,'')) and \n"
			+ " CASE WHEN COALESCE(?5,-999) <> -999 THEN ib.broker_company_id ELSE -999 END = COALESCE(?6,-999)  AND CASE WHEN COALESCE(?7,'') <> '' THEN ib.email ELSE '' END LIKE COALESCE(?8,'') AND\n"
			+ " CASE WHEN COALESCE(?9,'') <> '' THEN ib.contact_number ELSE '' END LIKE COALESCE(?10,'')  AND  CASE WHEN COALESCE(?11,'') <> '' THEN ib.sfdc_id ELSE '' END LIKE COALESCE(?12,'') AND \n"
			+ "CASE WHEN COALESCE(?13,'') <> '' THEN ib.status ELSE '' END LIKE COALESCE(?14,'')) and ib.organization_id =?15 order by ib.created_at desc", countQuery = "SELECT ib.first_name, ib.last_name,bc.broker_company_name, ib.email,ib.contact_number,ib.sfdc_id,ib.status,bc.id as broker_company_id, ib.id individual_broker_id,ib.country_code_Id,ib.address \n"
					+ "FROM individual_broker ib left join  broker_company bc on bc.id= ib.broker_company_id \n"
					+ "where  ((CASE WHEN COALESCE(?1,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?2,'') or CASE WHEN COALESCE(?3,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?4,'')) and \n"
					+ " CASE WHEN COALESCE(?5,-999) <> -999 THEN ib.broker_company_id ELSE -999 END = COALESCE(?6,-999)  AND CASE WHEN COALESCE(?7,'') <> '' THEN ib.email ELSE '' END LIKE COALESCE(?8,'') AND\n"
					+ " CASE WHEN COALESCE(?9,'') <> '' THEN ib.contact_number ELSE '' END LIKE COALESCE(?10,'')  AND  CASE WHEN COALESCE(?11,'') <> '' THEN ib.sfdc_id ELSE '' END LIKE COALESCE(?12,'') AND \n"
					+ "CASE WHEN COALESCE(?13,'') <> '' THEN ib.status ELSE '' END LIKE COALESCE(?14,''))  and ib.organization_id =?15 order by ib.created_at desc", nativeQuery = true)
	Page<Object[][]> getAllIndividualBrokers(String name, String name2, String name3, String name4,
			BrokerCompany brokerCompany, BrokerCompany brokerCompany2, String email, String email2, String contactNo,
			String contactNo2, String sfdcId, String sfdcId2, String status, String status2, long orgId,
			PageRequest pageRequest);

	Optional<IndividualBroker> findByEmail(String email);

	List<IndividualBroker> findByBrokerCompanyAndOrganizationId(BrokerCompany brokerCompany, Organization organization);

	List<IndividualBroker> findByOrganizationIdAndIndependent(Organization organization, boolean b);

	List<IndividualBroker> findByOrganizationIdAndIndependentAndIdNotIn(Organization organization, boolean b,
			List<Long> individualBrokerIds);

	List<IndividualBroker> findByBrokerCompanyAndOrganizationIdAndIdNotIn(BrokerCompany brokerCompany,
			Organization organizationId, List<Long> individualBrokerIds);

	@Query(value = "select ib.id, ib.revType, ib.updated_at, ib.address, ib.first_name, ib.last_name,\n"
			+ "       ib.contact_number, ib.email, ib.sfdc_id, ib.independent, ib.broker_company_id, ib.status, ib.user_id, bc.broker_company_name, rev from individual_broker_aud ib\n"
			+ "left join individual_broker ind on ind.id=ib.id left join broker_company bc on bc.id=ib.broker_company_id\n"
			+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?2,'') or CASE\n"
			+ "WHEN COALESCE(?3,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?4,'') and date(ib.updated_at) BETWEEN ?5\n"
			+ "AND ?6 and ib.revType in ?7 and ind.organization_id=?8 order by ib.updated_at desc,ib.rev desc", countQuery = "select ib.id, ib.revType, ib.updated_at, ib.address, ib.first_name, ib.last_name,\n"
					+ "       ib.contact_number, ib.email, ib.sfdc_id, ib.independent, ib.broker_company_id, ib.status, ib.user_id, bc.broker_company_name, rev from individual_broker_aud ib\n"
					+ "left join individual_broker ind on ind.id=ib.id left join broker_company bc on bc.id=ib.broker_company_id\n"
					+ "where  CASE WHEN COALESCE(?1,'') <> '' THEN ib.first_name ELSE '' END LIKE COALESCE(?2,'') or CASE\n"
					+ "WHEN COALESCE(?3,'') <> '' THEN ib.last_name ELSE '' END LIKE COALESCE(?4,'') and date(ib.updated_at) BETWEEN ?5\n"
					+ "AND ?6 and ib.revType in ?7 and ind.organization_id=?8 order by ib.updated_at desc, ib.rev desc", nativeQuery = true)
	Page<Object[]> getIndividualBrokerAuditInfo(String name, String name2, String name3, String name4,
			String fromDate, String toDate, List<Long> revtypes, long orgId, PageRequest pageRequest);

	@Query(value = "select ib.id, ib.revType, ib.updated_at, ib.address, ib.first_name, ib.last_name,\n"
			+ "       ib.contact_number, ib.email, ib.sfdc_id, ib.independent, ib.broker_company_id, ib.status, ib.user_id, bc.broker_company_name from individual_broker_aud ib\n"
			+ "left join broker_company bc on bc.id=ib.broker_company_id\n"
			+ "where  ib.id=?1 and rev<?2 order by ib.rev desc limit 1", countQuery = "select ib.id, ib.revType, ib.updated_at, ib.address, ib.first_name, ib.last_name,\n"
					+ "       ib.contact_number, ib.email, ib.sfdc_id, ib.independent, ib.broker_company_id, ib.status, ib.user_id, bc.broker_company_name from individual_broker_aud ib\n"
					+ "left join broker_company bc on bc.id=ib.broker_company_id\n"
					+ "where  ib.id=?1 and rev<?2 order by ib.rev desc limit 1", nativeQuery = true)
	List<Object[]> getindividualBrokerAuditInfoByIdAndRev(long longValue, long rev);

	@Query(value = "select ib.id, ib.revType, ib.updated_at, ib.address, ib.first_name, ib.last_name,\n"
			+ "       ib.contact_number, ib.email, ib.sfdc_id, ib.independent, ib.broker_company_id, ib.status, ib.user_id, bc.broker_company_name, rev from individual_broker_aud ib\n"
			+ "left join broker_company bc on bc.id=ib.broker_company_id\n"
			+ "where ib.id=?1 order by ib.rev desc", countQuery = "select ib.id, ib.revType, ib.updated_at, ib.address, ib.first_name, ib.last_name,\n"
					+ "       ib.contact_number, ib.email, ib.sfdc_id, ib.independent, ib.broker_company_id, ib.status, ib.user_id, bc.broker_company_name, rev from individual_broker_aud ib\n"
					+ "left join broker_company bc on bc.id=ib.broker_company_id\n"
					+ "where ib.id=?1 order by ib.rev desc", nativeQuery = true)
	Page<Object[]> getIndividualBrokerAuditInfoById(Long recordId, PageRequest pageRequest);

}
