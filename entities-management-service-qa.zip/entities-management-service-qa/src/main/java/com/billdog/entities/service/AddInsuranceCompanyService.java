package com.billdog.entities.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.CompanyProvider;
import com.billdog.entities.entity.IndividualProvider;
import com.billdog.entities.entity.InsuranceCompany;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.CompanyProviderRepository;
import com.billdog.entities.repository.IndividualProviderRepository;
import com.billdog.entities.repository.InsuranceCompanyRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.request.EditInsuranceCompanyRequest;
import com.billdog.entities.request.InsuranceCompanyRequest;
import com.billdog.entities.request.InsuranceCompanySearchRequest;
import com.billdog.entities.request.VerifySubCaseRequest;
import com.billdog.entities.view.GetCarrierInfo;
import com.billdog.entities.view.GetCountryCodeInfo;
import com.billdog.entities.view.ViewCarrierDetails;
import com.billdog.entities.view.ViewInsuranceCompany;
import com.billdog.entities.view.ViewInsuranceCompanyInfo;
import com.billdog.entities.view.ViewMemberResponse;
import com.billdog.entities.view.ViewResponse;

@Service
public class AddInsuranceCompanyService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AddInsuranceCompanyService.class);

	@Autowired
	InsuranceCompanyRepository insuranceCompanyRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	UserService userService;

	@Autowired
	IndividualProviderRepository individualProviderRepository;

	@Autowired
	CompanyProviderRepository companyProviderRepository;

	/**
	 * @param insuranceCompanyRequest
	 * @param organization
	 * @return
	 */
	public ViewResponse addInsuranceDetails(InsuranceCompanyRequest insuranceCompanyRequest,
			Organization organization) {
		LOGGER.info("addInsuranceDetails method started..!");

		saveInsuranceDetails(insuranceCompanyRequest, organization);

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.INSURANCE_DETAILS);
		LOGGER.info("addInsuranceDetails method has ended..!");
		return viewResponse;

	}

	/**
	 * @param insuranceCompanyRequest
	 * @param organization
	 */
	private void saveInsuranceDetails(InsuranceCompanyRequest insuranceCompanyRequest, Organization organization) {
		LOGGER.debug("creating new object in insurance table.!!");
		InsuranceCompany insuranceCompany = new InsuranceCompany();
		insuranceCompany.setCreatedAt(DateAndTimeUtil.now());
		insuranceCompany.setUpdatedAt(DateAndTimeUtil.now());
		insuranceCompany.setName(WordUtils.capitalizeFully(insuranceCompanyRequest.getInsuranceCompanyName()));
		insuranceCompany
				.setContactPersonName(WordUtils.capitalizeFully(insuranceCompanyRequest.getContactPersonName()));
		insuranceCompany.setContactNumber(insuranceCompanyRequest.getContactNumber());
		insuranceCompany.setEmail(insuranceCompanyRequest.getEmail());
		insuranceCompany.setSfdcId(insuranceCompanyRequest.getSfdcId());
		insuranceCompany.setAddress(insuranceCompanyRequest.getAddress());
		if (insuranceCompanyRequest.getSfdcId() != null) {
			insuranceCompany.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		insuranceCompany.setOrganizationId(organization);
		insuranceCompany.setStatus(StatusConstants.ACTIVE);
		insuranceCompany.setUserId(insuranceCompanyRequest.getUserId());
		if (insuranceCompanyRequest.getCountryCodeId() > 0) {
			checkCountryCode(insuranceCompanyRequest.getCountryCodeId(), organization.getId());
			insuranceCompany.setCountryCodeId(insuranceCompanyRequest.getCountryCodeId());
		}
		insuranceCompanyRepository.save(insuranceCompany);
	}

	private GetCountryCodeInfo checkCountryCode(long countryCodeId, long orgId) {
		GetCountryCodeInfo getCountryCodeInfo = userService.getCountryCode(countryCodeId, orgId);
		if (getCountryCodeInfo == null || (!getCountryCodeInfo.getStatusText().equalsIgnoreCase(Constants.SUCCESS))) {
			throw new RecordNotFoundException(ExceptionalMessages.COUNTRY_CODE_NOT_FOUND);
		}
		return getCountryCodeInfo;
	}

	public ResponseEntity<ViewMemberResponse> getCarrier(Long userId, Long memberId, Long organizationId) {
		LOGGER.info("getCarrier strated..");

		Optional<Organization> organization = organizationRepository.findById(organizationId);
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND + organizationId);
		}

		List<ViewCarrierDetails> viewCarrierDetailsList = new ArrayList<>();

		// fetching all carrier type which are in active status
		List<InsuranceCompany> carrier = insuranceCompanyRepository.findByOrganizationIdAndStatus(organization.get(),
				StatusConstants.ACTIVE);

		LOGGER.debug("fetching list of carrier type which are in active status..");

		carrier.forEach(carrierType -> {
			ViewCarrierDetails viewCarrierDetails = new ViewCarrierDetails();
			viewCarrierDetails.setCarrierId(carrierType.getId());
			viewCarrierDetails.setCarrierName(carrierType.getName());
			viewCarrierDetailsList.add(viewCarrierDetails);
		});

		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.CARRIER_TYPE_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewCarrierDetailsList);
		LOGGER.info("getCarrier ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<GetCarrierInfo> getCarrierById(Long carrierId, Long organizationId) {
		LOGGER.info("getCarrier strated..");

		Optional<Organization> organization = organizationRepository.findById(organizationId);
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND + organizationId);
		}

		// fetching all carrier type which are in active status
		Optional<InsuranceCompany> carrier = insuranceCompanyRepository.findByIdAndOrganizationIdAndStatus(carrierId,
				organization.get(), StatusConstants.ACTIVE);
		if (!carrier.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.CARRIER_TYPE_NOT_FOUND);
		}
		LOGGER.debug("fetching list of carrier type which are in active status..");

		GetCarrierInfo getCarrierInfo = new GetCarrierInfo();

		getCarrierInfo.setCarrierId(carrier.get().getId());
		getCarrierInfo.setCarrierName(carrier.get().getName());

		getCarrierInfo.setStatusText(Constants.SUCCESS);
		LOGGER.info("getCarrier ended..");
		return ResponseEntity.status(HttpStatus.OK).body(getCarrierInfo);
	}

	public ResponseEntity<ViewResponse> searchInsurance(InsuranceCompanySearchRequest insuranceCompanySearchRequest) {
		LOGGER.info("search Insurance details method started..!");

		String insuranceCompanyName = null;
		String contactPerson = null;
		String contactNo = null;
		String email = null;
		String sfdcId = null;
		String status = null;
		if (insuranceCompanySearchRequest.getInsuranceCompanyName() != null
				&& !insuranceCompanySearchRequest.getInsuranceCompanyName().equals("")) {
			insuranceCompanyName = "%" + insuranceCompanySearchRequest.getInsuranceCompanyName() + "%";
		} else {
			insuranceCompanyName = insuranceCompanySearchRequest.getInsuranceCompanyName();
		}

		if (insuranceCompanySearchRequest.getContactNo() != null
				&& !insuranceCompanySearchRequest.getContactNo().equals("")) {
			contactNo = "%" + insuranceCompanySearchRequest.getContactNo() + "%";
		} else {
			contactNo = insuranceCompanySearchRequest.getContactNo();
		}

		if (insuranceCompanySearchRequest.getContactPerson() != null
				&& !insuranceCompanySearchRequest.getContactPerson().equals("")) {
			contactPerson = "%" + insuranceCompanySearchRequest.getContactPerson() + "%";
		} else {
			contactPerson = insuranceCompanySearchRequest.getContactPerson();
		}

		if (insuranceCompanySearchRequest.getEmailId() != null
				&& !insuranceCompanySearchRequest.getEmailId().equals("")) {
			email = "%" + insuranceCompanySearchRequest.getEmailId() + "%";
		} else {
			email = insuranceCompanySearchRequest.getEmailId();
		}

		if (insuranceCompanySearchRequest.getSfdcId() != null
				&& !insuranceCompanySearchRequest.getSfdcId().equals("")) {
			sfdcId = "%" + insuranceCompanySearchRequest.getSfdcId() + "%";
		} else {
			sfdcId = insuranceCompanySearchRequest.getSfdcId();
		}

		status = insuranceCompanySearchRequest.getStatus();

		Integer pageNumber = insuranceCompanySearchRequest.getPageNumber() > 0
				? insuranceCompanySearchRequest.getPageNumber()
				: 0;
		Integer pageLimit = insuranceCompanySearchRequest.getPageLimit() > 0
				? insuranceCompanySearchRequest.getPageLimit()
				: 20;
		// native query for searching users and assigning parameters respectively
		Page<Object[][]> insuranceDetails = insuranceCompanyRepository.getInsuranceDetails(insuranceCompanyName,
				insuranceCompanyName, contactPerson, contactPerson, contactNo, contactNo, email, email, sfdcId, sfdcId,
				status, status, getPageRequest(pageNumber, pageLimit));

		// for loop for users searched with native query and assigning values
		// respectively

		List<ViewInsuranceCompany> viewInsuranceCompanyList = getInsuranceCompanyList(insuranceDetails);
		LOGGER.debug("Setting member details for new member object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.INSURANCE_DETAILS_FETCHED);
		if (viewInsuranceCompanyList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewInsuranceCompanyList);
		response.setTotal(insuranceDetails.getTotalElements());

		LOGGER.info("search Insurance details method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewInsuranceCompany> getInsuranceCompanyList(Page<Object[][]> memberDetails) {
		List<ViewInsuranceCompany> viewInsuranceCompanyList = new ArrayList<>();
		for (Object[] objects : memberDetails) {
			ViewInsuranceCompany viewInsuranceCompany = new ViewInsuranceCompany();
			viewInsuranceCompany.setInsuranceCompanyName(((String) objects[0]));
			if ((String) objects[1] == null) {
				viewInsuranceCompany.setContactPerson("");
			} else {
				viewInsuranceCompany.setContactPerson(((String) objects[1]));
			}
			if ((String) objects[2] == null) {
				viewInsuranceCompany.setContactNo("");
			} else {
				viewInsuranceCompany.setContactNo((String) objects[2]);
			}
			if ((String) objects[3] == null) {
				viewInsuranceCompany.setEmailId("");
			} else {
				viewInsuranceCompany.setEmailId((String) objects[3]);
			}
			if ((String) objects[4] == null) {
				viewInsuranceCompany.setSfdcId("");
			} else {
				viewInsuranceCompany.setSfdcId((String) objects[4]);
			}
			viewInsuranceCompany.setStatus((String) objects[5]);
			viewInsuranceCompany.setInsuranceId((BigInteger) objects[6]);
			if ((BigInteger) objects[7] != null) {
				viewInsuranceCompany.setCountryCodeId((BigInteger) objects[7]);
			}
			viewInsuranceCompany.setAddress((String) objects[8]);
			viewInsuranceCompanyList.add(viewInsuranceCompany);
		}
		return viewInsuranceCompanyList;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public ViewResponse editInsuranceCompany(EditInsuranceCompanyRequest editInsuranceCompanyRequest) {
		LOGGER.info("editInsuranceCompany method started..!");

		// checking whether insurance with given id present or not
		Optional<InsuranceCompany> insuranceCompany = insuranceCompanyRepository
				.findById(editInsuranceCompanyRequest.getInsuranceCompanyId());
		if (!insuranceCompany.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.INSURANCE_COMPANY_NOT_FOUND);
		}

		LOGGER.info("setting insurance details to respective fields");
		saveEditInsuranceDetails(editInsuranceCompanyRequest, insuranceCompany.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.INSURANCE_DETAILS_UPDATED);
		LOGGER.info("addInsuranceDetails method has ended..!");
		return viewResponse;

	}

	private void saveEditInsuranceDetails(EditInsuranceCompanyRequest editInsuranceCompanyRequest,
			InsuranceCompany insuranceCompany) {

		insuranceCompany.setName(WordUtils.capitalizeFully(editInsuranceCompanyRequest.getInsuranceCompanyName()));
		insuranceCompany
				.setContactPersonName(WordUtils.capitalizeFully(editInsuranceCompanyRequest.getContactPersonName()));
		insuranceCompany.setContactNumber(editInsuranceCompanyRequest.getContactNumber());
		insuranceCompany.setEmail(editInsuranceCompanyRequest.getEmail());
		insuranceCompany.setSfdcId(editInsuranceCompanyRequest.getSfdcId());
		if (editInsuranceCompanyRequest.getSfdcId() != null && !editInsuranceCompanyRequest.getSfdcId().isEmpty()) {
			insuranceCompany.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		insuranceCompany.setUserId(editInsuranceCompanyRequest.getUserId());
		insuranceCompany.setStatus(editInsuranceCompanyRequest.getStatus());
		insuranceCompany.setAddress(editInsuranceCompanyRequest.getAddress());
		if (editInsuranceCompanyRequest.getCountryCodeId() > 0) {
			checkCountryCode(editInsuranceCompanyRequest.getCountryCodeId(),
					insuranceCompany.getOrganizationId().getId());
			insuranceCompany.setCountryCodeId(editInsuranceCompanyRequest.getCountryCodeId());
		}
		insuranceCompany.setUpdatedAt(DateAndTimeUtil.now());
		insuranceCompanyRepository.save(insuranceCompany);
	}

	public ResponseEntity<ViewInsuranceCompany> getInsuranceCompany(Long userId, Long insuranceCompanyId) {
		LOGGER.info("getInsuranceCompany method started..!");

		// checking whether insurance with given id present or not
		Optional<InsuranceCompany> insuranceCompany = insuranceCompanyRepository.findById(insuranceCompanyId);
		if (!insuranceCompany.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.INSURANCE_COMPANY_NOT_FOUND);
		}
		InsuranceCompany insuranceCompanyDetails = insuranceCompany.get();
		LOGGER.info("setting insurance details to respective fields");
		ViewInsuranceCompany viewInsuranceCompany = new ViewInsuranceCompany();
		viewInsuranceCompany.setInsuranceCompanyName(insuranceCompanyDetails.getName());
		viewInsuranceCompany.setContactPerson(insuranceCompanyDetails.getContactPersonName());
		viewInsuranceCompany.setContactNo(insuranceCompanyDetails.getContactNumber());
		viewInsuranceCompany.setEmailId(insuranceCompanyDetails.getEmail());
		viewInsuranceCompany.setSfdcId(insuranceCompanyDetails.getSfdcId());
		viewInsuranceCompany.setStatus(insuranceCompanyDetails.getStatus());
		viewInsuranceCompany.setAddress(insuranceCompanyDetails.getAddress());

		LOGGER.info("addInsuranceDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewInsuranceCompany);

	}

	public ResponseEntity<ViewResponse> verifySubCaseRequest(VerifySubCaseRequest request) {
		LOGGER.info("getInsuranceCompany method started..!");
		ViewResponse response = new ViewResponse();
		// checking whether insurance with given id present or not
		if (request.getInsuranceCompanyId() > 0) {
			Optional<InsuranceCompany> insuranceCompany = insuranceCompanyRepository
					.findById(request.getInsuranceCompanyId());
			if (!insuranceCompany.isPresent()) {
				response.setMessage(ExceptionalMessages.INSURANCE_COMPANY_NOT_FOUND);
				response.setStatusText(Constants.FAILED);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				boolean updated = false;
				if ((!StringUtils.isBlank(request.getInsuranceCompanyAddress()) && !request.getInsuranceCompanyAddress()
						.equalsIgnoreCase(insuranceCompany.get().getAddress()))) {
					updated = true;
					insuranceCompany.get().setAddress(request.getInsuranceCompanyAddress());
				}
				if ((!StringUtils.isBlank(request.getInsuranceCompanyPhone()) && !request.getInsuranceCompanyPhone()
						.equalsIgnoreCase(insuranceCompany.get().getContactNumber()))) {
					updated = true;
					insuranceCompany.get().setContactNumber(request.getInsuranceCompanyPhone());
				}
				if (updated) {
					insuranceCompanyRepository.save(insuranceCompany.get());
				}

			}

		}

		if (request.getCompanyProviderId() > 0) {
			Optional<CompanyProvider> companyProvider = companyProviderRepository
					.findById(request.getCompanyProviderId());
			if (!companyProvider.isPresent()) {
				response.setMessage(ExceptionalMessages.COMPANY_PROVIDER_NOT_FOUND);
				response.setStatusText(Constants.FAILED);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			} else {
				boolean updated = false;
				if (!StringUtils.isBlank(request.getCompanyProviderAddress())
						&& !request.getCompanyProviderAddress().equalsIgnoreCase(companyProvider.get().getAddress())) {
					updated = true;
					companyProvider.get().setAddress(request.getCompanyProviderAddress());
				}
				if (!StringUtils.isBlank(request.getCompanyProviderPhone()) && !request.getCompanyProviderPhone()
						.equalsIgnoreCase(companyProvider.get().getContactNumber())) {
					updated = true;
					companyProvider.get().setContactNumber(request.getCompanyProviderPhone());
				}
				if (updated) {
					companyProviderRepository.save(companyProvider.get());
				}

			}
		}
		if (request.getIndividulProviderId() > 0) {
			Optional<IndividualProvider> individualProvider = individualProviderRepository
					.findById(request.getIndividulProviderId());
			if (!individualProvider.isPresent()) {
				response.setMessage(ExceptionalMessages.INDIVIDUAL_PROVIDER_NOT_FOUND);
				response.setStatusText(Constants.FAILED);
				return ResponseEntity.status(HttpStatus.OK).body(response);
			}
		}

		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.SUB_CASE_REQUEST_VERIFIED);
		LOGGER.info("addInsuranceDetails method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	public ResponseEntity<ViewResponse> getInsuranceCompaniesList(Long organizationId) {
		LOGGER.info("getInsuranceCompaniesList method started..!");
		Optional<Organization> orgOptional = organizationRepository.findById(organizationId);
		if (!orgOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		LOGGER.info("Fetching all insurance companies with organization id:: {}", organizationId);
		List<InsuranceCompany> insuranceCompaniesList = insuranceCompanyRepository
				.findByOrganizationIdAndStatus(orgOptional.get(), StatusConstants.ACTIVE);
		List<ViewInsuranceCompanyInfo> induranceCompanyInfos = new ArrayList<>();
		insuranceCompaniesList.forEach(induranceCompany -> {
			ViewInsuranceCompanyInfo induranceCompanyInfo = new ViewInsuranceCompanyInfo();
			induranceCompanyInfo.setInsuranceCompanyAddress(induranceCompany.getAddress());
			induranceCompanyInfo.setInsuranceCompanyId(induranceCompany.getId());
			induranceCompanyInfo.setInsuranceCompanyName(induranceCompany.getName());
			induranceCompanyInfo.setInsuranceCompanyPhone(induranceCompany.getContactNumber());
			induranceCompanyInfos.add(induranceCompanyInfo);
		});
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.INSURANCE_DETAILS_FETCHED);
		if (induranceCompanyInfos.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(induranceCompanyInfos);
		LOGGER.info("getInsuranceCompaniesList details method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

}
