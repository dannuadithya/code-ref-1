package com.billdog.entities.request;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class VerifySubCaseRequest {

	private long insuranceCompanyId;
	private long companyProviderId;
	private long individulProviderId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String insuranceCompanyAddress;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String insuranceCompanyPhone;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String companyProviderAddress;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String companyProviderPhone;
	private long userId;

	public long getInsuranceCompanyId() {
		return insuranceCompanyId;
	}

	public void setInsuranceCompanyId(long insuranceCompanyId) {
		this.insuranceCompanyId = insuranceCompanyId;
	}

	public long getCompanyProviderId() {
		return companyProviderId;
	}

	public void setCompanyProviderId(long companyProviderId) {
		this.companyProviderId = companyProviderId;
	}

	public long getIndividulProviderId() {
		return individulProviderId;
	}

	public void setIndividulProviderId(long individulProviderId) {
		this.individulProviderId = individulProviderId;
	}

	public String getInsuranceCompanyAddress() {
		return insuranceCompanyAddress;
	}

	public void setInsuranceCompanyAddress(String insuranceCompanyAddress) {
		this.insuranceCompanyAddress = insuranceCompanyAddress;
	}

	public String getInsuranceCompanyPhone() {
		return insuranceCompanyPhone;
	}

	public void setInsuranceCompanyPhone(String insuranceCompanyPhone) {
		this.insuranceCompanyPhone = insuranceCompanyPhone;
	}

	public String getCompanyProviderAddress() {
		return companyProviderAddress;
	}

	public void setCompanyProviderAddress(String companyProviderAddress) {
		this.companyProviderAddress = companyProviderAddress;
	}

	public String getCompanyProviderPhone() {
		return companyProviderPhone;
	}

	public void setCompanyProviderPhone(String companyProviderPhone) {
		this.companyProviderPhone = companyProviderPhone;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

}
