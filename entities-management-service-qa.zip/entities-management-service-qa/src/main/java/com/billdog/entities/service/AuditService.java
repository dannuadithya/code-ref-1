package com.billdog.entities.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.EntityAuditModules;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.OpportunityAuditModules;
import com.billdog.entities.common.RecordsTime;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.repository.CompanyProviderRepository;
import com.billdog.entities.repository.EmployerRepository;
import com.billdog.entities.repository.IndividualProviderRepository;
import com.billdog.entities.repository.InsuranceCompanyRepository;
import com.billdog.entities.request.AuditRequest;
import com.billdog.entities.view.ViewEntityAuditModule;
import com.billdog.entities.view.ViewResponse;

@Service
public class AuditService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AuditService.class);

	@Autowired
	CompanyProviderRepository companyProviderRepository;

	@Autowired
	InsuranceCompanyRepository insuranceCompanyRepository;

	@Autowired
	IndividualProviderRepository individualProviderRepository;

	@Autowired
	EmployerRepository employerRepository;

	@Autowired
	EmployerAuditService employerAuditService;

	@Autowired
	IndividualBrokerAuditService individualBrokerAuditService;

	@Autowired
	CompanyProviderAuditService companyProviderAuditService;

	@Autowired
	IndividualProviderAuditService individualProviderAuditService;

	@Autowired
	InsuranceCompanyAuditService insuranceCompanyAuditService;

	@Autowired
	BrokerCompanyAuditService brokerCompanyAuditService;

	@Autowired
	OpportunityAuditService opportunityAuditService;

	public ResponseEntity<ViewResponse> getEntityModules() {
		LOGGER.info("getEntityModules method started");
		List<ViewEntityAuditModule> auditModules = new ArrayList<>();
		Arrays.asList(EntityAuditModules.values()).forEach(module -> {
			ViewEntityAuditModule auditModule = new ViewEntityAuditModule();
			auditModule.setModuleName(module.toString().replace("_", " "));
			auditModules.add(auditModule);
		});
		ViewResponse response = new ViewResponse();
		response.setData(auditModules);
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.AUDIT_MODULE_LIST_FETCHED);
		if (auditModules.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getEntityModules method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getEntityAuditInfo(AuditRequest auditRequest) {
		LOGGER.info("getEntityAuditInfo method started");
		List<Long> revtypes = getRevtypes(auditRequest);
		if (StringUtils.isBlank(auditRequest.getModuleName())) {
			throw new BadRequestException(ExceptionalMessages.PLEASE_PROVIDE_MODULE);
		}
		if (auditRequest.getModuleName().equalsIgnoreCase(EntityAuditModules.Entities.toString())) {
			if (auditRequest.getSubModuleName().equalsIgnoreCase(EntityAuditModules.Employer.toString())) {
				return employerAuditService.getEmployerAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(EntityAuditModules.Individual_Broker.toString())) {
				return individualBrokerAuditService.getIndividualBrokerAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(EntityAuditModules.Company_Provider.toString())) {
				return companyProviderAuditService.getCompanyProviderAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(EntityAuditModules.Individual_Provider.toString())) {
				return individualProviderAuditService.getIndividualProviderAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(EntityAuditModules.Broker_Company.toString())) {
				return brokerCompanyAuditService.getBrokerCompanyAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(EntityAuditModules.Insurance_Company.toString())) {
				return insuranceCompanyAuditService.getInsuranceCompanyAuditInfo(auditRequest, revtypes);
			}
		}

		if (auditRequest.getModuleName().replace(" ", "_")
				.equalsIgnoreCase(OpportunityAuditModules.Opportunities.toString())) {
			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(OpportunityAuditModules.Block_Opportunity.toString())) {
				return opportunityAuditService.getOpportunityAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(OpportunityAuditModules.Sub_Group_Opportunity.toString())) {
				return opportunityAuditService.getSubOpportunityAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(OpportunityAuditModules.Broker_Sponsored.toString())) {
				return opportunityAuditService.getBrokerSponsoredAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName().replace(" ", "_")
					.equalsIgnoreCase(OpportunityAuditModules.Employer_Direct.toString())) {
				return opportunityAuditService.getEmployerDirectAuditInfo(auditRequest, revtypes);
			}
		}

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.NO_RESULTS_FOUND);
		response.setData(new ArrayList<Long>());
		LOGGER.info("getEntityAuditInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public List<Long> getRevtypes(AuditRequest auditRequest) {
		List<Long> revtypes = new ArrayList<>();
		if (StringUtils.isBlank(auditRequest.getType()) || auditRequest.getType().equalsIgnoreCase("All")) {
			revtypes.add(0l);
			revtypes.add(1l);
			revtypes.add(2l);
		}
		if (auditRequest.getType().equalsIgnoreCase(Constants.CREATED)) {
			revtypes.add(0l);
		}
		if (auditRequest.getType().equalsIgnoreCase(Constants.UPDATED)
				|| auditRequest.getType().equalsIgnoreCase(Constants.MODIFIED)) {
			revtypes.add(1l);
		}
		return revtypes;
	}

	public ResponseEntity<ViewResponse> getEntityAuditInfoById(Long recordId, String moduleName, Integer pageNumber,
			Integer pageLimit) {

		LOGGER.info("getEntityAuditInfoById method started");
		if (moduleName.equalsIgnoreCase(EntityAuditModules.Employer.toString())) {
			return employerAuditService.getEmployerAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(EntityAuditModules.Individual_Broker.toString())) {
			return individualBrokerAuditService.getIndividualBrokerAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(EntityAuditModules.Company_Provider.toString())) {
			return companyProviderAuditService.getCompanyProviderAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(EntityAuditModules.Individual_Provider.toString())) {
			return individualProviderAuditService.getIndividualProviderAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(EntityAuditModules.Broker_Company.toString())) {
			return brokerCompanyAuditService.getBrokerCompanyAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(EntityAuditModules.Insurance_Company.toString())) {
			return insuranceCompanyAuditService.getInsuranceCompanyAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(OpportunityAuditModules.Block_Opportunity.toString())) {
			return opportunityAuditService.getBlockOppAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(OpportunityAuditModules.Sub_Group_Opportunity.toString())) {
			return opportunityAuditService.getSubOppAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(OpportunityAuditModules.Broker_Sponsored.toString())) {
			return opportunityAuditService.getBrokerSponsoredAuditInfoById(recordId, pageNumber, pageLimit);
		}

		if (moduleName.replace(" ", "_").equalsIgnoreCase(OpportunityAuditModules.Employer_Direct.toString())) {
			return opportunityAuditService.getEmployerDirectAuditInfoById(recordId, pageNumber, pageLimit);
		}

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.NO_RESULTS_FOUND);
		LOGGER.info("getEntityAuditInfoById method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public LocalDateTime getDate(String time) {
		LocalDate date = LocalDate.now();
		if (!StringUtils.isBlank(time)) {
			if (time.equalsIgnoreCase(RecordsTime.LAST_WEEK.toString().replace("_", " "))) {
				date = LocalDate.now().minusDays(7);
			} else if (time.equalsIgnoreCase(RecordsTime.LAST_MONTH.toString().replace("_", " "))) {
				date = LocalDate.now().minusMonths(1);
			} else if (time.equalsIgnoreCase(RecordsTime.LAST_3_MONTHS.toString().replace("_", " "))) {
				date = LocalDate.now().minusMonths(3);
			} else if (time.equalsIgnoreCase(RecordsTime.LAST_6_MONTHS.toString().replace("_", " "))) {
				date = LocalDate.now().minusMonths(6);
			} else if (time.equalsIgnoreCase(RecordsTime.LAST_YEAR.toString().replace("_", " "))) {
				date = LocalDate.now().minusYears(1);
			} 
			else {
				date = LocalDate.of(2020, 01, 01);
			}
		}else {
			date = LocalDate.of(2020, 01, 01);
		}
		
		return date.atTime(00, 00);
	}

	public ResponseEntity<ViewResponse> getAuditTimeperiods() {
		LOGGER.info("getEntityModules method started");
		List<ViewEntityAuditModule> auditModules = new ArrayList<>();
		Arrays.asList(RecordsTime.values()).forEach(module -> {
			ViewEntityAuditModule auditModule = new ViewEntityAuditModule();
			auditModule.setModuleName(module.toString());
			auditModules.add(auditModule);
		});
		ViewResponse response = new ViewResponse();
		response.setData(auditModules);
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.AUDIT_MODULE_LIST_FETCHED);
		if (auditModules.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getEntityModules method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

}
