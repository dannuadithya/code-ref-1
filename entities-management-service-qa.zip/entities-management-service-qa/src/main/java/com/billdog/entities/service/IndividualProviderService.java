package com.billdog.entities.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.ExceptionalMessages;
import com.billdog.entities.common.StatusConstants;
import com.billdog.entities.entity.CompanyProvider;
import com.billdog.entities.entity.IndividualProvider;
import com.billdog.entities.entity.Organization;
import com.billdog.entities.exception.BadRequestException;
import com.billdog.entities.exception.InValidInputException;
import com.billdog.entities.exception.RecordNotFoundException;
import com.billdog.entities.repository.CompanyProviderRepository;
import com.billdog.entities.repository.IndividualProviderRepository;
import com.billdog.entities.repository.OrganizationRepository;
import com.billdog.entities.request.AddIndividualProviderRequest;
import com.billdog.entities.request.SearchIndividualProviderRequest;
import com.billdog.entities.request.UpdateIndividualProviderRequest;
import com.billdog.entities.view.GetCountryCodeInfo;
import com.billdog.entities.view.IndividualProviderInfo;
import com.billdog.entities.view.UpdateIndividualProviderResponse;
import com.billdog.entities.view.ViewIndividualProvider;
import com.billdog.entities.view.ViewIndividualProviderInfo;
import com.billdog.entities.view.ViewResponse;

@Service
public class IndividualProviderService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(IndividualProviderService.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	UserService userService;

	@Autowired
	AddInsuranceCompanyService addInsuranceCompanyService;

	@Autowired
	CompanyProviderRepository companyProviderRepository;

	@Autowired
	IndividualProviderRepository individualProviderRepository;

	public ResponseEntity<ViewResponse> addIndividualProvider(
			AddIndividualProviderRequest addIndividualProviderRequest) {
		LOGGER.info("addIndividualProvider method started..!");
		if (StringUtils.isBlank(addIndividualProviderRequest.getFirstName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME_SIZE);
		}
		if (StringUtils.isBlank(addIndividualProviderRequest.getLastName())) {
			throw new BadRequestException(ExceptionalMessages.LAST_NAME_SIZE);
		}
		if (addIndividualProviderRequest.getContactNumber() != null
				&& !addIndividualProviderRequest.getContactNumber().isEmpty()
				&& !StringUtils.isNumeric(addIndividualProviderRequest.getContactNumber())) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (addIndividualProviderRequest.getContactNumber() != null
				&& !addIndividualProviderRequest.getContactNumber().isEmpty()
				&& (addIndividualProviderRequest.getContactNumber().length() <= 9
						|| addIndividualProviderRequest.getContactNumber().length() > 10)) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
		}

		Optional<Organization> organization = organizationRepository
				.findById(addIndividualProviderRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.ORGANIZATION_NOT_FOUND + addIndividualProviderRequest.getOrganizationId());
		}
		Optional<CompanyProvider> companyProviderEntity = companyProviderRepository
				.findById(addIndividualProviderRequest.getCompanyProviderId());
		if (!companyProviderEntity.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.COMPANY_PROVIDER_NOT_FOUND);
		}
		if (addIndividualProviderRequest.getSfdcId() != null && !addIndividualProviderRequest.getSfdcId().isEmpty()) {
			if (addIndividualProviderRequest.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			Optional<IndividualProvider> individualProvider = individualProviderRepository
					.findBySfdcId(addIndividualProviderRequest.getSfdcId());
			if (individualProvider.isPresent()) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
			}
		}
		if (addIndividualProviderRequest.getAddress() != null && !addIndividualProviderRequest.getAddress().isEmpty()
				&& addIndividualProviderRequest.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}

		saveIndividualProvider(addIndividualProviderRequest, organization.get(), companyProviderEntity.get());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.INDIVIDUAL_PROVIDER_ADDED);
		LOGGER.info("addIndividualProvider method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void saveIndividualProvider(AddIndividualProviderRequest addIndividualProviderRequest,
			Organization organization, CompanyProvider companyProvider) {
		LOGGER.debug("creating new object in individual provider table.!!");
		IndividualProvider individualProvider = new IndividualProvider();
		individualProvider.setCreatedAt(DateAndTimeUtil.now());
		individualProvider.setUpdatedAt(DateAndTimeUtil.now());
		individualProvider.setFirstName(WordUtils.capitalizeFully(addIndividualProviderRequest.getFirstName()));
		individualProvider.setLastName(WordUtils.capitalizeFully(addIndividualProviderRequest.getLastName()));
		individualProvider.setEmail(addIndividualProviderRequest.getEmail());
		individualProvider.setContactNumber(addIndividualProviderRequest.getContactNumber());
		individualProvider.setAddress(addIndividualProviderRequest.getAddress());
		if (addIndividualProviderRequest.getSfdcId() != null && !addIndividualProviderRequest.getSfdcId().isEmpty()) {
			individualProvider.setSfdcId(addIndividualProviderRequest.getSfdcId());
			individualProvider.setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		individualProvider.setOrganizationId(organization);
		individualProvider.setStatus(StatusConstants.ACTIVE);
		individualProvider.setCompanyProviderId(companyProvider);
		individualProvider.setUserId(addIndividualProviderRequest.getUserId());
		if (addIndividualProviderRequest.getCountryCodeId() > 0) {
			checkCountryCode(addIndividualProviderRequest.getCountryCodeId(), organization.getId());
			individualProvider.setCountryCodeId(addIndividualProviderRequest.getCountryCodeId());
		}
		individualProviderRepository.save(individualProvider);
	}

	public GetCountryCodeInfo checkCountryCode(long countryCodeId, long orgId) {
		GetCountryCodeInfo getCountryCodeInfo = userService.getCountryCode(countryCodeId, orgId);
		if (getCountryCodeInfo == null || (!getCountryCodeInfo.getStatusText().equalsIgnoreCase(Constants.SUCCESS))) {
			throw new RecordNotFoundException(ExceptionalMessages.COUNTRY_CODE_NOT_FOUND + countryCodeId);
		}
		return getCountryCodeInfo;
	}

	public ViewResponse searchIndividualProvider(SearchIndividualProviderRequest request, long orgId) {
		LOGGER.info("searchCompanyProvider method started..!");
		CompanyProvider companyProvider = null;
		String name = null;
		String contactNo = null;
		String email = null;
		String sfdcId = null;
		String status = null;
		LOGGER.info("Fetching company provider with id:: {}", request.getCompanyProviderId());
		Optional<CompanyProvider> companyProviderOptional = companyProviderRepository
				.findById(request.getCompanyProviderId());
		if (companyProviderOptional.isPresent()) {
			companyProvider = companyProviderOptional.get();
		}
		if (request.getName() != null && !request.getName().equals("")) {
			name = "%" + request.getName() + "%";
		} else {
			name = request.getName();
		}

		if (request.getContactNo() != null && !request.getContactNo().equals("")) {
			contactNo = "%" + request.getContactNo() + "%";
		} else {
			contactNo = request.getContactNo();
		}

		if (request.getEmailId() != null && !request.getEmailId().equals("")) {
			email = "%" + request.getEmailId() + "%";
		} else {
			email = request.getEmailId();
		}

		if (request.getSfdcId() != null && !request.getSfdcId().equals("")) {
			sfdcId = "%" + request.getSfdcId() + "%";
		} else {
			sfdcId = request.getSfdcId();
		}

		status = request.getStatus();

		Integer pageNumber = request.getPageNumber() > 0 ? request.getPageNumber() : 0;
		Integer pageLimit = request.getPageLimit() > 0 ? request.getPageLimit() : 20;
		// native query for searching company provider and assigning parameters
		// respectively
		LOGGER.info("Fetching all individual providers match with input reuested");
		Page<Object[][]> individualProvidersList = individualProviderRepository.getProviders(name, name, name, name,
				companyProvider, companyProvider, email, email, contactNo, contactNo, sfdcId, sfdcId, status, status,
				orgId, getPageRequest(pageNumber, pageLimit));
		List<IndividualProviderInfo> individualProviderInfoList = getIndividualProviderInfoList(
				individualProvidersList);
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.INDIVIDUAL_PROVIDER_LIST_FETCHED);
		if (individualProviderInfoList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(individualProviderInfoList);
		response.setTotal(individualProvidersList.getTotalElements());
		LOGGER.info("searchIndividualProvider method ended..!");
		return response;
	}

	private List<IndividualProviderInfo> getIndividualProviderInfoList(Page<Object[][]> individualProvidersList) {
		List<IndividualProviderInfo> individualProviderInfoList = new ArrayList<>();
		for (Object[] provider : individualProvidersList) {
			IndividualProviderInfo individualProviderInfo = new IndividualProviderInfo();
			individualProviderInfo.setFirstName(((String) provider[0]));
			individualProviderInfo.setLastName(((String) provider[1]));
			individualProviderInfo.setCompanyProviderId(((BigInteger) provider[7]).longValue());
			individualProviderInfo.setCompanyProviderName(((String) provider[2]));
			if ((String) provider[4] == null) {
				individualProviderInfo.setContactNo("");
			} else {
				individualProviderInfo.setContactNo(((String) provider[4]));
			}
			if ((String) provider[3] == null) {
				individualProviderInfo.setEmailId("");
			} else {
				individualProviderInfo.setEmailId(((String) provider[3]));
			}

			individualProviderInfo.setIndividualProviderId(((BigInteger) provider[8]).longValue());
			if ((String) provider[5] == null) {
				individualProviderInfo.setSfdcId("");
			} else {
				individualProviderInfo.setSfdcId(((String) provider[5]));
			}
			individualProviderInfo.setStatus(((String) provider[6]));
			if ((BigInteger) provider[9] != null) {
				individualProviderInfo.setCountryCodeId(((BigInteger) provider[9]).longValue());
			}
			individualProviderInfo.setAddress((String) provider[10]);
			individualProviderInfoList.add(individualProviderInfo);

		}
		return individualProviderInfoList;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public UpdateIndividualProviderResponse updateIndividualProvider(UpdateIndividualProviderRequest request) {
		LOGGER.info("updateIndividualProvider method started..!");
		if (StringUtils.isBlank(request.getFirstName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME_SIZE);
		}
		if (StringUtils.isBlank(request.getLastName())) {
			throw new BadRequestException(ExceptionalMessages.LAST_NAME_SIZE);
		}
		if (request.getContactNumber() != null && !request.getContactNumber().isEmpty()
				&& !StringUtils.isNumeric(request.getContactNumber())) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (request.getContactNumber() != null && !request.getContactNumber().isEmpty()
				&& (request.getContactNumber().length() <= 9 || request.getContactNumber().length() > 10)) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
		}
		if (request.getEmail() != null && !request.getEmail().isEmpty() && !isValid(request.getEmail())) {
			throw new InValidInputException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
		}
		LOGGER.info("Fetching company provider info with id:: {}", request.getCompanyProviderId());
		Optional<CompanyProvider> companyProviderOptional = companyProviderRepository
				.findById(request.getCompanyProviderId());
		if (!companyProviderOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.COMPANY_PROVIDER_NOT_FOUND);
		}
		LOGGER.info("Fetching individual provider info with id:: {}", request.getIndividualProviderId());
		Optional<IndividualProvider> individualProviderOptional = individualProviderRepository
				.findById(request.getIndividualProviderId());
		if (!individualProviderOptional.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_PROVIDER_NOT_FOUND);
		}
		if (request.getSfdcId() != null && !request.getSfdcId().isEmpty()) {
			if (request.getSfdcId().length() > 100) {
				throw new RecordNotFoundException(ExceptionalMessages.SFDC_VALIDATION);
			}
			if (individualProviderOptional.get().getSfdcId() != null
					&& !individualProviderOptional.get().getSfdcId().equals(request.getSfdcId())) {
				Optional<IndividualProvider> companyProvider = individualProviderRepository
						.findBySfdcId(request.getSfdcId());
				if (companyProvider.isPresent()) {
					throw new RecordNotFoundException(ExceptionalMessages.SFDC_EXISTS);
				}
			}
		}

		if (request.getAddress() != null && !request.getAddress().isEmpty() && request.getAddress().length() > 60) {
			throw new RecordNotFoundException(ExceptionalMessages.ADDRESS);
		}

		individualProviderOptional.get().setUpdatedAt(DateAndTimeUtil.now());
		individualProviderOptional.get().setFirstName(WordUtils.capitalizeFully(request.getFirstName()));
		individualProviderOptional.get().setLastName(WordUtils.capitalizeFully(request.getLastName()));
		individualProviderOptional.get().setEmail(request.getEmail());
		individualProviderOptional.get().setContactNumber(request.getContactNumber());
		individualProviderOptional.get().setUserId(request.getUserId());
		individualProviderOptional.get().setSfdcId(request.getSfdcId());
		if (request.getSfdcId() != null && !request.getSfdcId().isEmpty()) {
			individualProviderOptional.get().setSfdcUpdatedTime(DateAndTimeUtil.now());
		}
		individualProviderOptional.get().setStatus(request.getStatus());
		individualProviderOptional.get().setCompanyProviderId(companyProviderOptional.get());
		if (request.getCountryCodeId() > 0
				&& request.getCountryCodeId() != individualProviderOptional.get().getCountryCodeId()) {
			checkCountryCode(individualProviderOptional.get().getCountryCodeId(),
					companyProviderOptional.get().getOrganizationId().getId());
			individualProviderOptional.get().setCountryCodeId(request.getCountryCodeId());
		}
		individualProviderOptional.get().setAddress(request.getAddress());
		LOGGER.info("updating individual provider info with id:: {}", request.getIndividualProviderId());
		individualProviderRepository.save(individualProviderOptional.get());
		LOGGER.info("updated individual provider info with id:: {}", request.getIndividualProviderId());
		UpdateIndividualProviderResponse response = new UpdateIndividualProviderResponse();
		response.setMessage(Constants.INDIVIDUAL_PROVIDER_UPDATED);
		response.setStatusText(Constants.SUCCESS);
		LOGGER.info("updateIndividualProvider method ended..!");
		return response;
	}

	private boolean isValid(String email) {
		String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
		return email.matches(regex);
	}

	public ResponseEntity<ViewIndividualProvider> getIndividualProvider(Long individualProviderId) {
		LOGGER.info("getIndividualProvider method started..!");

		// checking whether individual provider with given id present or not
		Optional<IndividualProvider> individualProvider = individualProviderRepository.findById(individualProviderId);
		if (!individualProvider.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.INDIVIDUAL_PROVIDER_NOT_FOUND);
		}
		ViewIndividualProvider viewIndividualProvider = new ViewIndividualProvider();
		Optional<CompanyProvider> companyProvider = companyProviderRepository
				.findById(individualProvider.get().getCompanyProviderId().getId());
		if (companyProvider.isPresent()) {
			viewIndividualProvider.setCompanyProviderName(companyProvider.get().getCompanyName());
		}
		IndividualProvider individualProviderDetails = individualProvider.get();
		LOGGER.info("setting individual provider details to respective fields");
		viewIndividualProvider.setFirstName(individualProviderDetails.getFirstName());
		viewIndividualProvider.setLastName(individualProviderDetails.getLastName());
		viewIndividualProvider.setEmail(individualProviderDetails.getEmail());
		viewIndividualProvider.setContactNumber(individualProviderDetails.getContactNumber());
		viewIndividualProvider.setCountryCodeId(individualProviderDetails.getCountryCodeId());
		viewIndividualProvider.setCompanyProviderId(individualProviderDetails.getCompanyProviderId().getId());
		if (individualProviderDetails.getSfdcId() != null) {
			viewIndividualProvider.setSfdcId(individualProviderDetails.getSfdcId());
		}
		viewIndividualProvider.setStatus(individualProviderDetails.getStatus());
		viewIndividualProvider.setAddress(individualProviderDetails.getAddress());

		LOGGER.info("getCompanyProvider method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewIndividualProvider);
	}

	public ResponseEntity<ViewResponse> getIndividualProviders(Long companyProviderId) {
		LOGGER.info("getIndividualProviders method ended..!");
		Optional<CompanyProvider> companyProvider = companyProviderRepository.findById(companyProviderId);
		if (!companyProvider.isPresent()) {
			throw new RecordNotFoundException(ExceptionalMessages.COMPANY_PROVIDER_NOT_FOUND);
		}

		List<IndividualProvider> individualProvidersList = individualProviderRepository
				.findByCompanyProviderId(companyProvider.get());
		List<ViewIndividualProviderInfo> individualProviders = new ArrayList<>();
		individualProvidersList.forEach(individualProvider -> {
			ViewIndividualProviderInfo individualProviderInfo = new ViewIndividualProviderInfo();
			individualProviderInfo.setIndividualProviderId(individualProvider.getId());
			individualProviderInfo.setIndividualProviderName(
					getName(individualProvider.getFirstName(), individualProvider.getLastName()));
			individualProviders.add(individualProviderInfo);
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.INDIVIDUAL_PROVIDER_LIST_FETCHED);
		if (individualProviders.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(individualProviders);
		LOGGER.info("searchIndividualProvider method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private String getName(String firstName, String lastName) {
		String name = "";
		if (firstName != null) {
			name = name + firstName;
		}
		if (lastName != null) {
			name = name + " " + lastName;
		}
		return name;
	}

}
