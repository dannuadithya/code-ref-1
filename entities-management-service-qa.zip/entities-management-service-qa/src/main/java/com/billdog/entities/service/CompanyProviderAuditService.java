package com.billdog.entities.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.entities.common.AuditConstants;
import com.billdog.entities.common.Constants;
import com.billdog.entities.common.DateAndTimeUtil;
import com.billdog.entities.common.RecordsTime;
import com.billdog.entities.repository.CompanyProviderRepository;
import com.billdog.entities.request.AuditRequest;
import com.billdog.entities.view.GetUsers;
import com.billdog.entities.view.ViewAuditResponse;
import com.billdog.entities.view.ViewResponse;
import com.billdog.entities.view.ViewUserInfo;

@Service
public class CompanyProviderAuditService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CompanyProviderAuditService.class);

	@Autowired
	CompanyProviderRepository companyProviderRepository;

	@Autowired
	AuditService auditService;

	@Autowired
	EmployerAuditService employerAuditService;

	public ResponseEntity<ViewResponse> getCompanyProviderAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {
		LOGGER.info("getCompanyProviderAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = auditService.getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (!StringUtils.isBlank(auditRequest.getTimePeriod())
				&& auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.CUSTOM.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}

		Page<Object[]> companyProviders = companyProviderRepository.getCompanyProviderAuditInfo(name, name,
				startDate, endDate, revtypes, auditRequest.getOrganizationId(),
				getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getData(companyProviders.getContent());
		if (companyProviders.getTotalElements() > pageLimit) {
			response.setTotalElements(companyProviders.getTotalElements());
		}

		LOGGER.info("getCompanyProviderAuditInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getCompanyProviderAuditInfoById(Long id, Integer pageNumber,
			Integer pageLimit) {
		LOGGER.info("getCompanyProviderAuditInfoById method started");
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null && pageLimit > 0 ? pageLimit : 20;
		Page<Object[]> companyProviders = companyProviderRepository.getCompanyProviderAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));

		ViewResponse response = getData(companyProviders.getContent());
		if (companyProviders.getTotalElements() > pageLimit) {
			response.setTotalElements(companyProviders.getTotalElements());
		}
		LOGGER.info("getCompanyProviderAuditInfoById method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getData(List<Object[]> companyProviders) {
		List<ViewAuditResponse> auditResponses = new ArrayList<>();
		GetUsers usersInfoList = getUsersInfoList(companyProviders);
		companyProviders.forEach(item -> {
			ViewAuditResponse auditResponse = new ViewAuditResponse();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> empObj = companyProviderRepository.getCompanyProviderAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[11]).longValue());
				if (empObj != null && !empObj.isEmpty()) {
					for (Object[] item2 : empObj) {
						auditResponse = setValues(item, item2, auditResponse, usersInfoList.getData());
					}
				}
				if (auditResponse != null && (!StringUtils.isBlank(auditResponse.getOldValue())
						|| !StringUtils.isBlank(auditResponse.getNewValue()))) {
					auditResponses.add(auditResponse);
				} else {
					auditResponse.setNewValue(Constants.NO_CHANGE);
					auditResponse.setOldValue(Constants.NO_CHANGE);
					auditResponses.add(auditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				auditResponse = setCreatedCompanyProvider(item, auditResponse, usersInfoList.getData());
				if (auditResponse != null && !StringUtils.isBlank(auditResponse.getNewValue())) {
					auditResponses.add(auditResponse);
				}
			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(companyProviders.size());
		response.setMessage(Constants.COMPANY_PROVIDER_AUDIT_LIST_FETCHED);
		if (auditResponses.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(auditResponses);
		LOGGER.info("getEmployerAuditInfo method ended");
		return response;
	}

	private ViewAuditResponse setValues(Object[] item, Object[] item2, ViewAuditResponse auditResponse,
			List<ViewUserInfo> usersInfo) {
		boolean updated = false;
		String oldValue = null;
		String newValue = null;

		Timestamp updatedAt = (Timestamp) item[2];

		if (!StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])
				&& !((String) item[4]).equalsIgnoreCase((String) item2[4])) {
			updated = true;
			oldValue = AuditConstants.COMPANY_PROVIDER_NAME + item2[4];
			newValue = AuditConstants.COMPANY_PROVIDER_NAME + item[4];
		}
		if (!StringUtils.isBlank((String) item[4]) && StringUtils.isBlank((String) item2[4])) {
			updated = true;
			newValue = AuditConstants.COMPANY_PROVIDER_NAME + item[4];
		}
		if (StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])) {
			updated = true;
			oldValue = AuditConstants.COMPANY_PROVIDER_NAME + item2[4];
		}

		if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])
				&& !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.CONTACT_NUMBER + item2[5]
					: AuditConstants.CONTACT_NUMBER + item2[5];
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_NUMBER + item[5]
					: AuditConstants.CONTACT_NUMBER + item[5];
		}
		if (!StringUtils.isBlank((String) item[5]) && StringUtils.isBlank((String) item2[5])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_NUMBER + item[5]
					: AuditConstants.CONTACT_NUMBER + item[5];
		}
		if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.CONTACT_NUMBER + item2[5]
					: AuditConstants.CONTACT_NUMBER + item2[5];
		}

		if (!StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])
				&& !((String) item[6]).equalsIgnoreCase((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item2[6]
					: AuditConstants.CONTACT_PERSON_NAME + item2[6];
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item[6]
					: AuditConstants.CONTACT_PERSON_NAME + item[6];
		}
		if (!StringUtils.isBlank((String) item[6]) && StringUtils.isBlank((String) item2[6])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item[6]
					: AuditConstants.CONTACT_PERSON_NAME + item[6];
		}
		if (StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item2[6]
					: AuditConstants.CONTACT_PERSON_NAME + item2[6];
		}

		if (!StringUtils.isBlank((String) item[3]) && !StringUtils.isBlank((String) item2[3])
				&& !((String) item[3]).equalsIgnoreCase((String) item2[3])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.ADDRESS + item2[3]
					: AuditConstants.ADDRESS + item2[3];
			newValue = newValue != null ? newValue + ", " + AuditConstants.ADDRESS + item[3]
					: AuditConstants.ADDRESS + item[3];
		}
		if (!StringUtils.isBlank((String) item[3]) && StringUtils.isBlank((String) item2[3])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.ADDRESS + item[3]
					: AuditConstants.ADDRESS + item[3];
		}
		if (StringUtils.isBlank((String) item[3]) && !StringUtils.isBlank((String) item2[3])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.ADDRESS + item2[3]
					: AuditConstants.ADDRESS + item2[3];
		}

		if (!StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])
				&& !((String) item[7]).equalsIgnoreCase((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.EMAIL_ID + item2[7]
					: AuditConstants.EMAIL_ID + item2[7];
			newValue = newValue != null ? newValue + ", " + AuditConstants.EMAIL_ID + item[7]
					: AuditConstants.EMAIL_ID + item[7];
		}
		if (!StringUtils.isBlank((String) item[7]) && StringUtils.isBlank((String) item2[7])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.EMAIL_ID + item[7]
					: AuditConstants.EMAIL_ID + item[7];
		}
		if (StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.EMAIL_ID + item2[7]
					: AuditConstants.EMAIL_ID + item2[7];
		}

		if (!StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])
				&& !((String) item[8]).equalsIgnoreCase((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.SFDC_ID + item2[8]
					: AuditConstants.SFDC_ID + item2[8];
			newValue = newValue != null ? newValue + ", " + AuditConstants.SFDC_ID + item[8]
					: AuditConstants.SFDC_ID + item[8];
		}
		if (!StringUtils.isBlank((String) item[8]) && StringUtils.isBlank((String) item2[8])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.SFDC_ID + item[8]
					: AuditConstants.SFDC_ID + item[8];
		}
		if (StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.SFDC_ID + item2[8]
					: AuditConstants.SFDC_ID + item2[8];
		}

		if (!StringUtils.isBlank((String) item[9]) && !StringUtils.isBlank((String) item2[9])
				&& !((String) item[9]).equalsIgnoreCase((String) item2[9])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.STATUS + item2[9]
					: AuditConstants.STATUS + item2[9];
			newValue = newValue != null ? newValue + ", " + AuditConstants.STATUS + item[9]
					: AuditConstants.STATUS + item[9];
		}
		if (!StringUtils.isBlank((String) item[9]) && StringUtils.isBlank((String) item2[9])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + AuditConstants.STATUS + item[9]
					: AuditConstants.STATUS + item[9];
		}
		if (StringUtils.isBlank((String) item[9]) && !StringUtils.isBlank((String) item2[9])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + AuditConstants.STATUS + item2[9]
					: AuditConstants.STATUS + item2[9];
		}

		if (updated) {
			auditResponse.setRecordId(((BigInteger) item[0]).longValue());
			if (item[10] != null) {
				ViewUserInfo userInfo = employerAuditService.getUserInfo(((BigInteger) item[10]).longValue(),
						usersInfo);
				auditResponse.setUpdatedById(item[10] != null ? ((BigInteger) item[10]).longValue() : 0);
				if (!StringUtils.isBlank(userInfo.getName())) {
					auditResponse.setModifiedBy(userInfo.getName());
				}
			}
			auditResponse.setMemberOrUser(Constants.USER);
			auditResponse.setAction(getAction(item[1]));
			auditResponse.setOldValue(oldValue);
			auditResponse.setNewValue(newValue);
			auditResponse.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
									+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			return auditResponse;
		}
		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		if (item[10] != null) {
			ViewUserInfo userInfo = employerAuditService.getUserInfo(((BigInteger) item[10]).longValue(), usersInfo);
			auditResponse.setUpdatedById(item[10] != null ? ((BigInteger) item[10]).longValue() : 0);
			if (!StringUtils.isBlank(userInfo.getName())) {
				auditResponse.setModifiedBy(userInfo.getName());
			}
		}
		auditResponse.setMemberOrUser(Constants.USER);
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		return auditResponse;
	}

	private String getAction(Object item) {
		String action = null;
		int actionValue = ((Byte) item);
		if (actionValue == 0) {
			action = Constants.CREATED;
		}
		if (actionValue == 1) {
			action = Constants.UPDATED;
		}
		if (actionValue == 2) {
			action = Constants.DELETED;
		}
		return action;
	}

	private GetUsers getUsersInfoList(List<Object[]> users) {
		List<Long> userIds = new ArrayList<>();
		users.forEach(user -> {
			if (user[10] != null) {
				userIds.add(((BigInteger) user[10]).longValue());
			}
		});
		return employerAuditService.getUsersList(userIds);
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	private ViewAuditResponse setCreatedCompanyProvider(Object[] item, ViewAuditResponse auditResponse,
			List<ViewUserInfo> usersInfo) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];

		if (item[4] != null && !StringUtils.isBlank((String) item[4])) {
			newValue = AuditConstants.COMPANY_PROVIDER_NAME + item[4];
		}
		if (item[5] != null && !StringUtils.isBlank((String) item[5])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_NUMBER + item[5]
					: AuditConstants.CONTACT_NUMBER + item[5];
		}
		if (item[6] != null && !StringUtils.isBlank((String) item[6])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.CONTACT_PERSON_NAME + item[6]
					: AuditConstants.CONTACT_PERSON_NAME + item[6];
		}
		if (item[3] != null && !StringUtils.isBlank((String) item[3])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.ADDRESS + item[3]
					: AuditConstants.ADDRESS + item[3];
		}

		if (item[7] != null && !StringUtils.isBlank((String) item[7])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.EMAIL_ID + item[7]
					: AuditConstants.EMAIL_ID + item[7];
		}
		if (item[8] != null && !StringUtils.isBlank((String) item[8])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.SFDC_ID + item[8]
					: AuditConstants.SFDC_ID + item[8];
		}
		if (item[9] != null && !StringUtils.isBlank((String) item[9])) {
			newValue = newValue != null ? newValue + ", " + AuditConstants.STATUS + item[9]
					: AuditConstants.STATUS + item[9];
		}

		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		if (item[10] != null) {
			ViewUserInfo userInfo = employerAuditService.getUserInfo(((BigInteger) item[10]).longValue(), usersInfo);
			auditResponse.setUpdatedById(item[10] != null ? ((BigInteger) item[10]).longValue() : 0);
			if (!StringUtils.isBlank(userInfo.getName())) {
				auditResponse.setModifiedBy(userInfo.getName());
			}
		}
		auditResponse.setMemberOrUser(Constants.USER);
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToString(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		auditResponse.setNewValue(newValue);
		return auditResponse;

	}
}
