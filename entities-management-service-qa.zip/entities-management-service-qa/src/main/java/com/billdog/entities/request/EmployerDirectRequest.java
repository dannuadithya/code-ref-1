package com.billdog.entities.request;

import com.billdog.entities.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class EmployerDirectRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String opportunityName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String emailId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String employer;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String status;
	private long userId;
	private int pageNumber;
	private int pageLimit;

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getEmployer() {
		return employer;
	}

	public void setEmployer(String employer) {
		this.employer = employer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getPageLimit() {
		return pageLimit;
	}

	public void setPageLimit(int pageLimit) {
		this.pageLimit = pageLimit;
	}

}
