package com.billdog.entities.view;

import java.math.BigInteger;
import java.util.List;

public class ViewBlockOpportunity {

	private String opportunityName;
	private String brokerage;
	private String brokerName;
	private Long activeMembers;
	private Long totalMembers;
	private String address;
	private BigInteger blockOpportunityId;
	private Long brokerCompanyId;
	private BigInteger idividualBrokerId;
	private String sfdcId;
	private List<SubGroupOpportunityView> subGroupOpportunities;

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public BigInteger getBlockOpportunityId() {
		return blockOpportunityId;
	}

	public void setBlockOpportunityId(BigInteger blockOpportunityId) {
		this.blockOpportunityId = blockOpportunityId;
	}

	public String getOpportunityName() {
		return opportunityName;
	}

	public void setOpportunityName(String opportunityName) {
		this.opportunityName = opportunityName;
	}

	public String getBrokerage() {
		return brokerage;
	}

	public void setBrokerage(String brokerage) {
		this.brokerage = brokerage;
	}

	public String getBrokerName() {
		return brokerName;
	}

	public void setBrokerName(String brokerName) {
		this.brokerName = brokerName;
	}

	public Long getActiveMembers() {
		return activeMembers;
	}

	public void setActiveMembers(Long activeMembers) {
		this.activeMembers = activeMembers;
	}

	public Long getTotalMembers() {
		return totalMembers;
	}

	public void setTotalMembers(Long totalMembers) {
		this.totalMembers = totalMembers;
	}

	public List<SubGroupOpportunityView> getSubGroupOpportunities() {
		return subGroupOpportunities;
	}

	public void setSubGroupOpportunities(List<SubGroupOpportunityView> subGroupOpportunities) {
		this.subGroupOpportunities = subGroupOpportunities;
	}

	public Long getBrokerCompanyId() {
		return brokerCompanyId;
	}

	public void setBrokerCompanyId(Long brokerCompanyId) {
		this.brokerCompanyId = brokerCompanyId;
	}

	public BigInteger getIdividualBrokerId() {
		return idividualBrokerId;
	}

	public void setIdividualBrokerId(BigInteger idividualBrokerId) {
		this.idividualBrokerId = idividualBrokerId;
	}

}
