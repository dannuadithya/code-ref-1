package com.billdog.entities;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class EntitiesManagementServiceApplicationTests {

	@Test
	public void contextLoads() {
	}

}
