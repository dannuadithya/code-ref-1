# entities-management-service

This microservice holds the apis of entities