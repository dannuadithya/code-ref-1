#!/bin/bash
sed "s/latest/$1/g" entities-pod.yaml > entities-management.yaml