package com.homejiny.customer.entity;

public enum TermsAndConditionsEnum {
	CUSTOMER_REGISTRATION
}
