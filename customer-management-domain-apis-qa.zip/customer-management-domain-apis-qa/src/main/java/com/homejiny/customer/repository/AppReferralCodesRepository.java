/**
 * 
 */
package com.homejiny.customer.repository;

import java.time.LocalDateTime;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.homejiny.customer.entity.AppReferralCodes;

/**
 * @author Thumma
 *
 */
public interface AppReferralCodesRepository extends JpaRepository<AppReferralCodes, Long> {
	
	AppReferralCodes findByReferralCode(String referralCOde);
	
	@Query(value="select ARC.id from hj_app_referral_codes ARC where \n" + 
			"referral_code=?1 AND ARC.valid_from<?2 AND ARC.expired_time >?3",nativeQuery = true)
	Object[][] referralCodeValidationChecking(String referralCOde,LocalDateTime dateTime1,LocalDateTime dateTime2);

}
