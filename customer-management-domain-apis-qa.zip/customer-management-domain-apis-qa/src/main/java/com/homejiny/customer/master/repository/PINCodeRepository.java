package com.homejiny.customer.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.PINCode;

@Repository
public interface PINCodeRepository extends JpaRepository<PINCode, Long> {

	PINCode findByPinCodeNumber(Long request);

	PINCode findByPinCodeNumberAndStatus(Long request, String string);

	List<PINCode> findAllByStatus(String status);

	List<PINCode> findAllByStatusOrderByDisplayOrderAsc(String status);

}
