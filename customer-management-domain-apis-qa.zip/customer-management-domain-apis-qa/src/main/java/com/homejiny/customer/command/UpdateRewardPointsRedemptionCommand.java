package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.UpdateRewardPointsStatusRequest;
import com.homejiny.customer.response.UpdateRewardPointsRedemptionResponse;
import com.homejiny.customer.service.CustomerLoyaltyPoints;

@Service
public class UpdateRewardPointsRedemptionCommand implements Command<UpdateRewardPointsStatusRequest, UpdateRewardPointsRedemptionResponse> {

	@Autowired
	CustomerLoyaltyPoints customerLoyaltyPoints;

	@Override
	public UpdateRewardPointsRedemptionResponse excute(UpdateRewardPointsStatusRequest request) {
		return customerLoyaltyPoints.updatePointsRedemptionStatus(request);
	}

}
