package com.homejiny.customer.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author brahmaiam
 *
 */
@Entity
@Table(name = "MICRO_CLUSTER")
public class MicroCluster extends BaseEntity {

}
