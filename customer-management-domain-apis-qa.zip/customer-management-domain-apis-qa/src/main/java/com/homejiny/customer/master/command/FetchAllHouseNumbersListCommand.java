package com.homejiny.customer.master.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homejiny.customer.exception.InValidInputException;
import com.homejiny.customer.master.service.MasterService;
import com.homejiny.customer.master.view.ResponseView;

/**
 * @author brahmaiam
 *
 */
@Service
public class FetchAllHouseNumbersListCommand implements Command<Long, ResponseEntity<ResponseView>> {
	@Autowired
	MasterService masterService;

	public ResponseEntity<ResponseView> excute(Long request) {
		if (StringUtils.isEmpty(request) || request <= 0) {
			throw new InValidInputException("Invlaid inputs");
		}
		return ResponseEntity.status(HttpStatus.OK).body(masterService.fetchAllHouseNumbersByBlockAndFloor(request));
	}
}
