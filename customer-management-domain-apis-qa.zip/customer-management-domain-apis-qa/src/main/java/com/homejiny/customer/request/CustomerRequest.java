package com.homejiny.customer.request;

public class CustomerRequest extends CustomerInfoRequest {

	private long customerId;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

}
