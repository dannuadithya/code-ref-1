package com.homejiny.customer.command;

import com.homejiny.customer.request.CustomerRequest;
import com.homejiny.customer.request.CustomerUpdateDetailsRequest;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

/**
 * @author naresh
 *
 */
@Service
public class UpdateCustomerDetailsCommand implements Command<CustomerUpdateDetailsRequest, ResponseEntity<Response>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<Response> excute(CustomerUpdateDetailsRequest request) {

		if (request == null) {
			Response response = new Response();
			response.setMessage("Invalid Inputs");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		return ResponseEntity.status(HttpStatus.OK).body(customerService.updateCustomerDetailsById(request));
	}
}
