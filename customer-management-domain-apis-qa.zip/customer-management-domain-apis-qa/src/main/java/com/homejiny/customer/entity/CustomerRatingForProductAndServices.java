package com.homejiny.customer.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "HJ_CUSTOMER_RATING_FOR_PRODUCTS_SERVICES")
public class CustomerRatingForProductAndServices extends com.homejiny.customer.entity.Entity {

	@Column(name = "hj_customer_id")
	private long customerId;

	@Column(name = "hj_order_id")
	private long orderId;

	@Column(name = "star_rating", columnDefinition = "Decimal(10,1)")
	private double starRating;

	@Column(name = "hj_service_order_id")
	private long serviceOrderId;

	@Column(name = "comment")
	private String comment;

	@Column(name = "Quality_rating", columnDefinition = "Decimal(10,1)")
	private double qualityRating;

	@Column(name = "delivery_rating", columnDefinition = "Decimal(10,1)")
	private double deliveryRating;

	@Column(name = "Price_rating", columnDefinition = "Decimal(10,1)")
	private double priceRating;

	public double getStarRating() {
		return starRating;
	}

	public void setStarRating(double starRating) {
		this.starRating = starRating;
	}

	public double getQualityRating() {
		return qualityRating;
	}

	public void setQualityRating(double qualityRating) {
		this.qualityRating = qualityRating;
	}

	public double getDeliveryRating() {
		return deliveryRating;
	}

	public void setDeliveryRating(double deliveryRating) {
		this.deliveryRating = deliveryRating;
	}

	public double getPriceRating() {
		return priceRating;
	}

	public void setPriceRating(double priceRating) {
		this.priceRating = priceRating;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public long getServiceOrderId() {
		return serviceOrderId;
	}

	public void setServiceOrderId(long serviceOrderId) {
		this.serviceOrderId = serviceOrderId;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

}
