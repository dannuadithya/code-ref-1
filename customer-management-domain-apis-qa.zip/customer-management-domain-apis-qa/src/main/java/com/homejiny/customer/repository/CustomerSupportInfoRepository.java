package com.homejiny.customer.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.entity.CustomerSupportInfo;

@Repository
public interface CustomerSupportInfoRepository extends JpaRepository<CustomerSupportInfo, Long> {

	@Query(value = "SELECT * FROM hj_customer_support_info where id=?", nativeQuery = true)
	Optional<CustomerSupportInfo> findByEmail(String email);

}
