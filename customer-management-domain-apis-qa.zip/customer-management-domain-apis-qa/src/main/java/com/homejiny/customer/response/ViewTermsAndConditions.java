package com.homejiny.customer.response;

public class ViewTermsAndConditions {
	
	private long id;
	private String termsDescripiton;
	
	
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getTermsDescripiton() {
		return termsDescripiton;
	}
	public void setTermsDescripiton(String termsDescripiton) {
		this.termsDescripiton = termsDescripiton;
	}
	
	
	
	

}
