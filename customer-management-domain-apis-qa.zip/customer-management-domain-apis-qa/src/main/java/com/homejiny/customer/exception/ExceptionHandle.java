package com.homejiny.customer.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.homejiny.customer.authorization.AuthTokenMissingException;
import com.homejiny.customer.authorization.InvalidAuthTokenException;
import com.homejiny.customer.authorization.TokenExpiredException;
import com.homejiny.customer.common.Constants;
import com.homejiny.customer.response.ErrorResponse;

/**
 * @author brahmaiam
 *
 */
@RestController
@ControllerAdvice
public class ExceptionHandle extends ResponseEntityExceptionHandler {

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<ErrorResponse> handleAllExceptions(Exception ex, WebRequest request) {
		ex.printStackTrace();
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(InvalidAuthTokenException.class)
	public final ResponseEntity<ErrorResponse> handleInvalidAuthTokenException(InvalidAuthTokenException ex,
			WebRequest request) {
		ex.printStackTrace();
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(TokenExpiredException.class)
	public final ResponseEntity<ErrorResponse> handleTokenExpiredException(TokenExpiredException ex,
			WebRequest request) {
		ex.printStackTrace();
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(AuthTokenMissingException.class)
	public final ResponseEntity<ErrorResponse> handleAuthTokenMissingException(AuthTokenMissingException ex,
			WebRequest request) {
		ex.printStackTrace();
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.UNAUTHORIZED);
	}

	@ExceptionHandler(CustomerAddressNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleCustomerAddressNotFoundException(
			CustomerAddressNotFoundException ex, WebRequest request) {
		ex.printStackTrace();
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(CustomerNotFoundException.class)
	public final ResponseEntity<ErrorResponse> customerNotExist(CustomerNotFoundException ex, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InvalidSocietyException.class)
	public final ResponseEntity<ErrorResponse> societyNotExist(InvalidSocietyException ex, WebRequest request) {
		ex.printStackTrace();
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(MaxUploadSizeExceededException.class)
	public final ResponseEntity<ErrorResponse> maxUploadExceededSize(MaxUploadSizeExceededException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(FileFormatedException.class)
	public final ResponseEntity<ErrorResponse> fileFormated(FileFormatedException ex, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(KycNotFoundException.class)
	public final ResponseEntity<ErrorResponse> kycNotFound(KycNotFoundException ex, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(KycDocNumberFormateException.class)
	public final ResponseEntity<ErrorResponse> kycDocNumberFormate(KycDocNumberFormateException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(PattrenMissMatchedException.class)
	public final ResponseEntity<ErrorResponse> pattrenMissMatch(PattrenMissMatchedException ex, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(InvalideReferrerCodeException.class)
	public final ResponseEntity<ErrorResponse> invalideReferrerCode(InvalideReferrerCodeException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<ErrorResponse> recordNotFound(RecordNotFoundException ex, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(CityNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleCityNotFoundException(CityNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(StateNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleStateNotFoundException(StateNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(PINCodeNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handlePINCodeNotFoundException(PINCodeNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(AreaNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleAreaNotFoundException(AreaNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(SocietyNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleSocietyNotFoundException(SocietyNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(BlockNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleBlockNotFoundException(BlockNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(FloorNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleFloorNotFoundException(FloorNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(HouseNumberNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleHouseNumberNotFoundException(HouseNumberNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(InValidInputException.class)
	public final ResponseEntity<ErrorResponse> handleInValidInputException(InValidInputException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(MediaFileNotFoundException.class)
	public final ResponseEntity<ErrorResponse> handleMediaFileNotFoundException(MediaFileNotFoundException ex,
			WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(ex.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(WalletMicroserviceDownException.class)
	public final ResponseEntity<ErrorResponse> walletMicroserviceDownException(
			WalletMicroserviceDownException exception, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(exception.getLocalizedMessage(), request.getDescription(false));

		return new ResponseEntity<>(errorResponse, HttpStatus.SERVICE_UNAVAILABLE);
	}

	@ExceptionHandler(WalletAmountExceedsException.class)
	public final ResponseEntity<ErrorResponse> walletWalletAmountExceedsException(
			WalletAmountExceedsException exception, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(exception.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}
	
	@ExceptionHandler(NotElgibleToUseRefferalCode.class)
	public final ResponseEntity<ErrorResponse> handleNotElgibleToUseRefferalCode(
			NotElgibleToUseRefferalCode exception, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(exception.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}
	
	
	@ExceptionHandler(HjAvailabilityException.class)
	public final ResponseEntity<ErrorResponse> handleHjAvailabilityException(
			HjAvailabilityException exception, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(exception.getLocalizedMessage(), request.getDescription(false),Constants.FAIL_NOT_SUPPORT_AREA);
		return new ResponseEntity<>(errorResponse, HttpStatus.ACCEPTED);
	}
	
	@ExceptionHandler(ReferralCodeAllReadyUsedException.class)
	public final ResponseEntity<ErrorResponse> handleReferralCodeAllReadyUsedException(
			ReferralCodeAllReadyUsedException exception, WebRequest request) {
		ErrorResponse errorResponse = new ErrorResponse(exception.getLocalizedMessage(), request.getDescription(false));
		return new ResponseEntity<>(errorResponse, HttpStatus.NOT_FOUND);
	}
}
