package com.homejiny.customer.command;

import java.security.NoSuchAlgorithmException;

/**
 * @author brahmaiam
 *
 * @param <E>
 * @param <T>
 */
public interface Command<E, T> {
	public T excute(E request) throws NoSuchAlgorithmException;
}
