package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.request.ReferralCodeRequest;
import com.homejiny.customer.service.InviteFriendService;
import com.homejiny.customer.view.InviteFriendsResponse;

@Service
public class VerifyingReferrerCode {
	@Autowired
	InviteFriendService inviteFriendService;

	public ResponseEntity<InviteFriendsResponse> excute(ReferralCodeRequest referralCodeRequest) {
		InviteFriendsResponse response = new InviteFriendsResponse();
		if (referralCodeRequest == null) {
			response.setMessage(Constants.INVALID_INPUTS);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		return inviteFriendService.verificationOfReferrerCode(referralCodeRequest);
	}

}
