package com.homejiny.customer.view;

import java.util.List;

public class ViewCustomerKycResponse {

	private Long customerId;
	private String status;
	private List<KycDetails> data;

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<KycDetails> getData() {
		return data;
	}

	public void setData(List<KycDetails> data) {
		this.data = data;
	}

}
