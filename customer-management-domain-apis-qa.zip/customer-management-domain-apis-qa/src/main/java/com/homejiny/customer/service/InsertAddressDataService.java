package com.homejiny.customer.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.exception.InValidInputException;
import com.homejiny.customer.master.entity.Area;
import com.homejiny.customer.master.entity.Block;
import com.homejiny.customer.master.entity.City;
import com.homejiny.customer.master.entity.Floor;
import com.homejiny.customer.master.entity.HouseNumber;
import com.homejiny.customer.master.entity.Society;
import com.homejiny.customer.master.entity.State;
import com.homejiny.customer.master.repository.AreaRepository;
import com.homejiny.customer.master.repository.BlockRepository;
import com.homejiny.customer.master.repository.FloorRepository;
import com.homejiny.customer.master.repository.HouseNumberRepository;
import com.homejiny.customer.master.repository.MasterCityRepository;
import com.homejiny.customer.master.repository.MasterStateRepository;
import com.homejiny.customer.master.repository.SocietyRepository;
import com.homejiny.customer.request.UploadAddressRequest;
import com.homejiny.customer.util.ErrorRecord;

@Service
public class InsertAddressDataService {

	@Autowired
	MasterStateRepository stateRepository;

	@Autowired
	MasterCityRepository cityRepository;

	@Autowired
	AreaRepository areaRepository;

	@Autowired
	SocietyRepository societyRepository;

	@Autowired
	BlockRepository blockRepository;

	@Autowired
	FloorRepository floorRepository;

	@Autowired
	HouseNumberRepository houseNumberRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(InsertAddressDataService.class);

	public ErrorRecord insertData(UploadAddressRequest uploadAddressRequest) {
		try {
			checkRequest(uploadAddressRequest);
			LOGGER.info("Insert Data method started....!");
			LOGGER.info("Processing state details..");
			State state = insertState(uploadAddressRequest.getState(), uploadAddressRequest.getStateCode());
			LOGGER.info("Processing City details..");
			City city = insertCity(uploadAddressRequest.getCity(), state);
			LOGGER.info("Processing area details..");
			Area area = insertArea(uploadAddressRequest.getArea(), city);
			LOGGER.info("Processing society details..");
			Society society = insertSociety(uploadAddressRequest.getSoceity(), area);
			LOGGER.info("Processing block details..");
			Block block = insertBlock(uploadAddressRequest.getBolck(), society);
			LOGGER.info("Processing floor details..");
			Floor floor = insertFloor(uploadAddressRequest.getFloor(), block);
			LOGGER.info("Processing house number details..");
			insertHouseNumber(uploadAddressRequest, floor);
			LOGGER.info("Insert Data method endded....!");
		} catch (Exception e) {
			ErrorRecord errorRecord = new ErrorRecord();
			errorRecord.setMessage(e.getMessage());
			return errorRecord;
		}
		return null;
	}

	private State insertState(String stateName, String code) {
		LOGGER.info("started to insert state details..");
		State state = stateRepository.findByName(stateName);
		if (state == null) {
			State newState = new State();
			newState.setCreatedAt(DateAndTimeUtil.now());
			newState.setDisplayOrder(0);
			newState.setName(stateName);
			newState.setCode(code);
			newState.setStatus("active");
			newState.setUpdatedAt(DateAndTimeUtil.now());
			state = stateRepository.save(newState);
			LOGGER.info("Created state details with id :: " + state.getId());
		}
		LOGGER.info("State with id :: " + state.getId());
		return state;
	}

	private City insertCity(String cityName, State state) {
		LOGGER.info("started to insert City details..");
		City city = cityRepository.findByNameAndState(cityName, state);
		if (city == null) {
			City newCity = new City();
			newCity.setCreatedAt(DateAndTimeUtil.now());
			newCity.setDisplayOrder(0);
			newCity.setName(cityName);
			newCity.setStatus("active");
			newCity.setState(state);
			newCity.setUpdatedAt(DateAndTimeUtil.now());
			city = cityRepository.save(newCity);
			LOGGER.info("Created new city details with id :: " + city.getId());
		}
		LOGGER.info("City with id :: " + city.getId());
		return city;
	}

	private Area insertArea(String areaName, City city) {
		LOGGER.info("started to insert Area details..");
		Area area = areaRepository.findByAreaNameAndCity(areaName, city);
		if (area == null) {
			Area newArea = new Area();
			newArea.setCreatedAt(DateAndTimeUtil.now());
			newArea.setDisplayOrder(0);
			newArea.setAreaName(areaName);
			newArea.setStatus("active");
			newArea.setUpdatedAt(DateAndTimeUtil.now());
			newArea.setCity(city);
			area = areaRepository.save(newArea);
			LOGGER.info("Created new Area details with id :: " + area.getId());
		}
		LOGGER.info("Area with id :: " + area.getId());
		return area;
	}

	private Society insertSociety(String societyName, Area area) {
		LOGGER.info("started to insert Society details..");
		Society society = societyRepository.findBySocietyNameAndArea(societyName, area);
		if (society == null) {
			Society newSociety = new Society();
			newSociety.setCreatedAt(DateAndTimeUtil.now());
			newSociety.setDisplayOrder(0);
			newSociety.setSocietyName(societyName);
			newSociety.setStatus("active");
			newSociety.setUpdatedAt(DateAndTimeUtil.now());
			newSociety.setArea(area);
			society = societyRepository.save(newSociety);
			LOGGER.info("Created new Society details with id :: " + society.getId());
		}
		LOGGER.info("Society with id :: " + society.getId());
		return society;
	}

	private Block insertBlock(String blockName, Society society) {
		LOGGER.info("started to insert Block details..");
		Block block = blockRepository.findByBlockNameAndSociety(blockName, society);
		if (block == null) {
			Block newBlock = new Block();
			newBlock.setCreatedAt(DateAndTimeUtil.now());
			newBlock.setDisplayOrder(0);
			newBlock.setBlockName(blockName);
			newBlock.setStatus("active");
			newBlock.setUpdatedAt(DateAndTimeUtil.now());
			newBlock.setSociety(society);
			block = blockRepository.save(newBlock);
			LOGGER.info("Created new Block details with id :: " + block.getId());

		}
		LOGGER.info("Block with id :: " + block.getId());
		return block;
	}

	private Floor insertFloor(String floorName, Block block) {
		LOGGER.info("started to insert Floor details..");
		Floor floor = floorRepository.findByFloorNameAndBlock(floorName, block);
		if (floor == null) {
			Floor newFloor = new Floor();
			newFloor.setCreatedAt(DateAndTimeUtil.now());
			newFloor.setDisplayOrder(0);
			newFloor.setFloorName(floorName);
			newFloor.setStatus("active");
			newFloor.setUpdatedAt(DateAndTimeUtil.now());
			newFloor.setBlock(block);
			floor = floorRepository.save(newFloor);
			LOGGER.info("Created new Floor details with id :: " + floor.getId());
		}

		LOGGER.info("Floor with id :: " + floor.getId());
		return floor;
	}

	private HouseNumber insertHouseNumber(UploadAddressRequest uploadAddressRequest, Floor floor) {
		LOGGER.info("started to insert House Number details..");
		HouseNumber houseNumber = houseNumberRepository.findByHouseNumberAndFloor(uploadAddressRequest.getHouseNumber(),
				floor);
		int deliverySeq = 0;

		int pin = 0;

		try {
			deliverySeq = Integer.parseInt(uploadAddressRequest.getDeliverySeq());
		} catch (Exception e) {
			throw new InValidInputException("Delivery Sequence conversion failed :"
					+ uploadAddressRequest.getDeliverySeq() + ", please provide number for Delivery Sequence..!");
		}

		try {
			pin = Integer.parseInt(uploadAddressRequest.getPincode());
		} catch (Exception e) {
			throw new InValidInputException("pincode conversion failed :" + uploadAddressRequest.getPincode()
					+ ", please provide number for pincode..!");
		}

		if (houseNumber == null) {
			HouseNumber newHouseNumber = new HouseNumber();
			newHouseNumber.setAdditionalInfo(uploadAddressRequest.getAdditionalInfo());
			newHouseNumber.setCreatedAt(DateAndTimeUtil.now());
			newHouseNumber.setDeliverySeq(deliverySeq);
			newHouseNumber.setEntryGate(uploadAddressRequest.getEntryGate());
			newHouseNumber.setExitGate(uploadAddressRequest.getExitGate());
			newHouseNumber.setFloor(floor);
			newHouseNumber.setHouseNumber(uploadAddressRequest.getHouseNumber());
			newHouseNumber.setPincodeNumber(pin);
			newHouseNumber.setStatus("active");
			newHouseNumber.setUpdatedAt(DateAndTimeUtil.now());
			houseNumber = houseNumberRepository.save(newHouseNumber);
			LOGGER.info("Created new House Number details with id :: " + houseNumber.getId());
		} else {
			if (!houseNumber.getAdditionalInfo().equalsIgnoreCase(uploadAddressRequest.getAdditionalInfo())) {
				houseNumber.setAdditionalInfo(uploadAddressRequest.getAdditionalInfo());
			}
			if (houseNumber.getDeliverySeq() != deliverySeq) {
				houseNumber.setDeliverySeq(deliverySeq);
			}
			if (!uploadAddressRequest.getEntryGate().isEmpty()
					&& !houseNumber.getEntryGate().equalsIgnoreCase(uploadAddressRequest.getEntryGate())) {
				houseNumber.setEntryGate(uploadAddressRequest.getEntryGate());
			}
			if (!uploadAddressRequest.getExitGate().isEmpty()
					&& !houseNumber.getExitGate().equalsIgnoreCase(uploadAddressRequest.getExitGate())) {
				houseNumber.setExitGate(uploadAddressRequest.getExitGate());
			}
			if (houseNumber.getPincodeNumber() != pin) {
				houseNumber.setPincodeNumber(pin);
			}
			houseNumber.setUpdatedAt(DateAndTimeUtil.now());
			houseNumber = houseNumberRepository.save(houseNumber);
			LOGGER.info("Updated House Number details with id :: " + houseNumber.getId());
		}
		LOGGER.info("House Number with id :: " + houseNumber.getId());
		return houseNumber;
	}

	private void checkRequest(UploadAddressRequest uploadAddressRequest) {
		if (uploadAddressRequest.getAdditionalInfo() == null || uploadAddressRequest.getAdditionalInfo().isEmpty()) {
			throw new InValidInputException("Additional info is missing..!");
		} else if (uploadAddressRequest.getAdditionalInfo().contains("+")) {
			throw new InValidInputException("Additional info contains formula..!");
		}

		if (uploadAddressRequest.getArea() == null || uploadAddressRequest.getArea().isEmpty()) {
			throw new InValidInputException("Area is missing..!");
		} else if (uploadAddressRequest.getArea().contains("+")) {
			throw new InValidInputException("Area contains formula..!");
		}
		if (uploadAddressRequest.getBolck() == null || uploadAddressRequest.getBolck().isEmpty()) {
			throw new InValidInputException("Block info is missing..!");
		} else if (uploadAddressRequest.getBolck().contains("+")) {
			throw new InValidInputException("Block contains formula..!");
		}
		if (uploadAddressRequest.getCity() == null || uploadAddressRequest.getCity().isEmpty()) {
			throw new InValidInputException("City is missing..!");
		} else if (uploadAddressRequest.getCity().contains("+")) {
			throw new InValidInputException("City contains formula..!");
		}
		if (uploadAddressRequest.getDeliverySeq() == null || uploadAddressRequest.getDeliverySeq().isEmpty()) {
			throw new InValidInputException("Delivery Sequence is empty..!");
		} else if (uploadAddressRequest.getDeliverySeq().contains("+")) {
			throw new InValidInputException("Delivery Sequence contains formula..!");
		}
		if (uploadAddressRequest.getEntryGate() == null || uploadAddressRequest.getEntryGate().isEmpty()) {
			throw new InValidInputException("Entry gate info is missing..!");
		} else if (uploadAddressRequest.getEntryGate().contains("+")) {
			throw new InValidInputException("Entry gate contains formula..!");
		}
		if (uploadAddressRequest.getExitGate() == null || uploadAddressRequest.getExitGate().isEmpty()) {
			throw new InValidInputException("Exit gate info is missing..!");
		} else if (uploadAddressRequest.getExitGate().contains("+")) {
			throw new InValidInputException("Exit gate contains formula..!");
		}
		if (uploadAddressRequest.getFloor() == null || uploadAddressRequest.getFloor().isEmpty()) {
			throw new InValidInputException("Floor is missing..!");
		} else if (uploadAddressRequest.getFloor().contains("+")) {
			throw new InValidInputException("Floor contains formula..!");
		}
		if (uploadAddressRequest.getHouseNumber() == null || uploadAddressRequest.getHouseNumber().isEmpty()) {
			throw new InValidInputException("House Number is missing..!");
		} else if (uploadAddressRequest.getHouseNumber().contains("+")) {
			throw new InValidInputException("House Number contains formula..!");
		}
		if (uploadAddressRequest.getPincode() == null || uploadAddressRequest.getPincode().isEmpty()) {
			throw new InValidInputException("Pincode is missing..!");
		} else if (uploadAddressRequest.getPincode().contains("+")) {
			throw new InValidInputException("Pincode contains formula..!");
		}
		if (uploadAddressRequest.getSoceity() == null || uploadAddressRequest.getSoceity().isEmpty()) {
			throw new InValidInputException("Society is missing..!");
		} else if (uploadAddressRequest.getSoceity().contains("+")) {
			throw new InValidInputException("Society contains formula..!");
		}
		if (uploadAddressRequest.getState() == null || uploadAddressRequest.getState().isEmpty()) {
			throw new InValidInputException("State is missing ..!");
		} else if (uploadAddressRequest.getState().contains("+")) {
			throw new InValidInputException("State contains formula..!");
		}
		/*
		 * if(uploadAddressRequest.getStateCode()==null ||
		 * uploadAddressRequest.getStateCode().isEmpty()) { throw new
		 * InValidInputException("State code is missing ..!"); }
		 */
	}
}
