package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.service.FetchCustomerKycService;
import com.homejiny.customer.view.ViewCustomerKycResponse;

@Service
public class GetCustomerKycCommand implements Command<Long, ResponseEntity<ViewCustomerKycResponse>> {

	@Autowired
	FetchCustomerKycService fetchCustomerKycService;

	@Override
	public ResponseEntity<ViewCustomerKycResponse> excute(Long request) {

		if (request == null) {
			ResponseEntity.status(HttpStatus.BAD_REQUEST).body(fetchCustomerKycService.getCustomerKyc(request));
		}
		return ResponseEntity.status(HttpStatus.OK).body(fetchCustomerKycService.getCustomerKyc(request));
	}

}
