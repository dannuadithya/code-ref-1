package com.homejiny.customer.view;

public class CustomerKycAndDeliveryInfoResponse {
	
	private long customerId;
	private boolean hasKyc;
	private boolean hasDeliveryDetails;
	
	public long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}
	public boolean isHasKyc() {
		return hasKyc;
	}
	public void setHasKyc(boolean hasKyc) {
		this.hasKyc = hasKyc;
	}
	public boolean isHasDeliveryDetails() {
		return hasDeliveryDetails;
	}
	public void setHasDeliveryDetails(boolean hasDeliveryDetails) {
		this.hasDeliveryDetails = hasDeliveryDetails;
	}
	
	
}
