package com.homejiny.customer.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.Area;
import com.homejiny.customer.master.entity.City;
import com.homejiny.customer.master.entity.PINCode;

/**
 * @author brahmaiam
 *
 */
@Repository
public interface AreaRepository extends JpaRepository<Area, Long> {

	List<Area> findByCity(City city);

	Area findByAreaName(String areaName);

	List<Area> findAllByPinCode(PINCode pinCode);

	Area findByAreaNameAndCity(String areaName, City city);

	List<Area> findAllByPinCodeAndStatus(PINCode pinCode, String string);

	List<Area> findByCityAndStatus(City city, String status);

	List<Area> findAllByPinCodeAndStatusOrderByDisplayOrderAsc(PINCode pinCode, String status);

}
