package com.homejiny.customer.request;

public class RewardPointsRedemptionRequest {

	private long customerId;
	private long redemPoints;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getRedemPoints() {
		return redemPoints;
	}

	public void setRedemPoints(long redemPoints) {
		this.redemPoints = redemPoints;
	}

}
