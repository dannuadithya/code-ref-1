package com.homejiny.customer.request;

public class UpdateAppVersionRequest {

	private long customerId;
	private String platform;
	private String version;

	public long getCustomerId() {
		return customerId;
	}

	public String getPlatform() {
		return platform;
	}

	public String getVersion() {
		return version;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public void setVersion(String version) {
		this.version = version;
	}

}
