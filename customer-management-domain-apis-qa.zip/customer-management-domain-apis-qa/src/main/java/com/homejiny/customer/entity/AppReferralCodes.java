/**
 * 
 */
package com.homejiny.customer.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

/**
 * @author thumma
 *
 */
@Entity
@Table(name = "hj_app_referral_codes")
public class AppReferralCodes extends com.homejiny.customer.entity.Entity{

	@Column(name="referral_code")
	private String referralCode;

	public String getReferralCode() {
		return referralCode;
	}

	public void setReferralCode(String referralCode) {
		this.referralCode = referralCode;
	}
	
	
}
