package com.homejiny.customer.master.view;

public class ViewPinCodeData {
	private long id;
	private long pinCode;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public long getPinCode() {
		return pinCode;
	}
	public void setPinCode(long pinCode) {
		this.pinCode = pinCode;
	}
	
}
