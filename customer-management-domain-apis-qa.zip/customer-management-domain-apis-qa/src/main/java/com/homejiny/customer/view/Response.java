package com.homejiny.customer.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class Response {

	private long id;
	private Boolean hasEmail;
	private String status;
	private String message;
	private String dropLocationImagePath;
	private String qrCodeLocationImagePath;

	public Boolean getHasEmail() {
		return hasEmail;
	}

	public void setHasEmail(Boolean hasEmail) {
		this.hasEmail = hasEmail;
	}

	public String getDropLocationImagePath() {
		return dropLocationImagePath;
	}

	public void setDropLocationImagePath(String dropLocationImagePath) {
		this.dropLocationImagePath = dropLocationImagePath;
	}
	private Boolean hasDeliveryDetails;
	public String getQrCodeLocationImagePath() {
		return qrCodeLocationImagePath;
	}

	public void setQrCodeLocationImagePath(String qrCodeLocationImagePath) {
		this.qrCodeLocationImagePath = qrCodeLocationImagePath;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
}