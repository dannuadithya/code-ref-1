package com.homejiny.customer.master.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.master.service.MasterService;
import com.homejiny.customer.master.view.ResponseView;

/**
 * @author brahmaiam
 *
 */
@Service
public class FetchAllStatesListCommand implements Command<Void, ResponseEntity<ResponseView>> {
	@Autowired
	MasterService masterService;

	public ResponseEntity<ResponseView> excute(Void request) {
		return ResponseEntity.status(HttpStatus.OK).body(masterService.fetchAllStates());
	}
}
