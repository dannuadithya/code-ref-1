package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homejiny.customer.request.CustomerRequest;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.CustomerResponse;

/**
 * @author brahmaiam
 *
 */
@Service
public class CustomerAccountCommand implements Command<CustomerRequest, ResponseEntity<CustomerResponse>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<CustomerResponse> excute(CustomerRequest request) {
		CustomerResponse customerResponse;
		if (request == null
				|| (StringUtils.isEmpty(request.getFirstName()) || StringUtils.isEmpty(request.getLastName()))) {
			customerResponse = new CustomerResponse();
			customerResponse.setMessage("Invalid inputs");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(customerResponse);
		}
		customerResponse = customerService.createCustomerAccount(request);
		return ResponseEntity.status(HttpStatus.OK).body(customerResponse);
	}
}
