package com.homejiny.customer.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.homejiny.customer.adapter.PushNotificationAdapter;
import com.homejiny.customer.common.ConditionalConstants;
import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerRewardPointLog;
import com.homejiny.customer.entity.CustomerRewardType;
import com.homejiny.customer.entity.CustomerRewardTypeEnum;
import com.homejiny.customer.entity.PushNotifications;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.repository.CustomerRewardPointLogRepository;
import com.homejiny.customer.repository.CustomerRewardTypeRepository;
import com.homejiny.customer.repository.PushNotificationRepository;
import com.homejiny.customer.request.PushNotificationRequest;
import com.homejiny.customer.response.PushNotificationResponse;

@Service
public class CustomerLoyaltyPointsJobs {

	private static final Logger LOGGER = LoggerFactory.getLogger(CustomerLoyaltyPointsJobs.class);

	@Autowired
	CustomerRewardTypeRepository customerRewardTypeRepository;

	@Autowired
	CustomerRewardPointLogRepository customerRewardPointLogRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	PushNotificationRepository pushNotificationRepository;

	@Autowired
	PushNotificationAdapter pushNotificationAdapter;

	@Value("${referral.Info}")
	private String referral;

	@Value("${patronage.Info}")
	private String patronage;

	@Value("${sustainability.Info}")
	private String sustainability;

	@Value("${homejiny.signin.reward.points}")
	private Long referralPointsForReferrer;

	@Value("${referred.points}")
	private Long referralPoints;

	@Value("${referred.points.for.homejiny}")
	private Long referralPointsForHomejiny;

	@Value("${loyalty.Info}")
	private String loyalty;

	@Scheduled(cron = ConditionalConstants.REWARD_POINTS_MONTHLY_CRON)	
	public void updateLoyalityPoints() {
		LOGGER.info("Referrel points job started at :: " + DateAndTimeUtil.now());
		LocalDate localDate = DateAndTimeUtil.now().toLocalDate().minusMonths(1);
		LocalDate startDate = LocalDate.of(localDate.getYear(), localDate.getMonthValue(), 1);
		LocalDate endDate = LocalDate.of(localDate.getYear(), localDate.getMonthValue(), localDate.lengthOfMonth());
		LOGGER.info("Month ::  " + localDate.getMonth() + " And Days in a Month:: " + localDate.lengthOfMonth());
		LOGGER.info("Start Date:: " + startDate + " End Date :: " + endDate);		
		
		Long minimumOrderCount = customerRepository.getMinimunOrdersCount();
		LOGGER.info("Minimum order count to add points:: "+minimumOrderCount);
		Object[][] customerOrders = customerRepository.getCustomerOrders(startDate.toString(), endDate.toString(),
					startDate.toString(), endDate.toString(),minimumOrderCount);		

		for (Object[] customerInfo : customerOrders) {
			try {
				long customerId = 0;
				int ordersCount = 0;
				double orderAmountAvarage = 0;
				if (customerInfo[0] != null) {
					ordersCount = ((BigDecimal) customerInfo[0]).intValue();
				}
				if (customerInfo[1] != null && ordersCount>0) {
					double total = ((BigDecimal) customerInfo[1]).doubleValue();
					orderAmountAvarage = BigDecimal.valueOf(total / ordersCount).setScale(2, RoundingMode.FLOOR)
							.doubleValue();
				}
				if (customerInfo[2] != null) {
					customerId = (((BigInteger) customerInfo[2]).longValue());
				}
				if(ordersCount>=minimumOrderCount) {
					addRewardPointsForOrdersCount(customerId, ordersCount);
					addRewardPointsForAvarageOrderAmount(customerId, orderAmountAvarage, ordersCount);

					long totalDeliveredBags = customerRepository.getOrderBags(customerId, startDate.toString(),
							endDate.toString());
					long totalReturnedBags = customerRepository.getOrderBagsReturned(customerId, startDate.toString(),
							endDate.toString());
					LOGGER.info("Total delivered bags:: "+totalDeliveredBags+", Total bags returned:: "+totalReturnedBags);
					if (totalDeliveredBags > 0 && totalReturnedBags > 0) {
						double baggageReturn = BigDecimal.valueOf((totalReturnedBags * 100) / totalDeliveredBags)
								.setScale(2, RoundingMode.FLOOR).doubleValue();
						Long orderCount = customerRepository.getOrderCount(customerId, startDate.toString(),
								endDate.toString());
						if(orderCount>0 && orderCount>=minimumOrderCount) {
							addRewardPointsForBaggageReturn(customerId, baggageReturn, totalReturnedBags, orderCount);
							LOGGER.info("Total bags returned:: "+totalReturnedBags+", Avarage Order Bags Return:: "+baggageReturn);							
						}
						LOGGER.info("Minimum order count to add points "+minimumOrderCount+", customer orderCount for SUSTAINABILITY points:: "+orderCount);
					}
				}	
				LOGGER.info("Customer Id:: " + customerId + ", Orders Count::" + ordersCount
						+ ", Avarage Order Value:: " + orderAmountAvarage);

			} catch (Exception exception) {
				LOGGER.info("[ALERT] Exception occures while processing customer Id:: " + customerInfo[2] + " cause "
						+ exception.getMessage());
			}
		}
	}

	private void addRewardPointsForOrdersCount(long customerId, int ordersCount) {
		int points = 0;
		List<BigInteger> data = customerRepository.getRewardPoints(CustomerRewardTypeEnum.LOYALTY.toString(),
				ordersCount, ordersCount);
		if (!data.isEmpty()) {
			points = data.get(0).intValue();
		}
		Optional<Customer> customerOptional = customerRepository.findById(customerId);
		if (customerOptional.isPresent() && points > 0) {
			LOGGER.info("Adding points::" + points
					+ "  under :: " + CustomerRewardTypeEnum.LOYALTY+" for CustomerId:: " + customerId);
			setRewardPoints(customerOptional.get(), points, CustomerRewardTypeEnum.LOYALTY);
			sendPushNotigication(customerOptional.get(), Constants.CREDITED_LOYALTY_POINTS, points, ordersCount, 0, 0);
		}
	}

	private void addRewardPointsForAvarageOrderAmount(long customerId, double avarage, int ordersCount) {
		int points = 0;

		List<BigInteger> data = customerRepository.getRewardPoints(CustomerRewardTypeEnum.PATRONAGE.toString(), avarage,
				avarage);
		if (!data.isEmpty()) {
			points = data.get(0).intValue();
		}
		Optional<Customer> customerOptional = customerRepository.findById(customerId);
		if (customerOptional.isPresent() && points > 0) {
			LOGGER.info("Adding points::" + points
					+ "  under :: " +  CustomerRewardTypeEnum.PATRONAGE+" for CustomerId:: " + customerId);
			setRewardPoints(customerOptional.get(), points, CustomerRewardTypeEnum.PATRONAGE);
			sendPushNotigication(customerOptional.get(), Constants.CREDITED_PATRONAGE_POINTS, points, ordersCount,
					avarage, 0);
		}
	}

	private void addRewardPointsForBaggageReturn(long customerId, double baggageReturn, long bagCount,
			long ordersCount) {
		int points = 0;
		List<BigInteger> data = customerRepository.getRewardPoints(CustomerRewardTypeEnum.SUSTAINABILITY.toString(),
				baggageReturn, baggageReturn);
		if (!data.isEmpty()) {
			points = data.get(0).intValue();
		}
		else if(baggageReturn>100) {
			points=50;
		}
		Optional<Customer> customerOptional = customerRepository.findById(customerId);
		if (customerOptional.isPresent() && points > 0) {
			LOGGER.info("Adding points::" + points
					+ "  under :: " +  CustomerRewardTypeEnum.SUSTAINABILITY+" for CustomerId:: " + customerId);
			setRewardPoints(customerOptional.get(), points, CustomerRewardTypeEnum.SUSTAINABILITY);
			sendPushNotigication(customerOptional.get(), Constants.CREDITED_SUSTAINABILITY_POINTS, points, ordersCount,
					0, bagCount);
		}
	}

	private void setRewardPoints(Customer customer, long points, CustomerRewardTypeEnum type) {
		LOGGER.info(
				"Started to add " + points + " points under ::" + type + " to customer with id:: " + customer.getId());
		CustomerRewardPointLog customerRewardPointLog = new CustomerRewardPointLog();
		customerRewardPointLog.setCustomerId(customer);
		customerRewardPointLog.setOperationType(Constants.ADD);
		customerRewardPointLog.setRewardPoints(points);
		customerRewardPointLog.setRewardType(type.toString());
		customerRewardPointLog.setCreatedAt(DateAndTimeUtil.now());
		customerRewardPointLog.setUpdatedAt(DateAndTimeUtil.now());
		CustomerRewardPointLog customerRewardPointLogEntity = customerRewardPointLogRepository
				.save(customerRewardPointLog);
		LOGGER.info(Constants.CUSTOMER_REWARD_POINTS_CREATED_SUCCESSFULLY_WITH
				+ customerRewardPointLogEntity.getCustomerId());
		CustomerRewardType customerRewardType = customerRewardTypeRepository.findByCustomerIdAndRewardType(customer,
				type.toString());
		customerRewardType.setUpdatedAt(DateAndTimeUtil.now());
		customerRewardType.setRewardPoints(customerRewardType.getRewardPoints() + points);
		customerRewardType.setRewardType(customerRewardType.getRewardType());
		customerRewardTypeRepository.save(customerRewardType);
	}

	private void sendPushNotigication(Customer customer, String title, long points, long ordersCount,
			double orderAvarageAmount, long bagReturnCount) {
		try {
			LOGGER.info("Started to send push notification for customerId :: " + customer.getId() + " with title :: "
					+ title);
			if (customer.getDeviceToken() != null) {
				PushNotifications pushNotifications = pushNotificationRepository.findByTitleName(title);
				String message = "";
				if (pushNotifications.getMessage() != null) {
					message = pushNotifications.getMessage();
				}
				switch (title) {
				case Constants.CREDITED_SUSTAINABILITY_POINTS:
					message = message.replace("<Points>", String.valueOf(points));
					message = message.replace("<Baggage Count>", String.valueOf(bagReturnCount));
					message = message.replace("<Customer>", customer.getFirstName() + " " + customer.getLastName());
					break;
				case Constants.CREDITED_PATRONAGE_POINTS:
					message = message.replace("<Points>", String.valueOf(points));
					message = message.replace("<Order Count>", String.valueOf(ordersCount));
					message = message.replace("<Customer>", customer.getFirstName() + " " + customer.getLastName());
					break;
				case Constants.CREDITED_LOYALTY_POINTS:
					message = message.replace("<Points>", String.valueOf(points));
					message = message.replace("<Avarage Order Amount>", getPriceDecimal(orderAvarageAmount));
					message = message.replace("<Customer>", customer.getFirstName() + " " + customer.getLastName());
					break;
				default:
					message = "";
				}
				LOGGER.info("started to send pushNotification to customer_id:::" + customer.getId());
				PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();
				pushNotificationRequest.setMessage(message);
				pushNotificationRequest.setTitle(title);
				pushNotificationRequest.setToken(customer.getDeviceToken());
				pushNotificationRequest.setTopic("");
				pushNotificationRequest.setScreenflow("ReferrelPoints");
				PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
						.sendPushNotification(pushNotificationRequest);
				LOGGER.info("pushNotificationResponse inside Referrel points job : " + pushNotificationResponse);
				if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
					LOGGER.info("Failed to call push notification, Reason: " + Constants.REST_API_CALL_FAILED);
				}
			} else {
				LOGGER.info("Device Token not found for that customer " + customer.getId());
			}
		} catch (Exception exception) {
			LOGGER.info("Failed to send push notification for customerId :: " + customer.getId());
		}
	}

	private String getPriceDecimal(double value) {
		NumberFormat formatter = new DecimalFormat("#0.00");
		return formatter.format(value);
	}

	public void addSustainabilityPoints() {

		for (int i = 0; i < 3; i++) {
			LocalDate localDate = DateAndTimeUtil.now().toLocalDate().minusMonths(3);
			localDate = localDate.plusMonths(i);
			LocalDate startDate = LocalDate.of(localDate.getYear(), localDate.getMonthValue(), 1);

			LocalDate endDate = LocalDate.of(localDate.getYear(), localDate.getMonthValue(), localDate.lengthOfMonth());
			LOGGER.info("Month ::  " + endDate.getMonth());
			LOGGER.info("Start Date:: " + startDate + " End Date :: " + endDate);
			List<BigInteger> customerIds = customerRepository.getSustainabilityCustomerIds(startDate.toString(),
					endDate.toString());

			customerIds.forEach(customerId -> {

				Optional<Customer> customer = customerRepository.findById(customerId.longValue());
				if (customer.isPresent()) {
					// setRewardPoints(customer.get(), 50, CustomerRewardTypeEnum.SUSTAINABILITY);
					// sendSustainabilityPushNotigication(customer.get(), 50,
					// Constants.CREDITED_SUSTAINABILITY_POINTS,
					// Constants.CREDITED_SUSTAINABILITY_POINTS_MESSAGE
					// ,endDate.getMonth().toString());
				}
			});

		}

	}

	private void sendSustainabilityPushNotigication(Customer customer, int points, String title, String message,
			String month) {
		try {
			LOGGER.info("Started to send push notification for customerId :: " + customer.getId() + " with title :: "
					+ title);
			if (customer.getDeviceToken() != null) {
				LOGGER.info("started to send pushNotification to customer_id:::" + customer.getId());
				PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();
				message = message.replace("<Points>", String.valueOf(points));
				message = message.replace("<Customer>", customer.getFirstName() + " " + customer.getLastName());

				message = message.replace("<Month Name>", month);

				pushNotificationRequest.setMessage(message);
				pushNotificationRequest.setTitle(title);
				pushNotificationRequest.setToken(customer.getDeviceToken());
				pushNotificationRequest.setTopic("");
				pushNotificationRequest.setScreenflow("ReferrelPoints");
				PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
						.sendPushNotification(pushNotificationRequest);
				LOGGER.info("pushNotificationResponse inside Referrel points job : " + pushNotificationResponse);
				if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
					LOGGER.info("Failed to call push notification, Reason: " + Constants.REST_API_CALL_FAILED);
				}
			} else {
				LOGGER.info("Device Token not found for that customer " + customer.getId());
			}
		} catch (Exception exception) {
			LOGGER.info("Failed to send push notification for customerId :: " + customer.getId());
		}
	}

}
