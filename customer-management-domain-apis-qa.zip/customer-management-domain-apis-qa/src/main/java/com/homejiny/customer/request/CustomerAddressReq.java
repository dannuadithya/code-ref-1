package com.homejiny.customer.request;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class CustomerAddressReq {

	@JsonIgnore
	private long customerId;
	private String postalCode;
	private String state;
	private String city;
	private String area;
	private String society;
	private String block;
	private String floor;
	private String houseNo;
	private String otherArea;
	private long societyId;
	private boolean ringTheBell;

	public boolean isRingTheBell() {
		return ringTheBell;
	}

	public void setRingTheBell(boolean ringTheBell) {
		this.ringTheBell = ringTheBell;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getOtherArea() {
		return otherArea;
	}

	public void setOtherArea(String otherArea) {
		this.otherArea = otherArea;
	}

	public String getSociety() {
		return society;
	}

	public void setSociety(String society) {
		this.society = society;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getHouseNo() {
		return houseNo;
	}

	public void setHouseNo(String houseNo) {
		this.houseNo = houseNo;
	}

	public long getSocietyId() {
		return societyId;
	}

	public void setSocietyId(long societyId) {
		this.societyId = societyId;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

}
