package com.homejiny.customer.view;

import java.util.List;

public class CustomerRewardPoints {

	private double totalRewardPoints;
	private List<RewardPoints> rewardPointsList;
	private String referralInfo;
	private String patronageInfo;
	private String sustainabilityInfo;
	private String loyaltyInfo;

	public String getReferralInfo() {
		return referralInfo;
	}

	public void setReferralInfo(String referralInfo) {
		this.referralInfo = referralInfo;
	}

	public String getPatronageInfo() {
		return patronageInfo;
	}

	public void setPatronageInfo(String patronageInfo) {
		this.patronageInfo = patronageInfo;
	}

	public String getSustainabilityInfo() {
		return sustainabilityInfo;
	}

	public void setSustainabilityInfo(String sustainabilityInfo) {
		this.sustainabilityInfo = sustainabilityInfo;
	}

	public String getLoyaltyInfo() {
		return loyaltyInfo;
	}

	public void setLoyaltyInfo(String loyaltyInfo) {
		this.loyaltyInfo = loyaltyInfo;
	}

	private List<RewardTypeAndPoints> rewardTypeAndPoints;

	public double getTotalRewardPoints() {
		return totalRewardPoints;
	}

	public void setTotalRewardPoints(double totalRewardPoints2) {
		this.totalRewardPoints = totalRewardPoints2;
	}

	public List<RewardPoints> getRewardPointsList() {
		return rewardPointsList;
	}

	public void setRewardPointsList(List<RewardPoints> rewardPointsList) {
		this.rewardPointsList = rewardPointsList;
	}

	public List<RewardTypeAndPoints> getRewardTypeAndPoints() {
		return rewardTypeAndPoints;
	}

	public void setRewardTypeAndPoints(List<RewardTypeAndPoints> rewardTypeAndPoints) {
		this.rewardTypeAndPoints = rewardTypeAndPoints;
	}

}
