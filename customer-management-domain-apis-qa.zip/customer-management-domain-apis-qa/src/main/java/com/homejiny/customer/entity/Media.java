package com.homejiny.customer.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.springframework.lang.Nullable;

/**
 * @author brahmaiam
 *
 */
@Entity
@Table(name = "HJ_MEDIA")
public class Media extends com.homejiny.customer.entity.Entity {

	@Column(name = "original_file_name")
	private String originalFileName;

	@Nullable
	@Column(name = "size")
	private double size;

	@Column(name = "media_type")
	private String mediaType;

	@Column(name = "storage_type")
	private String storageType;

	@Column(name = "original_size_path")
	private String originalSizePath;

	@Column(name = "thumbnail_size_path")
	private String thumbnailSizePath;

	public String getOriginalFileName() {
		return originalFileName;
	}

	public void setOriginalFileName(String originalFileName) {
		this.originalFileName = originalFileName;
	}

	public double getSize() {
		return size;
	}

	public void setSize(double size) {
		this.size = size;
	}

	public String getMediaType() {
		return mediaType;
	}

	public void setMediaType(String mediaType) {
		this.mediaType = mediaType;
	}

	public String getStorageType() {
		return storageType;
	}

	public void setStorageType(String storageType) {
		this.storageType = storageType;
	}

	public String getOriginalSizePath() {
		return originalSizePath;
	}

	public void setOriginalSizePath(String originalSizePath) {
		this.originalSizePath = originalSizePath;
	}

	public String getThumbnailSizePath() {
		return thumbnailSizePath;
	}

	public void setThumbnailSizePath(String thumbnailSizePath) {
		this.thumbnailSizePath = thumbnailSizePath;
	}

}