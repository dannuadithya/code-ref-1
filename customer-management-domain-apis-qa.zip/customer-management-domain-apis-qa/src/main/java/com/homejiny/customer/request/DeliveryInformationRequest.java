package com.homejiny.customer.request;

import org.springframework.web.multipart.MultipartFile;

public class DeliveryInformationRequest {

	private String baggageDropLocation;
	private String qrCodeLocation;
	private long customerId;
	private MultipartFile dropLocationImagePath;
	private MultipartFile qrCodeLocationImagePath;
	public String getBaggageDropLocation() {
		return baggageDropLocation;
	}

	public void setBaggageDropLocation(String baggageDropLocation) {
		this.baggageDropLocation = baggageDropLocation;
	}

	public String getQrCodeLocation() {
		return qrCodeLocation;
	}

	public void setQrCodeLocation(String qrCodeLocation) {
		this.qrCodeLocation = qrCodeLocation;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public MultipartFile getDropLocationImagePath() {
		return dropLocationImagePath;
	}

	public void setDropLocationImagePath(MultipartFile dropLocationImagePath) {
		this.dropLocationImagePath = dropLocationImagePath;
	}

	public MultipartFile getQrCodeLocationImagePath() {
		return qrCodeLocationImagePath;
	}

	public void setQrCodeLocationImagePath(MultipartFile qrCodeLocationImagePath) {
		this.qrCodeLocationImagePath = qrCodeLocationImagePath;
	}

}
