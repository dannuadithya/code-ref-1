package com.homejiny.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.homejiny.customer.entity.TermsAndConditions;
import com.homejiny.customer.entity.TermsAndConditionsEnum;

public interface TermsAndConditionsRepository extends JpaRepository<TermsAndConditions, Long>  {

	TermsAndConditions findTopByOrderByIdDesc();

	TermsAndConditions findByConditionTo(TermsAndConditionsEnum request);

}
