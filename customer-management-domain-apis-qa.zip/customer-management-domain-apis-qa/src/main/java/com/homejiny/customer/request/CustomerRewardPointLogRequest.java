package com.homejiny.customer.request;

import javax.validation.constraints.NotEmpty;

import com.homejiny.customer.common.Constants;



public class CustomerRewardPointLogRequest {
	
	@NotEmpty(message = Constants.CUSTOMER_ID_SHOULD_NOT_BE_EMPTY)
	private long customerId;
	
	@NotEmpty(message = Constants.REWARD_POINTS_SHOULD_NOT_BE_EMPTY)
	private long rewardPoints;
	
	@NotEmpty(message = Constants.OPERATION_TYPE_SHOULD_NOT_BE_EMPTY)
	private String operationType;
	
	@NotEmpty(message = Constants.REWARD_TYPE_SHOULD_NOT_BE_EMPTY)
	private String rewardType;
	
	private String referralCode;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getRewardPoints() {
		return rewardPoints;
	}

	public void setRewardPoints(long rewardPoints) {
		this.rewardPoints = rewardPoints;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getRewardType() {
		return rewardType;
	}

	public void setRewardType(String rewardType) {
		this.rewardType = rewardType;
	}

	public String getReferralCode() {
		return referralCode;
	}

	public void setReferralCode(String referralCode) {
		this.referralCode = referralCode;
	}

}
