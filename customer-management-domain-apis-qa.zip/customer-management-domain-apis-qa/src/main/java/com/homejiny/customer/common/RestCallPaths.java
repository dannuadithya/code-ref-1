package com.homejiny.customer.common;

public class RestCallPaths {
	
	public static final String CREDIT_WALLET = "creditWallet";

}
