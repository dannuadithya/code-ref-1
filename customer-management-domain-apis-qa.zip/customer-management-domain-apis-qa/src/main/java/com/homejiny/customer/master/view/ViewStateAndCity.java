package com.homejiny.customer.master.view;

/**
 * @author brahmaiam
 *
 */
public class ViewStateAndCity {

	private ViewState state;
	private ViewCity city;

	public ViewState getState() {
		return state;
	}

	public void setState(ViewState viewState) {
		this.state = viewState;
	}

	public ViewCity getCity() {
		return city;
	}

	public void setCity(ViewCity viewCity) {
		this.city = viewCity;
	}

}
