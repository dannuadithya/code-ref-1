package com.homejiny.customer.common;

public enum KycImageView {

	FRONTVIEW, BACKVIEW;

}
