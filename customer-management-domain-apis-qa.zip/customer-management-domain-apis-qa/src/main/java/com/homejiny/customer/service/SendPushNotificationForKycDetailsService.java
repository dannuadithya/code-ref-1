package com.homejiny.customer.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.adapter.PushNotificationAdapter;
import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.PushNotifications;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.repository.PushNotificationRepository;
import com.homejiny.customer.request.PushNotificationRequest;
import com.homejiny.customer.response.PushNotificationResponse;

@Service
class SendPushNotificationForKycDetailsService {
	private static final Logger logger = LoggerFactory.getLogger(SendPushNotificationForKycDetailsService.class);

	@Autowired
	PushNotificationRepository pushNotificationRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	PushNotificationAdapter pushNotificationAdapter;

	public PushNotifications sendPushNotificationForKycDetails(Long customerId) {

		PushNotifications pushNotifications = pushNotificationRepository.findByTitleName("KYC Details Successful");

		Optional<Customer> customer = customerRepository.findById(customerId);

		if (!customer.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}
		logger.info("pushNotifications entity data : " + pushNotifications);
		PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();
		pushNotificationRequest.setMessage(pushNotifications.getMessage());
		pushNotificationRequest.setTitle(pushNotifications.getTitleName());
		pushNotificationRequest.setToken(customer.get().getDeviceToken());
		pushNotificationRequest.setTopic("");
		pushNotificationRequest.setScreenflow("UploadKYCDocuments");
		PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
				.sendPushNotification(pushNotificationRequest);
		logger.info("pushNotificationResponse inside createKycDetails(): " + pushNotificationResponse);
		if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
			logger.info("Failed to call push notification,Reason: " + Constants.REST_API_CALL_FAILED);
		} else {
			logger.info("Device Token not found for that customer :" + customer.get().getId());
		}
		return null;

	}

}
