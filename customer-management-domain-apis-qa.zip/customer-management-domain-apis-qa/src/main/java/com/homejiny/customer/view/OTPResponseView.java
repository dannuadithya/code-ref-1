package com.homejiny.customer.view;

public class OTPResponseView {

	private String status;
	private String message;
	private long customerId;
	private String registrationStep;
	private boolean isNewCustomer;
	private Boolean hasAddress;
	private String accessToken;

	public Boolean getHasAddress() {
		return hasAddress;
	}

	public void setHasAddress(Boolean hasAddress) {
		this.hasAddress = hasAddress;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getRegistrationStep() {
		return registrationStep;
	}

	public void setRegistrationStep(String registrationStep) {
		this.registrationStep = registrationStep;
	}

	public boolean isNewCustomer() {
		return isNewCustomer;
	}

	public void setNewCustomer(boolean isNewCustomer) {
		this.isNewCustomer = isNewCustomer;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

}
