package com.homejiny.customer.command;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.service.KycVerifiedService;
import com.homejiny.customer.view.KycVerifiedResponse;

@Service
public class KycVerifiedCommand implements Command<Long, ResponseEntity<KycVerifiedResponse>> {
	private Logger logger = LogManager.getLogger(KycVerifiedCommand.class);
	@Autowired
	KycVerifiedService kycVerifiedService;
	
	@Override
	public ResponseEntity<KycVerifiedResponse> excute(Long customerId){
		logger.info("markKycAsVerified() method execution started");
		if (customerId == null) {
			KycVerifiedResponse kycVerifiedResponse = new KycVerifiedResponse();
			kycVerifiedResponse.setMessage(Constants.INVALID_INPUTS);
			kycVerifiedResponse.setStatus(Constants.SUCCESS);

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(kycVerifiedResponse);

		}
		return ResponseEntity.status(HttpStatus.OK)
				.body(kycVerifiedService.markKycVerified(customerId));
	}

}
