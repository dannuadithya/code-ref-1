package com.homejiny.customer.request;

import org.springframework.web.multipart.MultipartFile;

public class ProfilePictureRequest {

	private long customerId;
	private MultipartFile profilePicture;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public MultipartFile getProfilePicture() {
		return profilePicture;
	}

	public void setProfilePicture(MultipartFile profilePicture) {
		this.profilePicture = profilePicture;
	}


}
