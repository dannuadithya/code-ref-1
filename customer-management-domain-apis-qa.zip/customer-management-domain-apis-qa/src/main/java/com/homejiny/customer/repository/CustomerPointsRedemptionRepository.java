package com.homejiny.customer.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.homejiny.customer.entity.CustomerRewardPointsRedemption;

public interface CustomerPointsRedemptionRepository extends JpaRepository<CustomerRewardPointsRedemption, Long>{

	Optional<CustomerRewardPointsRedemption> findBycustomerId(long customerId);

	long countByCustomerId(long customerId);

	List<CustomerRewardPointsRedemption> findByStatus(String completedPaymentPending);

}
