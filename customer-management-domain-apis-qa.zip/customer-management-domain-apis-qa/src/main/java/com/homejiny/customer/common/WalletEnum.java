package com.homejiny.customer.common;

public enum WalletEnum {
	
	BANK_DEPOSIT, PRODUCTS, SERVICES, HJ_REWARD_POINTS

}
