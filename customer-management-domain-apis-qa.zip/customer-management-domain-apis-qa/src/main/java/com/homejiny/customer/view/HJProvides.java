package com.homejiny.customer.view;

import com.homejiny.customer.common.HJProvide;

public class HJProvides {

	private HJProvide provides;
	private boolean status;
	private String message;
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public HJProvide getProvides() {
		return provides;
	}
	public void setProvides(HJProvide provides) {
		this.provides = provides;
	}
	
	
}
