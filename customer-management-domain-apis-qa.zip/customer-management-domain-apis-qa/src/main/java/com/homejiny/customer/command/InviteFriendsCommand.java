package com.homejiny.customer.command;

import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.service.InviteFriendService;
import com.homejiny.customer.view.InviteFriendsResponse;

@Service
public class InviteFriendsCommand implements Command<Long, ResponseEntity<InviteFriendsResponse>> {

	@Autowired
	InviteFriendService inviteFriendService;

	public ResponseEntity<InviteFriendsResponse> excute(Long customerId) throws NoSuchAlgorithmException {

		if (customerId == null) {
			InviteFriendsResponse inviteFriendsResponse = new InviteFriendsResponse();
			inviteFriendsResponse.setMessage(Constants.INVALID_INPUTS);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(inviteFriendsResponse);
		}

		return inviteFriendService.inviteFriends(customerId);
	}

}
