package com.homejiny.customer.request;

public class RefferalPointsRequest {

	private String refferalType;
	private int pointsValue;
	private long id;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getRefferalType() {
		return refferalType;
	}

	public void setRefferalType(String refferalType) {
		this.refferalType = refferalType;
	}

	public int getPointsValue() {
		return pointsValue;
	}

	public void setPointsValue(int pointsValue) {
		this.pointsValue = pointsValue;
	}

}
