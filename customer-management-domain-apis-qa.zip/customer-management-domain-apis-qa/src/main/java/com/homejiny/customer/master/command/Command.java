package com.homejiny.customer.master.command;

import java.security.NoSuchAlgorithmException;

/**
 * @author brahmaiam
 *
 * @param <E>
 * @param <T>
 */
public interface Command<E, T> {
	public T excute(E request) throws NoSuchAlgorithmException;
}
