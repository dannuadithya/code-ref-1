package com.homejiny.customer.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.view.LogoutResponse;

/**
 * @author brahmaiam
 *
 */
@Service
public class LogoutService {

	public LogoutResponse logoutApplication(HttpServletRequest request) {
		LogoutResponse logoutResponse = new LogoutResponse();
		HttpSession session = request.getSession();
		if (session != null) {
			session.invalidate();
			logoutResponse.setStatus(Constants.SUCCESS);
			logoutResponse.setMessage("Logout Done Successfully");
		} else {
			logoutResponse.setStatus(Constants.SUCCESS);
			logoutResponse.setMessage("Session is Allready Inactive");
		}
		return logoutResponse;
	}
}
