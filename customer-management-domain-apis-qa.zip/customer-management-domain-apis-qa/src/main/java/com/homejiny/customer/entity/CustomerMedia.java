package com.homejiny.customer.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.homejiny.customer.common.MediaStorageType;

@Entity(name = "hj_media")
@Table(name = "HJ_MEDIA")
public class CustomerMedia extends BaseEntity {

	@Column(name = "original_name")
	private String originalName;

	@Column(name = "media_file_size")
	private double mediaFileSize;

	@Column(name = "thumbnail_size_path")
	private String thumbnailPath;

	@Column(name = "storage_type")
	private MediaStorageType stroageType;

	@Column(name = "original_size_path")
	private String originalPath;

	@Column(name = "format")
	private String format;

	public String getOriginalName() {
		return originalName;
	}

	public void setOriginalName(String originalName) {
		this.originalName = originalName;
	}

	public double getMediaFileSize() {
		return mediaFileSize;
	}

	public void setMediaFileSize(double mediaFileSize) {
		this.mediaFileSize = mediaFileSize;
	}

	public String getThumbnailPath() {
		return thumbnailPath;
	}

	public void setThumbnailPath(String thumbnailPath) {
		this.thumbnailPath = thumbnailPath;
	}

	public MediaStorageType getStroageType() {
		return stroageType;
	}

	public void setStroageType(MediaStorageType stroageType) {
		this.stroageType = stroageType;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getOriginalPath() {
		return originalPath;
	}

	public void setOriginalPath(String originalPath) {
		this.originalPath = originalPath;
	}

}
