package com.homejiny.customer.request;

public class WalletRequest {
	private String walletMobileNumber;

	public String getWalletMobileNumber() {
		return walletMobileNumber;
	}

	public void setWalletMobileNumber(String walletMobileNumber) {
		this.walletMobileNumber = walletMobileNumber;
	}
	
	
}
