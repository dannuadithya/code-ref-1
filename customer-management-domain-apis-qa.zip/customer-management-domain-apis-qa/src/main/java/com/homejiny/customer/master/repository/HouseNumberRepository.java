package com.homejiny.customer.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.Floor;
import com.homejiny.customer.master.entity.HouseNumber;
@Repository
public interface HouseNumberRepository extends JpaRepository<HouseNumber, Long> {

	List<HouseNumber> findByFloor(Floor floor);

	List<HouseNumber> findByFloorOrderByHouseNumberAsc(Floor floor);

	List<HouseNumber> findByFloorAndStatusOrderByHouseNumberAsc(Floor floor, String status);


	HouseNumber findByHouseNumberAndFloor(String houseNumber, Floor floor);

}
