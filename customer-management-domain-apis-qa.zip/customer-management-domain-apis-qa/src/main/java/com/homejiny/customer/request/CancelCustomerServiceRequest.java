package com.homejiny.customer.request;

/**
 * @author - Chaitanya Mannem
 */
public class CancelCustomerServiceRequest {

    private Long customerId;
    private Long serviceRequestId;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Long getServiceRequestId() {
        return serviceRequestId;
    }

    public void setServiceRequestId(Long serviceRequestId) {
        this.serviceRequestId = serviceRequestId;
    }
}
