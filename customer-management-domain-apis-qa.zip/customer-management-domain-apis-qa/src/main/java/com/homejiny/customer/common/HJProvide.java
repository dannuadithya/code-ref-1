package com.homejiny.customer.common;

public enum HJProvide {
	PRODUCTS,SERVICES
}
