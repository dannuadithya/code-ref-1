package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.exception.InValidInputException;
import com.homejiny.customer.request.CustomerAddressReq;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.AddressResponse;

/**
 * @author brahmaiam
 *
 */
@Service
public class CreateCustomerAddressCommand implements Command<CustomerAddressReq, ResponseEntity<AddressResponse>> {
	@Autowired
	CustomerService customerService;
	public ResponseEntity<AddressResponse> excute(CustomerAddressReq request) {
		if (request == null || request.getCustomerId() <= 0) {
			throw new InValidInputException("Invalid inputs");
		}
		AddressResponse addressResponse = customerService.createOrUpdateCustomerAddress(request);
		if (addressResponse.getStatus().equalsIgnoreCase("Accepted")) {
			return ResponseEntity.status(HttpStatus.ACCEPTED).body(addressResponse);
		}
		return ResponseEntity.status(HttpStatus.CREATED).body(addressResponse);
	}
}
