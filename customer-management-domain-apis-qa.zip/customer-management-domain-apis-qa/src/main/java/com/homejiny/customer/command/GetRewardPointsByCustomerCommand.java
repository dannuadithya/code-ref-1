package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.GetRewardPointsByCustomerRequest;
import com.homejiny.customer.service.CustomerLoyaltyPoints;
import com.homejiny.customer.view.CustomerRewardPoints;

@Service
public class GetRewardPointsByCustomerCommand implements Command<GetRewardPointsByCustomerRequest, ResponseEntity<CustomerRewardPoints>> {

	@Autowired
	CustomerLoyaltyPoints customerLoyaltyPoints;

	public ResponseEntity<CustomerRewardPoints> excute(GetRewardPointsByCustomerRequest getRewardPointsByCustomerRequest) {
		return ResponseEntity.status(HttpStatus.OK).body(customerLoyaltyPoints.getRewardPointsByCustomer(getRewardPointsByCustomerRequest));
	}

}
