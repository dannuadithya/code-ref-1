package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.PointsRedemptionRequest;
import com.homejiny.customer.response.UpdateRewardPointsRedemptionResponse;
import com.homejiny.customer.service.CustomerLoyaltyPoints;

@Service
public class CustomerPointsRedemptionCommand implements Command<PointsRedemptionRequest, UpdateRewardPointsRedemptionResponse> {

	@Autowired
	CustomerLoyaltyPoints customerLoyaltyPoints;

	@Override
	public UpdateRewardPointsRedemptionResponse excute(PointsRedemptionRequest request) {
		return customerLoyaltyPoints.customerPointsRedemption(request);
	}

}
