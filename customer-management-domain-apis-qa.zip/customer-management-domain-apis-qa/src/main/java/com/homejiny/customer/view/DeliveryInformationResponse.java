package com.homejiny.customer.view;

public class DeliveryInformationResponse {

	private String status;
	private long id;
	private String message;
	private String bagDropLocation;
	private String dropLocationImagePath;
	private String qrCodeLocation;
	private String qrCodeLocationImagePath;
	private boolean ringTheBell;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getBagDropLocation() {
		return bagDropLocation;
	}
	public void setBagDropLocation(String bagDropLocation) {
		this.bagDropLocation = bagDropLocation;
	}
	public String getDropLocationImagePath() {
		return dropLocationImagePath;
	}
	public void setDropLocationImagePath(String dropLocationImagePath) {
		this.dropLocationImagePath = dropLocationImagePath;
	}
	public String getQrCodeLocation() {
		return qrCodeLocation;
	}
	public void setQrCodeLocation(String qrCodeLocation) {
		this.qrCodeLocation = qrCodeLocation;
	}
	public String getQrCodeLocationImagePath() {
		return qrCodeLocationImagePath;
	}
	public void setQrCodeLocationImagePath(String qrCodeLocationImagePath) {
		this.qrCodeLocationImagePath = qrCodeLocationImagePath;
	}
	public boolean isRingTheBell() {
		return ringTheBell;
	}
	public void setRingTheBell(boolean ringTheBell) {
		this.ringTheBell = ringTheBell;
	}
	
	
}
