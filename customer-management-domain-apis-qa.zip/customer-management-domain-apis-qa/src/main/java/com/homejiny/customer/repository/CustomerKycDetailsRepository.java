package com.homejiny.customer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerKycDetails;
import com.homejiny.customer.entity.KycType;

/**
 * @author brahmaiam
 *
 */
@Repository
public interface CustomerKycDetailsRepository extends JpaRepository<CustomerKycDetails, Long> {

	List<CustomerKycDetails> findByCustomer(Customer customer);

	List<CustomerKycDetails> findByMedia(String mediaFile);

	List<CustomerKycDetails> findByCustomerOrderByCreatedAtAsc(Customer customer);

}
