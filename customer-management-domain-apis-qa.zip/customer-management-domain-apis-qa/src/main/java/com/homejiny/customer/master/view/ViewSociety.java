package com.homejiny.customer.master.view;

public class ViewSociety {
	
	private long id;
	private String name;
	private long hjAvailability;
	private long displayOrder;
	private String status;
	
	
	public long getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public long getHjAvailability() {
		return hjAvailability;
	}
	public long getDisplayOrder() {
		return displayOrder;
	}
	public void setId(long id) {
		this.id = id;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setHjAvailability(long hjAvailability) {
		this.hjAvailability = hjAvailability;
	}
	public void setDisplayOrder(long displayOrder) {
		this.displayOrder = displayOrder;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}

}
