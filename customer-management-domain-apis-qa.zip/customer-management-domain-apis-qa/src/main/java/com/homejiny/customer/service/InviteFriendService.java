package com.homejiny.customer.service;

import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.exception.InvalideReferrerCodeException;
import com.homejiny.customer.exception.NotElgibleToUseRefferalCode;
import com.homejiny.customer.repository.AppReferralCodesRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.request.ReferralCodeRequest;
import com.homejiny.customer.view.InviteFriendsResponse;

@Service
public class InviteFriendService {
	private static final Logger LOGGER = LoggerFactory.getLogger(InviteFriendService.class);

	@Value("${invite.directory.href}")
	private String inviteDirectoryHref;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	AppReferralCodesRepository appReferralCodesRepository;
	
	@Value("${referred.points}")
	private Long referralPoints;

	public ResponseEntity<InviteFriendsResponse> inviteFriends(Long customerId) throws NoSuchAlgorithmException {

		LOGGER.info("Generating a code for Refferal");
		InviteFriendsResponse inviteFriendsResponse = new InviteFriendsResponse();
		String message = null;
		Optional<Customer> customerEntity = customerRepository.findById(customerId);
		if (customerEntity.isPresent()) {
			Customer customer = customerEntity.get();
			String referralcode = customer.getReferrerCode();
			if (referralcode != null) {
				message = inviteDirectoryHref.replace("<code>", referralcode);
				message = message.replace("<Points>", ""+referralPoints);
				inviteFriendsResponse.setId(customer.getId());
				inviteFriendsResponse.setMessage(Constants.GENERATED_CODE);
				inviteFriendsResponse.setGenerateCode(referralcode);
				inviteFriendsResponse.setLink(inviteDirectoryHref);
				inviteFriendsResponse.setLink(message);
				return ResponseEntity.status(HttpStatus.OK).body(inviteFriendsResponse);
			}
			String singleCode = generatedCode();
			customer.setReferrerCode(singleCode);
			message = inviteDirectoryHref.replace("<code>", customer.getReferrerCode());
			message = message.replace("<Points>", ""+referralPoints);
			customerRepository.save(customer);
			inviteFriendsResponse.setId(customer.getId());
			inviteFriendsResponse.setMessage(Constants.GENERATED_CODE);
			inviteFriendsResponse.setGenerateCode(singleCode);
			inviteFriendsResponse.setLink(message);
			inviteFriendsResponse.setStatus(Constants.SUCCESS);
			return ResponseEntity.status(HttpStatus.OK).body(inviteFriendsResponse);

		} else {

			inviteFriendsResponse.setMessage(Constants.CUSTOMER_NOT_EXIST);
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(inviteFriendsResponse);
		}
	}

	public String generatedCode() throws NoSuchAlgorithmException {
		LOGGER.info("Entering in generate Code method");

		String refCode = "";
		Object[][] customerEntity = customerRepository.findByMaxRefferCode();

		if (customerEntity.length == 0) {
			refCode = "HJ05001";
		} else {
			for (Object[] obj : customerEntity) {
				String incrementNo = "";
				int finalNo = Integer.parseInt(((String) obj[0]).substring(3));
				finalNo++;

				if (finalNo < 9999) {
					incrementNo = "0" + finalNo;
					LOGGER.info(incrementNo);
					refCode = incrementNo;
				} else if (finalNo < 99999) {
					incrementNo = "" + finalNo;
					System.out.println(incrementNo);
					refCode = incrementNo;

				}

			}
		}
		return Constants.HJ + refCode;

	}

	/**
	 * verification Of Referrar Code
	 * 
	 * @param referrerCode
	 * @return
	 */
	public ResponseEntity<InviteFriendsResponse> verificationOfReferrerCode(ReferralCodeRequest referralCodeRequest) {
		LOGGER.info("Entering in Verification Of Referrer Code method");

		Optional<Customer> getreferralCode = customerRepository
				.findByReferrerCode(referralCodeRequest.getReferralCode());
		Object[][] appReferralCodes = appReferralCodesRepository.referralCodeValidationChecking(
				referralCodeRequest.getReferralCode(), DateAndTimeUtil.now(), DateAndTimeUtil.now());

		InviteFriendsResponse response = new InviteFriendsResponse();

		if (getreferralCode.isPresent() || appReferralCodes.length != 0) {
			if (appReferralCodes.length != 0) {
				if (appReferralCodes.length != 0) {
					for (Object[] appRef : appReferralCodes) {
						response.setId(((BigInteger) appRef[0]).longValue());
					}
				}
			} else {
				if (!getreferralCode.isPresent()) {
					throw new InvalideReferrerCodeException(Constants.INVALIDE_REFERRAL_CODE);
				}	else {
					response.setId(getreferralCode.get().getId());
				}
			}
			response.setReferrerCode(Constants.VALIDE_REFERRAL_CODE);

			// response.setMessage(Constants.VALIDE_REFERRAL_CODE);
			// response.setStatus(Constants.SUCCESS);

		} else {
			throw new InvalideReferrerCodeException(Constants.INVALIDE_REFERRAL_CODE);

		}
		Customer customer = customerRepository.findByMobileNumber(referralCodeRequest.getMobileNumber());
		if (customer != null) {
			if (customer.getReferrerCode() != null
					&& referralCodeRequest.getReferralCode().equalsIgnoreCase(customer.getReferrerCode())) {
				throw new NotElgibleToUseRefferalCode(Constants.OWN_REFERRAL_CODE);
			} else if (referralCodeRequest.getReferralCode() != null && !referralCodeRequest.getReferralCode().isEmpty()
					&& (customer.getReferrerbyId() == -1 || customer.getReferrerbyId() > 0)) {
				throw new NotElgibleToUseRefferalCode(Constants.ALLREADY_USED_REFERRAL_CODE);
			} else if (referralCodeRequest.getReferralCode() != null && !referralCodeRequest.getReferralCode().isEmpty()
					&& customer.getReferrerbyId() == 0) {
				throw new NotElgibleToUseRefferalCode(Constants.APP_REFERRAL_NOT_ELGIBLE);
			}
		}
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
}
