package com.homejiny.customer.request;

import java.sql.Date;

public class PointsRedemptionRequest {

	private long customerId;
	private long points;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getPoints() {
		return points;
	}

	public void setPoints(long points) {
		this.points = points;
	}

}
