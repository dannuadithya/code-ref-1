package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homejiny.customer.request.EmailAddressRequest;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.Response;

/**
 * @author brahmaiam
 *
 */
@Service
public class CreateEmailAddressCommand implements Command<EmailAddressRequest, ResponseEntity<Response>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<Response> excute(EmailAddressRequest request) {

		if (request == null || request.getCustomerId() <= 0 || StringUtils.isEmpty(request.getEmailId())) {
			Response response = new Response();
			response.setMessage("Invalid Inputs");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		return ResponseEntity.status(HttpStatus.OK).body(customerService.createEmailAddress(request));
	}
}
