package com.homejiny.customer.authorization;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class InvalidAuthTokenException extends RuntimeException {

	public InvalidAuthTokenException(String errMsg) {
		super(errMsg);
	}
	
	public InvalidAuthTokenException(String message, Throwable cause) {
        super(message, cause);
    }
}
