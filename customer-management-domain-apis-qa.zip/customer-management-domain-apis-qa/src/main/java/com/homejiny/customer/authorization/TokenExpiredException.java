package com.homejiny.customer.authorization;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.UNAUTHORIZED)
public class TokenExpiredException extends RuntimeException{
	public TokenExpiredException(String errMsg) {
		super(errMsg);
	}
	
	public TokenExpiredException(String message, Throwable cause) {
        super(message, cause);
    }

}
