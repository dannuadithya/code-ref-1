package com.homejiny.customer.request;

import com.homejiny.customer.util.ErrorRecord;

public class UploadAddressRequest {

	private String state;
	private String city;
	private String area;
	private String soceity;
	private String bolck;
	private String floor;
	private String houseNumber;
	private String pincode;
	private String additionalInfo;
	private String entryGate;
	private String exitGate;
	private String deliverySeq;
	private ErrorRecord errorRecord;
	private String stateCode;
	public String getState() {
		return state;
	}
	public String getCity() {
		return city;
	}
	public String getArea() {
		return area;
	}
	public String getSoceity() {
		return soceity;
	}
	public String getBolck() {
		return bolck;
	}
	public String getFloor() {
		return floor;
	}
	public String getHouseNumber() {
		return houseNumber;
	}
	public String getPincode() {
		return pincode;
	}
	public String getAdditionalInfo() {
		return additionalInfo;
	}
	public String getEntryGate() {
		return entryGate;
	}
	public String getExitGate() {
		return exitGate;
	}
	public String getDeliverySeq() {
		return deliverySeq;
	}
	public ErrorRecord getErrorRecord() {
		return errorRecord;
	}
	public String getStateCode() {
		return stateCode;
	}
	public void setState(String state) {
		this.state = state;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public void setSoceity(String soceity) {
		this.soceity = soceity;
	}
	public void setBolck(String bolck) {
		this.bolck = bolck;
	}
	public void setFloor(String floor) {
		this.floor = floor;
	}
	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}
	public void setPincode(String pincode) {
		this.pincode = pincode;
	}
	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}
	public void setEntryGate(String entryGate) {
		this.entryGate = entryGate;
	}
	public void setExitGate(String exitGate) {
		this.exitGate = exitGate;
	}
	public void setDeliverySeq(String deliverySeq) {
		this.deliverySeq = deliverySeq;
	}
	public void setErrorRecord(ErrorRecord errorRecord) {
		this.errorRecord = errorRecord;
	}
	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}
	
}
