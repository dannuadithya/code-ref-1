package com.homejiny.customer.request;

import java.util.Date;

public class UpdateRewardPointsStatusRequest {

	private Date moneyAddedToWalletDate;
	private String status;
	private long CustomerRewardPointsRedemptionId;

	public long getCustomerRewardPointsRedemptionId() {
		return CustomerRewardPointsRedemptionId;
	}

	public void setCustomerRewardPointsRedemptionId(long customerRewardPointsRedemptionId) {
		CustomerRewardPointsRedemptionId = customerRewardPointsRedemptionId;
	}

	public Date getMoneyAddedToWalletDate() {
		return moneyAddedToWalletDate;
	}

	public void setMoneyAddedToWalletDate(Date moneyAddedToWalletDate) {
		this.moneyAddedToWalletDate = moneyAddedToWalletDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
