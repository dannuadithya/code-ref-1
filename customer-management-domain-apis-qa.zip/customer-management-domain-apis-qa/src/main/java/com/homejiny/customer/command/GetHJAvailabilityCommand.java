package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.service.HJAvailabilityService;
import com.homejiny.customer.view.ViewResponse;

@Service
public class GetHJAvailabilityCommand implements Command<Long, ResponseEntity<ViewResponse>>{

	@Autowired
	HJAvailabilityService hJAvailabilityService;
	
	@Override
	public ResponseEntity<ViewResponse> excute(Long customerId) {
		
		return ResponseEntity.status(HttpStatus.OK).body(hJAvailabilityService.getHJAvailabilityDetails(customerId));
	}

}
