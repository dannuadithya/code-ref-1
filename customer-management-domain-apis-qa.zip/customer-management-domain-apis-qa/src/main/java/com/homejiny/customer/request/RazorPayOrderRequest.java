package com.homejiny.customer.request;

public class RazorPayOrderRequest {

	private String appName;

	private double amount;
	private long serviceOrderId;

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public long getServiceOrderId() {
		return serviceOrderId;
	}

	public void setServiceOrderId(long serviceOrderId) {
		this.serviceOrderId = serviceOrderId;
	}
	
	
}
