package com.homejiny.customer.service;

import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.view.KycVerifiedResponse;

@Service
public class KycVerifiedService {

	private Logger logger = LogManager.getLogger(KycVerifiedService.class);

	@Autowired
	CustomerRepository customerRepository;

	public KycVerifiedResponse markKycVerified(Long customerId) {
		Optional<Customer> customer = customerRepository.findById(customerId);
		if (!customer.isPresent()) {
			logger.info("customer  not found with this id" + customerId);
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);

		}
		KycVerifiedResponse kycVerifiedResponse = new KycVerifiedResponse();
		Customer kycCustomer = customer.get();
		kycCustomer.setKycVerified(true);
		customerRepository.save(kycCustomer);
		kycVerifiedResponse.setMessage(Constants.CUST_KYC_VERIFIED);
		kycVerifiedResponse.setStatus(Constants.SUCCESS);
		logger.info(Constants.CUST_KYC_VERIFIED + " For Customer Id " + customerId);
		return kycVerifiedResponse;
	}

}
