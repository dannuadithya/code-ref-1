package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.CustomerKycRequest;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.KycResponse;

@Service
public class CustomerKycCommand implements Command<CustomerKycRequest, ResponseEntity<KycResponse>> {
	@Autowired
	CustomerService customerService;

	public ResponseEntity<KycResponse> excute(CustomerKycRequest customerKycRequest) {

		return customerService.createKycDetails(customerKycRequest);
	}

}
