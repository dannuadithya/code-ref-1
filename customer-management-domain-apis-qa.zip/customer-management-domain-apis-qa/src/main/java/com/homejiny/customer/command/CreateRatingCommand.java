package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.request.RatingRequest;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.Response;

@Service
public class CreateRatingCommand implements Command<RatingRequest, ResponseEntity<Response>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<Response> excute(RatingRequest request) {

		if (request == null) {
			Response response = new Response();
			response.setMessage(Constants.INVALID_INPUTS);
			response.setStatus(Constants.FAILED);

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);
		}
		return ResponseEntity.status(HttpStatus.CREATED).body(customerService.submitReviewRating(request));
	}

}
