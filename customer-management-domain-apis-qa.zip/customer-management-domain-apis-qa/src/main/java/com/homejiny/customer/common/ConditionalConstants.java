package com.homejiny.customer.common;

public class ConditionalConstants {

	public static final String CUSTOMER_SIGNUP_INCOMPLETE = "0 30 1 * * ?";

	public static final String CUSTOMER_ORDER_CUTTOFFWARNING = "0 15 15 * * ?";

	public static final String CUSTOMER_WALLET_LOWBALANCE = "0 30 1 * * ?";

	public static final String REFERRAL_POINTS_CRON = "0 30 14 ? * *";
	
	public static final String REDEEM_POINTS_CRON = "0 30 3 ? * *";

	public static final String REWARD_POINTS_MONTHLY_CRON = "0 30 5 1 * ?";

}
