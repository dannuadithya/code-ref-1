package com.homejiny.customer.common;

public enum MediaStorageType {

	S3;

}
