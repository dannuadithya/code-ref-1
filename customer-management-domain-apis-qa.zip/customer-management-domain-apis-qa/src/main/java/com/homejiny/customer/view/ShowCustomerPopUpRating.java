package com.homejiny.customer.view;

public class ShowCustomerPopUpRating {

	private double QualityRating;
	private double deliveryRating;
	private double PriceRating;
	private double starRating;
	private String comment;

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public double getQualityRating() {
		return QualityRating;
	}

	public void setQualityRating(double qualityRating) {
		QualityRating = qualityRating;
	}

	public double getDeliveryRating() {
		return deliveryRating;
	}

	public void setDeliveryRating(double deliveryRating) {
		this.deliveryRating = deliveryRating;
	}

	public double getPriceRating() {
		return PriceRating;
	}

	public void setPriceRating(double priceRating) {
		PriceRating = priceRating;
	}

	public double getStarRating() {
		return starRating;
	}

	public void setStarRating(double starRating) {
		this.starRating = starRating;
	}

}
