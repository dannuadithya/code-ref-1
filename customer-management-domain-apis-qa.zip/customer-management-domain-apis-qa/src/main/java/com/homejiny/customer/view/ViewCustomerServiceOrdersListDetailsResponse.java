package com.homejiny.customer.view;

import java.util.List;

/**
 * @author - Chaitanya Mannem
 */
public class ViewCustomerServiceOrdersListDetailsResponse {

    private Long customerId;
    private String status;
    private String message;
    private List<ViewServiceOrdersListDetails> viewServiceOrdersListDetailsList;
    private String customerAddress;


    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public List<ViewServiceOrdersListDetails> getViewServiceOrdersListDetailsList() {
        return viewServiceOrdersListDetailsList;
    }

    public void setViewServiceOrdersListDetailsList(List<ViewServiceOrdersListDetails> viewServiceOrdersListDetailsList) {
        this.viewServiceOrdersListDetailsList = viewServiceOrdersListDetailsList;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCustomerAddress() {
        return customerAddress;
    }

    public void setCustomerAddress(String customerAddress) {
        this.customerAddress = customerAddress;
    }
}
