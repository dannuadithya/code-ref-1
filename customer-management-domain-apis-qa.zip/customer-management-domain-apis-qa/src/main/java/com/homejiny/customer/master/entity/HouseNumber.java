package com.homejiny.customer.master.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author brahmaiam
 *
 */
@Entity(name = "hj_house_number")
@Table(name = "HJ_HOUSE_NUMBER")
public class HouseNumber {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID")
	private long id;

	@Column(name = "house_number")
	private String houseNumber;

	@Column(name = "status")
	private String status;

	@Column(name = "additional_info")
	private String additionalInfo;

	@Column(name = "exit_gate")
	private String exitGate;

	@Column(name = "delivery_seq")
	private long deliverySeq;

	@Column(name = "entry_gate")
	private String entryGate;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "hj_floor_id")
	private Floor floor;
	
	@Column(name = "pincode_number")
	private long pincodeNumber;

	@Column(name = "created_time")
	private LocalDateTime createdAt;

	@Column(name = "updated_time")
	private LocalDateTime updatedAt;

	public long getId() {
		return id;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getExitGate() {
		return exitGate;
	}

	public void setExitGate(String exitGate) {
		this.exitGate = exitGate;
	}

	public long getDeliverySeq() {
		return deliverySeq;
	}

	public void setDeliverySeq(long deliverySeq) {
		this.deliverySeq = deliverySeq;
	}

	public String getEntryGate() {
		return entryGate;
	}

	public void setEntryGate(String entryGate) {
		this.entryGate = entryGate;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Floor getFloor() {
		return floor;
	}

	public void setFloor(Floor floor) {
		this.floor = floor;
	}

	public long getPincodeNumber() {
		return pincodeNumber;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setPincodeNumber(long pincodeNumber) {
		this.pincodeNumber = pincodeNumber;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	
}
