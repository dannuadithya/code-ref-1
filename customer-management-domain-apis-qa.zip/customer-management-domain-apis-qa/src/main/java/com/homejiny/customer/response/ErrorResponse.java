package com.homejiny.customer.response;

import java.time.LocalDateTime;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.homejiny.customer.common.DateAndTimeUtil;

@JsonInclude(Include.NON_NULL)
public class ErrorResponse {

	private String status;
	private String message;
	private LocalDateTime timeStamp;
	private String path;

	public ErrorResponse(String message, String path,String status) {
		super();
		this.message = message;
		this.path = path;
		this.timeStamp = DateAndTimeUtil.now();
		this.status= status;
	}

	public ErrorResponse(String message, String path) {
		super();
		this.message = message;
		this.path = path;
		this.timeStamp = DateAndTimeUtil.now();
	}

	public String getStatus() {
		return status;
	}

	public String getMessage() {
		return message;
	}

	public LocalDateTime getTimeStamp() {
		return timeStamp;
	}

	public String getPath() {
		return path;
	}

	
	
	
}
