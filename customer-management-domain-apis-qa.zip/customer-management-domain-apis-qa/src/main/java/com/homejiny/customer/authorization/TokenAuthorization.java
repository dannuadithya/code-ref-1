package com.homejiny.customer.authorization;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class TokenAuthorization implements WebMvcConfigurer {
	
	@Bean
	public RequestProcessingInterceptorAdapter pagePopulationInterceptor() {
	    return new RequestProcessingInterceptorAdapter();
	}
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(pagePopulationInterceptor());
	}
}
