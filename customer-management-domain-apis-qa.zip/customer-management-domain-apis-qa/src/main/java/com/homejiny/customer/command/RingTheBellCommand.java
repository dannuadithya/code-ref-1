package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.RingTheBellRequest;
import com.homejiny.customer.response.AgreeTermsAndConditionsReponse;
import com.homejiny.customer.service.RingTheBellService;

@Service
public class RingTheBellCommand
		implements Command<RingTheBellRequest, AgreeTermsAndConditionsReponse> {

	@Autowired
	RingTheBellService ringTheBellService;

	@Override
	public AgreeTermsAndConditionsReponse excute(RingTheBellRequest request) {
		return ringTheBellService.ringTheBell(request);
	}

}
