package com.homejiny.customer.response;

/**
 * @author - Chaitanya Mannem
 */
public class CancelCustomerServiceRequestResponse {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
