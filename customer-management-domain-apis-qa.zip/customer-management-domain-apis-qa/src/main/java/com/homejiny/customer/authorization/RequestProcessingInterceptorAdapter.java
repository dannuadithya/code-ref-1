package com.homejiny.customer.authorization;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.homejiny.customer.authentications.JWTAuthentication;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.repository.CustomerRepository;

import io.jsonwebtoken.Claims;

public class RequestProcessingInterceptorAdapter extends HandlerInterceptorAdapter {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	JWTAuthentication jwtAuthentication;
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		if (handler instanceof HandlerMethod) {
			HandlerMethod method = (HandlerMethod) handler;
			if (method != null) {
				EnableTokenAuthorisation methodAnnotation = method.getMethodAnnotation(EnableTokenAuthorisation.class);
				if (methodAnnotation != null) {
					methodAnnotation.roles();
					String header = request.getHeader("Authorization");
					if (header != null) {
						Claims verifyToken = jwtAuthentication.verifyToken(header);
						if (verifyToken != null) {
							String subject = verifyToken.getSubject();
							Customer mobileExists = customerRepository.findByMobileNumber(subject);
							if (mobileExists != null) {
								request.setAttribute("MOBILE", verifyToken.getSubject());
								request.setAttribute("id", mobileExists.getId());
								logger.info("Auth Token verified for MOBILE: " + verifyToken.getSubject());
							} else {
								logger.info("Invalid Token");
								throw new InvalidAuthTokenException("INVALID TOKEN");
							}
						} else {
							logger.info("Token Expired");
							throw new TokenExpiredException("TOKEN EXPIRED");
						}
					} else {
						logger.info("Token Missing");
						throw new AuthTokenMissingException("AUTH TOKEN MISSING");
					}
				}
			}
		}
		return super.preHandle(request, response, handler);
	}
}
