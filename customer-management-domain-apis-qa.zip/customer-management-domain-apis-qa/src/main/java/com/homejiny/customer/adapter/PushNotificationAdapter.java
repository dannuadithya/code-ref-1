package com.homejiny.customer.adapter;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.request.PushNotificationRequest;
import com.homejiny.customer.response.PushNotificationResponse;



/**
 * @author haripriya
 *
 */
@Service
public class PushNotificationAdapter {

	private static final Logger logger = LoggerFactory.getLogger(PushNotificationAdapter.class);

	private final RestTemplate restTemplate = new RestTemplate();

	@Value("${notification.api.endpoint}")
	private String notificationApiEndpoint;

	/**
	 * This method is used to send pushNotifications 
	 * 
	 *
	 * @return PushNotificationResponse
	 */
	public PushNotificationResponse sendPushNotification(PushNotificationRequest pushNotificationRequest) {
		logger.info("Started to send pushnotification with title:: "+ pushNotificationRequest.getTitle() + " at endpoint: "+notificationApiEndpoint);
		PushNotificationResponse pushNotificationResponse = new PushNotificationResponse();
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<PushNotificationRequest> httpEntity = new HttpEntity<>(pushNotificationRequest, headers);
			pushNotificationResponse = restTemplate.exchange(notificationApiEndpoint,
					HttpMethod.POST, httpEntity, PushNotificationResponse.class).getBody();
		}catch ( RestClientException exception){
				logger.info("Failed api call for " + notificationApiEndpoint );
				logger.info("Message: " + exception.getLocalizedMessage() + "Cause: " + exception.getCause());
				pushNotificationResponse.setMessage(Constants.REST_API_CALL_FAILED);
		}
		logger.info("PushNotificationResponse from API:"+pushNotificationResponse);
		return pushNotificationResponse;
	}

}
