package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.service.FetchCustomerKycService;
import com.homejiny.customer.view.ViewResponse;

@Service
public class GetCustomerKycAndDeliveryInfoCommand implements Command<Long, ResponseEntity<ViewResponse>> {
	
	@Autowired
	FetchCustomerKycService fetchCustomerKycService;

	@Override
	public ResponseEntity<ViewResponse> excute(Long request) {
		
		return ResponseEntity.status(HttpStatus.OK).body(fetchCustomerKycService.getCustomerKycAndDeliveryInfo(request));
	}
}
