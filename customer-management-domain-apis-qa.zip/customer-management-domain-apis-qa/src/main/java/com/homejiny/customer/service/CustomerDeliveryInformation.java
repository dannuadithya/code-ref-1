package com.homejiny.customer.service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerAddress;
import com.homejiny.customer.exception.CustomerAddressNotFoundException;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.exception.MediaFileNotFoundException;
import com.homejiny.customer.repository.AddressRepository;
import com.homejiny.customer.repository.CustomerMediaRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.request.DeliveryInformationRequest;
import com.homejiny.customer.view.Response;

/**
 * @author sridevi
 *
 */
@Service
public class CustomerDeliveryInformation {

	private Logger logger = LogManager.getLogger(CustomerDeliveryInformation.class);

	@Autowired
	AddressRepository addressRepository;

	@Autowired
	CustomerMediaRepository customerMediaRepository;

	@Value("${cloud.aws.credentials.accessKey}")
	private String accessKey;

	@Value("${cloud.aws.credentials.secretKey}")
	private String secretKey;

	@Value("${cloud.aws.region}")
	private String region;

	@Value("${cloud.aws.file_size}")
	private String fileSize;

	@Value("${cloud.aws.credentials.bucketName}")
	private String bucketName;

	@Value("${cloud.aws.image_url}")
	private String cloudAwsDBURL;

	@Autowired
	CustomerRepository customerRespository;

	/**
	 * createAWSConnection
	 * 
	 * @return AmazonS3
	 */
	public AmazonS3 createAWSConnection() {
		AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);

		return AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials))
				.withRegion(region).build();
	}

	/**
	 * upload Media
	 * 
	 * @param multiPartFile
	 * @return CustomerMedia
	 */
	public String uploadMedia(MultipartFile multiPartFile, long directoryName) {
		logger.info("Create a media upload file");
		if (multiPartFile == null) {
			throw new MediaFileNotFoundException(Constants.MEDIA_FILE_NOT_FOUND);
		}
		File mediaFile = new File(multiPartFile.getOriginalFilename());

		try (FileOutputStream fileOutputStream = new FileOutputStream(mediaFile)) {

			fileOutputStream.write(multiPartFile.getBytes());
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		try {
			createAWSConnection().putObject(bucketName, directoryName + "/" + directoryName + mediaFile.getName(),
					mediaFile);
		} catch (AmazonServiceException amazonException) {
			throw new RuntimeException(amazonException.getMessage());
		}

		return directoryName + "/" + directoryName + multiPartFile.getOriginalFilename();
	}

	/**
	 * createDeliveryInformation
	 * 
	 * @param deliveryInformationRequest
	 * @return Response
	 */
	public Response createDeliveryInformation(DeliveryInformationRequest deliveryInformationRequest) {
		logger.info(Constants.CUSTOMER_DELIVERY_INFO_CREATED);
		Optional<Customer> customerOptional = customerRespository.findById(deliveryInformationRequest.getCustomerId());
		if (!customerOptional.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND_WITH_THIS_ID);
		}
		Customer customer = customerOptional.get();
		CustomerAddress customerAddress = addressRepository.findByCustomer(customer);

		if (customerAddress == null) {
			throw new CustomerAddressNotFoundException(
					"Address not found when Updating customer delivery Information ");
		}

		String dropLocationImagePath = uploadMedia(deliveryInformationRequest.getDropLocationImagePath(),
				deliveryInformationRequest.getCustomerId());
		if (dropLocationImagePath == null) {
			throw new MediaFileNotFoundException(Constants.MEDIA_FILE_NOT_FOUND);
		}

		customerAddress.setDropLocationImagePath(dropLocationImagePath);
		String qrCodeimagePath = uploadMedia(deliveryInformationRequest.getQrCodeLocationImagePath(),
				deliveryInformationRequest.getCustomerId());
		if (qrCodeimagePath == null) {
			throw new MediaFileNotFoundException(Constants.MEDIA_FILE_NOT_FOUND);
		}
		customerAddress.setQrCodeLocationImagePath(qrCodeimagePath);
		customerAddress.setBaggageDropLocation(deliveryInformationRequest.getBaggageDropLocation());
		customerAddress.setQrCodeLocation(deliveryInformationRequest.getQrCodeLocation());
		customerAddress.setCreatedAt(DateAndTimeUtil.now());
		customerAddress.setUpdatedAt(DateAndTimeUtil.now());

		CustomerAddress addressEntity = addressRepository.save(customerAddress);
		customer.setRegistrationStep("delivery_information_updated");
		customer.setHasDeliveryInformationDetails(true);

		customerRespository.save(customer);

		Response response = new Response();

		response.setId(addressEntity.getId());
		response.setMessage(Constants.CUSTOMER_DELIVERY_INFO_CREATED);
		response.setStatus(Constants.SUCCESS);
		response.setDropLocationImagePath(cloudAwsDBURL+dropLocationImagePath);
		response.setQrCodeLocationImagePath(cloudAwsDBURL+qrCodeimagePath);
		return response;

	}

}
