package com.homejiny.customer.request;

public class RingTheBellRequest {

	private Boolean ringTheBell;
	private long customerId;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public Boolean getRingTheBell() {
		return ringTheBell;
	}

	public void setRingTheBell(Boolean ringTheBell) {
		this.ringTheBell = ringTheBell;
	}

}
