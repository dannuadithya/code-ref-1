package com.homejiny.customer.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerAddress;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerAddressRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.request.RingTheBellRequest;
import com.homejiny.customer.response.AgreeTermsAndConditionsReponse;

@Service
public class RingTheBellService {

	@Autowired
	CustomerAddressRepository customerAddressRepository;

	@Autowired
	CustomerRepository customerRepository;

	public AgreeTermsAndConditionsReponse ringTheBell(RingTheBellRequest request) {
		Optional<Customer> optionalCustomer = customerRepository.findById(request.getCustomerId());

		if (!optionalCustomer.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}
		
		Optional<CustomerAddress> customer = customerAddressRepository.findByCustomer(optionalCustomer.get());
		if(!customer.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}
		customer.get().setRingTheBell(request.getRingTheBell());
		customer.get().setCustomer(customer.get().getCustomer());
		customerAddressRepository.save(customer.get());

		AgreeTermsAndConditionsReponse agreeTermsAndConditionsReponse = new AgreeTermsAndConditionsReponse();
		agreeTermsAndConditionsReponse.setId(request.getCustomerId());
		if(customer.get().isRingTheBell()){
			agreeTermsAndConditionsReponse.setMessage(Constants.RING_THE_BELL_UPDATED_TRUE);
		}else {
			agreeTermsAndConditionsReponse.setMessage(Constants.RING_THE_BELL_UPDATED_FALSE);
		}

		agreeTermsAndConditionsReponse.setStatus(Constants.SUCCESS);

		return agreeTermsAndConditionsReponse;
	}

}
