package com.homejiny.customer.view;


import java.util.List;

/**
 * @author - Chaitanya Mannem
 */
public class ViewServiceOrdersListDetailsResponse {

    private List<ViewServiceOrdersListDetails> viewServiceOrdersListDetailsList;

    public List<ViewServiceOrdersListDetails> getViewServiceOrdersListDetailsList() {
        return viewServiceOrdersListDetailsList;
    }

    public void setViewServiceOrdersListDetailsList(List<ViewServiceOrdersListDetails> viewServiceOrdersListDetailsList) {
        this.viewServiceOrdersListDetailsList = viewServiceOrdersListDetailsList;
    }
}
