package com.homejiny.customer.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ViewCustomerDetails {

	private long customerId;
	private String status;
	private String message;
	private String firstName;
	private String lastName;
	private String emailAddress;
	private String mobileNumber;
	private String middleName;
	private String registrationStep;
	private long walletId;
	private String profileImage;
	private String deviceToken;
	private AddressDetails addressDetails;
	private Boolean hasEmail;
	private Boolean hasName;
	private Boolean hasAddress;
	private Boolean hasKyc;
	private Boolean hasDeliveryDetails;
	private boolean canOrderProducts;
	private boolean canOrderServices;
	private String dbAppVersion;

	public Boolean getHasAddress() {
		return hasAddress;
	}

	public void setHasAddress(Boolean hasAddress) {
		this.hasAddress = hasAddress;
	}

	public Boolean getHasKyc() {
		return hasKyc;
	}

	public void setHasKyc(Boolean hasKyc) {
		this.hasKyc = hasKyc;
	}

	public Boolean getHasDeliveryDetails() {
		return hasDeliveryDetails;
	}

	public void setHasDeliveryDetails(Boolean hasDeliveryDetails) {
		this.hasDeliveryDetails = hasDeliveryDetails;
	}

	public Boolean getHasEmail() {
		return hasEmail;
	}

	public void setHasEmail(Boolean hasEmail) {
		this.hasEmail = hasEmail;
	}

	public Boolean getHasName() {
		return hasName;
	}

	public void setHasName(Boolean hasName) {
		this.hasName = hasName;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getRegistrationStep() {
		return registrationStep;
	}

	public void setRegistrationStep(String registrationStep) {
		this.registrationStep = registrationStep;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public AddressDetails getAddressDetails() {
		return addressDetails;
	}

	public void setAddressDetails(AddressDetails addressDetails) {
		this.addressDetails = addressDetails;
	}

	public long getWalletId() {
		return walletId;
	}

	public void setWalletId(long walletId) {
		this.walletId = walletId;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public boolean isCanOrderProducts() {
		return canOrderProducts;
	}

	public void setCanOrderProducts(boolean canOrderProducts) {
		this.canOrderProducts = canOrderProducts;
	}

	public boolean isCanOrderServices() {
		return canOrderServices;
	}

	public void setCanOrderServices(boolean canOrderServices) {
		this.canOrderServices = canOrderServices;
	}

	public String getDbAppVersion() {
		return dbAppVersion;
	}

	public void setDbAppVersion(String dbAppVersion) {
		this.dbAppVersion = dbAppVersion;
	}

	
}
