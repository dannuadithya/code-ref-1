package com.homejiny.customer.adapter;

import java.util.Optional;

import com.homejiny.customer.request.*;
import com.homejiny.customer.response.MobikwikResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.RestCallPaths;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerAddress;
import com.homejiny.customer.exception.CustomerAddressNotFoundException;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.exception.HjAvailabilityException;
import com.homejiny.customer.exception.InValidInputException;
import com.homejiny.customer.exception.WalletAmountExceedsException;
import com.homejiny.customer.exception.WalletMicroserviceDownException;
import com.homejiny.customer.master.entity.City;
import com.homejiny.customer.master.entity.State;
import com.homejiny.customer.master.repository.MasterCityRepository;
import com.homejiny.customer.master.repository.MasterStateRepository;
import com.homejiny.customer.repository.CustomerAddressRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.response.PaytmPayOrderResponse;
import com.homejiny.customer.response.WalletResponse;
import com.homejiny.customer.view.ViewRazorPayOrderDetails;
import com.homejiny.customer.view.ViewRazorpayGatewayKey;
import com.homejiny.customer.view.WalletDetails;
import com.homejiny.customer.view.WalletView;

@Service
public class WalletAdapter {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	CustomerAddressRepository customerAddressRepository;

	@Autowired
	MasterStateRepository masterStateRepository;
	
	@Autowired
	MasterCityRepository masterCityRepository;
	
	@Value("${wallet.api.endpoint}")
	private String url;

	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	
	private RestTemplate restTemplate = new RestTemplate();

	/**
	 * @return
	 */
	public ResponseEntity<ViewRazorpayGatewayKey> fetchRazorPaymentGateWayKey() {

		StringBuilder walletApi = new StringBuilder(url);
		walletApi.append("v1/wallet/razorpay/gatewaykey");
		logger.info("Url for View Razorpay Gateway Key set : " + walletApi.toString());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<ViewRazorpayGatewayKey> response = restTemplate.exchange(walletApi.toString(), HttpMethod.GET,
				null, ViewRazorpayGatewayKey.class);
		return response;
	}

	/**
	 * @param razorPayOrderRequest
	 * @param customerId
	 * @return
	 */
	public ResponseEntity<ViewRazorPayOrderDetails> createRazorPayOrder(RazorPayOrderRequest razorPayOrderRequest,
			long customerId) {
		/*
		 * if(!canAddMoneyToWallet()) { throw new
		 * HjAvailabilityException(Constants.AVAILABILITY); }
		 */
		if (razorPayOrderRequest == null || StringUtils.isEmpty(razorPayOrderRequest.getAppName())
				|| razorPayOrderRequest.getAmount() <= 0.9) {
			throw new InValidInputException(Constants.INVALID_INPUTS);
		}
		Optional<Customer> optionalCustomer = customerRepository.findById(customerId);

		if (!optionalCustomer.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}

		if (optionalCustomer.get().getWalletId() <= 0) {
			throw new InValidInputException("Customer Wallet Id does not exist with customer id : " + customerId);
		}

		Optional<CustomerAddress> optionalCustomerAddress = customerAddressRepository
				.findByCustomer(optionalCustomer.get());

		if (optionalCustomerAddress.isPresent()) {			
			State state = masterStateRepository.findByName(optionalCustomerAddress.get().getState());
			City city = masterCityRepository.findByName(optionalCustomerAddress.get().getCity());				
			if (optionalCustomerAddress.get().getSocietyId() == null && (state ==null || city ==null)) {
				throw new HjAvailabilityException(Constants.AVAILABILITY);
			}
		} else {
			throw new CustomerAddressNotFoundException(Constants.UPDATE_ADDRESS);
		}

		long walletId = optionalCustomer.get().getWalletId();
		logger.info("Wallet id : " + walletId);

		// To call wallet api and get the wallet total amount.

		isWalletAmountExceeds(razorPayOrderRequest.getAmount(), walletId, razorPayOrderRequest.getServiceOrderId());

		StringBuilder walletApi = new StringBuilder(url);
		walletApi.append("v1/wallet/").append("razorpay/").append("order");
		logger.info("Url for Create RazorPay Order Request : " + walletApi.toString());
		CreateRazorPayOrderRequest createRazorPayOrderRequest = new CreateRazorPayOrderRequest();
		createRazorPayOrderRequest.setWalletId(walletId);
		createRazorPayOrderRequest.setAppName(razorPayOrderRequest.getAppName());
		createRazorPayOrderRequest.setAmount(razorPayOrderRequest.getAmount());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<CreateRazorPayOrderRequest> httpEntity = new HttpEntity<>(createRazorPayOrderRequest, headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<ViewRazorPayOrderDetails> response = restTemplate.exchange(walletApi.toString(), HttpMethod.POST,
				httpEntity, ViewRazorPayOrderDetails.class);
		return response;
	}

	public boolean isWalletAmountExceeds(double amount, long walletId, long serviceOrderId) {
		StringBuilder walletApi = new StringBuilder(url);
		walletApi.append("v1/wallet/").append(walletId);
		logger.info("Url for get wallet amount : " + walletApi.toString());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<WalletView> response = restTemplate.exchange(walletApi.toString(), HttpMethod.GET, null,
				WalletView.class);
		if (response.getStatusCodeValue() == 200) {
			WalletDetails walletDetails = response.getBody().getWalletDetails();
			logger.info("Wallet Id " + walletId + " , Wallet Details : " + walletDetails);
			double walletTotalBalance = walletDetails.getWalletTotalAmount().doubleValue();
			logger.info("Current wallet TotalBalance " + walletTotalBalance);
			if (walletTotalBalance + amount > 5000 && serviceOrderId == 0) {
				throw new WalletAmountExceedsException(
						"Your wallet amount going to exceeds as per the Guidelines, wallet amount should be less than or equal to Rs.5000 only, your current balance is "
								+ walletTotalBalance);
			}
		} else {
			throw new WalletMicroserviceDownException("Currently, Wallet Service is un available");
		}
		return true;
	}
	private boolean canAddMoneyToWallet() {
		return false;
	}

	public ResponseEntity<PaytmPayOrderResponse> createChecksum(PaytmPayOrderRequest paytmPayOrderRequest) {
		/*
		 * if(!canAddMoneyToWallet()) { throw new
		 * HjAvailabilityException(Constants.AVAILABILITY); }
		 */
		if (paytmPayOrderRequest == null || StringUtils.isEmpty(paytmPayOrderRequest.getAppName())
				|| Double.valueOf(paytmPayOrderRequest.getAmount()) <= 0.9) {
			throw new InValidInputException(Constants.INVALID_INPUTS);
		}
		Optional<Customer> optionalCustomer = customerRepository.findById(paytmPayOrderRequest.getCustomerId());

		if (!optionalCustomer.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}

		if (optionalCustomer.get().getWalletId() <= 0) {
			throw new InValidInputException(
					"Customer Wallet Id does not exist with customer id : " + paytmPayOrderRequest.getCustomerId());
		}

		Optional<CustomerAddress> optionalCustomerAddress = customerAddressRepository
				.findByCustomer(optionalCustomer.get());

		if (optionalCustomerAddress.isPresent()) {
			State state = masterStateRepository.findByName(optionalCustomerAddress.get().getState());
			City city = masterCityRepository.findByName(optionalCustomerAddress.get().getCity());				
			if (optionalCustomerAddress.get().getSocietyId() == null && (state ==null || city ==null)) {
				throw new HjAvailabilityException(Constants.AVAILABILITY);
			}
		} else {
			throw new CustomerAddressNotFoundException(Constants.UPDATE_ADDRESS);
		}
		long walletId = optionalCustomer.get().getWalletId();
		logger.info("Wallet id : " + walletId);

		// To call wallet api and get the wallet total amount.

		isWalletAmountExceeds(Double.parseDouble(paytmPayOrderRequest.getAmount()), walletId,
				paytmPayOrderRequest.getServiceOrderId());

		StringBuilder walletApi = new StringBuilder(url);
		walletApi.append("/v1/checksum");
		logger.info("Url for Create checksum using paytm : " + walletApi.toString());
		ChecksumRequest checksumRequest = new ChecksumRequest();
		checksumRequest.setAppName(paytmPayOrderRequest.getAppName());
		checksumRequest.setWalletId(walletId);
		checksumRequest.setAmount(paytmPayOrderRequest.getAmount());
		checksumRequest.setMerchantUniqueRef(
				optionalCustomer.get().getFirstName() + "_" + optionalCustomer.get().getMobileNumber() + "_"
						+ optionalCustomer.get().getEmail() + "/CUS" + optionalCustomer.get().getId());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<ChecksumRequest> httpEntity = new HttpEntity<>(checksumRequest, headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<PaytmPayOrderResponse> response = restTemplate.exchange(walletApi.toString(), HttpMethod.POST,
				httpEntity, PaytmPayOrderResponse.class);
		return response;
	}

	public ResponseEntity<MobikwikResponse> createMobiwekChecksum(MobiwekPayOrderRequest mobiwekPayOrderRequest) {
		if(!canAddMoneyToWallet()) {
			throw new HjAvailabilityException(Constants.AVAILABILITY);
		}
		if (mobiwekPayOrderRequest == null || StringUtils.isEmpty(mobiwekPayOrderRequest.getAppName())
				|| Double.valueOf(mobiwekPayOrderRequest.getAmount()) <= 0.9) {
			throw new InValidInputException(Constants.INVALID_INPUTS);
		}
		Optional<Customer> optionalCustomer = customerRepository.findById(mobiwekPayOrderRequest.getCustomerId());

		if (!optionalCustomer.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}

		if (optionalCustomer.get().getWalletId() <= 0) {
			throw new InValidInputException(
					"Customer Wallet Id does not exist with customer id : " + mobiwekPayOrderRequest.getCustomerId());
		}

		Optional<CustomerAddress> optionalCustomerAddress = customerAddressRepository
				.findByCustomer(optionalCustomer.get());

		if (optionalCustomerAddress.isPresent()) {
			State state = masterStateRepository.findByName(optionalCustomerAddress.get().getState());
			City city = masterCityRepository.findByName(optionalCustomerAddress.get().getCity());
			if (optionalCustomerAddress.get().getSocietyId() == null && (state ==null || city ==null)) {
				throw new HjAvailabilityException(Constants.AVAILABILITY);
			}
		} else {
			throw new CustomerAddressNotFoundException(Constants.UPDATE_ADDRESS);
		}
		long walletId = optionalCustomer.get().getWalletId();
		logger.info("Wallet id : " + walletId);

		// To call wallet api and get the wallet total amount.

		isWalletAmountExceeds(Double.parseDouble(mobiwekPayOrderRequest.getAmount()), walletId,
				mobiwekPayOrderRequest.getServiceOrderId());

		StringBuilder walletApi = new StringBuilder(url);
		walletApi.append("/v1/mobikwikChecksum");
		logger.info("Url for Create checksum using Mobikwik : " + walletApi.toString());

		MobikwikRequest checksumRequest = new MobikwikRequest();
		checksumRequest.setAppName(mobiwekPayOrderRequest.getAppName());
		checksumRequest.setWalletId(walletId);
		checksumRequest.setAmount(Integer.parseInt(mobiwekPayOrderRequest.getAmount()));
		checksumRequest.setDate(mobiwekPayOrderRequest.getDate());
		checksumRequest.setIp(mobiwekPayOrderRequest.getIp());
		checksumRequest.setEmailId(mobiwekPayOrderRequest.getEmailId());

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<MobikwikRequest> httpEntity = new HttpEntity<>(checksumRequest, headers);
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<MobikwikResponse> response = restTemplate.exchange(walletApi.toString(), HttpMethod.POST,
				httpEntity, MobikwikResponse.class);
		return response;
	}
	
	public WalletResponse creditMoneyToWallet(WalletCreditRequest walletCreditRequest) {
		String apiUrl = url +"v1/"+ RestCallPaths.CREDIT_WALLET;
		ResponseEntity<WalletResponse> walletResponse = null;
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		HttpEntity<WalletCreditRequest> httpEntity = new HttpEntity<>(walletCreditRequest, headers);
		try {
			walletResponse = restTemplate.exchange(apiUrl, HttpMethod.POST, httpEntity,
					WalletResponse.class);
		} catch (Exception exception) {
			logger.info("[Alert] unable to credit Money to wallet_id# "+walletCreditRequest.getWalletId(), exception.getMessage());
			return null;
		}
		if (walletResponse.getStatusCode() != HttpStatus.OK) {
			logger.info("[Alert] unable to credit Money to wallet_id# "+walletCreditRequest.getWalletId()+" status code# "+walletResponse.getStatusCode());			
			return null;
		}
		return walletResponse.getBody();
	}
	
	
}
