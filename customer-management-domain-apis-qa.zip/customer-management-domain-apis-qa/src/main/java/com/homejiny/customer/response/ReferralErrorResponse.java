package com.homejiny.customer.response;

import java.time.Instant;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class ReferralErrorResponse {

	private String message;
	private Instant timeStamp;
	private String path;
	private String status;

	public ReferralErrorResponse(String message, String path, String status) {
		super();
		this.message = message;
		this.path = path;
		this.timeStamp = Instant.now();
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public Instant getTimeStamp() {
		return timeStamp;
	}

	public String getPath() {
		return path;
	}

	public String getStatus() {
		return status;
	}

}
