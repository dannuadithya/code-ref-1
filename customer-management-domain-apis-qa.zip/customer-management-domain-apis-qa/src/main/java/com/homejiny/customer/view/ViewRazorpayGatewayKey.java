package com.homejiny.customer.view;

public class ViewRazorpayGatewayKey {

	private String razorPaymentGateWayKey;

	private String razorPaymentGateWaySC;

	public String getRazorPaymentGateWayKey() {
		return razorPaymentGateWayKey;
	}

	public void setRazorPaymentGateWayKey(String razorPaymentGateWayKey) {
		this.razorPaymentGateWayKey = razorPaymentGateWayKey;
	}

	public String getRazorPaymentGateWaySC() {
		return razorPaymentGateWaySC;
	}

	public void setRazorPaymentGateWaySC(String razorPaymentGateWaySC) {
		this.razorPaymentGateWaySC = razorPaymentGateWaySC;
	}

}