package com.homejiny.customer.common;

/**
 * @author brahmaiam
 *
 */
public class Constants {
	public static final String CUSTOMER_NOT_EXIST = "Customer not exist";
	public static final String CUSTOMER_ACCOUNT_CREATED = "Customer account created";
	public static final String INVALID_INPUTS = "Invalid Inputs";
	public static final String SUCCESS = "Success";
	public static final String CUSTOMER_NOT_FOUND = "Customer not found";
	public static final String CUSTOMER_ACCOUNT_UPDATED = "Customer account updated";
	public static final String NO_CUSTOMER_EXIST_WITH_CUSTOMER_ID_IS = "No Customer exist with customer id is ";
	public static final String SOCIETY_DOES_NOT_EXIST = "Invalid Society";
	public static final String CUSTOMER_UPDATED_WITH_CUSTOMER_ID = "Customer updated with customer Id : ";
	public static final String ACTIVE = "active";
	public static final String _1234567890 = "1234567890";
	public static final String _1234 = "1234";
	public static final String OTP_VERIFIED = "OTP verified";
	public static final String _1234567891 = "1234567891";
	public static final String OTP_NOT_VERIFIED = "OTP not verified";
	public static final String FAILED = "Failed";
	public static final String OTP_SENT = "OTP sent ";
	public static final String FILE_FORMATED = "Please choose valid format files like jpeg,jpg,png,pdf";
	public static final String KYC_UPLOAD_FAILED = "KYC Document upload is Failed";
	public static final String KYC_UPLOAD_SUCCESS = "KYC Document is upload Successfully";
	public static final String File_SIZE = "File size is should not exceed more than 2MB";
	public static final String KYC_TYPE = "please select KYC type";

	public static final String PAN_CARD_SIZE = "Pan Card is should be 10 digits";
	public static final String ADHAR_CARD_SIZE = "Adhar Card is should be 12 digits ";
	public static final String DRIVING_LIC_CARD_SIZE = "Driving Licence is should be 20 digits";
	public static final String VOTER_CARD_SIZE = "Voter card is should be 10 digits";
	public static final String PASSPORT_SIZE = "Passport is should be 10 digits";

	public static final int PAN_CARD_LENGTH = 10;
	public static final int ADHAR_CARD_LENGTH = 12;
	public static final int DRIVING_LIC_CARD_LENGTH = 20;
	public static final int VOTER_CARD_LENGTH = 10;
	public static final int PASSPORT_LENGTH = 10;

	public static final String AADHAR_CARD = "Aadhar Card";
	public static final String PAN_CARD = "Pan Card";
	public static final String DRIVING_CARD = "Driving Licence";
	public static final String VOTER_CARD = "Voter Card";
	public static final String PASSPORT = "Passport";

	public static final String KYC_ACTIVE = "Active";

	public static final String ALPHA_NUMARIC_PATTERN = "Document number is mandtory please follow the pattern like A-Z,0-9";
	public static final String NUMARIC_PATTERN = "Document number is mandtory please follow the pattern 0-9";
	public static final String REVIEW_RATINGS_SUBMITTED_SUCCESSFULLY = "Review Ratings Submitted Successfully";
	public static final String REVIEW_RATING_SUBMITTED_SUCCESSFULLY = "review rating submitted successfully";
	public static final String GENERATED_CODE = "Generated a code  ";
	public static final String INVALIDE_REFERRAL_CODE = "Please enter valid Referral Code";
	public static final String VALIDE_REFERRAL_CODE = " Verified ";
	public static final String NO_REFERRAL_CODE = "There is no Referral Code ";
	public static final String CUSTOMER_ID_SHOULD_NOT_BE_EMPTY = "customer id should not be empty";
	public static final String REWARD_POINTS_SHOULD_NOT_BE_EMPTY = "Reward points should not be empty";
	public static final String OPERATION_TYPE_SHOULD_NOT_BE_EMPTY = "operation type should not be empty";
	public static final String REWARD_TYPE_SHOULD_NOT_BE_EMPTY = "Reward type should not be empty";
	public static final String CUSTOMER_REWARD_POINTS_CREATED_SUCCESSFULLY = "customer reward points created successfully";
	public static final String NO_RECORD_FOUND_WITH_ID = "no record found with customerId";
	public static final String NO_RECORD_FOUND_WITH = "no record found with";
	public static final String RECORD_CREATED_FOR_CUSTOMER_REWARD_TYPE = "record created with customer reward type";
	public static final String CUSTOMER_REWARD_POINTS_CREATED_SUCCESSFULLY_WITH = "customer reward points created successfully with ";
	public static final String CUSTOMER_REWARD_POINTS_CREATED_UPDATED_WITH = "customer reward points updated successfully with";
	public static final String CUSTOMER_REWARD_POINTS_UPDATED_WITH = "Customer reward points updated with";
	public static final String ADD = "ADD";
	public static final String NO_RECORD_FOUND_WITH_MOBILE_NUMBER = "no record found with mobile number ";

	public static final String INVALID_PIN_CODE = "Invalid Pin code";
	public static final String CITY_NOT_FOUND_WITH_PIN_CODE = "City Not found with Pin code : ";
	public static final String STATE_NOT_FOUND_WITH_PIN_CODE = "State Not found with Pin code : ";
	public static final String CITIES_ARE_NOT_AVAILABLE_WITH_STATE = "Cities are not available with state id : ";
	public static final String AREAS_ARE_NOT_AVAILABLE_WITH_CITY = "Areas are not available with city id : ";
	public static final String SOCIETIES_ARE_NOT_AVAILABLE_WITH_AREA_NAME = "Societies are not available with area id : ";
	public static final String SOCIETY_NOT_AVAILABLE= "No society found with id : ";
	public static final String BLOCKS_ARE_NOT_AVAILABLE_WITH_SOCIETY_NAME = "Blocks are not available with Society id : ";
	public static final String FLOORS_ARE_NOT_AVAILABLE_WITH_BLOCK_NAME = "Floors are not available with block id : ";
	public static final String HOUSE_NUMBERS_ARE_NOT_AVAILABLE_WITH_BLCAK_NAME_AND_FLOOR_NAME = "House Numbers are not available with Floor id : ";
	public static final String FILE_SIZE = "File size should be 3MB";
	public static final String CUSTOMER_DELIVERY_INFO_CREATED = "Customer Delivery info created ";
	public static final String CUSTOMER_DELIVERY_INFO_FAILED = "Customer delivery info failed";

	public static final String ALPHANUM = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	public static final String CUSTOMER_NOT_FOUND_WITH_THIS_ID = "customer id notfound with this id";
	public static final String MEDIA_FILE_NOT_FOUND = "media file not found";
	public static final String STORAGE_SERVICE = "S3";
	public static final String PROFILE_PICTURE = "Profile picture is upload Successfully";
	public static final String NO_IMAGE_FILE = "Please select Image file";

	public static final String SERVICE_ORDERS_LIST_API = "service/";
	public static final String CANCEL_SERVICE_REQUEST_API = "service/cancelServiceRequest/";
	public static final String REFERRAL_CODE_IS_ALREADY_USED = "referral code is already used";
	public static final String CUSTOMER_ADDRESS_NOT_FOUND_WITH_THIS_ID = "Customer address not found with this id ";
	public static final String ALLREADY_USED_REFERRAL_CODE = "You have Already availed Referral Benefit";
	public static final String OWN_REFERRAL_CODE = "You Cannot Use your Own Referral Code";
//	public static final String APP_REFERRAL_NOT_ELGIBLE = "The referral code entered is invalid or expired";
	public static final String APP_REFERRAL_NOT_ELGIBLE = "You are already registered with Home Jiny and You are not eligible for referral Program.";
	public static final String REST_API_CALL_FAILED = "Push Notification Rest API call Failed";
	public static final String CUST_KYC_VERIFIED = "Success! Marked KYC as verified";
	public static final String HJ = "HJ";
	public static String DELIVERY_INFORMATION_UPDATED = "delivery_information_updated";
	public static final String STATUS = "active";
	public static final String AVAILABILITY = "Thank you for your interest, we would start products or services delivery soon in your area. We will keep you informed";
	public static final String PRODUCT_AVAILABILITY = "Thank you for your interest, we would start products delivery soon in your area. We will keep you informed";
	public static final String SERVICE_AVAILABILITY = "Thank you for your interest, we would start services delivery soon in your area. We will keep you informed ";
	public static final String RING_THE_BELL_UPDATED_TRUE = "Thank for choosing 'Yes' for Ring the Bell, our delivery person will ring your bell to handover the delivery bag. Please keep previously delivered bags lying with you ready to give to our person. The outer bags and KIF ZIP lock bags are returnable";
	public static final String RING_THE_BELL_UPDATED_FALSE = "You have chosen 'No' for Ring the Bell, our delivery person will leave the delivery bag at your door and not disturb by ringing the bell.. Please keep previously delivered bags lying with you outside your door. The outer bags and KIF ZIP lock bags are returnable";

	public static final String REFERRED_BY_MESSAGE = "Referred By Message";

	public static final String REFERRED_MESSAGE = "Referred Message";
	public static final String FAIL_NOT_SUPPORT_AREA = "Fail_Not_Support_Area";

	public static final String HOMEJINY_REFERRED_MESSAGE = "Homejiny Referred Messages";

	public static final String UPDATE_ADDRESS = "Could you please update address and try again!!";
	public static final String CUSTOMER_SUPPORT_INFO = "Customer Support Info Added Successfully";
	public static final String INVITE_FRIENDS_MESSAGE = "share yourcode with your friends, you get 200 points and your friend will get 100 points ";
	public static final String INVITE_FRIENDS_MSG = "1.Invite your friends to Download Homejiny App ,2.When your friend signs up and places the firstorder,you earn 100 star points and your friends earns 50 start points";
	public static final String COMPLETED = "COMPLETED";
	public static final String COMPLETED_PAYMENT_PENDING = "COMPLETED - PAYMENT PENDING";
	public static final String SORRY_YOU_DONT_HAVE_SUFFICIENT_POINTS_IN_YOUR_ACCOUNT = "sorry you don't have sufficient points in your account";
	public static final String DEFAULT = "#";

	public static final String CREDITED_PATRONAGE_POINTS = "Credited PATRONAGE Points";
	public static final String CREDITED_SUSTAINABILITY_POINTS = "Credited SUSTAINABILITY Points";
	public static final String CREDITED_LOYALTY_POINTS = "Credited LOYALTY Points";
	public static final String REMOVE = "REMOVE";
	public static final String POINTS_REDEEMED = "POINTS REDEEMED";
	public static final String REDEMPTION_ARE_ALLOWED_ONLY_ON_MONDAY = "Redemption are allowed only on monday's";
	public static final String REDEMPTION_NOT_ALLOWED= "The last date of points redemption was 20th of April 2020 by 9 pm.";
	public static final String REDEMPTION_LAST_DATE= "2020-04-20 21:00:00";

	public static final String CREDITED_SUSTAINABILITY_POINTS_MESSAGE = "Dear <Customer>! you have returned all delivery bags for <Month Name> month you have been credited with <Points> SUSTAINABILITY points.";
	public static final String QUALITY_OF_PRODUCTS_DELIVERED = "Quality of products delivered";
	public static final String PRICE_OF_PRODUCTS_DELIVERED = "Price of products delivered";
	public static final String ON_TIME_DELIVERY_OF_PRODUCTS = "On-time delivery of products";
	public static final String QUALITY_OF_SERVICE_DELIVERED = "Quality of service delivered";
	public static final String PRICE_OF_SERVICE_PROVIDED = "Price of service provided";
	public static final String TIMELINESS_OF_SERVICE_DELIVERED = "Timeliness of service delivered ";
	public static final String THANK_YOU_FOR_RATING = "Thanks for your time! We value your feedback.";
	public static final String APP_VERSION_UPDATED = "App version updated successfully";
	
	
	public static final String FILE_CANNOT_BE_NULL = "File cannot be null..!";
	public static final String UNABLE_TO_READ = "Unable to read given file..!";
	public static final Object SPECIFIER = "%s";
	public static final String UNABLE_TO_CLOSE_FILE = "Unable to close file ";
	public static final String FILE_CANNOT_BE_EMPTY = "File cannot be empty";
	
	public static final String SOCIETY_HJAVAILABILITY= "Hj Availability is either 0 for No- Products and Services or 1 for Services only or 2 -Both Products and Services are available in this society ";
	public static final String REFFEREDBY = "refferedBy";
	public static final String REFFEREDTO = "refferedTo";
	public static final String REFFEREDBY_HOMEJINY = "Homejiny_Referral";
}
