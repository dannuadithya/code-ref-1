package com.homejiny.customer.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class PushNotificationRequest {

	private long orderId;
	private long offerId;
	private long serviceId;
	private long productId;
	private long vendorId;
	private long customerId;
	private long serviceRequestId;
	private String screenflow;
	private String title;
	private String message;
	private String topic;
	private String token;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getOrderId() {
		return orderId;
	}

	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	public long getOfferId() {
		return offerId;
	}

	public void setOfferId(long offerId) {
		this.offerId = offerId;
	}

	public long getServiceId() {
		return serviceId;
	}

	public void setServiceId(long serviceId) {
		this.serviceId = serviceId;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public long getVendorId() {
		return vendorId;
	}

	public void setVendorId(long vendorId) {
		this.vendorId = vendorId;
	}

	public long getServiceRequestId() {
		return serviceRequestId;
	}

	public void setServiceRequestId(long serviceRequestId) {
		this.serviceRequestId = serviceRequestId;
	}

	public String getScreenflow() {
		return screenflow;
	}

	public void setScreenflow(String screenflow) {
		this.screenflow = screenflow;
	}

	public PushNotificationRequest() {
	}

	public PushNotificationRequest(String title, String messageBody, String topicName) {
		this.title = title;
		this.message = messageBody;
		this.topic = topicName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	@Override
	public String toString() {
		return "PushNotificationRequest [title=" + title + ", message=" + message + ", topic=" + topic + ", token="
				+ token + "]";
	}
}
