package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.ViewCustomerDetails;

/**
 * @author brahmaiam
 *
 */
@Service
public class FetchCustomerDetailsCommand implements Command<Long, ResponseEntity<ViewCustomerDetails>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<ViewCustomerDetails> excute(Long request) {

		ViewCustomerDetails viewCustomerDetails;

		if (request == null) {
			viewCustomerDetails = new ViewCustomerDetails();
			viewCustomerDetails.setMessage("Invalid inputs");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(viewCustomerDetails);
		}
		return customerService.fetchCustomerDetails(request);
	}
}
