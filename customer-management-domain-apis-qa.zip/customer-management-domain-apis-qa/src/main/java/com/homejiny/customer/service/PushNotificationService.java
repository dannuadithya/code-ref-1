package com.homejiny.customer.service;

import java.math.BigInteger;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.homejiny.customer.adapter.PushNotificationAdapter;
import com.homejiny.customer.common.ConditionalConstants;
import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.PushNotifications;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.repository.PushNotificationRepository;
import com.homejiny.customer.request.PushNotificationRequest;
import com.homejiny.customer.response.PushNotificationResponse;

@Service
public class PushNotificationService {
	private static final Logger logger = LoggerFactory.getLogger(PushNotificationService.class);

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	PushNotificationRepository pushNotificationRepository;

	@Autowired
	PushNotificationAdapter pushNotificationAdapter;

	@Scheduled(cron = ConditionalConstants.CUSTOMER_SIGNUP_INCOMPLETE)
	// @Scheduled(cron = "0 0/2 * * * ?")
	public void sendPushNotificationToIncomepleteSignUp() {
		logger.info("sendPushNotificationToIncomepleteSignUp() started");

		List<Customer> customerList = customerRepository.findByHasAddressOrHasAddressIsNull(false);
		for (Customer customer : customerList) {
			if (customer.getDeviceToken() != null) {
				PushNotifications pushNotifications = pushNotificationRepository.findByTitleName("Signup Incomplete");
				logger.info("pushNotifications Title :" + pushNotifications.getTitleName() + " for Customer_Id"
						+ customer.getId());
				PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();
				pushNotificationRequest.setTitle(pushNotifications.getTitleName());
				pushNotificationRequest.setMessage(pushNotifications.getMessage());
				pushNotificationRequest.setToken(customer.getDeviceToken());
				pushNotificationRequest.setTopic("");
				pushNotificationRequest.setScreenflow("AddressDetails");
				PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
						.sendPushNotification(pushNotificationRequest);
				if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
					logger.info("Rest API call failed, Reason : " + Constants.REST_API_CALL_FAILED);
				}
			} else {
				logger.info("Device Token Not Found for this Customer Id :" + customer.getId());
			}
		}
		logger.info("sendPushNotificationToIncomepleteSignUp() ended");
	}

	//@Scheduled(cron = "0 0/1 * * * ?")
	//@Scheduled(cron = ConditionalConstants.CUSTOMER_ORDER_CUTTOFFWARNING)
	public void sendPushNotificationToOrderCutOffWarning() {
		logger.info("sendPushNotificationToOrderCutOffWarning() started");
		List<Customer> customerList = customerRepository.findAll();
		for (Customer customer : customerList) {
			if (customer.getDeviceToken() != null) {
				PushNotifications pushNotifications = pushNotificationRepository
						.findByTitleName("Order cutoff time approaching!");
				logger.info("pushNotifications Title :" + pushNotifications.getTitleName() + " for Customer_Id"
						+ customer.getId());
				PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();
				if (customer.getFirstName() != null) {
					String customerFirstName = customer.getFirstName();
					String message = pushNotifications.getMessage();
					message = message.replace("<Customer First Name>", customerFirstName);
					pushNotificationRequest.setTitle(pushNotifications.getTitleName());
					pushNotificationRequest.setMessage(message);
					pushNotificationRequest.setToken(customer.getDeviceToken());
					pushNotificationRequest.setTopic("");
					pushNotificationRequest.setScreenflow("homejiny");
					PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
							.sendPushNotification(pushNotificationRequest);
					if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
						logger.info("Rest API call failed, Reason : " + Constants.REST_API_CALL_FAILED);
					}
				}
			} else {
				logger.info("Device Token Not Found for this Customer Id :" + customer.getId());
			}
		}
		logger.info("sendPushNotificationToOrderCutOffWarning() ended");
	}

	//@Scheduled(cron = ConditionalConstants.CUSTOMER_WALLET_LOWBALANCE)
	//@Scheduled(cron = "0 0/15 * * * ?")
	public void SendNotificationToLowWalletBalance() {
		Object[][] getWalletDetails = customerRepository.getAllCustomersWalletBalance();
		for (Object[] walletDetails : getWalletDetails) {
			logger.info("Fecth customer details with wallet id:: "+walletDetails[0]);
			try {
				Customer customerDetails = customerRepository
						.findByWalletIdAndHasAddress(((BigInteger) walletDetails[0]).longValue(), true);
				if (customerDetails != null) {
					if (customerDetails.getDeviceToken() != null) {
						PushNotifications pushNotifications = pushNotificationRepository
								.findByTitleName("Low Wallet Balance!");
						logger.info("pushNotifications Title :" + pushNotifications.getTitleName() + " for Customer_Id"
								+ customerDetails.getId());
						PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();
						String totalBalance = String.valueOf(walletDetails[2]);
						String message = pushNotifications.getMessage();
						message = message.replace("<XXX.XX>", totalBalance);
						pushNotificationRequest.setScreenflow("WalletDetails");
						pushNotificationRequest.setTitle(pushNotifications.getTitleName());
						pushNotificationRequest.setMessage(message);
						pushNotificationRequest.setToken(customerDetails.getDeviceToken());
						pushNotificationRequest.setTopic("");
						PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
								.sendPushNotification(pushNotificationRequest);
						logger.info("Started to send pushnotification for customer id:: " + customerDetails.getId()
								+ " with title:: " + pushNotificationRequest.getTitle());
						if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
							logger.info("Rest API call failed, Reason : " + Constants.REST_API_CALL_FAILED);
						}
					} else {
						logger.info("Device Token Not Found for this Customer Id :" + customerDetails.getId());
					}
				}
				else {
					logger.info("[ALERT] customer deatils are not found for wallet id:::"+walletDetails[0]);
				}
				logger.info("SendNotificationToLowWalletBalance() ended");

			} catch (Exception e) {
				logger.info("[ALERT] exception occures while sending Low Wallet Balance! notification for wallet id:::"+walletDetails[0]+ " Exception message:: "+e.getMessage());
			}
		}
	}
}
