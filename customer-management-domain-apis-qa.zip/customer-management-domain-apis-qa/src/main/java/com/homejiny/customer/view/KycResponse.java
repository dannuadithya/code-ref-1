package com.homejiny.customer.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class KycResponse {

	private long id;
	private Boolean hasKyc;
	private String status;
	private String message;
	private String imageUrl;

	public Boolean getHasKyc() {
		return hasKyc;
	}

	public void setHasKyc(Boolean hasKyc) {
		this.hasKyc = hasKyc;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}

}
