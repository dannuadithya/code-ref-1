package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.CustomerRequest;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.Response;

/**
 * @author brahmaiam
 *
 */
@Service
public class UpdateCustomerCommand implements Command<CustomerRequest, ResponseEntity<Response>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<Response> excute(CustomerRequest request) {

		if (request == null) {
			Response response = new Response();
			response.setMessage("Invalid Inputs");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}
		return ResponseEntity.status(HttpStatus.OK).body(customerService.updateCustomerDetails(request));
	}
}
