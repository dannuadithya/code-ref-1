package com.homejiny.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.HJProvide;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerAddress;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerAddressRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.view.HJProvides;
import com.homejiny.customer.view.ViewResponse;

@Service
public class HJAvailabilityService {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	CustomerAddressRepository customerAddressRepository;

	private static Logger LOGGER = LoggerFactory.getLogger(HJAvailabilityService.class);

	public ViewResponse getHJAvailabilityDetails(long customerId) {
		LOGGER.info("started to fetch HJ providing details for customer with id--- " + customerId);
		Optional<Customer> customerEntity = customerRepository.findById(customerId);
		if (!customerEntity.isPresent()) {
			throw new CustomerNotFoundException("Customer with id: " + customerId + "not found");
		}
		Optional<CustomerAddress> customerAddress = customerAddressRepository.findByCustomer(customerEntity.get());
		List<HJProvides> hjProvidesList = new ArrayList<>();
		if (customerAddress.isPresent()) {
			HJProvides hjProvides = new HJProvides();
			hjProvides.setProvides(HJProvide.PRODUCTS);
			HJProvides hjProvides2 = new HJProvides();
			hjProvides2.setProvides(HJProvide.SERVICES);
					hjProvides.setStatus(true);
				hjProvides2.setStatus(true);
			/*	switch ((int) customerAddress.get().getSocietyId().getHjAvailability()) {
				case 0:
					hjProvides.setMessage(Constants.PRODUCT_AVAILABILITY);
					hjProvides.setStatus(false);
					hjProvides2.setMessage(Constants.SERVICE_AVAILABILITY);
					hjProvides2.setStatus(false);
					break;
				case 1:
					hjProvides.setMessage(Constants.PRODUCT_AVAILABILITY);
					hjProvides.setStatus(false);
					hjProvides2.setStatus(true);
					break;
				case 2:
					hjProvides.setStatus(true);
					hjProvides2.setStatus(true);
					break;
				default:
					hjProvides.setMessage(Constants.PRODUCT_AVAILABILITY);
					hjProvides.setStatus(false);
					hjProvides2.setMessage(Constants.SERVICE_AVAILABILITY);
					hjProvides2.setStatus(false);
				}*/
				/*} else {
				hjProvides.setStatus(true);
				hjProvides2.setStatus(true);
				hjProvides.setMessage(Constants.PRODUCT_AVAILABILITY);
				hjProvides.setStatus(false);
				hjProvides2.setMessage(Constants.SERVICE_AVAILABILITY);
				hjProvides2.setStatus(false);
			}*/
			hjProvidesList.add(hjProvides);
			hjProvidesList.add(hjProvides2);
		}
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatus(Constants.SUCCESS);
		viewResponse.setData(hjProvidesList);
		return viewResponse;

	}

}
