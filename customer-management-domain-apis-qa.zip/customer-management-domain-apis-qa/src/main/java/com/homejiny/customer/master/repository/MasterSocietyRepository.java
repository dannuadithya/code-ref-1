package com.homejiny.customer.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.Area;
import com.homejiny.customer.master.entity.Society;

/**
 * @author brahmaiam
 *
 */
@Repository
public interface MasterSocietyRepository extends JpaRepository<Society, Long> {

	List<Society> findByArea(Area area);

	Society findBySocietyName(String societyName);

	Society findBySocietyNameAndArea(String societyName, Area area);

	List<Society> findByAreaAndStatus(Area area, String status);

	List<Society> findAllByOrderByDisplayOrderAsc();


}
