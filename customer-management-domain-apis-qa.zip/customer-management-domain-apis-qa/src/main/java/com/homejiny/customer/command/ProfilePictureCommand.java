package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.ProfilePictureRequest;
import com.homejiny.customer.service.ProfilePictureService;
import com.homejiny.customer.view.ProfilePictureResponse;

@Service
public class ProfilePictureCommand implements Command<ProfilePictureRequest, ResponseEntity<ProfilePictureResponse>> {

	@Autowired
	ProfilePictureService profilePictureService;

	public ResponseEntity<ProfilePictureResponse> excute(ProfilePictureRequest profilePictureRequest) {
		// TODO Auto-generated method stub
		return ResponseEntity.status(HttpStatus.OK)
				.body(profilePictureService.addProfilePicture(profilePictureRequest));
	}

}
