package com.homejiny.customer.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerRewardPointLog;

@Repository
public interface CustomerRewardPointLogRepository extends JpaRepository<CustomerRewardPointLog, Long> {

	List<CustomerRewardPointLog> findByCustomerId(Customer customerId);

	List<CustomerRewardPointLog> findByCustomerIdOrderByCreatedAtAsc(Customer customerId);

//	List<CustomerRewardPointLog> findByCustomerIdOrderByCreatedAtDesc(Customer customer);

	Page<CustomerRewardPointLog> findByCustomerIdOrderByCreatedAtDesc(Customer customer, Pageable pageable);



}
