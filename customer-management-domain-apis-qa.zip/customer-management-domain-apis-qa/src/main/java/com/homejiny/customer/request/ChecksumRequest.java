package com.homejiny.customer.request;

public class ChecksumRequest {


	private String amount;

	private String appName;
	private String merchantUniqueRef;
	private long walletId;


	public String getMerchantUniqueRef() {
		return merchantUniqueRef;
	}

	public void setMerchantUniqueRef(String merchantUniqueRef) {
		this.merchantUniqueRef = merchantUniqueRef;
	}

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public long getWalletId() {
		return walletId;
	}

	public void setWalletId(long walletId) {
		this.walletId = walletId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

}
