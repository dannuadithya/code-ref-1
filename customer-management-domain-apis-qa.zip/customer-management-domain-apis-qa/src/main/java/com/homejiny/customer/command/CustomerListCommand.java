package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.CustomerListRequest;
import com.homejiny.customer.service.AdminCustomerSearchService;
import com.homejiny.customer.view.CustomerSearchResponse;

@Service
public class CustomerListCommand implements Command<CustomerListRequest, ResponseEntity<CustomerSearchResponse>> {

	@Autowired
	AdminCustomerSearchService customerListService;

	public ResponseEntity<CustomerSearchResponse> excute(CustomerListRequest customerListRequest) {
		return customerListService.getCustomerList(customerListRequest);

	}

}
