package com.homejiny.customer.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.Block;
import com.homejiny.customer.master.entity.Floor;

/**
 * @author brahmaiam
 *
 */
@Repository
public interface FloorRepository extends JpaRepository<Floor, Long> {
	List<Floor> findByBlock(Block block);

	Floor findByFloorNameAndBlock(String floorName, Block block);

	List<Floor> findByBlockOrderByFloorNameAsc(Block block);

	List<Floor> findByBlockAndStatusOrderByFloorNameAsc(Block block, String status);

}
