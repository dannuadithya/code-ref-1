package com.homejiny.customer.authorization;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class AuthTokenMissingException extends RuntimeException {

	public AuthTokenMissingException(String errMsg) {
		super(errMsg);
	}
	
	public AuthTokenMissingException(String message, Throwable cause) {
        super(message, cause);
    }
}

