package com.homejiny.customer.view;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class InviteFriendsResponse extends Response {

	private String generateCode;
	private String link;
	private String referrerCode;

	public String getReferrerCode() {
		return referrerCode;
	}

	public void setReferrerCode(String referrerCode) {
		this.referrerCode = referrerCode;
	}

	public String getGenerateCode() {
		return generateCode;
	}

	public void setGenerateCode(String generateCode) {
		this.generateCode = generateCode;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

}
