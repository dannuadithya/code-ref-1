package com.homejiny.customer.master.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.exception.AreaNotFoundException;
import com.homejiny.customer.exception.BlockNotFoundException;
import com.homejiny.customer.exception.CityNotFoundException;
import com.homejiny.customer.exception.FloorNotFoundException;
import com.homejiny.customer.exception.HouseNumberNotFoundException;
import com.homejiny.customer.exception.PINCodeNotFoundException;
import com.homejiny.customer.exception.SocietyNotFoundException;
import com.homejiny.customer.exception.StateNotFoundException;
import com.homejiny.customer.master.entity.Area;
import com.homejiny.customer.master.entity.Block;
import com.homejiny.customer.master.entity.City;
import com.homejiny.customer.master.entity.Floor;
import com.homejiny.customer.master.entity.HouseNumber;
import com.homejiny.customer.master.entity.PINCode;
import com.homejiny.customer.master.entity.Society;
import com.homejiny.customer.master.entity.State;
import com.homejiny.customer.master.repository.AreaRepository;
import com.homejiny.customer.master.repository.BlockRepository;
import com.homejiny.customer.master.repository.FloorRepository;
import com.homejiny.customer.master.repository.HouseNumberRepository;
import com.homejiny.customer.master.repository.MasterCityRepository;
import com.homejiny.customer.master.repository.MasterSocietyRepository;
import com.homejiny.customer.master.repository.MasterStateRepository;
import com.homejiny.customer.master.repository.PINCodeRepository;
import com.homejiny.customer.master.view.ResponseView;
import com.homejiny.customer.master.view.ViewCity;
import com.homejiny.customer.master.view.ViewData;
import com.homejiny.customer.master.view.ViewPinCodeData;
import com.homejiny.customer.master.view.ViewState;
import com.homejiny.customer.master.view.ViewStateAndCity;

/**
 * @author brahmaiam
 *
 */
@Service
public class MasterService {

	private static final Logger logger = LoggerFactory.getLogger(MasterService.class);
	@Autowired
	PINCodeRepository pinCodeRepository;

	@Autowired
	MasterStateRepository masterStateRepository;

	@Autowired
	MasterCityRepository masterCityRepository;

	@Autowired
	AreaRepository areaRepository;

	@Autowired
	MasterSocietyRepository masterSocietyRepository;

	@Autowired
	BlockRepository blockRepository;

	@Autowired
	FloorRepository floorRepository;

	@Autowired
	HouseNumberRepository houseNumberRepository;

	/**
	 * This API is used to fetch Customer State And City By PostalCode
	 * 
	 * @param request
	 * @return {@link ViewStateAndCity}
	 */
	public ViewStateAndCity fetchCustomerStateAndCityByPostalCode(Long request) {
		ViewStateAndCity viewStateAndCity = new ViewStateAndCity();
		PINCode pinCode = pinCodeRepository.findByPinCodeNumberAndStatus(request, Constants.STATUS);
		if (pinCode == null) {
			throw new PINCodeNotFoundException(Constants.INVALID_PIN_CODE);
		}

		List<Area> areas = areaRepository.findAllByPinCodeAndStatus(pinCode, Constants.STATUS);

		if (areas.isEmpty()) {
			throw new CityNotFoundException("Areas are not available with PIN code " + request);
		}
		IntStream.range(0, areas.size()).forEach(index -> {
			Area area = areas.get(index);
			if (area.getCity() == null || area.getCity().getState() == null || area.getCity().getName() == null) {
				throw new CityNotFoundException(Constants.STATE_NOT_FOUND_WITH_PIN_CODE + request);
			}
			ViewState viewState = new ViewState();
			viewState.setId(area.getCity().getState().getId());
			viewState.setName(area.getCity().getState().getName());

			ViewCity viewCity = new ViewCity();
			viewCity.setId(area.getCity().getId());
			viewCity.setName(area.getCity().getName());

			viewStateAndCity.setCity(viewCity);
			viewStateAndCity.setState(viewState);
		});
		return viewStateAndCity;
	}
	
	
	public ResponseView fetchAllPostalCodes() {
		
		List<PINCode> pinCodes = pinCodeRepository.findAllByStatus(Constants.STATUS);
		List<Object> pinCodeList = new ArrayList<>();
		pinCodes.stream().forEach(pincode ->{
			ViewPinCodeData pinCodeData = new ViewPinCodeData();
			pinCodeData.setId(pincode.getId());
			pinCodeData.setPinCode(pincode.getPinCodeNumber());
			pinCodeList.add(pinCodeData);
		});
		
		return setResponse(pinCodeList);
	}

	/**
	 * This api is used to fetch All States
	 * 
	 * @return {@link ResponseView}
	 */
	public ResponseView fetchAllStates() {
		logger.info("Entering into fetchAllStates method");
		List<State> states = masterStateRepository.findAllByStatus(Constants.STATUS);
		List<Object> listOfStates = new ArrayList<>();
		IntStream.range(0, states.size()).forEach(index -> {
			State state = states.get(index);
			ViewData viewData = new ViewData();
			viewData.setId(state.getId());
			viewData.setName(state.getName());
			listOfStates.add(viewData);
		});
		return setResponse(listOfStates);
	}

	/**
	 * This api is used to fetch All Cities By State.
	 * 
	 * @param stateName
	 * @return {@link ResponseView}
	 */
	public ResponseView fetchAllCitiesByState(Long stateId) {
		logger.info("Entering into fetchAllCitiesByState method");
		Optional<State> optionalState = masterStateRepository.findById(stateId);
		if (!optionalState.isPresent()) {
			throw new StateNotFoundException(Constants.INVALID_INPUTS);
		}
		List<City> cities = masterCityRepository.findByStateAndStatus(optionalState.get(), Constants.STATUS);
		if (cities.isEmpty()) {
			throw new CityNotFoundException(Constants.CITIES_ARE_NOT_AVAILABLE_WITH_STATE + stateId);
		}
		List<Object> listOfCities = new ArrayList<>();
		IntStream.range(0, cities.size()).forEach(index -> {
			City city = cities.get(index);
			ViewData viewData = new ViewData();
			viewData.setId(city.getId());
			viewData.setName(city.getName());
			listOfCities.add(viewData);
		});
		return setResponse(listOfCities);
	}

	/**
	 * This api is used fetch All Areas By City.
	 * 
	 * @param cityName
	 * @return {@link ResponseView}
	 */
	public ResponseView fetchAllAreasByCity(Long cityId) {
		logger.info("Entering into fetchAllAreasByCity method");
		Optional<City> optionalCity = masterCityRepository.findById(cityId);
		if (!optionalCity.isPresent()) {
			throw new CityNotFoundException(Constants.INVALID_INPUTS);
		}
		List<Area> areas = areaRepository.findByCityAndStatus(optionalCity.get(), Constants.STATUS);
		if (areas.isEmpty()) {
			throw new AreaNotFoundException(Constants.AREAS_ARE_NOT_AVAILABLE_WITH_CITY + cityId);
		}
		List<Object> listOfAreas = new ArrayList<>();
		IntStream.range(0, areas.size()).forEach(index -> {
			Area area = areas.get(index);
			ViewData viewData = new ViewData();
			viewData.setId(area.getId());
			viewData.setName(area.getAreaName());
			listOfAreas.add(viewData);
		});
		return setResponse(listOfAreas);
	}

	/**
	 * This method is used to fetch all societies by Area and city
	 * 
	 * @param fetchSocietiesRequest
	 * @return {@link ResponseView}
	 */
	public ResponseView fetchAllSocietiesByArea(Long areaId) {
		logger.info("Entering into fetchAllSocietiesByArea method");
		Optional<Area> optionalArea = areaRepository.findById(areaId);
		if (!optionalArea.isPresent()) {
			throw new AreaNotFoundException(Constants.INVALID_INPUTS);
		}
		List<Society> societies = masterSocietyRepository.findByAreaAndStatus(optionalArea.get(), Constants.STATUS);
		if (societies.isEmpty()) {
			throw new SocietyNotFoundException(Constants.SOCIETIES_ARE_NOT_AVAILABLE_WITH_AREA_NAME + areaId);
		}
		List<Object> listOfSocieties = new ArrayList<>();
		IntStream.range(0, societies.size()).forEach(index -> {
			Society society = societies.get(index);
			ViewData viewData = new ViewData();
			viewData.setId(society.getId());
			viewData.setName(society.getSocietyName());
			listOfSocieties.add(viewData);
		});
		return setResponse(listOfSocieties);
	}

	/**
	 * This api used to fetch All Blocks By Society and Area.
	 * 
	 * @param fetchBloksRequest
	 * @return {@link ResponseView}
	 */
	public ResponseView fetchAllBlocksBySociety(Long societyId) {
		logger.info("Entering into fetchAllBlocksBySociety method");
		Optional<Society> optionalSociety = masterSocietyRepository.findById(societyId);
		if (!optionalSociety.isPresent()) {
			throw new SocietyNotFoundException(Constants.INVALID_INPUTS);
		}
		List<Block> blocks = blockRepository.findBySocietyAndStatusOrderByBlockNameAsc(optionalSociety.get(),Constants.STATUS);
		if (blocks.isEmpty()) {
			throw new BlockNotFoundException(Constants.BLOCKS_ARE_NOT_AVAILABLE_WITH_SOCIETY_NAME + societyId);
		}
		List<Object> listOfBlocks = new ArrayList<>();
		IntStream.range(0, blocks.size()).forEach(index -> {
			Block block = blocks.get(index);
			ViewData viewData = new ViewData();
			viewData.setId(block.getId());
			viewData.setName(block.getBlockName());
			listOfBlocks.add(viewData);
		});
		return setResponse(listOfBlocks);
	}

	/**
	 * This api is used to fetch All Floors By Block name and Society.
	 * 
	 * @param fetchFloorsRequest
	 * @return {@link ResponseView}
	 */
	public ResponseView fetchAllFloorsByBlock(Long blockId) {
		logger.info("Entering into fetchAllFloorsByBlock method");
		Optional<Block> optionalBlock = blockRepository.findById(blockId);
		if (!optionalBlock.isPresent()) {
			throw new BlockNotFoundException(Constants.INVALID_INPUTS);
		}
		List<Floor> floors = floorRepository.findByBlockAndStatusOrderByFloorNameAsc(optionalBlock.get(), Constants.STATUS);
		if (floors.isEmpty()) {
			throw new SocietyNotFoundException(Constants.FLOORS_ARE_NOT_AVAILABLE_WITH_BLOCK_NAME + blockId);
		}
		List<Object> listOfFloors = new ArrayList<>();
		IntStream.range(0, floors.size()).forEach(index -> {
			Floor floor = floors.get(index);
			ViewData viewData = new ViewData();
			viewData.setId(floor.getId());
			viewData.setName(floor.getFloorName());
			listOfFloors.add(viewData);
		});
		return setResponse(listOfFloors);
	}

	/**
	 * This api is used to fetch All HouseNumbers By Block And Floor.
	 * 
	 * @param fetchHouseNumberRequest
	 * @return {@link ResponseView}
	 */
	public ResponseView fetchAllHouseNumbersByBlockAndFloor(Long floorId) {
		logger.info("Entering into fetchAllHouseNumbersByBlockAndFloor method");
		Optional<Floor> optionalFloor = floorRepository.findById(floorId);
		if (!optionalFloor.isPresent()) {
			throw new FloorNotFoundException(Constants.INVALID_INPUTS);
		}
		List<HouseNumber> houseNumbers = houseNumberRepository.findByFloorAndStatusOrderByHouseNumberAsc(optionalFloor.get(),Constants.STATUS);
		if (houseNumbers.isEmpty()) {
			throw new HouseNumberNotFoundException(
					Constants.HOUSE_NUMBERS_ARE_NOT_AVAILABLE_WITH_BLCAK_NAME_AND_FLOOR_NAME + floorId);
		}
		List<ViewData> listOfHouseNumbers = new ArrayList<>();
		getHouseNumbers(houseNumbers).values().forEach(index -> {
			ViewData viewData = new ViewData();			
			index.forEach(indexid -> {				
			viewData.setId(indexid.getId());
			viewData.setName(indexid.getHouseNumber());			
			});
			listOfHouseNumbers.add(viewData);
		});
		List<ViewData> listOfHouseNumber= listOfHouseNumbers.stream().sorted(Comparator.comparing(ViewData::getName))
				.collect(Collectors.toList());
				
		List<Object> a = new ArrayList<>();
		a.addAll(listOfHouseNumber);
		return setResponse(a);
	}

	private HashMap<String, List<HouseNumber>> getHouseNumbers(List<HouseNumber> houseNumbers){
		 
		HashMap<String, List<HouseNumber>>  houseNumberMap = new HashMap<>();
		houseNumbers.stream().forEach(houseNumber -> {
			List<HouseNumber> houseNumbersList = new ArrayList<>();
			if (houseNumberMap.containsKey(houseNumber.getHouseNumber())) {
				houseNumbersList = houseNumberMap.get(houseNumber.getHouseNumber());
				houseNumbersList.add(houseNumber);
				houseNumberMap.put(houseNumber.getHouseNumber(), houseNumbersList);
			} else {
				houseNumbersList.add(houseNumber);
				houseNumberMap.put(houseNumber.getHouseNumber(), houseNumbersList);
			}
		});
		return houseNumberMap;
	}
	
	/**
	 * This method is used to set Response.
	 * 
	 * @param listOfBlocks
	 * @return {@link ResponseView}
	 */
	private ResponseView setResponse(List<Object> lists) {
	
		ResponseView responseView = new ResponseView();
		responseView.setStatus(Constants.SUCCESS);
		responseView.setData(lists);
		return responseView;
	}
}