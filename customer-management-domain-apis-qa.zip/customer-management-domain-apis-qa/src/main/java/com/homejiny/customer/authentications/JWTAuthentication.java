package com.homejiny.customer.authentications;

import java.time.LocalDateTime;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.DateAndTimeUtil;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JWTAuthentication {

	@Value("${jwt.token.days}")
	private Integer expireDays;

	private static final String SECRET_KEY = "70c349b2-9b18-4dc3-b5f6-57b10cc74f56";

	public String generateToken(String mobile) {
		LocalDateTime localDateTime = DateAndTimeUtil.now();
		Date today = java.sql.Timestamp.valueOf(localDateTime);
		Date expiryDate = java.sql.Timestamp.valueOf(localDateTime.plusDays(expireDays.longValue()));
		String compact = Jwts.builder().setSubject(mobile).setIssuedAt(today)
				.setExpiration(expiryDate)
				.signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
		return compact;
	}

	public Claims verifyToken(String token) {
		try {
			final Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
			if (claims == null) {
				return null;
			}
			Date currentDate = new Date();
			if (claims.getExpiration().compareTo(currentDate) >= 0) {
				return claims;
			}
		} catch (Exception e) {
			return null;
		}
		return null;
	}
}