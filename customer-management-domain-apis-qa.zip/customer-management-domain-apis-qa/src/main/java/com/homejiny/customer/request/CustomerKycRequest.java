package com.homejiny.customer.request;

import org.springframework.web.multipart.MultipartFile;

import com.homejiny.customer.common.KycImageView;

public class CustomerKycRequest {

	private long customerId;
	private String kycdocNumber;
	private MultipartFile mediaFile;
	private KycImageView imageView;
	private String kycCode;
	private Boolean hasKyc;

	public KycImageView getImageView() {
		return imageView;
	}

	public void setImageView(KycImageView imageView) {
		this.imageView = imageView;
	}

	public Boolean getHasKyc() {
		return hasKyc;
	}

	public void setHasKyc(Boolean hasKyc) {
		this.hasKyc = hasKyc;
	}

	public String getKycCode() {
		return kycCode;
	}

	public void setKycCode(String kycCode) {
		this.kycCode = kycCode;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getKycdocNumber() {
		return kycdocNumber;
	}

	public void setKycdocNumber(String kycdocNumber) {
		this.kycdocNumber = kycdocNumber;
	}

	public MultipartFile getMediaFile() {
		return mediaFile;
	}

	public void setMediaFile(MultipartFile mediaFile) {
		this.mediaFile = mediaFile;
	}

}