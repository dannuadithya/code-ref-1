package com.homejiny.customer.view;

public class RewardTypeAndPoints {
	private String rewardType;
	private long points;

	public String getRewardType() {
		return rewardType;
	}

	public void setRewardType(String rewardType) {
		this.rewardType = rewardType;
	}

	public long getPoints() {
		return points;
	}

	public void setPoints(long points) {
		this.points = points;
	}

}
