package com.homejiny.customer.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerRatingForProductAndServices;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerRatingForProductAndServicesRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.request.CustomerRatingRequest;
import com.homejiny.customer.request.CustomerSubRatingRequest;
import com.homejiny.customer.response.AgreeTermsAndConditionsReponse;
import com.homejiny.customer.response.CustomerRatingResponse;
import com.homejiny.customer.response.RatingResponse;
import com.homejiny.customer.view.ShowCustomerPopUpRating;
import com.homejiny.customer.view.ShowCustomerRating;

@Service
public class CustomerRating {

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	CustomerRatingForProductAndServicesRepository customerRatingForProductAndServicesRepository;

	@Value("${cloud.aws.db_url}")
	private String cloudAwsDBURL;

	public RatingResponse showCustomerRating(Long customerId) {
		
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("dd-MM-yyyy");

		List<ShowCustomerRating> showCustomerRatingList = new ArrayList<>();

		Object[][] customerRating = customerRepository.showCustomerRating(customerId, customerId);

		for (Object[] objects : customerRating) {

			ShowCustomerRating showCustomerRating = new ShowCustomerRating();

			showCustomerRating.setId((BigInteger) objects[0]);
			showCustomerRating.setCustomerId((BigInteger) objects[1]);
			showCustomerRating.setOrderId((String) objects[2]);
			Timestamp orderDate = (Timestamp) objects[3];
			LocalDate oDate = orderDate.toLocalDateTime().toLocalDate();
			showCustomerRating.setDeliveryDate(oDate.format(formatter1));
			showCustomerRating.setType((String) objects[7]);
			showCustomerRating.setSubCategory((String) objects[4]);
			showCustomerRating.setImage(cloudAwsDBURL + (String) objects[6]);
			showCustomerRating.setCategory((String) objects[5]);
			showCustomerRatingList.add(showCustomerRating);
		}

		RatingResponse response = new RatingResponse();
		response.setStatus("success");
		response.setMessage("order details fetched successfully");
		response.setData(showCustomerRatingList);

		return response;

	}

	public ResponseEntity<CustomerRatingResponse> customerRating(CustomerRatingRequest request) {
		CustomerRatingResponse customerRatingResponse = new CustomerRatingResponse();

		Optional<Customer> customer = customerRepository.findById(request.getCustomerId());

		if (!customer.isPresent()) {
			throw new CustomerNotFoundException(
					Constants.NO_CUSTOMER_EXIST_WITH_CUSTOMER_ID_IS + request.getCustomerId());
		}
		CustomerRatingForProductAndServices customerRatingForProductAndServices = new CustomerRatingForProductAndServices();

		if (request.getRating() == 5) {
			customerRatingForProductAndServices.setCustomerId(request.getCustomerId());
			customerRatingForProductAndServices.setStarRating(request.getRating());
			customerRatingForProductAndServices.setQualityRating(request.getRating());
			customerRatingForProductAndServices.setPriceRating(request.getRating());
			customerRatingForProductAndServices.setDeliveryRating(request.getRating());
			customerRatingForProductAndServices.setCreatedAt(DateAndTimeUtil.now());
			customerRatingForProductAndServices.setUpdatedAt(DateAndTimeUtil.now());
			if (request.getType().toString().equals("PRODUCTS")) {
				customerRatingForProductAndServices.setOrderId(request.getId());
			} else {
				customerRatingForProductAndServices.setServiceOrderId((request.getId()));
			}
			customerRatingForProductAndServicesRepository.save(customerRatingForProductAndServices);
			customerRatingResponse.setCustomerId(request.getCustomerId());
			customerRatingResponse.setRating(request.getRating());
			customerRatingResponse.setMessage(Constants.THANK_YOU_FOR_RATING);
			customerRatingResponse.setStatus("Success");

			return ResponseEntity.status(HttpStatus.OK).body(customerRatingResponse);
		} else if (request.getRating() < 5 && request.getType().toString().equals("PRODUCTS")) {
			customerRatingResponse.setStatus("Success");
			customerRatingResponse.setCustomerId(request.getCustomerId());
			customerRatingResponse.setRating(request.getRating());
			customerRatingResponse.setDelivery(Constants.ON_TIME_DELIVERY_OF_PRODUCTS);
			customerRatingResponse.setPrice(Constants.PRICE_OF_PRODUCTS_DELIVERED);
			customerRatingResponse.setQuality(Constants.QUALITY_OF_PRODUCTS_DELIVERED);

			return ResponseEntity.status(HttpStatus.OK).body(customerRatingResponse);
		} else if (request.getRating() < 5 && request.getType().toString().equals("SERVICES")) {
			customerRatingResponse.setStatus("Success");
			customerRatingResponse.setCustomerId(request.getCustomerId());
			customerRatingResponse.setRating(request.getRating());
			customerRatingResponse.setDelivery(Constants.TIMELINESS_OF_SERVICE_DELIVERED);
			customerRatingResponse.setPrice(Constants.PRICE_OF_SERVICE_PROVIDED);
			customerRatingResponse.setQuality(Constants.QUALITY_OF_SERVICE_DELIVERED);

			return ResponseEntity.status(HttpStatus.OK).body(customerRatingResponse);
		}
		return null;
	}

	public AgreeTermsAndConditionsReponse customerSubRating(CustomerSubRatingRequest request) {
		AgreeTermsAndConditionsReponse agreeTermsAndConditionsReponse = new AgreeTermsAndConditionsReponse();

		CustomerRatingForProductAndServices customerRatingForProductAndServices = new CustomerRatingForProductAndServices();

		customerRatingForProductAndServices.setCustomerId(request.getCustomerId());
		customerRatingForProductAndServices.setDeliveryRating(request.getDeliveryRating());
		customerRatingForProductAndServices.setPriceRating(request.getPriceRating());
		customerRatingForProductAndServices.setQualityRating(request.getQualityRating());
		customerRatingForProductAndServices.setStarRating(request.getStarRating());
		if (request.getType().toString().equals("PRODUCTS")) {
			customerRatingForProductAndServices.setOrderId(request.getId());
		} else {
			customerRatingForProductAndServices.setServiceOrderId((request.getId()));
		}
		customerRatingForProductAndServices.setCreatedAt(DateAndTimeUtil.now());
		customerRatingForProductAndServices.setUpdatedAt(DateAndTimeUtil.now());
		customerRatingForProductAndServices.setComment(request.getText());
		customerRatingForProductAndServicesRepository.save(customerRatingForProductAndServices);

		agreeTermsAndConditionsReponse.setId(request.getCustomerId());
		agreeTermsAndConditionsReponse.setMessage(Constants.THANK_YOU_FOR_RATING);
		agreeTermsAndConditionsReponse.setStatus("success");

		return agreeTermsAndConditionsReponse;

	}

	public RatingResponse showCustomerPopUpRatingForProducts(Long ProductOrderId) {

		List<ShowCustomerPopUpRating> showCustomerPopUpRatingList = new ArrayList<ShowCustomerPopUpRating>();

		Object[][] customerPopUpRating = customerRepository.showCustomerPopUpRating(ProductOrderId);

		for (Object[] objects : customerPopUpRating) {

			ShowCustomerPopUpRating showCustomerPopUpRating = new ShowCustomerPopUpRating();

			showCustomerPopUpRating.setDeliveryRating(((BigDecimal) objects[1]).doubleValue());
			showCustomerPopUpRating.setQualityRating(((BigDecimal) objects[0]).doubleValue());
			showCustomerPopUpRating.setPriceRating(((BigDecimal) objects[2]).doubleValue());
			showCustomerPopUpRating.setStarRating(((BigDecimal) objects[3]).doubleValue());
			showCustomerPopUpRating.setComment((String) objects[6]);

			showCustomerPopUpRatingList.add(showCustomerPopUpRating);
		}

		RatingResponse response = new RatingResponse();
		response.setStatus("success");
		response.setMessage("order details fetched successfully");
		response.setData(showCustomerPopUpRatingList);

		return response;

	}

	public RatingResponse showCustomerPopUpRatingForServices(Long serviceOrderId) {

		List<ShowCustomerPopUpRating> showCustomerPopUpRatingList = new ArrayList<ShowCustomerPopUpRating>();

		Object[][] customerPopUpRating = customerRepository.showCustomerPopUpRatingForService(serviceOrderId);

		for (Object[] objects : customerPopUpRating) {

			ShowCustomerPopUpRating showCustomerPopUpRating = new ShowCustomerPopUpRating();

			showCustomerPopUpRating.setDeliveryRating(((BigDecimal) objects[1]).doubleValue());
			showCustomerPopUpRating.setQualityRating(((BigDecimal) objects[0]).doubleValue());
			showCustomerPopUpRating.setPriceRating(((BigDecimal) objects[2]).doubleValue());
			showCustomerPopUpRating.setStarRating(((BigDecimal) objects[3]).doubleValue());
			showCustomerPopUpRating.setComment((String) objects[6]);

			showCustomerPopUpRatingList.add(showCustomerPopUpRating);
		}

		RatingResponse response = new RatingResponse();
		response.setStatus("success");
		response.setMessage("service order details fetched successfully");
		response.setData(showCustomerPopUpRatingList);

		return response;

	}

}
