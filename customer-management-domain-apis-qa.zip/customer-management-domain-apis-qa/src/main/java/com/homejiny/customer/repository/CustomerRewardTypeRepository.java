package com.homejiny.customer.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerRewardPointLog;
import com.homejiny.customer.entity.CustomerRewardType;

@Repository
public interface CustomerRewardTypeRepository extends JpaRepository<CustomerRewardType, Long> {

	CustomerRewardPointLog save(CustomerRewardPointLog customerRewardPointLog);

	List<CustomerRewardType> findByCustomerId(Customer id);

	CustomerRewardType findByrewardType(Optional<CustomerRewardType> customerRewardTypeExist);

	CustomerRewardType findByCustomerIdAndRewardType(Customer customer, String rewardType);

	List<CustomerRewardType> findByCustomerIdOrderByCreatedAtDesc(Customer customer);

	Optional<CustomerRewardType> findByCustomerId(long customerId);


	List<CustomerRewardType> findByCustomerIdOrderById(Customer customer);

	CustomerRewardType findByCustomerIdAndRewardTypeAndFirstOrder(Customer customer, String string, boolean b);


}
