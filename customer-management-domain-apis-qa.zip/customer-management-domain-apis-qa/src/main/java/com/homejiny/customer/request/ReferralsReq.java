package com.homejiny.customer.request;

public class ReferralsReq {
	
	

}
