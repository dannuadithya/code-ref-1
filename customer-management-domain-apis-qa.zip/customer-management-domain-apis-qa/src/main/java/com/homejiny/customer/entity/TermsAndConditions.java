package com.homejiny.customer.entity;

import java.time.Instant;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "hj_terms_and_conditions")
@Table(name = "HJ_TERMS_AND_CONDITIONS")
public class TermsAndConditions {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "id")
	private long id;

	@Column(name = "created_time")
	private Instant createdAt;

	@Column(name = "updated_time")
	private Instant updatedAt;

	@Column(name = "TERMS_DESCRIPITON")
	private String termsDescripiton;

	@Column(name = "CONDITION_TO")
	private TermsAndConditionsEnum conditionTo;

	public long getId() {
		return id;
	}

	public Instant getCreatedAt() {
		return createdAt;
	}

	public Instant getUpdatedAt() {
		return updatedAt;
	}

	public String getTermsDescripiton() {
		return termsDescripiton;
	}

	public TermsAndConditionsEnum getConditionTo() {
		return conditionTo;
	}

}
