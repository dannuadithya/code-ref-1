package com.homejiny.customer.entity;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.lang.NonNull;

/**
 * @author brahmaiam
 *
 */
@Entity
@Table(name = "HJ_CUSTOMER")
public class Customer extends com.homejiny.customer.entity.Entity {

	@Column(name = "email")
	private String email;

	@NonNull
	@Column(name = "mobile_number", unique = true)
	private String mobileNumber;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "middle_name")
	private String middleName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "registration_step")
	private String registrationStep;

	@Column(name = "referrer_code", unique = true)
	private String referrerCode;

	@Column(name = "referral_count")
	private long referralCount;

	@Column(name = "referrer_by_id")
	private long referrerbyId;

	@Column(name = "status")
	private String status;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinTable(name = "hj_customer_media", joinColumns = @JoinColumn(name = "hj_customer_id"), inverseJoinColumns = @JoinColumn(name = "hj_media_id"))
	private Media media;

	@Column(name = "is_kyc_verified")
	private boolean isKycVerified;

	@Column(name = "ring_the_bell")
	private boolean ringTheBell;

	@Column(name = "wallet_id")
	private long walletId;

	@Column(name = "Agreed")
	private boolean agreed;

	@Column(name = "device_token")
	private String deviceToken;

	@Column(name = "has_address")
	private Boolean hasAddress;

	@Column(name = "has_email")
	private Boolean hasEmail;

	@Column(name = "has_name")
	private Boolean hasName;

	@Column(name = "has_kyc_docs")
	private Boolean hasKyc;

	@Column(name = "has_delivery_details")
	private Boolean hasDeliveryInformationDetails;
	
	@Column(name = "referrer_code_used")
	private String referrerCodeUsed;

	@Column(name="version")
	private String version;

	@Column(name="platform")
	private String platform;
	
	@Column(name="old_version")
	private String oldVersion;
	
	@Column(name="app_updated_time")
	private LocalDateTime appUpdatedTime;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public Boolean getHasAddress() {
		return hasAddress;
	}

	public void setHasAddress(Boolean hasAddress) {
		this.hasAddress = hasAddress;
	}

	public Boolean getHasEmail() {
		return hasEmail;
	}

	public void setHasEmail(Boolean hasEmail) {
		this.hasEmail = hasEmail;
	}

	public Boolean getHasName() {
		return hasName;
	}

	public void setHasName(Boolean hasName) {
		this.hasName = hasName;
	}

	public Boolean getHasKyc() {
		return hasKyc;
	}

	public void setHasKyc(Boolean hasKyc) {
		this.hasKyc = hasKyc;
	}

	public Boolean getHasDeliveryInformationDetails() {
		return hasDeliveryInformationDetails;
	}

	public void setHasDeliveryInformationDetails(Boolean hasDeliveryInformationDetails) {
		this.hasDeliveryInformationDetails = hasDeliveryInformationDetails;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Media getMedia() {
		return media;
	}

	public void setMedia(Media media) {
		this.media = media;
	}

	public boolean isKycVerified() {
		return isKycVerified;
	}

	public void setKycVerified(boolean isKycVerified) {
		this.isKycVerified = isKycVerified;
	}

	public boolean isRingTheBell() {
		return ringTheBell;
	}

	public void setRingTheBell(boolean ringTheBell) {
		this.ringTheBell = ringTheBell;
	}

	public String getRegistrationStep() {
		return registrationStep;
	}

	public void setRegistrationStep(String registrationStep) {
		this.registrationStep = registrationStep;
	}

	public long getWalletId() {
		return walletId;
	}

	public void setWalletId(long walletId) {
		this.walletId = walletId;
	}

	public long getReferrerbyId() {
		return referrerbyId;
	}

	public void setReferrerbyId(long referrerbyId) {
		this.referrerbyId = referrerbyId;
	}

	public long getReferralCount() {
		return referralCount;
	}

	public void setReferralCount(long referralCount) {
		this.referralCount = referralCount;
	}

	public String getReferrerCode() {
		return referrerCode;
	}

	public void setReferrerCode(String referrerCode) {
		this.referrerCode = referrerCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public boolean isAgreed() {
		return agreed;
	}

	public void setAgreed(boolean agreed) {
		this.agreed = agreed;
	}

	public String getReferrerCodeUsed() {
		return referrerCodeUsed;
	}

	public void setReferrerCodeUsed(String referrerCodeUsed) {
		this.referrerCodeUsed = referrerCodeUsed;
	}

	public String getOldVersion() {
		return oldVersion;
	}

	public LocalDateTime getAppUpdatedTime() {
		return appUpdatedTime;
	}

	public void setOldVersion(String oldVersion) {
		this.oldVersion = oldVersion;
	}

	public void setAppUpdatedTime(LocalDateTime appUpdatedTime) {
		this.appUpdatedTime = appUpdatedTime;
	}
	
	

}
