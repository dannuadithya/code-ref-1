package com.homejiny.customer.entity;

import java.util.HashMap;
import java.util.Map;

public enum CustomerRewardTypeEnum {
	
	PATRONAGE(1),LOYALTY(2),SUSTAINABILITY(3),REFERRAL(4);
	
	 private long value;
	 private static Map map = new HashMap<>();

	    private CustomerRewardTypeEnum(int value) {
	        this.value = value;
	    }

	    static {
	        for (CustomerRewardTypeEnum customerRewardType : CustomerRewardTypeEnum.values()) {
	            map.put(customerRewardType.value, customerRewardType);
	        }
	    }

	    public static CustomerRewardTypeEnum valueOf(long customerRewardType) {
	        return (CustomerRewardTypeEnum) map.get(customerRewardType);
	    }

	    public long getValue() {
	        return value;
	    }

}
