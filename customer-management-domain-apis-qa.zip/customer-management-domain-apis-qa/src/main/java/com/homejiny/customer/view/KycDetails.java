package com.homejiny.customer.view;

public class KycDetails {

	private String kycdocNumber;
	private String mediaFile;
	private String imageView;
	private String kycCode;
	private String kycTypeName;

	public String getImageView() {
		return imageView;
	}

	public void setImageView(String imageView) {
		this.imageView = imageView;
	}

	public String getKycCode() {
		return kycCode;
	}

	public void setKycCode(String kycCode) {
		this.kycCode = kycCode;
	}

	public String getKycTypeName() {
		return kycTypeName;
	}

	public void setKycTypeName(String kycTypeName) {
		this.kycTypeName = kycTypeName;
	}

	public String getKycdocNumber() {
		return kycdocNumber;
	}

	public void setKycdocNumber(String kycdocNumber) {
		this.kycdocNumber = kycdocNumber;
	}

	public String getMediaFile() {
		return mediaFile;
	}

	public void setMediaFile(String mediaFile) {
		this.mediaFile = mediaFile;
	}

}
