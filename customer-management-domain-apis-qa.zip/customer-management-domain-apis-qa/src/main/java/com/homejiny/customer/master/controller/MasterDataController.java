package com.homejiny.customer.master.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.homejiny.customer.command.DeliveryInformationCommand;
import com.homejiny.customer.command.UploadAdressMasterCommand;
import com.homejiny.customer.master.command.FetchAllAreasListCommand;
import com.homejiny.customer.master.command.FetchAllBlocksListCommand;
import com.homejiny.customer.master.command.FetchAllCitiesListCommand;
import com.homejiny.customer.master.command.FetchAllFloorsListCommand;
import com.homejiny.customer.master.command.FetchAllHouseNumbersListCommand;
import com.homejiny.customer.master.command.FetchAllSocietiesListCommand;
import com.homejiny.customer.master.command.FetchAllStatesListCommand;
import com.homejiny.customer.master.command.FetchCustomerStateCityCommand;
import com.homejiny.customer.master.service.MasterService;
import com.homejiny.customer.master.service.SocietyService;
import com.homejiny.customer.master.view.ResponseView;
import com.homejiny.customer.master.view.SocietyRequest;
import com.homejiny.customer.master.view.ViewSociety;
import com.homejiny.customer.master.view.ViewStateAndCity;
import com.homejiny.customer.response.ErrorResponse;
import com.homejiny.customer.util.ErrorRecord;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;


@RestController
@RequestMapping("/master/api/v2/")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class MasterDataController {

	@Autowired
	FetchCustomerStateCityCommand fetchCustomerStateCityCommand;

	@Autowired
	FetchAllAreasListCommand fetchAllAreasListCommand;

	@Autowired
	FetchAllBlocksListCommand fetchAllBlocksListCommand;

	@Autowired
	FetchAllCitiesListCommand fetchAllCitiesListCommand;

	@Autowired
	FetchAllFloorsListCommand fetchAllFloorsListCommand;

	@Autowired
	FetchAllHouseNumbersListCommand fetchAllHouseNumbersListCommand;

	@Autowired
	FetchAllSocietiesListCommand fetchAllSocietiesListCommand;

	@Autowired
	FetchAllStatesListCommand fetchAllStatesListCommand;

	@Autowired
	DeliveryInformationCommand deliveryInformationCommand;

	@Autowired
	MasterService masterService;
	
	@Autowired
	SocietyService societyService;
	
	@Autowired
	UploadAdressMasterCommand uploadAdressMasterCommand;

	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = String.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "postalcode/{postalcode}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewStateAndCity> fetchStateAndCity(@PathVariable(value = "postalcode") long postalcode) {
		return fetchCustomerStateCityCommand.excute(postalcode);
	}

	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "states", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> fetchAllStates() {
		return fetchAllStatesListCommand.excute(null);
	}

	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "state/{stateId}/cities", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> fetchAllCities(@PathVariable(value = "stateId") Long stateId) {
		return fetchAllCitiesListCommand.excute(stateId);
	}

	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "city/{cityId}/areas", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> fetchAllAreas(@PathVariable(value = "cityId") Long cityId) {
		return fetchAllAreasListCommand.excute(cityId);
	}

	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "area/{areaId}/societies", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> fetchAllSocieties(@PathVariable(value = "areaId") Long areaId) {
		return fetchAllSocietiesListCommand.excute(areaId);
	}

	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "society/{societyId}/blocks", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> fetchAllBlocks(@PathVariable(value = "societyId") Long societyId) {
		return fetchAllBlocksListCommand.excute(societyId);
	}

	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "block/{blockId}/floors", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> fetchAllFloors(@PathVariable(value = "blockId") Long blockId) {
		return fetchAllFloorsListCommand.excute(blockId);
	}

	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "floor/{floorId}/houseNumbers", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> fetchAllHouseNumbers(@PathVariable(value = "floorId") Long floorId) {
		return fetchAllHouseNumbersListCommand.excute(floorId);
	}
	
	@PostMapping(value = "/uploadAdressMasterData", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<List<ErrorRecord>> uploadAddressMasterData(@RequestBody MultipartFile file) {
		return uploadAdressMasterCommand.excute(file);
	}
	
	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/societies", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> getAllSocieties() {
		return societyService.fetchAllSocieties();
	}
	
	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/societyOrder", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> updateSocietyOrder(@RequestBody List<ViewSociety> societyRequest) {
		return societyService.updateSocietyOrder(societyRequest);
	}

}
