package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.AgreeTermsAndConditionsRequest;
import com.homejiny.customer.response.AgreeTermsAndConditionsReponse;
import com.homejiny.customer.service.GetTermsAndConditionsService;

@Service
public class AgreeTermsAndConditionsCommand implements Command<AgreeTermsAndConditionsRequest, ResponseEntity<AgreeTermsAndConditionsReponse>> {

	@Autowired
	GetTermsAndConditionsService getTermsAndConditionsService;

	@Override
	public ResponseEntity<AgreeTermsAndConditionsReponse> excute(AgreeTermsAndConditionsRequest request) {
		return getTermsAndConditionsService.agreeTermsAndConditions(request);
	}

}
