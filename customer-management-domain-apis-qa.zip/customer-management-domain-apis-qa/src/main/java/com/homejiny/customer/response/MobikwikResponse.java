package com.homejiny.customer.response;

public class MobikwikResponse {

    private String checksumTransact,checksumPO,orderID,amount,callBackUrl;

    private String merchantIconUrl,merchantName,merchantID;

    public String getMerchantIconUrl() {
        return merchantIconUrl;
    }

    public void setMerchantIconUrl(String merchantIconUrl) {
        this.merchantIconUrl = merchantIconUrl;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getMerchantID() {
        return merchantID;
    }

    public void setMerchantID(String merchantID) {
        this.merchantID = merchantID;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    public String getCallBackUrl() {
        return callBackUrl;
    }

    public void setCallBackUrl(String callBackUrl) {
        this.callBackUrl = callBackUrl;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getChecksumTransact() {
        return checksumTransact;
    }

    public void setChecksumTransact(String checksumTransact) {
        this.checksumTransact = checksumTransact;
    }

    public String getChecksumPO() {
        return checksumPO;
    }

    public void setChecksumPO(String checksumPO) {
        this.checksumPO = checksumPO;
    }
}
