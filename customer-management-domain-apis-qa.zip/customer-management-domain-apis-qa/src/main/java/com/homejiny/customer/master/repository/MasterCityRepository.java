package com.homejiny.customer.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.City;
import com.homejiny.customer.master.entity.State;

@Repository
public interface MasterCityRepository extends JpaRepository<City, Long> {
	List<City> findByState(State state);

	City findByName(String cityName);

	List<City> findByStateAndStatus(State state, String status);

	City findByNameAndState(String cityName, State state);
}
