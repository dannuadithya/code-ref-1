package com.homejiny.customer.util;

import java.util.Optional;
import java.util.stream.IntStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.homejiny.customer.request.UploadAddressRequest;



public class UploadAddressExcelLoader extends ExcelReader {
	DataFormatter dataFormatter = new DataFormatter();

	public UploadAddressExcelLoader(MultipartFile multipartFile) {
		load(multipartFile);
	}

	/***
	 * Get next agent record
	 * 
	 * @return
	 */
	public Optional<UploadAddressRequest> next() {
		if (super.hasNext()) {
			Row row = sheet.getRow(rowNumber);
			rowNumber++;
			UploadAddressRequest branchRequest = createAddressRequest(row);
			return Optional.of(branchRequest);
		}
		return Optional.empty();
	}
	

	/***
	 * read data from excel sheet and set it to agent value object
	 * 
	 * @param row
	 * @return
	 */
	private UploadAddressRequest createAddressRequest(Row row) {
		UploadAddressRequest uploadAddressRequest = new UploadAddressRequest();
		IntStream.range(0, columnHeaders.size()).forEach(header -> {
			try {				
			switch(columnHeaders.get(header).toUpperCase()) {
			case "STATE":
				uploadAddressRequest.setState(getValueFromCell(row, header));
				break;			
			case "STATE CODE":
				uploadAddressRequest.setStateCode(getValueFromCell(row, header));
				break;			
			case "CITY":
				uploadAddressRequest.setCity(getValueFromCell(row, header));
				break;
			case "AREA":
				uploadAddressRequest.setArea(getValueFromCell(row, header));
				break;
			case "SOCIETY":
				uploadAddressRequest.setSoceity(getValueFromCell(row, header));
				break;
			case "BLOCK":
				uploadAddressRequest.setBolck(getValueFromCell(row, header));
				break;				
			case "FLOOR":
				uploadAddressRequest.setFloor(getValueFromCell(row, header));
				break;
			case "HOUSE NUMBER":
				uploadAddressRequest.setHouseNumber(getValueFromCell(row, header));
				break;
			
			case "PIN CODE":
				uploadAddressRequest.setPincode(getValueFromCell(row, header));
				break;		
			case "ADDITIONAL INFO":
				uploadAddressRequest.setAdditionalInfo(getValueFromCell(row, header));
				break;
			case "ENTRY GATE":
				uploadAddressRequest.setEntryGate(getValueFromCell(row, header));
				break;
			case "EXIT GATE":
				uploadAddressRequest.setExitGate(getValueFromCell(row, header));
				break;
			case "DELIVERY SEQ":
				uploadAddressRequest.setDeliverySeq(getValueFromCell(row, header));
				break;			
			
			}
			}catch (Exception e) {
				uploadAddressRequest.setErrorRecord(new ErrorRecord(rowNumber,
						 "Error reading columns values from the row"));
				 }
		});
		return uploadAddressRequest;
	}

	/**
	 * Convert String to integer values.
	 * 
	 * @param value
	 * @return
	 */
	private Integer readIntegerValues(String value) {
		return StringUtils.isEmpty(value) ? null : Integer.parseInt(value);
	}

	/**
	 * Read value from the row with a given column number.
	 * 
	 * @param row
	 * @param columnType
	 * @return
	 */
	private String getValueFromCell(Row row, int position) {
		Cell cellValue = row.getCell(position);
		String value = (cellValue != null && cellValue.getCellType() == Cell.CELL_TYPE_NUMERIC)
				? NumberToTextConverter.toText(cellValue.getNumericCellValue())
				: dataFormatter.formatCellValue(cellValue);
		return value == null ? value : value.trim();
	}

}
