package com.homejiny.customer.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.homejiny.customer.master.entity.Society;

/**
 * @author brahmaiam
 *
 */
@Entity
@Table(name = "HJ_CUSTOMER_ADDRESS")
public class CustomerAddress extends com.homejiny.customer.entity.Entity {
	@Column(name = "house_number")
	private String houseNumber;

	@Column(name = "floor")
	private String floor;

	@Column(name = "block")
	private String block;

	@Column(name = "postal_code")
	private String postalCode;

	@Column(name = "state")
	private String state;

	@Column(name = "city")
	private String city;

	@Column(name = "area")
	private String area;

	@Column(name = "other_area")
	private String otherArea;

	@Column(name = "society")
	private String society;

	@Column(name = "status")
	private String status;
	
	@Column(name="microcluster_name")
	private String microclusterName;
	
	@Column(name="zone_name")
	private String zoneName;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "hj_customer_id")
	private Customer customer;

	@Column(name = "hj_baggage_drop_location")
	private String baggageDropLocation;

	@Column(name = "hj_drop_location_image_path")
	private String dropLocationImagePath;

	@Column(name = "hj_qr_code_location")
	private String qrCodeLocation;

	@Column(name = "hj_qr_code_location_image_path")
	private String qrCodeLocationImagePath;

	@Column(name = "hj_ring_the_bell")
	private boolean ringTheBell;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "hj_society_id")
	private Society societyId;

	public String getBaggageDropLocation() {
		return baggageDropLocation;
	}

	public void setBaggageDropLocation(String baggageDropLocation) {
		this.baggageDropLocation = baggageDropLocation;
	}

	public String getDropLocationImagePath() {
		return dropLocationImagePath;
	}

	public void setDropLocationImagePath(String dropLocationImagePath) {
		this.dropLocationImagePath = dropLocationImagePath;
	}

	public String getQrCodeLocationImagePath() {
		return qrCodeLocationImagePath;
	}

	public void setQrCodeLocationImagePath(String qrCodeLocationImagePath) {
		this.qrCodeLocationImagePath = qrCodeLocationImagePath;
	}

	public String getQrCodeLocation() {
		return qrCodeLocation;
	}

	public void setQrCodeLocation(String qrCodeLocation) {
		this.qrCodeLocation = qrCodeLocation;
	}

	public boolean isRingTheBell() {
		return ringTheBell;
	}

	public void setRingTheBell(boolean ringTheBell) {
		this.ringTheBell = ringTheBell;
	}

	public String getHouseNumber() {
		return houseNumber;
	}

	public String getMicroclusterName() {
		return microclusterName;
	}

	public void setMicroclusterName(String microclusterName) {
		this.microclusterName = microclusterName;
	}

	public void setHouseNumber(String houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getFloor() {
		return floor;
	}

	public void setFloor(String floor) {
		this.floor = floor;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getOtherArea() {
		return otherArea;
	}

	public void setOtherArea(String otherArea) {
		this.otherArea = otherArea;
	}

	public String getSociety() {
		return society;
	}

	public void setSociety(String society) {
		this.society = society;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getZoneName() {
		return zoneName;
	}

	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}

	public Society getSocietyId() {
		return societyId;
	}

	public void setSocietyId(Society societyId) {
		this.societyId = societyId;
	}
	
}
