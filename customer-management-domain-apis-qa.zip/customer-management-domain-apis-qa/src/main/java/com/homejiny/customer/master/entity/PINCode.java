package com.homejiny.customer.master.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "hj_pincode")
@Table(name = "HJ_PINCODE")
public class PINCode {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID")
	private long id;

	@Column(name = "pincode_number")
	private long pinCodeNumber;

	@Column(name = "status")
	private String status;

	@Column(name = "created_time")
	private LocalDateTime createdAt;

	@Column(name = "updated_time")
	private LocalDateTime updatedAt;
	
	@Column(name = "display_order")
	private long displayOrder;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getPinCodeNumber() {
		return pinCodeNumber;
	}

	public void setPinCodeNumber(long pinCodeNumber) {
		this.pinCodeNumber = pinCodeNumber;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public long getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(long displayOrder) {
		this.displayOrder = displayOrder;
	}

}
