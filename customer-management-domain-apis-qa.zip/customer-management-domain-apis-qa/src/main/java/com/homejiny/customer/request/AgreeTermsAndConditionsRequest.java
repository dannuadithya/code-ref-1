package com.homejiny.customer.request;

public class AgreeTermsAndConditionsRequest {

	private long customerId;
	private Boolean agreed;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public Boolean getAgreed() {
		return agreed;
	}

	public void setAgreed(Boolean agreed) {
		this.agreed = agreed;
	}

}
