package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.entity.TermsAndConditionsEnum;
import com.homejiny.customer.service.GetTermsAndConditionsService;
import com.homejiny.customer.view.TermsAndConditionsView;

@Service
public class GetTermsAndConditionsCommand
		implements Command<TermsAndConditionsEnum, ResponseEntity<TermsAndConditionsView>> {

	@Autowired
	GetTermsAndConditionsService getTermsAndConditionsService;

	@Override
	public ResponseEntity<TermsAndConditionsView> excute(TermsAndConditionsEnum request) {
		return ResponseEntity.status(HttpStatus.OK).body(getTermsAndConditionsService.getTermsAndConditions(request));
	}

}
