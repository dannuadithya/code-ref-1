package com.homejiny.customer.response;

import com.homejiny.customer.entity.RefferalPoints;

public class RefferalPointsResponse {

	private String status;
	private RefferalPoints data;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public RefferalPoints getData() {
		return data;
	}

	public void setData(RefferalPoints data) {
		this.data = data;
	}

}
