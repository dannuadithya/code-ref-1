package com.homejiny.customer.controller;

import java.security.NoSuchAlgorithmException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.homejiny.customer.request.*;
import com.homejiny.customer.response.*;
import org.glassfish.jersey.media.multipart.FormDataParam;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.homejiny.customer.adapter.WalletAdapter;
import com.homejiny.customer.authorization.EnableTokenAuthorisation;
import com.homejiny.customer.authorization.InvalidAuthTokenException;
import com.homejiny.customer.command.AgreeTermsAndConditionsCommand;
import com.homejiny.customer.command.CancelCustomerServiceRequestCommand;
import com.homejiny.customer.command.CreateCustomerAddressCommand;
import com.homejiny.customer.command.CreateEmailAddressCommand;
import com.homejiny.customer.command.CreateRatingCommand;
import com.homejiny.customer.command.CustomerAccountCommand;
import com.homejiny.customer.command.CustomerKycCommand;
import com.homejiny.customer.command.CustomerListCommand;
import com.homejiny.customer.command.CustomerPointsRedemptionCommand;
import com.homejiny.customer.command.DeliveryInformationCommand;
import com.homejiny.customer.command.FetchCustomerDeliveryInformationCommand;
import com.homejiny.customer.command.FetchCustomerDetailsCommand;
import com.homejiny.customer.command.FetchServiceOrdersListCommand;
import com.homejiny.customer.command.GetCustomerKycAndDeliveryInfoCommand;
import com.homejiny.customer.command.GetCustomerKycCommand;
import com.homejiny.customer.command.GetHJAvailabilityCommand;
import com.homejiny.customer.command.GetRewardPointsByCustomerCommand;
import com.homejiny.customer.command.GetTermsAndConditionsCommand;
import com.homejiny.customer.command.InviteFriendsCommand;
import com.homejiny.customer.command.KycVerifiedCommand;
import com.homejiny.customer.command.LogoutCommand;
import com.homejiny.customer.command.ProfilePictureCommand;
import com.homejiny.customer.command.ResendOTPCommand;
import com.homejiny.customer.command.RingTheBellCommand;
import com.homejiny.customer.command.SignInCommand;
import com.homejiny.customer.command.UpdateCustomerAddressCommand;
import com.homejiny.customer.command.UpdateCustomerCommand;
import com.homejiny.customer.command.UpdateCustomerDetailsCommand;
import com.homejiny.customer.command.UpdateRewardPointsRedemptionCommand;
import com.homejiny.customer.command.VerifyOTPCommand;
import com.homejiny.customer.command.VerifyingReferrerCode;
import com.homejiny.customer.common.KycImageView;
import com.homejiny.customer.entity.TermsAndConditionsEnum;
import com.homejiny.customer.master.service.SocietyService;
import com.homejiny.customer.master.view.ResponseView;
import com.homejiny.customer.master.view.SocietyRequest;
import com.homejiny.customer.service.CustomerLoyaltyPoints;
import com.homejiny.customer.service.CustomerRating;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.service.CustomerSupportInfoService;
import com.homejiny.customer.service.HowRefferalPointsWorkService;
import com.homejiny.customer.view.AddressResponse;
import com.homejiny.customer.view.CustomerResponse;
import com.homejiny.customer.view.CustomerRewardPoints;
import com.homejiny.customer.view.CustomerSearchResponse;
import com.homejiny.customer.view.CustomerSupportInfoResponse;
import com.homejiny.customer.view.DeliveryInformationResponse;
import com.homejiny.customer.view.InviteFriendsResponse;
import com.homejiny.customer.view.KycResponse;
import com.homejiny.customer.view.KycVerifiedResponse;
import com.homejiny.customer.view.LogoutResponse;
import com.homejiny.customer.view.OTPResponseView;
import com.homejiny.customer.view.ProfilePictureResponse;
import com.homejiny.customer.view.Response;
import com.homejiny.customer.view.TermsAndConditionsView;
import com.homejiny.customer.view.ViewCustomerDetails;
import com.homejiny.customer.view.ViewCustomerKycResponse;
import com.homejiny.customer.view.ViewCustomerRewardLog;
import com.homejiny.customer.view.ViewCustomerServiceOrdersListDetailsResponse;
import com.homejiny.customer.view.ViewRazorPayOrderDetails;
import com.homejiny.customer.view.ViewRazorpayGatewayKey;
import com.homejiny.customer.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping(value = "/v2")
@CrossOrigin(origins = "*")
public class CustomerController {

	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

	@Autowired
	CustomerAccountCommand customerCommand;

	@Autowired
	SignInCommand signInCmd;

	@Autowired
	VerifyOTPCommand verifyOTPCommand;

	@Autowired
	UpdateCustomerAddressCommand updateCustomerAddressCommand;

	@Autowired
	ResendOTPCommand resendOTPCommand;

	@Autowired
	UpdateCustomerCommand updateCustomerCommand;

	@Autowired
	FetchCustomerDetailsCommand fetchCustomerDetailsCommand;

	@Autowired
	CreateEmailAddressCommand createEmailAddressCommand;

	@Autowired
	CustomerKycCommand customerKycCommand;

	@Autowired
	CustomerLoyaltyPoints customerLoyaltyPoints;

	@Autowired
	GetCustomerKycCommand getCustomerKycCommand;

	@Autowired
	InviteFriendsCommand inviteFriendsCommand;

	@Autowired
	CreateCustomerAddressCommand createCustomerAddressCommand;

	@Autowired
	CreateRatingCommand createRatingCommand;

	@Autowired
	GetRewardPointsByCustomerCommand getRewardPointsByCustomerCommand;

	@Autowired
	CustomerListCommand customerListCommand;

	@Autowired
	DeliveryInformationCommand deliveryInformationCommand;

	@Autowired
	VerifyingReferrerCode verifyingReferrerCode;

	@Autowired
	ProfilePictureCommand profilePictureCommand;

	@Autowired
	GetTermsAndConditionsCommand getTermsAndConditionsCommand;

	@Autowired
	AgreeTermsAndConditionsCommand agreeTermsAndConditionsCommand;

	@Autowired
	FetchServiceOrdersListCommand fetchServiceOrdersListCommand;

	@Autowired
	CancelCustomerServiceRequestCommand cancelCustomerServiceRequestCommand;

	@Autowired
	LogoutCommand logoutCommand;

	@Autowired
	FetchCustomerDeliveryInformationCommand fetchCustomerDeliveryInformationCommand;

	@Autowired
	KycVerifiedCommand kycVerifiedCommand;

	@Autowired
	GetHJAvailabilityCommand getHJAvailabilityCommand;
	@Autowired
	GetCustomerKycAndDeliveryInfoCommand getCustomerKycAndDeliveryInfoCommand;

	@Autowired
	RingTheBellCommand ringTheBellCommand;

	@Autowired
	UpdateCustomerDetailsCommand updateCustomerDetailsCommand;

	@Autowired
	CustomerSupportInfoService customerSupportInfoService;

	@Autowired
	HowRefferalPointsWorkService howRefferalPointsWorkService;

	@Autowired
	CustomerPointsRedemptionCommand customerPointsRedemptionCommand;

	@Autowired
	UpdateRewardPointsRedemptionCommand updateRewardPointsRedemptionCommand;

	@Autowired
	CustomerRating customerRating;
	
	@Autowired
	CustomerService customerService;
	
	@Autowired
	SocietyService societyService;

	Integer pageNumber;
	Integer pageSize;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Generate OTP"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/signin", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomerSignInResponse> signIn(@RequestBody SignInRequest request) {
		return signInCmd.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = OTPResponseView.class, message = "Verify OTP"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_NON_AUTHORITATIVE_INFORMATION, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/verifyOTP", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<OTPResponseView> verifyOTP(@RequestBody OTPDetails otpDetails) {
		return verifyOTPCommand.excute(otpDetails);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Generate OTP"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/resendotp", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Response> resendOTP(@RequestBody SignInRequest request) {
		return resendOTPCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "Cutomer signin"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@EnableTokenAuthorisation
	@PostMapping(value = "/{customerId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomerResponse> createCustomerAccount(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId, @RequestBody CustomerInfoRequest customerInfoRequest) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		CustomerRequest request = new CustomerRequest();
		request.setFirstName(customerInfoRequest.getFirstName());
		request.setLastName(customerInfoRequest.getLastName());
		request.setMiddleName(customerInfoRequest.getMiddleName());
		request.setCustomerId(customerId);
		return customerCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "Updated Cutomer Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@EnableTokenAuthorisation
	@PostMapping(value = "/email", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Response> updateEmailAddress(HttpServletRequest httpRequest,
			@RequestBody EmailAddressRequest request) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, request.getCustomerId());
		return createEmailAddressCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "Updated Cutomer Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@EnableTokenAuthorisation
	@PostMapping(value = "/{customerId}/address", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<AddressResponse> createCustomerAddress(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId, @RequestBody CustomerAddressReq addressRequest) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		CustomerAddressReq request = new CustomerAddressReq();
		request.setCustomerId(customerId);
		request.setBlock(addressRequest.getBlock());
		request.setFloor(addressRequest.getFloor());
		request.setHouseNo(addressRequest.getHouseNo());
		request.setPostalCode(addressRequest.getPostalCode());
		request.setState(addressRequest.getState());
		request.setCity(addressRequest.getCity());
		request.setArea(addressRequest.getArea());
		request.setOtherArea(addressRequest.getOtherArea());
		request.setSociety(addressRequest.getSociety());
		request.setSocietyId(addressRequest.getSocietyId());
		request.setRingTheBell(addressRequest.isRingTheBell());
		addressRequest.setCustomerId(customerId);
		return createCustomerAddressCommand.excute(addressRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "Updated Cutomer Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@EnableTokenAuthorisation
	@PutMapping(value = "/{customerId}/address", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<AddressResponse> updateCustomerAddress(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId, @RequestBody AddressRequest addressRequest) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		CustomerAddressReq request = new CustomerAddressReq();
		request.setCustomerId(customerId);
		request.setBlock(addressRequest.getBlock());
		request.setFloor(addressRequest.getFloor());
		request.setHouseNo(addressRequest.getHouseNo());
		request.setPostalCode(addressRequest.getPostalCode());
		request.setState(addressRequest.getState());
		request.setCity(addressRequest.getCity());
		request.setArea(addressRequest.getArea());
		request.setSocietyId(addressRequest.getSocietyId());
		request.setOtherArea(addressRequest.getOtherArea());
		request.setSociety(addressRequest.getSociety());
		return updateCustomerAddressCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "Updated Cutomer Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/{customerId}/updateCustomerAddress", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<AddressResponse> updateCustomerAddressFromAdmin(
			@PathVariable(value = "customerId") long customerId, @RequestBody AddressRequest addressRequest) {
		CustomerAddressReq request = new CustomerAddressReq();
		request.setCustomerId(customerId);
		request.setBlock(addressRequest.getBlock());
		request.setFloor(addressRequest.getFloor());
		request.setHouseNo(addressRequest.getHouseNo());
		request.setPostalCode(addressRequest.getPostalCode());
		request.setState(addressRequest.getState());
		request.setCity(addressRequest.getCity());
		request.setArea(addressRequest.getArea());
		request.setSocietyId(addressRequest.getSocietyId());
		request.setOtherArea(addressRequest.getOtherArea());
		request.setSociety(addressRequest.getSociety());
		return updateCustomerAddressCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "Updated Cutomer Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
//	@EnableTokenAuthorisation
	@PutMapping(value = "/updateCustomerDetails", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Response> updateCustomerDetailsById(HttpServletRequest httpRequest,
			@RequestBody CustomerUpdateDetailsRequest customerUpdateDetailsRequest) {
		// isValidCustomerIdWithRespectToAccessToken(httpRequest,
		// customerUpdateDetailsRequest.getCustomerId());
		return updateCustomerDetailsCommand.excute(customerUpdateDetailsRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "Updated Cutomer Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@EnableTokenAuthorisation
	@PutMapping(value = "/{customerId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Response> updateCustomerDetails(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId, @RequestBody CustomerInfoRequest customerInfoRequest) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		CustomerRequest request = new CustomerRequest();
		request.setFirstName(customerInfoRequest.getFirstName());
		request.setLastName(customerInfoRequest.getLastName());
		request.setMiddleName(customerInfoRequest.getMiddleName());
		request.setCustomerId(customerId);
		return updateCustomerCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewCustomerDetails.class, message = "Updated Cutomer Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@EnableTokenAuthorisation
	@GetMapping(value = "/{customerId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewCustomerDetails> fetchCustomerDetails(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return fetchCustomerDetailsCommand.excute(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = KycResponse.class, message = "KYC details Added"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = String.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = String.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = String.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/kycdetails")
	public @ResponseBody ResponseEntity<KycResponse> createKycDetails(
			@FormDataParam(value = "mediaFile") MultipartFile mediaFile,
			@RequestParam(name = "customerId") long customerId,
			@RequestParam(name = "kycdocNumber") String kycdocNumber, @RequestParam(name = "kycCode") String kycCode,
			@RequestParam(name = "kycImageView") KycImageView imageView) {
		CustomerKycRequest customerKycRequest = new CustomerKycRequest();
		customerKycRequest.setCustomerId(customerId);
		customerKycRequest.setKycdocNumber(kycdocNumber);
		customerKycRequest.setMediaFile(mediaFile);
		customerKycRequest.setKycCode(kycCode);
		customerKycRequest.setImageView(imageView);
		return customerKycCommand.excute(customerKycRequest);
	}

	@Override
	public String toString() {
		return super.toString();
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewCustomerDetails.class, message = "Updated Cutomer Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/customer/{cust}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewCustomerDetails> getCustomerDetails(@PathVariable(value = "cust") long cust) {
		return fetchCustomerDetailsCommand.excute(cust);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Vendor Submitting Review Rating Successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/reviewRatings", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<Response> createReviewRating(@RequestBody RatingRequest request) {
		return createRatingCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewCustomerDetails.class, message = "Invite a friend"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/invite/friend/{customerId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	// @EnableTokenAuthorisation
	public ResponseEntity<InviteFriendsResponse> inviteFriends(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId) throws NoSuchAlgorithmException {
		// isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return inviteFriendsCommand.excute(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "All Reward Points"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = String.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = String.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = String.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/rewardPoints", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewCustomerRewardLog> createCustomerRewardPointLog(
			@RequestBody CustomerRewardPointLogRequest request) {
		return customerLoyaltyPoints.createCustomerRewardPointLog(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "RewardPointsByCustomerId"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = String.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = String.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = String.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/rewardPoints/{customerId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomerRewardPoints> getAllRewardPointsByCustomerId(@PathVariable long customerId,
			@RequestParam(value = "pageNumber", required = false) Integer pageNumber,
			@RequestParam(value = "pageLimit", required = false) Integer pageLimit) {
		this.pageNumber = pageNumber != null ? pageNumber : 0;
		this.pageSize = pageLimit != null ? pageLimit : 100;
		GetRewardPointsByCustomerRequest getRewardPointsByCustomerRequest = new GetRewardPointsByCustomerRequest();
		getRewardPointsByCustomerRequest.setCustomerId(customerId);
		getRewardPointsByCustomerRequest.setPageNumber(this.pageNumber);
		getRewardPointsByCustomerRequest.setPageLimit(this.pageSize);
		return getRewardPointsByCustomerCommand.excute(getRewardPointsByCustomerRequest);

	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "All customer list"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = String.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = String.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = String.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/admin/customerList", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomerSearchResponse> getCustomerList(
			@RequestBody CustomerListRequest customerListRequest) {
		return customerListCommand.excute(customerListRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "delivery info created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/deliveryLocationInfo")
	public ResponseEntity<Response> deliveryInformation(
			@FormDataParam("deliveryInformationRequest") DeliveryInformationRequest deliveryInformationRequest) {
		return deliveryInformationCommand.excute(deliveryInformationRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Verification of Referrer Code"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/verifyingReferrerCode", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<InviteFriendsResponse> verificationOfReferrerCode(
			@RequestBody ReferralCodeRequest referralCodeRequest) {

		return verifyingReferrerCode.excute(referralCodeRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ProfilePictureResponse.class, message = "Add Profile Picture"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/profilePicture", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ProfilePictureResponse> addProfilePicture(
			@FormDataParam(value = "profilePicture") MultipartFile profilePicture,
			@RequestParam(name = "customerId") long customerId) {

		ProfilePictureRequest profilePictureRequest = new ProfilePictureRequest();
		profilePictureRequest.setCustomerId(customerId);
		profilePictureRequest.setProfilePicture(profilePicture);

		return profilePictureCommand.excute(profilePictureRequest);
	}

	/**
	 * This method is used to Validate CustomerId With Respect To AccessToken.
	 * 
	 * @param httpRequest
	 * @param requestCustomerId
	 * @return boolean
	 */
	private boolean isValidCustomerIdWithRespectToAccessToken(HttpServletRequest httpRequest, long requestCustomerId) {
		long customerId = Long.parseLong(httpRequest.getAttribute("id").toString());
		String mobileNumber = httpRequest.getAttribute("MOBILE").toString();
		logger.info("Requested Customer Id : " + requestCustomerId);
		logger.info("Based on AccessToken Mobile Number : " + mobileNumber + " , with customer Id : " + customerId);
		if (customerId != requestCustomerId) {
			throw new InvalidAuthTokenException("INVALID TOKEN");
		}
		return true;
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Terms And Conditions View"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = Response.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = Response.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = Response.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/termsAndConditions", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<TermsAndConditionsView> viewTermsAndConditions(@RequestParam TermsAndConditionsEnum request) {
		return getTermsAndConditionsCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_ACCEPTED, response = Response.class, message = "customer terms and conditions accepted successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/agreeTermsAndConditions")
	public ResponseEntity<AgreeTermsAndConditionsReponse> agreeTermsAndConditions(
			@RequestBody AgreeTermsAndConditionsRequest agreeTermsAndConditionsRequest) {
		return agreeTermsAndConditionsCommand.excute(agreeTermsAndConditionsRequest);
	}

	@Autowired
	WalletAdapter walletAdapter;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_ACCEPTED, response = Response.class, message = "customer terms and conditions accepted successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "{customerId}/wallet/addmoney")
	@EnableTokenAuthorisation
	public ResponseEntity<ViewRazorPayOrderDetails> addMoneyToWallet(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId,
			@RequestBody RazorPayOrderRequest razorPayOrderRequest) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return walletAdapter.createRazorPayOrder(razorPayOrderRequest, customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_ACCEPTED, response = Response.class, message = "customer terms and conditions accepted successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/wallet/generateChecksum")
	// @EnableTokenAuthorisation
	public ResponseEntity<PaytmPayOrderResponse> generateChecksum(HttpServletRequest httpRequest,
			@RequestBody PaytmPayOrderRequest paytmPayOrderRequest) {

		// isValidCustomerIdWithRespectToAccessToken(httpRequest,
		// paytmPayOrderRequest.getCustomerId());
		return walletAdapter.createChecksum(paytmPayOrderRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_ACCEPTED, response = Response.class, message = "customer terms and conditions accepted successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/wallet/generateMobikwikChecksum")
	// @EnableTokenAuthorisation
	public ResponseEntity<MobikwikResponse> generateMobikwikChecksum(HttpServletRequest httpRequest,
																	 @RequestBody MobiwekPayOrderRequest mobiwekPayOrderRequest) {

		// isValidCustomerIdWithRespectToAccessToken(httpRequest,
		// paytmPayOrderRequest.getCustomerId());
		return walletAdapter.createMobiwekChecksum(mobiwekPayOrderRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_ACCEPTED, response = Response.class, message = "customer terms and conditions accepted successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "{customerId}/wallet/gateWayKey")
	@EnableTokenAuthorisation
	public ResponseEntity<ViewRazorpayGatewayKey> fetchRazorPaymentGateWayKey(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return walletAdapter.fetchRazorPaymentGateWayKey();
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewCustomerServiceOrdersListDetailsResponse.class, message = "Customer Service orders List"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/{customerId}/serviceOrdersList", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewCustomerServiceOrdersListDetailsResponse> getServiceOrdersList(
			HttpServletRequest httpRequest, @PathVariable(value = "customerId") long customerId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return fetchServiceOrdersListCommand.excute(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CancelCustomerServiceRequestResponse.class, message = "Customer Service Request Cancelled"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/customer/{customerId}/{serviceRequestId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<CancelCustomerServiceRequestResponse> cancelCustomerServiceRequest(
			HttpServletRequest httpRequest, @PathVariable(value = "customerId") long customerId,
			@PathVariable(value = "serviceRequestId") long serviceRequestId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		CancelCustomerServiceRequest cancelCustomerServiceRequest = new CancelCustomerServiceRequest();
		cancelCustomerServiceRequest.setCustomerId(customerId);
		cancelCustomerServiceRequest.setServiceRequestId(serviceRequestId);
		return cancelCustomerServiceRequestCommand.excute(cancelCustomerServiceRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_ACCEPTED, response = Response.class, message = "customer terms and conditions accepted successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "customer/{customerId}/logout")
	@EnableTokenAuthorisation
	public ResponseEntity<LogoutResponse> logout(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") long customerId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return logoutCommand.excute(httpRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Fetched customer deliveryinformation successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/{customerId}/customerdeliveryinformation", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<DeliveryInformationResponse> getCustomerDeliveryInformation(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") Long customerId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return fetchCustomerDeliveryInformationCommand.excute(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = KycVerifiedResponse.class, message = "Customer kyc updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/markKycAsVerified/{customerId}")
	public ResponseEntity<KycVerifiedResponse> markKycAsVerified(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") Long customerId) {
		return kycVerifiedCommand.excute(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Fetched customer deliveryinformation successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/{customerId}/hjavailabilities", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getHJAvailabilities(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") Long customerId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return getHJAvailabilityCommand.excute(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Fetched customer deliveryinformation successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/{customerId}/customerKycDetails", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewCustomerKycResponse> fetchCustomerKycDetails(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") Long customerId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return getCustomerKycCommand.excute(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "Fetched customer deliveryinformation successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/{customerId}/customerKycAndDeliveryInfo", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> fetchCustomerKycAndDeliveryInfo(HttpServletRequest httpRequest,
			@PathVariable(value = "customerId") Long customerId) {
		isValidCustomerIdWithRespectToAccessToken(httpRequest, customerId);
		return getCustomerKycAndDeliveryInfoCommand.excute(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_ACCEPTED, response = Response.class, message = "ring the bell updated succesfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/updateRingTheBell", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public AgreeTermsAndConditionsReponse updateRingTheBell(@RequestBody RingTheBellRequest request) {
		return ringTheBellCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "update CustomerSupportInfo Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/getCustomerSupportInfo", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public CustomerSupportInfoResponse getCustomerSupportInfo(@RequestParam long id) {
		return customerSupportInfoService.getCustomerSupportInfo(id);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "HowRefferalPointsWorks Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/getHowPointsWork", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public RefferalPointsResponse getHowRefferalPointsWork(@RequestParam long id) {
		return howRefferalPointsWorkService.getHowRefferalPointsWorks(id);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "customer redemed points Successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/pointsRedemption", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public UpdateRewardPointsRedemptionResponse pointsRedemption(@RequestBody PointsRedemptionRequest request) {
		return customerPointsRedemptionCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "customer redemed points Successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/pointsRedemption", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public UpdateRewardPointsRedemptionResponse updaterewardPointsStatus(
			@RequestBody UpdateRewardPointsStatusRequest request) {
		return updateRewardPointsRedemptionCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "orders Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/showCustomerOrders", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public RatingResponse showCustomerOrders(@RequestParam long customerId) {
		return customerRating.showCustomerRating(customerId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "customer rating"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = Response.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = Response.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = Response.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/customerRating", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomerRatingResponse> customerRating(@RequestBody CustomerRatingRequest request) {
		return customerRating.customerRating(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "customer rating"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = Response.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = Response.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = Response.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/customerSubRating", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public AgreeTermsAndConditionsReponse customerSubRating(@RequestBody CustomerSubRatingRequest request) {
		return customerRating.customerSubRating(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "orders Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/getCustomerOrdersRating", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public RatingResponse getCustomerOrdersRatingForProducts(@RequestParam long productOrderId) {
		return customerRating.showCustomerPopUpRatingForProducts(productOrderId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "orders Details"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@GetMapping(value = "/getCustomerOrdersRatingForServices", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public RatingResponse getCustomerOrdersRatingForServices(@RequestParam long serviceOrderId) {
		return customerRating.showCustomerPopUpRatingForServices(serviceOrderId);
	}
	
	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = CustomerResponse.class, message = "App version updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PutMapping(value = "/updateAppVersion", produces = MediaType.APPLICATION_JSON_UTF8_VALUE , consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CustomerResponse> updateAppVersion(@RequestBody UpdateAppVersionRequest updateAppVersionRequest) {
		return customerService.updateAppVersion(updateAppVersionRequest);
	}
	
	@ApiResponses(value = { @ApiResponse(code = HttpServletResponse.SC_OK, response = ResponseView.class, message = ""),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid inputs"),
			@ApiResponse(code = HttpServletResponse.SC_UNAUTHORIZED, response = ErrorResponse.class, message = "Invalid Token / Without Token"),
			@ApiResponse(code = HttpServletResponse.SC_FORBIDDEN, response = ErrorResponse.class, message = "UnAuthorized Access") })
	@PostMapping(value = "/updateHjAvailability", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ResponseView> updateHjAvailability(@RequestBody SocietyRequest societyRequest) {
		return societyService.updateHjAvailability(societyRequest);
	}
	
}
