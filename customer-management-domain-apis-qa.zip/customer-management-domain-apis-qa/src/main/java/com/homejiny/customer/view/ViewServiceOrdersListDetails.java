package com.homejiny.customer.view;

/**
 * @author - Chaitanya Mannem
 */
public class ViewServiceOrdersListDetails {

    private Long serviceOrderId;
    private Double amount;
    private Long quantity;
    private String description;
    private String pickupDate;
    private String pickupTime;
    private String returnTime;
    private String returnDate;
    private String bookingDate;
    private String status;
    private Long serviceRequestId;
    private boolean showCancelService;
    private Long vendorReportedQuantity;
    private String serviceType;
    private String scheduleType;
    private String type;
    private String skuName;
    private String serviceSubCategoryName;
    private String serviceOrderNumber;


    public String getServiceOrderNumber() {
		return serviceOrderNumber;
	}

	public void setServiceOrderNumber(String serviceOrderNumber) {
		this.serviceOrderNumber = serviceOrderNumber;
	}

	public Long getServiceOrderId() {
        return serviceOrderId;
    }

    public void setServiceOrderId(Long serviceOrderId) {
        this.serviceOrderId = serviceOrderId;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public Long getQuantity() {
        return quantity;
    }

    public void setQuantity(Long quantity) {
        this.quantity = quantity;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPickupDate() {
        return pickupDate;
    }

    public void setPickupDate(String pickupDate) {
        this.pickupDate = pickupDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public String getBookingDate() {
        return bookingDate;
    }

    public void setBookingDate(String bookingDate) {
        this.bookingDate = bookingDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPickupTime() {
        return pickupTime;
    }

    public void setPickupTime(String pickupTime) {
        this.pickupTime = pickupTime;
    }

    public String getReturnTime() {
        return returnTime;
    }

    public void setReturnTime(String returnTime) {
        this.returnTime = returnTime;
    }

    public Long getServiceRequestId() {
        return serviceRequestId;
    }

    public void setServiceRequestId(Long serviceRequestId) {
        this.serviceRequestId = serviceRequestId;
    }

    public boolean isShowCancelService() {
        return showCancelService;
    }

    public void setShowCancelService(boolean showCancelService) {
        this.showCancelService = showCancelService;
    }

    public Long getVendorReportedQuantity() {
        return vendorReportedQuantity;
    }

    public void setVendorReportedQuantity(Long vendorReportedQuantity) {
        this.vendorReportedQuantity = vendorReportedQuantity;
    }

    public String getServiceType() {
        return serviceType;
    }

    public void setServiceType(String serviceType) {
        this.serviceType = serviceType;
    }

    public String getScheduleType() {
        return scheduleType;
    }

    public void setScheduleType(String scheduleType) {
        this.scheduleType = scheduleType;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSkuName() {
        return skuName;
    }

    public void setSkuName(String skuName) {
        this.skuName = skuName;
    }

    public String getServiceSubCategoryName() {
        return serviceSubCategoryName;
    }

    public void setServiceSubCategoryName(String serviceSubCategoryName) {
        this.serviceSubCategoryName = serviceSubCategoryName;
    }
}
