package com.homejiny.customer.util;
public class ErrorRecord {

	private int rowId;
	private String message;	

	public ErrorRecord() {
	}

	public ErrorRecord(int rowId, String message) {
		this.rowId = rowId;
		this.message = message;
	}

	public int getRowId() {
		return rowId;
	}

	public void setRowId(int rowId) {
		this.rowId = rowId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
