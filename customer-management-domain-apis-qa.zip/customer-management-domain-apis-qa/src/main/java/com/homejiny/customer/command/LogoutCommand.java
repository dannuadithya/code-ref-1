package com.homejiny.customer.command;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.service.LogoutService;
import com.homejiny.customer.view.LogoutResponse;

/**
 * @author brahmaiam
 *
 */
@Service
public class LogoutCommand implements Command<HttpServletRequest, ResponseEntity<LogoutResponse>> {
	@Autowired
	LogoutService logoutService;

	public ResponseEntity<LogoutResponse> excute(HttpServletRequest request) {
		return ResponseEntity.status(HttpStatus.OK).body(logoutService.logoutApplication(request));
	}
}
