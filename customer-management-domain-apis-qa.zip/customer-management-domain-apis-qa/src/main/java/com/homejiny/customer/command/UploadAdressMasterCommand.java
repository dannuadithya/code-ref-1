package com.homejiny.customer.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.homejiny.customer.request.UploadAddressRequest;
import com.homejiny.customer.service.InsertAddressDataService;
import com.homejiny.customer.util.ErrorRecord;
import com.homejiny.customer.util.UploadAddressExcelLoader;

@Service
public class UploadAdressMasterCommand implements Command<MultipartFile,ResponseEntity<List<ErrorRecord>>> {

	private static final Logger LOGGER = LoggerFactory.getLogger(UploadAdressMasterCommand.class);
	@Autowired
	InsertAddressDataService insertAddressDataService;

	@Override
	public ResponseEntity<List<ErrorRecord>> excute(MultipartFile request) {
		long startTime = System.currentTimeMillis();
		UploadAddressExcelLoader uploadAddressExcelLoader = new UploadAddressExcelLoader(request);
		// check whether the given sheet is valid sheet or not.
		uploadAddressExcelLoader.isValidSheet();
		List<ErrorRecord> errors = new ArrayList<>();
		List<UploadAddressRequest> requests = new ArrayList<>();
		IntStream.range(1, uploadAddressExcelLoader.totalNumberOfRows()).forEach(productIndex -> {
			LOGGER.info("Started processing row ------> " + (productIndex+1));
			// read row of the sheet from row 2
			Optional<UploadAddressRequest> uploadAddressRequestOptional = uploadAddressExcelLoader.next();
			// if row is empty read next row
			if (!uploadAddressRequestOptional.isPresent()) {
				LOGGER.info("Data not present in row ------> " + (productIndex+1));
				return;
			}
			// if row is not empty process the data.
			UploadAddressRequest uploadAddressRequest = uploadAddressRequestOptional.get();
			requests.add(uploadAddressRequest);
			// If any exception is thrown while reading data save the error to the list
			if (uploadAddressRequest.getErrorRecord() != null) {
				errors.add(uploadAddressRequest.getErrorRecord());
			} else {
				ErrorRecord insertData = insertAddressDataService.insertData(uploadAddressRequest);
				if (insertData != null) {
					insertData.setRowId(productIndex + 1);
					errors.add(insertData);
					return;
				}
			}
			LOGGER.info("Finished processing row ------> " + (productIndex+1));
		});
		LOGGER.info("Total rows ------> " + requests.size());
		LOGGER.info("Number of rows with errors ------> " + errors.size());
		LOGGER.info("Total rows uploaded successfully ------> " + (requests.size()-errors.size()));
		LOGGER.info("Total time to upload the sheet ------> " + (System.currentTimeMillis()-startTime) + "milliseconds");
		return ResponseEntity.status(HttpStatus.OK).body(errors);
	}
}
