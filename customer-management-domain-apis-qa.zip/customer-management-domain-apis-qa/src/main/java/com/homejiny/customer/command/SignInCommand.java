package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.request.SignInRequest;
import com.homejiny.customer.response.CustomerSignInResponse;
import com.homejiny.customer.service.CustomerService;

/**
 * @author brahmaiam
 *
 */
@Service
public class SignInCommand implements Command<SignInRequest, ResponseEntity<CustomerSignInResponse>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<CustomerSignInResponse> excute(SignInRequest request) {

		if (request == null || StringUtils.isEmpty(request.getMobileNumber())) {
			CustomerSignInResponse customerSignInResponse = new CustomerSignInResponse();
			customerSignInResponse.setMessage(Constants.INVALID_INPUTS);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(customerSignInResponse);
		}

		return customerService.sendOTP(request);
	}

}
