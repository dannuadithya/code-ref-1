package com.homejiny.customer.master.view;

public class SocietyRequest {
	private long id;
	private long value;

	public long getId() {
		return id;
	}

	public long getValue() {
		return value;
	}

	public void setId(long id) {
		this.id = id;
	}

	public void setValue(long value) {
		this.value = value;
	}

}
