
package com.homejiny.customer.service;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.homejiny.customer.adapter.PushNotificationAdapter;
import com.homejiny.customer.authentications.JWTAuthentication;
import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.entity.AppReferralCodes;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerAddress;
import com.homejiny.customer.entity.CustomerKycDetails;
import com.homejiny.customer.entity.CustomerRewardType;
import com.homejiny.customer.entity.CustomerRewardTypeEnum;
import com.homejiny.customer.entity.KycType;
import com.homejiny.customer.entity.Media;
import com.homejiny.customer.entity.PushNotifications;
import com.homejiny.customer.entity.Rating;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.exception.FileFormatedException;
import com.homejiny.customer.exception.KycDocNumberFormateException;
import com.homejiny.customer.exception.KycNotFoundException;
import com.homejiny.customer.exception.MaxUploadSizeExceededException;
import com.homejiny.customer.exception.PattrenMissMatchedException;
import com.homejiny.customer.master.entity.City;
import com.homejiny.customer.master.entity.Society;
import com.homejiny.customer.master.entity.State;
import com.homejiny.customer.master.repository.AreaRepository;
import com.homejiny.customer.master.repository.MasterCityRepository;
import com.homejiny.customer.master.repository.MasterStateRepository;
import com.homejiny.customer.master.repository.SocietyRepository;
import com.homejiny.customer.repository.AddressRepository;
import com.homejiny.customer.repository.AppReferralCodesRepository;
import com.homejiny.customer.repository.CustomerKycDetailsRepository;
import com.homejiny.customer.repository.CustomerMediaRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.repository.CustomerRewardTypeRepository;
import com.homejiny.customer.repository.KycTypeRepository;
import com.homejiny.customer.repository.PushNotificationRepository;
import com.homejiny.customer.repository.RatingRepository;
import com.homejiny.customer.request.CancelCustomerServiceRequest;
import com.homejiny.customer.request.CustomerAddressReq;
import com.homejiny.customer.request.CustomerKycRequest;
import com.homejiny.customer.request.CustomerRequest;
import com.homejiny.customer.request.CustomerRewardPointLogRequest;
import com.homejiny.customer.request.CustomerUpdateDetailsRequest;
import com.homejiny.customer.request.EmailAddressRequest;
import com.homejiny.customer.request.OTPDetails;
import com.homejiny.customer.request.PushNotificationRequest;
import com.homejiny.customer.request.RatingRequest;
import com.homejiny.customer.request.SignInRequest;
import com.homejiny.customer.request.UpdateAppVersionRequest;
import com.homejiny.customer.request.WalletRequest;
import com.homejiny.customer.response.CancelCustomerServiceRequestResponse;
import com.homejiny.customer.response.CreateWalletResponse;
import com.homejiny.customer.response.CustomerSignInResponse;
import com.homejiny.customer.response.PushNotificationResponse;
import com.homejiny.customer.view.AddressDetails;
import com.homejiny.customer.view.AddressResponse;
import com.homejiny.customer.view.CustomerResponse;
import com.homejiny.customer.view.KycResponse;
import com.homejiny.customer.view.OTPResponseView;
import com.homejiny.customer.view.Response;
import com.homejiny.customer.view.ViewCustomerDetails;
import com.homejiny.customer.view.ViewCustomerServiceOrdersListDetailsResponse;
import com.homejiny.customer.view.ViewServiceOrdersListDetailsResponse;

/**
 * @author brahmaiam
 *
 */
@Service
public class CustomerService {

	private static Pattern fileExtnPtrn = Pattern.compile(".*(\\.(?i)(jpeg|jpg|png)$)");
	private static Pattern numberExtnPtrn = Pattern.compile("[A-Z0-9]+");
	private static Pattern adharNumberPattern = Pattern.compile("[0-9]+");
	private static final Logger logger = LoggerFactory.getLogger(CustomerService.class);

	private static final String ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	PushNotificationRequest pushNotificationRequest = new PushNotificationRequest(); // to set pushnotications details

	@Value("${cloud.aws.credentials.accessKey}")
	private String accessKey;

	@Value("${cloud.aws.credentials.secretKey}")
	private String secretKey;

	@Value("${cloud.aws.region}")
	private String region;

	@Value("${cloud.aws.credentials.bucketName}")
	private String bucketName;

	@Value("${cloud.aws.image_url}")
	private String imageUrl;

	@Value("${sms.otp.verification.service}")
	private String sms_service_url;

	@Value("${wallet.api.endpoint}")
	private String walletEndPoint;

	@Value("${homejiny.signin.reward.points}")
	private long rewardPoints;

	@Value("${service.api.endpoint}")
	private String serviceEndPoint;

	@Value("${homejiny.signin.referal.code}")
	private String homejinyReferalCode;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	AddressRepository addressRepository;

	@Autowired
	CustomerKycDetailsRepository customerKycDetailsRepository;

	@Autowired
	CustomerMediaRepository customerMediaRepository;

	@Autowired
	CustomerRewardTypeRepository customerRewardTypeRepository;

	@Autowired
	KycTypeRepository kycTypeRepository;

	@Autowired
	JWTAuthentication jwtAuthentication;

	@Autowired
	RatingRepository ratingRepository;

	@Autowired
	SocietyRepository societyRepository;

	@Autowired
	AreaRepository areaRepository;

	@Autowired
	CustomerLoyaltyPoints customerLoyaltyPoints;

	@Autowired
	PushNotificationRepository pushNotificationRepository;

	@Autowired
	PushNotificationAdapter pushNotificationAdapter;

	@Autowired
	AppReferralCodesRepository appReferralCodesRepository;

	@Autowired
	SendPushNotificationForKycDetailsService sendPushNotificationForKycDetailsService;

	@Autowired
	MasterStateRepository masterStateRepository;

	@Autowired
	MasterCityRepository masterCityRepository;

	/**
	 * updating customer details based on id
	 * 
	 * @param request
	 * @return
	 */
	public Response updateCustomerDetailsById(CustomerUpdateDetailsRequest request) {
		logger.info("Enter into updateCustomerDetails method");
		Response response = new Response();

		Optional<Customer> customer = customerRepository.findById(request.getCustomerId());
		if (!customer.isPresent()) {
			throw new CustomerNotFoundException(
					Constants.NO_CUSTOMER_EXIST_WITH_CUSTOMER_ID_IS + request.getCustomerId());
		}
		Customer customerEntity = customer.get();
		customerEntity.setUpdatedAt(DateAndTimeUtil.now());

		if (request.getFirstName() != null && request.getFirstName().length() > 0) {
			customerEntity.setFirstName(request.getFirstName());
		}

		if (request.getLastName() != null && request.getLastName().length() > 0) {
			customerEntity.setLastName(request.getLastName());
		}

		if (request.getLastName() != null && request.getLastName().length() > 0) {
			customerEntity.setEmail(request.getEmail());
		}

		CustomerAddress customerAddress = addressRepository.findByCustomer(customer.get());

		if (request.getFloor() != null && request.getFloor().length() > 0) {
			customerAddress.setFloor(request.getFloor());
		}

		if (request.getHouseNumber() != null && request.getHouseNumber().length() > 0) {
			customerAddress.setHouseNumber(request.getHouseNumber());
		}

		customerAddress.setCustomer(customerEntity);

		addressRepository.save(customerAddress);

		response.setId(request.getCustomerId());
		response.setMessage("Customer Details updated");
		response.setStatus("Success");

		return response;
	}

	/**
	 * @param customerRepository
	 * @param addressRepository
	 * @param stateRepository
	 * @param cityRepository
	 * @param societyRepository
	 * @param customerKycDetailsRepository
	 * @param kycTypeRepository
	 * @param customerMediaRepository
	 * @param jwtAuthentication
	 */

	/**
	 * createCustomerAccount
	 * 
	 * @param request
	 * @return CustomerResponse
	 */
	public CustomerResponse createCustomerAccount(OTPDetails request) {

		logger.info("Entering in createCustomerAccount method");
		Customer customer = new Customer();
		customer.setMobileNumber(request.getMobileNumber());
		customer.setCreatedAt(DateAndTimeUtil.now());
		customer.setUpdatedAt(DateAndTimeUtil.now());
		// customer.setReferrerCode(request.getReferralCode());
		customer.setStatus("ACTIVE");
		customer.setWalletId(0);

		// to call crete wallet and set wallet id to customer entity
		String apiEndPoint = walletEndPoint + "v1/wallet/";
		logger.info("Url for Wallet micro services : " + apiEndPoint);
		RestTemplate restTemplate = new RestTemplate();
		WalletRequest walletRequest = new WalletRequest();
		walletRequest.setWalletMobileNumber(request.getMobileNumber());
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON_UTF8);
		HttpEntity<WalletRequest> requestEntity = new HttpEntity<WalletRequest>(walletRequest, headers);
		logger.info("Before rest template");

		ResponseEntity<CreateWalletResponse> result = restTemplate.exchange(apiEndPoint, HttpMethod.POST, requestEntity,
				CreateWalletResponse.class);
		logger.info("After rest template result  " + result);
		result.getBody().getWalletId();
		if (result.getStatusCodeValue() == 200) {
			customer.setWalletId(result.getBody().getWalletId());
			logger.info("The Wallet Id is Created for the mobile No ::" + request.getMobileNumber() + " "
					+ "Wallet Id :: " + result.getBody().getWalletId());
		} else {
			logger.info("Error Is Occured At The Time Of Wallet Creation For The Mobile No :: "
					+ request.getMobileNumber());
			logger.info("Error Is Occured " + result.getStatusCodeValue() + "");
		}
		customer.setAgreed(false);
		Customer customerEntity = customerRepository.save(customer);
		createCustomerRewardType(customerEntity);
		CustomerResponse viewCustomerDetails = new CustomerResponse();
		viewCustomerDetails.setCustomerId(customerEntity.getId());

		if (request.getReferralCode() != null && !request.getReferralCode().isEmpty()) {
			Optional<Customer> getReferreralCode = customerRepository.findByReferrerCode(request.getReferralCode());
			AppReferralCodes appReferralCodes = appReferralCodesRepository
					.findByReferralCode(request.getReferralCode());

			if (getReferreralCode.isPresent()) {
				Customer getReferreralCount = getReferreralCode.get();
				long referrerId = getReferreralCount.getId();
				customerEntity.setReferrerbyId(referrerId);
				customerEntity.setReferrerCodeUsed(request.getReferralCode());
				customerRepository.save(customerEntity);
				getReferreralCount.setReferralCount(getReferreralCount.getReferralCount() + 1);
				customerRepository.save(getReferreralCount);
			} else if (appReferralCodes != null && appReferralCodes.getReferralCode() != null
					&& appReferralCodes.getReferralCode().equalsIgnoreCase(request.getReferralCode())) {
				customerEntity.setReferrerbyId(-1);
				customerEntity.setReferrerCodeUsed(request.getReferralCode());
				customerRepository.save(customerEntity);

			} // else {
				// throw new InvalideReferrerCodeException(Constants.INVALIDE_REFERRAL_CODE);
				// }
		}
		viewCustomerDetails.setMessage(Constants.CUSTOMER_ACCOUNT_CREATED);
		viewCustomerDetails.setStatus(Constants.SUCCESS);
		return viewCustomerDetails;
	}

	private CustomerRewardPointLogRequest setCustomerRewardPointLogRequest(long customerId, String refferalCode) {
		CustomerRewardPointLogRequest customerRewardPointLogRequest = new CustomerRewardPointLogRequest();

		customerRewardPointLogRequest.setCustomerId(customerId);
		customerRewardPointLogRequest.setOperationType(Constants.ADD);
		customerRewardPointLogRequest.setRewardType(CustomerRewardTypeEnum.REFERRAL.toString());
		customerRewardPointLogRequest.setRewardPoints(rewardPoints);
		customerRewardPointLogRequest.setReferralCode(refferalCode);
		return customerRewardPointLogRequest;
	}

	/**
	 * createEmailAddress
	 * 
	 * @param request
	 * @return Response
	 */
	public Response createEmailAddress(EmailAddressRequest request) {

		Optional<Customer> optionalCustomer = customerRepository.findById(request.getCustomerId());

		if (!optionalCustomer.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}

		Customer cust = optionalCustomer.get();

		if (cust.getEmail() == null) {
			cust.setRegistrationStep("email_updated");
		}
		cust.setEmail(request.getEmailId());
		cust.setHasEmail(true);
		cust.setUpdatedAt(DateAndTimeUtil.now());
		customerRepository.save(cust);
		Response viewCustomerDetails = new Response();
		viewCustomerDetails.setId(cust.getId());
		viewCustomerDetails.setHasEmail(cust.getHasEmail());
		viewCustomerDetails.setMessage("Email address updated successful..");
		viewCustomerDetails.setStatus("Success");
		return viewCustomerDetails;
	}

	/**
	 * createCustomerAccount
	 * 
	 * @param customerInfoRequest
	 * @return CustomerResponse
	 */
	public CustomerResponse createCustomerAccount(CustomerRequest customerInfoRequest) {
		logger.info("Entering in customerInfoUpdate method");

		CustomerResponse viewCustomerDetails = new CustomerResponse();
		Optional<Customer> optionalCustomer = customerRepository.findById((customerInfoRequest.getCustomerId()));

		if (!optionalCustomer.isPresent()) {
			throw new CustomerNotFoundException(
					Constants.NO_CUSTOMER_EXIST_WITH_CUSTOMER_ID_IS + customerInfoRequest.getCustomerId());
		}
		Customer cust = optionalCustomer.get();
		cust.setUpdatedAt(DateAndTimeUtil.now());

		if (customerInfoRequest.getFirstName() != null) {
			cust.setFirstName(customerInfoRequest.getFirstName());
		}
		if (customerInfoRequest.getMiddleName() != null) {
			cust.setMiddleName(customerInfoRequest.getMiddleName());
		}

		if (customerInfoRequest.getLastName() != null) {
			cust.setLastName(customerInfoRequest.getLastName());
		}

		cust.setRegistrationStep("name_updated");
		cust.setHasName(true);
		customerRepository.save(cust);

		viewCustomerDetails.setCustomerId(customerInfoRequest.getCustomerId());
		viewCustomerDetails.setHasName(cust.getHasName());
		viewCustomerDetails.setMessage("Customer Account created!!");
		viewCustomerDetails.setStatus(Constants.SUCCESS);
		return viewCustomerDetails;

	}

	/**
	 * sendOTP
	 * 
	 * @param customerRequest
	 * @return ResponseEntity<Response>
	 */
	public ResponseEntity<CustomerSignInResponse> sendOTP(SignInRequest customerRequest) {

		logger.info("Entering in sendOTP method");
		CustomerSignInResponse customerSignInResponse = new CustomerSignInResponse();
		if (customerRequest.getMobileNumber().equals("1234567890")) {

			customerSignInResponse.setStatus(Constants.SUCCESS);
			customerSignInResponse.setMessage(Constants.OTP_SENT + customerRequest.getMobileNumber());
			return ResponseEntity.status(HttpStatus.OK).body(customerSignInResponse);
		}

		String apiEndPoint = sms_service_url + "/sendotp/" + customerRequest.getMobileNumber();
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> result = restTemplate.exchange(apiEndPoint, HttpMethod.GET, null, String.class);

		if (result.getStatusCodeValue() == 200) {
			customerSignInResponse.setStatus(Constants.SUCCESS);
			customerSignInResponse.setMessage(Constants.OTP_SENT + customerRequest.getMobileNumber());
			return ResponseEntity.status(HttpStatus.OK).body(customerSignInResponse);
		} else {
			customerSignInResponse.setStatus(Constants.FAILED);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(customerSignInResponse);
		}

	}

	/**
	 * verifyOTP
	 * 
	 * @param request
	 * @return ResponseEntity<OTPResponseView>
	 */
	public ResponseEntity<OTPResponseView> verifyOTP(OTPDetails request) {
		logger.info("Enter into verifyOPT method");
		OTPResponseView otpResponseView = new OTPResponseView();
		/**
		 * This is added for testing purpose, will remove for prod
		 */
		if (request.getMobileNumber().equals(Constants._1234567890) && request.getOtp().equals(Constants._1234)) {
			otpResponseView.setMessage(Constants.OTP_VERIFIED);
			otpResponseView.setStatus(Constants.SUCCESS);
			otpResponseView.setNewCustomer(true);
			otpResponseView.setAccessToken(jwtAuthentication.generateToken(request.getMobileNumber()));
			Customer customer = customerRepository.findByMobileNumber(request.getMobileNumber());
			if (customer == null) {
				SignInRequest signInRequest = new SignInRequest();
				signInRequest.setMobileNumber(request.getMobileNumber());
				CustomerResponse customerResponse = createCustomerAccount(request);
				otpResponseView.setCustomerId(customerResponse.getCustomerId());
				otpResponseView.setHasAddress(false);
			} else {
				otpResponseView.setCustomerId(customer.getId());
				otpResponseView.setHasAddress(customer.getHasAddress());
			}
			return ResponseEntity.status(HttpStatus.OK).body(otpResponseView);
		}

		if (request.getMobileNumber().equals(Constants._1234567891) && request.getOtp().equals(Constants._1234)) {
			otpResponseView.setMessage(Constants.OTP_VERIFIED);
			otpResponseView.setStatus(Constants.SUCCESS);
			otpResponseView.setAccessToken(jwtAuthentication.generateToken(request.getMobileNumber()));
			Customer customer = customerRepository.findByMobileNumber(request.getMobileNumber());
			otpResponseView.setNewCustomer(!customer.isAgreed());
			otpResponseView.setHasAddress(customer.getHasAddress());
			otpResponseView.setCustomerId(customer.getId());
			otpResponseView.setRegistrationStep(customer.getRegistrationStep());
			return ResponseEntity.status(HttpStatus.OK).body(otpResponseView);
		}

		RestTemplate restTemplate = new RestTemplate();
		String endPoint = sms_service_url + "/verifyotp/mobileNo/" + request.getMobileNumber() + "/otp/"
				+ request.getOtp();
		ResponseEntity<String> result = restTemplate.exchange(endPoint, HttpMethod.GET, null, String.class);

		if (result.getStatusCodeValue() == 200) {
			otpResponseView.setMessage(Constants.OTP_VERIFIED);
			otpResponseView.setStatus(Constants.SUCCESS);
			logger.info("OTP Verification Succesful");

			Customer customer = customerRepository.findByMobileNumber(request.getMobileNumber());

			if (customer == null) {
				SignInRequest signInRequest = new SignInRequest();
				signInRequest.setMobileNumber(request.getMobileNumber());
				CustomerResponse customerResponse = createCustomerAccount(request);
				otpResponseView.setNewCustomer(true);
				otpResponseView.setHasAddress(false);
				otpResponseView.setAccessToken(jwtAuthentication.generateToken(request.getMobileNumber()));
				// otpResponseView.setRegistrationStep(customer.getRegistrationStep());
				otpResponseView.setCustomerId(customerResponse.getCustomerId());
				Optional<Customer> customerEntityOptional = customerRepository
						.findById(customerResponse.getCustomerId());
				if (!customerEntityOptional.isPresent()) {
					throw new CustomerNotFoundException(
							Constants.NO_CUSTOMER_EXIST_WITH_CUSTOMER_ID_IS + customerResponse.getCustomerId());
				} else {
					customerEntityOptional.get().setDeviceToken(request.getDeviceToken());
					customerEntityOptional.get().setVersion(request.getVersion());
					customerEntityOptional.get().setPlatform(request.getPlatform());
					customerRepository.save(customerEntityOptional.get());
				}
				return ResponseEntity.status(HttpStatus.OK).body(otpResponseView);

			}
			otpResponseView.setCustomerId(customer.getId());
			otpResponseView.setNewCustomer(false);
			otpResponseView.setHasAddress(customer.getHasAddress());
			otpResponseView.setAccessToken(jwtAuthentication.generateToken(request.getMobileNumber()));
			otpResponseView.setRegistrationStep(customer.getRegistrationStep());
			customer.setVersion(request.getVersion());
			customer.setPlatform(request.getPlatform());
			customer.setDeviceToken(request.getDeviceToken());
			customerRepository.save(customer);
			if (customer.getDeviceToken() != null) {
				PushNotifications pushNotifications = pushNotificationRepository.findByTitleName("OTP Verified");
				logger.info("pushNotifications entity data :" + pushNotifications);
				pushNotificationRequest.setMessage(pushNotifications.getMessage());
				pushNotificationRequest.setTitle(pushNotifications.getTitleName());
				pushNotificationRequest.setToken(request.getDeviceToken());
				pushNotificationRequest.setTopic("");
				pushNotificationRequest.setScreenflow("otp verified");
				PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
						.sendPushNotification(pushNotificationRequest);
				logger.info("pushNotificationResponse inside verify otp(): " + pushNotificationResponse);
				if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
					logger.info("Failed to call push notification,Reason: " + Constants.REST_API_CALL_FAILED);
				}
			} else {
				logger.info("Device Token not found for that customer :" + customer.getId());
			}

			return ResponseEntity.status(HttpStatus.OK).body(otpResponseView);

		} else {
			otpResponseView.setMessage(Constants.OTP_NOT_VERIFIED);
			otpResponseView.setMessage(Constants.FAILED);
			return ResponseEntity.status(result.getStatusCodeValue()).body(otpResponseView);
		}
	}

	private CustomerRewardType createCustomerRewardType(Customer customer) {
		CustomerRewardType customerRewardType = null;
		List<CustomerRewardType> customerRewardTypesList = new ArrayList<CustomerRewardType>();
		for (int i = 1; i <= CustomerRewardTypeEnum.values().length; i++) {
			CustomerRewardType customerRewardType2 = new CustomerRewardType();
			String type = CustomerRewardTypeEnum.valueOf(i).toString();
			customerRewardType2.setCreatedAt(DateAndTimeUtil.now());
			customerRewardType2.setRewardType(type);
			customerRewardType2.setRewardPoints(0);
			customerRewardType2.setCustomerId(customer);
			customerRewardTypesList.add(customerRewardType2);
		}
		customerRewardTypeRepository.saveAll(customerRewardTypesList);

		logger.info(Constants.RECORD_CREATED_FOR_CUSTOMER_REWARD_TYPE);
		return customerRewardType;

	}

	/**
	 * resendOTP
	 *
	 * @param request
	 * @return ResponseEntity<Response>
	 */
	public ResponseEntity<Response> resendOTP(SignInRequest request) {
		logger.info("Enter into resendOTP method");
		String endPoint = sms_service_url + "/resendotp/" + request.getMobileNumber();
		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<String> result = restTemplate.exchange(endPoint, HttpMethod.GET, null, String.class);

		Response response = new Response();

		if (result.getStatusCodeValue() == 200) {
			response.setStatus(Constants.SUCCESS);
			response.setMessage(Constants.OTP_SENT + request.getMobileNumber());
			return ResponseEntity.status(HttpStatus.OK).body(response);
		} else {
			response.setStatus(Constants.FAILED);
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

	}

	/**
	 * updateCustomerDetails
	 * 
	 * @param request
	 * @return Response
	 */
	public Response updateCustomerDetails(CustomerRequest request) {
		logger.info("Enter into updateCustomerDetails method");
		Response response = new Response();

		Optional<Customer> customer = customerRepository.findById(request.getCustomerId());
		if (!customer.isPresent()) {
			throw new CustomerNotFoundException(
					Constants.NO_CUSTOMER_EXIST_WITH_CUSTOMER_ID_IS + request.getCustomerId());
		}
		Customer customerEntity = customer.get();
		customerEntity.setUpdatedAt(DateAndTimeUtil.now());
		customerEntity.setFirstName(request.getFirstName());
		customerEntity.setLastName(request.getLastName());

		customerEntity.setMiddleName(request.getMiddleName());
		customerRepository.save(customerEntity);

		response.setId(request.getCustomerId());
		response.setMessage("Customer updated");
		response.setStatus("Success");

		return response;
	}

	/**
	 * fetch Customer Details
	 * 
	 * @param request
	 * @return ResponseEntity<ViewCustomerDetails>
	 */
	public ResponseEntity<ViewCustomerDetails> fetchCustomerDetails(Long request) {

		Optional<Customer> customerEntity = customerRepository.findById(request);

		if (!customerEntity.isPresent()) {
			throw new CustomerNotFoundException("this Customer not available");
		}
		Customer customer = customerEntity.get();
		logger.info("Fetch Customer Details with customer Id : " + customer.getId());

		ViewCustomerDetails viewCustomerDetails = getViewCustomerDetails(customer);
		return ResponseEntity.status(HttpStatus.OK).body(viewCustomerDetails);
	}

	/**
	 * get View CustomerDetails
	 * 
	 *
	 * @param customer
	 */
	private ViewCustomerDetails getViewCustomerDetails(Customer customer) {

		ViewCustomerDetails viewCustomerDetails = new ViewCustomerDetails();
		viewCustomerDetails.setCustomerId(customer.getId());
		viewCustomerDetails.setMobileNumber(customer.getMobileNumber());
		viewCustomerDetails.setMiddleName(customer.getMiddleName());
		viewCustomerDetails.setFirstName(customer.getFirstName());
		viewCustomerDetails.setLastName(customer.getLastName());
		viewCustomerDetails.setRegistrationStep(customer.getRegistrationStep());
		viewCustomerDetails.setEmailAddress(customer.getEmail());
		viewCustomerDetails.setWalletId(customer.getWalletId());
		viewCustomerDetails.setDeviceToken(customer.getDeviceToken());
		viewCustomerDetails.setHasEmail(customer.getHasEmail());
		viewCustomerDetails.setHasName(customer.getHasName());
		viewCustomerDetails.setHasAddress(customer.getHasAddress());
		viewCustomerDetails.setHasDeliveryDetails(customer.getHasDeliveryInformationDetails());
		viewCustomerDetails.setHasKyc(customer.getHasKyc());
		
		if(customer.getVersion()!=null) {
			viewCustomerDetails.setDbAppVersion(customer.getVersion());
		}
		
		CustomerAddress customerAddress = addressRepository.findByCustomer(customer);
		if (customerAddress != null) {
			AddressDetails addressDetails = new AddressDetails();
			State state = masterStateRepository.findByName(customerAddress.getState());
			addressDetails.setBlock(customerAddress.getBlock());
			addressDetails.setFloor(customerAddress.getFloor());
			addressDetails.setHouseNo(customerAddress.getHouseNumber());
			addressDetails.setPostalCode(customerAddress.getPostalCode());
			addressDetails.setState(customerAddress.getState());
			addressDetails.setCity(customerAddress.getCity());
			if (state != null) {
				addressDetails.setStateCode(state.getCode());
			}
			if (customerAddress.getArea() != null) {
				addressDetails.setArea(customerAddress.getArea());
			} else if (customerAddress.getOtherArea() != null) {
				addressDetails.setArea(customerAddress.getOtherArea());
			}
			addressDetails.setSociety(customerAddress.getSociety());
			addressDetails.setRingTheBell(customerAddress.isRingTheBell());
			viewCustomerDetails.setAddressDetails(addressDetails);
			if (customerAddress.getSocietyId() != null) {
				if (customerAddress.getSocietyId().getHjAvailability() == 1) {
					viewCustomerDetails.setCanOrderServices(true);
				} else if (customerAddress.getSocietyId().getHjAvailability() == 2) {
					viewCustomerDetails.setCanOrderServices(true);
					viewCustomerDetails.setCanOrderProducts(true);
				} else if (customerAddress.getSocietyId().getHjAvailability() == 0) {
					//viewCustomerDetails.setCanOrderServices(true);
				}
			} else {

				City city = masterCityRepository.findByName(customerAddress.getCity());
				if (state != null && city != null) {
					//viewCustomerDetails.setCanOrderServices(true);
				}
			}
		}
		if (customer.getMedia() != null && customer.getMedia().getOriginalSizePath() != null) {
			viewCustomerDetails.setProfileImage(imageUrl + customer.getMedia().getOriginalSizePath());
		}
		return viewCustomerDetails;
	}

	private String getCustomerAddressAsString(CustomerAddress customerAddress) {
		StringBuilder addressString = new StringBuilder();
		if (!StringUtils.isEmpty(customerAddress.getBlock())) {
			addressString.append(customerAddress.getBlock());
			addressString.append(", ");
		}
		if (!StringUtils.isEmpty(customerAddress.getFloor())) {
			addressString.append(customerAddress.getFloor());
			addressString.append(", ");
		}
		if (!StringUtils.isEmpty(customerAddress.getHouseNumber())) {
			addressString.append(customerAddress.getHouseNumber());
			addressString.append(", ");
		}
		if (!StringUtils.isEmpty(customerAddress.getSociety())) {
			addressString.append(customerAddress.getSociety());
			addressString.append(", ");
		}
		if (!StringUtils.isEmpty(customerAddress.getArea())) {
			addressString.append(customerAddress.getArea());
			addressString.append(", ");
		}
		if (!StringUtils.isEmpty(customerAddress.getCity())) {
			addressString.append(customerAddress.getCity());
			addressString.append(" - ");
		}
		if (!StringUtils.isEmpty(customerAddress.getPostalCode())) {
			addressString.append(customerAddress.getPostalCode());
		}
		return addressString.toString();
	}

	/**
	 * fetch service orders list
	 *
	 * @param customerId
	 * @return ViewCustomerServiceOrdersListDetailsResponse
	 */
	public ResponseEntity<ViewCustomerServiceOrdersListDetailsResponse> fetchServiceOrdersList(Long customerId) {

		Optional<Customer> customerEntity = customerRepository.findById(customerId);

		if (!customerEntity.isPresent()) {
			throw new CustomerNotFoundException("Customer with id: " + customerId + "not found");
		}
		Customer customer = customerEntity.get();
		logger.info("Fetch Service orders list  with customer Id : " + customer.getId());

		String apiEndPoint = serviceEndPoint + Constants.SERVICE_ORDERS_LIST_API + customerId;
		logger.info("service Endpoint url for getting service orders with customerId  : " + apiEndPoint);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<ViewServiceOrdersListDetailsResponse> response = restTemplate.exchange(apiEndPoint,
				HttpMethod.GET, null, ViewServiceOrdersListDetailsResponse.class);
		ViewCustomerServiceOrdersListDetailsResponse viewCustomerServiceOrdersListDetailsResponse = new ViewCustomerServiceOrdersListDetailsResponse();
		viewCustomerServiceOrdersListDetailsResponse.setCustomerId(customerId);
		viewCustomerServiceOrdersListDetailsResponse.setStatus(Constants.SUCCESS);
		viewCustomerServiceOrdersListDetailsResponse.setMessage("Fetched Service Orders successfully");
		viewCustomerServiceOrdersListDetailsResponse
				.setViewServiceOrdersListDetailsList(response.getBody().getViewServiceOrdersListDetailsList());
		CustomerAddress customerAddress = addressRepository.findByCustomer(customer);
		if (customerAddress != null) {
			viewCustomerServiceOrdersListDetailsResponse
					.setCustomerAddress(getCustomerAddressAsString(customerAddress));
		}
		logger.info("Response from service end point: Number of service orders "
				+ response.getBody().getViewServiceOrdersListDetailsList().size());
		return ResponseEntity.status(HttpStatus.OK).body(viewCustomerServiceOrdersListDetailsResponse);

	}

	public ResponseEntity<CancelCustomerServiceRequestResponse> cancelCustomerServiceRequest(
			CancelCustomerServiceRequest cancelCustomerServiceRequest) {

		Optional<Customer> customerEntity = customerRepository.findById(cancelCustomerServiceRequest.getCustomerId());

		if (!customerEntity.isPresent()) {
			throw new CustomerNotFoundException(
					"Customer with id: " + cancelCustomerServiceRequest.getCustomerId() + "not found");
		}
		String apiEndPoint = serviceEndPoint + Constants.CANCEL_SERVICE_REQUEST_API
				+ cancelCustomerServiceRequest.getCustomerId() + "/"
				+ cancelCustomerServiceRequest.getServiceRequestId();
		logger.info("service Endpoint url for cancelling service request  : " + apiEndPoint);

		RestTemplate restTemplate = new RestTemplate();
		ResponseEntity<CancelCustomerServiceRequestResponse> response = restTemplate.exchange(apiEndPoint,
				HttpMethod.PUT, null, CancelCustomerServiceRequestResponse.class);

		logger.info(
				"Response from service end point for cancelling service request " + response.getBody().getMessage());
		return ResponseEntity.status(HttpStatus.OK).body(response.getBody());

	}

	/**
	 * create Kyc Details
	 * 
	 * @param customerKycRequest
	 * @return ResponseEntity<KycResponse>
	 */
	public ResponseEntity<KycResponse> createKycDetails(CustomerKycRequest customerKycRequest) {

		logger.info("KYC document creation is Started");
		KycResponse kycResponse = new KycResponse();
		CustomerKycDetails customerKycDetails = new CustomerKycDetails();
		Media customermedia = new Media();

		Optional<Customer> customerId = customerRepository.findById(customerKycRequest.getCustomerId());

		if (!customerId.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}
		Customer customer = customerId.get();

		if (customer.isKycVerified() == false) {
			if (validateFileExtn(customerKycRequest.getMediaFile().getOriginalFilename())) {

				customermedia = uploadMedia(customerKycRequest.getMediaFile(), customerKycRequest.getCustomerId());
				customerKycDetails.setMedia(customermedia);
				customerKycDetails.setKycDocNumber(customerKycRequest.getKycdocNumber());
				customerKycDetails.setImageView(customerKycRequest.getImageView().toString());
				customerKycDetails.setCreatedAt(DateAndTimeUtil.now());
				customerKycDetails.setUpdatedAt(DateAndTimeUtil.now());
				KycType kyctype = kycTypeRepository.findByCodeAndStatus(customerKycRequest.getKycCode(),
						Constants.KYC_ACTIVE);
				customerKycDetails.setCustomer(customer);
				if (kyctype == null) {
					throw new KycNotFoundException(Constants.KYC_TYPE);
				}
				String nameOfValue = kyctype.getName();
				customerKycDetails.setKycType(kyctype);
				if (nameOfValue.equals(Constants.AADHAR_CARD)) {
					adharvalidateNumberExtn(kyctype.getName(), customerKycRequest.getKycdocNumber());

				} else {
					validateAlphanumericExtn(kyctype.getName(), customerKycRequest.getKycdocNumber());
				}

			} else {
				throw new FileFormatedException(Constants.FILE_FORMATED);
			}
		} else {
			updateKyc(customerKycRequest);
		}

		CustomerKycDetails saveKycType = customerKycDetailsRepository.save(customerKycDetails);
		customer.setRegistrationStep("kyc_updated");
		customer.setHasKyc(true);
		customer.setKycVerified(true);
		customerRepository.save(customer);
		kycResponse.setId(saveKycType.getId());
		kycResponse.setHasKyc(customer.getHasKyc());
		kycResponse.setImageUrl(imageUrl + customerKycRequest.getMediaFile().getOriginalFilename());
		kycResponse.setMessage(Constants.KYC_UPLOAD_SUCCESS);
		kycResponse.setStatus(Constants.SUCCESS);
		if (customer.getDeviceToken() != null) {
			sendPushNotificationForKycDetailsService.sendPushNotificationForKycDetails(customer.getId());
		} else {
			logger.info("Device Token not found for that customer :" + customer.getId());
		}
		logger.info("KYC document creation() is ended");
		return ResponseEntity.status(HttpStatus.CREATED).body(kycResponse);
	}

	public KycResponse updateKyc(CustomerKycRequest customerKycRequest) {

		logger.info("KYC document Update is Started");
		KycResponse kycResponse = new KycResponse();
		CustomerKycDetails customerKycDetails = new CustomerKycDetails();
		Media customermedia = new Media();

		Optional<Customer> customerId = customerRepository.findById(customerKycRequest.getCustomerId());

		if (!customerId.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}
		Customer customer = customerId.get();
		if (validateFileExtn(customerKycRequest.getMediaFile().getOriginalFilename())) {

			customermedia = uploadMedia(customerKycRequest.getMediaFile(), customerKycRequest.getCustomerId());
			customerKycDetails.setMedia(customermedia);
			customerKycDetails.setKycDocNumber(customerKycRequest.getKycdocNumber());
			customerKycDetails.setImageView(customerKycRequest.getImageView().toString());

			customerKycDetails.setCreatedAt(DateAndTimeUtil.now());
			customerKycDetails.setUpdatedAt(DateAndTimeUtil.now());

			KycType kyctype = kycTypeRepository.findByCodeAndStatus(customerKycRequest.getKycCode(),
					Constants.KYC_ACTIVE);

			customerKycDetails.setCustomer(customer);

			if (kyctype == null) {
				throw new KycNotFoundException(Constants.KYC_TYPE);
			}
			String nameOfValue = kyctype.getName();
			customerKycDetails.setKycType(kyctype);
			if (nameOfValue.equals(Constants.AADHAR_CARD)) {
				adharvalidateNumberExtn(kyctype.getName(), customerKycRequest.getKycdocNumber());

			} else {
				validateAlphanumericExtn(kyctype.getName(), customerKycRequest.getKycdocNumber());
			}

		} else {
			throw new FileFormatedException(Constants.FILE_FORMATED);
		}

		CustomerKycDetails saveKycType = customerKycDetailsRepository.save(customerKycDetails);
		customer.setRegistrationStep("kyc_updated");
		customer.setHasKyc(true);
		customerRepository.save(customer);
		kycResponse.setId(saveKycType.getId());
		kycResponse.setHasKyc(customer.getHasKyc());
		kycResponse.setImageUrl(imageUrl + customerKycRequest.getMediaFile().getOriginalFilename());
		kycResponse.setMessage(Constants.KYC_UPLOAD_SUCCESS);
		kycResponse.setStatus(Constants.SUCCESS);

		return kycResponse;

	}

	/**
	 * createAWSConnection
	 * 
	 * @return AmazonS3
	 */
	public AmazonS3 createAWSConnection() {
		AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);

		return AmazonS3ClientBuilder.standard().withCredentials(new AWSStaticCredentialsProvider(credentials))
				.withRegion(region).build();
	}

	/**
	 * getMediaFileNameFromPath
	 * 
	 * @param path
	 * @return String
	 */
	private String getMediaFileNameFromPath(String path) {

		return path.substring(0, path.lastIndexOf('.'));
	}

	/**
	 * get Media FileSize
	 * 
	 * @param file
	 * @return double
	 */
	private double getMediaFileSize(File file) {

		double requestValue = (file.length() / 1024);

		double currentValue = 2000000;
		if (requestValue > currentValue) {

			throw new MaxUploadSizeExceededException(Constants.File_SIZE);
		}
		return requestValue;

	}

	/**
	 * get MediaExtension
	 * 
	 * @param url
	 * @return String
	 */
	private String getMediaExtension(String url) {
		return url.substring(url.lastIndexOf('.') + 1, url.length());
	}

	/**
	 * validateAlphanumericExtn
	 * 
	 * @param name
	 * @param number
	 * @return Boolean
	 */
	public static Boolean validateAlphanumericExtn(String name, String number) {

		if (name.equals(Constants.PAN_CARD) && number.length() != Constants.PAN_CARD_LENGTH)
			throw new KycDocNumberFormateException(Constants.PAN_CARD_SIZE);

		else if (name.equals(Constants.DRIVING_CARD) && number.length() > Constants.DRIVING_LIC_CARD_LENGTH)
			throw new KycDocNumberFormateException(Constants.DRIVING_LIC_CARD_SIZE);

		else if (name.equals(Constants.VOTER_CARD) && number.length() > Constants.VOTER_CARD_LENGTH)
			throw new KycDocNumberFormateException(Constants.VOTER_CARD_SIZE);

		else if (name.equals(Constants.PASSPORT) && number.length() > Constants.PASSPORT_LENGTH)
			throw new KycDocNumberFormateException(Constants.PASSPORT_SIZE);

		boolean flag = true;

		Matcher mtch = numberExtnPtrn.matcher(number);

		if (!mtch.matches()) {
			throw new PattrenMissMatchedException(Constants.ALPHA_NUMARIC_PATTERN);
		}
		return flag;

	}

	/**
	 * adharvalidateNumberExtn
	 * 
	 * @param name
	 * @param number
	 * @return Boolean
	 */
	public static Boolean adharvalidateNumberExtn(String name, String number) {

		if (name.equals(Constants.AADHAR_CARD) && number.length() > Constants.ADHAR_CARD_LENGTH) {
			throw new KycDocNumberFormateException(Constants.ADHAR_CARD_SIZE);
		}

		boolean flag = true;
		Matcher mtch = adharNumberPattern.matcher(number);

		if (!mtch.matches()) {
			throw new PattrenMissMatchedException(Constants.NUMARIC_PATTERN);
		}
		return flag;

	}

	/**
	 * validate File Extn
	 * 
	 * @param file
	 * @return Boolean
	 */
	public static Boolean validateFileExtn(String file) {
		boolean flag = true;
		Matcher mtch = fileExtnPtrn.matcher(file);
		if (!mtch.matches()) {
			flag = false;
		}
		return flag;

	}

	/**
	 * upload Media
	 * 
	 * @param multiPartFile
	 * @param directoryName
	 * @return CustomerMedia
	 */
	public Media uploadMedia(MultipartFile multiPartFile, long directoryName) {

		logger.info("Create a media upload file");

		File mediaFile = new File(multiPartFile.getOriginalFilename());
		try (FileOutputStream fileOutputStream = new FileOutputStream(mediaFile)) {

			fileOutputStream.write(multiPartFile.getBytes());
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}
		try {
			createAWSConnection().putObject(bucketName, directoryName + "/" + mediaFile.getName(), mediaFile);
		} catch (AmazonServiceException amazonException) {
			throw new RuntimeException(amazonException.getMessage());
		}

		Media customerMedia = new Media();

		customerMedia.setCreatedAt(DateAndTimeUtil.now());
		customerMedia.setOriginalSizePath(directoryName + "/" + mediaFile.getName());
		customerMedia.setOriginalFileName(getMediaFileNameFromPath(mediaFile.getName()));
		customerMedia.setSize(getMediaFileSize(mediaFile));
		customerMedia.setMediaType(getMediaExtension(mediaFile.getName()));
		customerMedia.setStorageType(Constants.STORAGE_SERVICE);
		customerMedia.setUpdatedAt(DateAndTimeUtil.now());

		customerMedia = customerMediaRepository.save(customerMedia);

		return customerMedia;
	}

	/**
	 * create Customer Address
	 * 
	 * @param request
	 * @return AddressResponse
	 */
	public AddressResponse createOrUpdateCustomerAddress(CustomerAddressReq request) {
		Optional<Customer> customerOptional = customerRepository.findById(request.getCustomerId());
		if (!customerOptional.isPresent()) {
			throw new CustomerNotFoundException("Invalid customer id : " + request.getCustomerId());
		}
		AddressResponse response = new AddressResponse();
		CustomerAddress existCustomerAddress = addressRepository.findByCustomer(customerOptional.get());
		CustomerAddress address = null;
		Optional<Society> societyEntity = societyRepository.findById(request.getSocietyId());

		if (existCustomerAddress == null) {
			Customer customer = customerOptional.get();
			customer.setRegistrationStep("address_updated");
			customer.setHasAddress(true);
			customer.setUpdatedAt(DateAndTimeUtil.now());
			customer.setCreatedAt(DateAndTimeUtil.now());
			customer.setRingTheBell(request.isRingTheBell());
			customerRepository.save(customer);
			CustomerAddress customerAddress = new CustomerAddress();
			if (societyEntity.isPresent()) {
				setCustomerAddressData(request, customerAddress, societyEntity.get());
			} else {
				setCustomerAddressData(request, customerAddress, null);
			}
			customerAddress.setStatus("active");
			customerAddress.setCreatedAt(DateAndTimeUtil.now());
			customerAddress.setUpdatedAt(DateAndTimeUtil.now());
			customerAddress.setCustomer(customer);
			address = addressRepository.save(customerAddress);
			response.setMessage("Customer address created successfully");
		} else {
			if (societyEntity.isPresent()) {
				setCustomerAddressData(request, existCustomerAddress, societyEntity.get());
			} else {
				setCustomerAddressData(request, existCustomerAddress, null);
			}
			existCustomerAddress.setUpdatedAt(DateAndTimeUtil.now());
			address = addressRepository.save(existCustomerAddress);
			response.setMessage("Customer address updated successfully");
		}
		response.setAddressId(address.getId());
		if (StringUtils.isEmpty(address.getArea())) {
			response.setStatus("Accepted");
			response.setMessage(
					"We are not available in your location currently. We shall notify you once we're there!");
			return response;
		}

		response.setStatus("SUCCESS");
		return response;
	}

	/**
	 * This method is used to set Customer Address Data
	 * 
	 * @param request
	 * @param customerAddress
	 * @param society
	 */
	private void setCustomerAddressData(CustomerAddressReq request, CustomerAddress customerAddress, Society society) {
		customerAddress.setBlock(request.getBlock());
		customerAddress.setCity(request.getCity());
		customerAddress.setState(request.getState());
		customerAddress.setSociety(request.getSociety());
		customerAddress.setFloor(request.getFloor());
		customerAddress.setHouseNumber(request.getHouseNo());
		customerAddress.setPostalCode(request.getPostalCode());
		customerAddress.setRingTheBell(request.isRingTheBell());
		if (!StringUtils.isEmpty(request.getArea())) {
			customerAddress.setArea(request.getArea());
			customerAddress.setOtherArea(null);
		} else {
			customerAddress.setOtherArea(request.getOtherArea());
			customerAddress.setArea(null);
		}
		customerAddress.setSocietyId(society);
	}

	/**
	 * submitReviewRating
	 * 
	 * @param request
	 * @return ResponseEntity<Response>
	 */
	public Response submitReviewRating(RatingRequest request) {
		Response response = new Response();

		Rating rating = new Rating();
		rating.setComment(request.getComment());
		rating.setCustomerId(request.getCustomerId());
		rating.setServiceId(request.getServiceId());
		rating.setStarRatings(request.getStarRatings());
		rating.setVendorId(request.getVendorId());
		rating.setBookingDate(request.getBookingDate().toString());
		rating.setServiceName(request.getServiceName());

		ratingRepository.save(rating);

		response.setMessage(Constants.REVIEW_RATINGS_SUBMITTED_SUCCESSFULLY);
		response.setStatus(Constants.SUCCESS);
		response.setId(rating.getId());

		logger.info(Constants.REVIEW_RATING_SUBMITTED_SUCCESSFULLY + rating.getId());
		return response;

	}
	
	public ResponseEntity<CustomerResponse> updateAppVersion(UpdateAppVersionRequest updateAppVersionRequest) {

		Optional<Customer> customerEntity = customerRepository.findById(updateAppVersionRequest.getCustomerId());
		if (!customerEntity.isPresent()) {
			throw new CustomerNotFoundException("Customer not found with vendor id:" + updateAppVersionRequest.getCustomerId());
		}
		Customer customer= customerEntity.get();
		customer.setUpdatedAt(DateAndTimeUtil.now());		
		if(!updateAppVersionRequest.getVersion().equalsIgnoreCase(customer.getVersion())) {
			customer.setOldVersion(customer.getVersion());
		}
		customer.setVersion(updateAppVersionRequest.getVersion());
		customer.setPlatform(updateAppVersionRequest.getPlatform());		
		customer.setAppUpdatedTime(DateAndTimeUtil.now());
		customerRepository.save(customer);

		CustomerResponse response = new CustomerResponse();
		response.setCustomerId(updateAppVersionRequest.getCustomerId());
		response.setMessage(Constants.APP_VERSION_UPDATED);
		response.setStatus(Constants.SUCCESS);
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

}
