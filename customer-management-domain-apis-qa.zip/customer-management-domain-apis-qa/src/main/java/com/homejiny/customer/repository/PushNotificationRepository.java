package com.homejiny.customer.repository;

import java.math.BigDecimal;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.entity.PushNotifications;

@Repository
public interface PushNotificationRepository extends JpaRepository<PushNotifications, String> {

	PushNotifications findByTitleName(String titleName);

	@Query(value = "select distinct(c.id),concat(c.first_name,' ',c.last_name) as customerName, cast(coalesce((w.total_amount),0)as decimal(10,2)) as walletBalance ,c.device_token as deviceToken\n"
			+ "from hj_customer c\n" + "join hj_wallet w on w.id=c.wallet_id  where c.id = ?1", nativeQuery = true)
	Object[][] cartUsers(Long id);

	@Query(value = "\n"
			+ "select c.id,concat(c.first_name,' ',c.last_name) as customerName , c.device_token ,crpr.points_redemed\n"
			+ "from hj_customer c\n" + "join hj_customer_reward_points_redemption crpr on crpr.hj_customer_id=c.id\n"
			+ "where c.id = ?1", nativeQuery = true)

	Object[][] pointsRedeemed(Long customerId);

	@Query(value = "select cast(coalesce((total_amount),0)as decimal(10,2)) as total_amount from hj_wallet where id=?1", nativeQuery = true)
	BigDecimal getWalletDetails(Long walletId);

}
