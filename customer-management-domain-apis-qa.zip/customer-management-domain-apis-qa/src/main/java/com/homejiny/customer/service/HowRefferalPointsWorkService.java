package com.homejiny.customer.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.RefferalPoints;
import com.homejiny.customer.exception.RecordNotFoundException;
import com.homejiny.customer.repository.RefferalPointsRepository;
import com.homejiny.customer.request.RefferalPointsRequest;
import com.homejiny.customer.response.RefferalPointsResponse;

@Service
public class HowRefferalPointsWorkService {

	@Autowired
	RefferalPointsRepository refferalPointsRepository;

	public RefferalPoints getHowRefferalPointsWorksService(long id) {

		Optional<RefferalPoints> refferalPoint = refferalPointsRepository.findById(id);
		if (!refferalPoint.isPresent()) {
			throw new RecordNotFoundException(Constants.NO_RECORD_FOUND_WITH_ID);
		}
		RefferalPointsRequest request = new RefferalPointsRequest();
		request.setId(refferalPoint.get().getId());
		request.setPointsValue(refferalPoint.get().getPointsValue());
		request.setRefferalType(refferalPoint.get().getRefferalType());
		return refferalPointsRepository.save(refferalPoint.get());
	}

	public RefferalPointsResponse getHowRefferalPointsWorks(Long id) {

		RefferalPointsResponse refferalPointsResponse = new RefferalPointsResponse();
		refferalPointsResponse.setData(getHowRefferalPointsWorksService(id));
		refferalPointsResponse.setStatus(Constants.SUCCESS);
		return refferalPointsResponse;
	}

}
