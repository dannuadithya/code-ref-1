package com.homejiny.customer.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.entity.KycType;

/**
 * @author brahmaiam
 *
 */
@Repository
public interface KycTypeRepository extends JpaRepository<KycType, Long> {

	KycType findByCodeAndStatus(String string, String kycActive);

	KycType findByCode(String string);

}
