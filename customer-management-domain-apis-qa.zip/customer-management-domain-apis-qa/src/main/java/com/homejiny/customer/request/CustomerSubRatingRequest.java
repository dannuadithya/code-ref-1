package com.homejiny.customer.request;

import com.homejiny.customer.common.HJProvide;

public class CustomerSubRatingRequest {

	private long customerId;
	private double deliveryRating;
	private double priceRating;
	private double qualityRating;
	private double starRating;
	private long Id;
	private String text;
	private HJProvide type;

	public double getStarRating() {
		return starRating;
	}

	public void setStarRating(double starRating) {
		this.starRating = starRating;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public HJProvide getType() {
		return type;
	}

	public void setType(HJProvide type) {
		this.type = type;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public double getDeliveryRating() {
		return deliveryRating;
	}

	public void setDeliveryRating(double deliveryRating) {
		this.deliveryRating = deliveryRating;
	}

	public double getPriceRating() {
		return priceRating;
	}

	public void setPriceRating(double priceRating) {
		this.priceRating = priceRating;
	}

	public double getQualityRating() {
		return qualityRating;
	}

	public void setQualityRating(double qualityRating) {
		this.qualityRating = qualityRating;
	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

}
