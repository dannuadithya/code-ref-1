package com.homejiny.customer.master.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.exception.InValidInputException;
import com.homejiny.customer.exception.SocietyNotFoundException;
import com.homejiny.customer.master.entity.Society;
import com.homejiny.customer.master.repository.MasterSocietyRepository;
import com.homejiny.customer.master.view.ResponseView;
import com.homejiny.customer.master.view.SocietyRequest;
import com.homejiny.customer.master.view.ViewSociety;

@Service
public class SocietyService {

	private static final Logger logger = LoggerFactory.getLogger(SocietyService.class);

	@Autowired
	MasterSocietyRepository masterSocietyRepository;

	public ResponseEntity<ResponseView> fetchAllSocieties() {
		logger.info("fetchAllSocieties method started..!");
		List<Society> societies = masterSocietyRepository.findAllByOrderByDisplayOrderAsc();
		List<ViewSociety> societyResponse = new ArrayList<>();
		societies.forEach(society -> {
			ViewSociety viewSociety = new ViewSociety();
			viewSociety.setId(society.getId());
			viewSociety.setName(society.getSocietyName());
			viewSociety.setHjAvailability(society.getHjAvailability());
			viewSociety.setDisplayOrder(society.getDisplayOrder());
			viewSociety.setStatus(society.getStatus());
			societyResponse.add(viewSociety);
		});
		ResponseView responseView = new ResponseView();
		responseView.setStatus(Constants.SUCCESS);
		responseView.setData(societyResponse);
		logger.info("fetchAllSocieties method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(responseView);
	}

	public ResponseEntity<ResponseView> updateSocietyOrder(List<ViewSociety> societyRequest) {
		logger.info("updateSocietyOrder method started..!");

		societyRequest.forEach(society -> {
			int displayOrder = societyRequest.indexOf(society)+1;
			Optional<Society> optional = masterSocietyRepository.findById(society.getId());
			if (optional.isPresent()) {
				Society newSociety = optional.get();
				newSociety.setDisplayOrder(displayOrder);
				masterSocietyRepository.save(newSociety);
			}
		});

		ResponseView responseView = new ResponseView();
		responseView.setStatus(Constants.SUCCESS);
		responseView.setData("Society display order updated successfully..!");
		logger.info("updateSocietyOrder method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(responseView);
	}

	public ResponseEntity<ResponseView> updateHjAvailability(SocietyRequest societyRequest) {
		logger.info("updateHjAvailability method started..!");

		Optional<Society> optional = masterSocietyRepository.findById(societyRequest.getId());
		if (!optional.isPresent()) {
			throw new SocietyNotFoundException(Constants.SOCIETY_NOT_AVAILABLE + societyRequest.getId());
		}
		
		if (societyRequest.getValue()>2) {
			throw new InValidInputException(Constants.SOCIETY_HJAVAILABILITY);
		}
		
		Society newSociety = optional.get();
		newSociety.setHjAvailability(societyRequest.getValue());
		masterSocietyRepository.save(newSociety);

		ResponseView responseView = new ResponseView();
		responseView.setStatus(Constants.SUCCESS);
		responseView.setData("HjAvailability updated successfully for society :" + newSociety.getSocietyName());
		logger.info("updateHjAvailability method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(responseView);
	}

}
