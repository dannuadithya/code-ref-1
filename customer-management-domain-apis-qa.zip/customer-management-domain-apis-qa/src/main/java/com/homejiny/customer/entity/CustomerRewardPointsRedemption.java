package com.homejiny.customer.entity;

import java.sql.Date;
import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity(name = "hj_customer_reward_points_redemption")
@Table(name = "HJ_CUSTOMER_REWARD_POINTS_REDEMPTION")
public class CustomerRewardPointsRedemption {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID")
	private long id;

	@Column(name = "created_time")
	private LocalDateTime createdTime;

	@Column(name = "updated_time")
	private LocalDateTime updatedTime;

	@Column(name = "hj_customer_id")
	private long customerId;

	@Column(name = "points_redemed")
	private long pointsRedemed;

	@Column(name = "status")
	private String status;

	@Column(name = "Transaction_id")
	private String TransactionId;

	@Column(name = "Transaction_date")
	private Date TransactionDate;

	@Column(name = "money_added_to_wallet_date")
	private LocalDate moneyAddedToWalletDate;

	@Column(name = "amount")
	private double amount;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDateTime getCreatedTime() {
		return createdTime;
	}

	public void setCreatedTime(LocalDateTime createdTime) {
		this.createdTime = createdTime;
	}

	public LocalDateTime getUpdatedTime() {
		return updatedTime;
	}

	public void setUpdatedTime(LocalDateTime updatedTime) {
		this.updatedTime = updatedTime;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public long getPointsRedemed() {
		return pointsRedemed;
	}

	public void setPointsRedemed(long pointsRedemed) {
		this.pointsRedemed = pointsRedemed;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getTransactionId() {
		return TransactionId;
	}

	public void setTransactionId(String transactionId) {
		TransactionId = transactionId;
	}

	public Date getTransactionDate() {
		return TransactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		TransactionDate = transactionDate;
	}

	public LocalDate getMoneyAddedToWalletDate() {
		return moneyAddedToWalletDate;
	}

	public void setMoneyAddedToWalletDate(LocalDate moneyAddedToWalletDate) {
		this.moneyAddedToWalletDate = moneyAddedToWalletDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
