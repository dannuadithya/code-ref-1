package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homejiny.customer.request.OTPDetails;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.OTPResponseView;

/**
 * @author brahmaiam
 *
 */
@Service
public class VerifyOTPCommand implements Command<OTPDetails, ResponseEntity<OTPResponseView>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<OTPResponseView> excute(OTPDetails request) {

		if (request == null
				|| (StringUtils.isEmpty(request.getMobileNumber()) || StringUtils.isEmpty(request.getOtp()))) {
			OTPResponseView response = new OTPResponseView();
			response.setMessage("Invalid Inputs");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

		return customerService.verifyOTP(request);
	}
}
