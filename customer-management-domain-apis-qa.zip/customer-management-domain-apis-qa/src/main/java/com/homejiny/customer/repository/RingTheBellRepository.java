package com.homejiny.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.entity.Customer;

@Repository
public interface RingTheBellRepository extends JpaRepository<Customer, Long> {

}
