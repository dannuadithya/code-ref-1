package com.homejiny.customer.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.State;

@Repository
public interface MasterStateRepository extends JpaRepository<State, Long> {

	State findByName(String stateName);

	List<State> findAllByStatus(String status);

}
