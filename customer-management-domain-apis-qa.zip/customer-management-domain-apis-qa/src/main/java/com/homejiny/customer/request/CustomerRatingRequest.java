package com.homejiny.customer.request;

import com.homejiny.customer.common.HJProvide;

public class CustomerRatingRequest {

	private long customerId;
	private double rating;
	private long Id;
	private HJProvide type;
	private String text;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public long getId() {
		return Id;
	}

	public void setId(long id) {
		Id = id;
	}

	public HJProvide getType() {
		return type;
	}

	public void setType(HJProvide type) {
		this.type = type;
	}

}
