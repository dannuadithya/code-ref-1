package com.homejiny.customer.master.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.Area;
import com.homejiny.customer.master.entity.Society;

/**
 * @author Haripriya.V
 *
 */
@Repository
public interface SocietyRepository extends JpaRepository<Society, Long> {

	Society findBySocietyName(String society);

	Society findBySocietyNameAndArea(String soceityName, Area area);

	

	

}
