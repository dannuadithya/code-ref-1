package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.request.CancelCustomerServiceRequest;
import com.homejiny.customer.response.CancelCustomerServiceRequestResponse;
import com.homejiny.customer.service.CustomerService;

/**
 * @author - Chaitanya Mannem
 */
@Service
public class CancelCustomerServiceRequestCommand implements Command<CancelCustomerServiceRequest, ResponseEntity<CancelCustomerServiceRequestResponse>> {

    @Autowired
    CustomerService customerService;

    public ResponseEntity<CancelCustomerServiceRequestResponse> excute(CancelCustomerServiceRequest cancelCustomerServiceRequest) {

        CancelCustomerServiceRequestResponse cancelCustomerServiceRequestResponse;

        if (cancelCustomerServiceRequest.getCustomerId() == null) {
            cancelCustomerServiceRequestResponse = new CancelCustomerServiceRequestResponse();
            cancelCustomerServiceRequestResponse.setMessage("Invalid inputs");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(cancelCustomerServiceRequestResponse);
        }
        return customerService.cancelCustomerServiceRequest(cancelCustomerServiceRequest);
    }


}
