package com.homejiny.customer.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.Media;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.request.ProfilePictureRequest;
import com.homejiny.customer.view.ProfilePictureResponse;

/**
 * @author ashok
 *
 */
@Service
public class ProfilePictureService {

	private static final Logger logger = LoggerFactory.getLogger(ProfilePictureService.class);

	@Value("${cloud.aws.image_url}")
	private String imageUrl;

	@Autowired
	CustomerService customerService;

	@Autowired
	CustomerRepository customerRepository;

	/**
	 * @param AddProfilePicture
	 * @return
	 */
	public ProfilePictureResponse addProfilePicture(ProfilePictureRequest profilePictureRequest) {
		logger.info("Enter the Profile picture method");

		Optional<Customer> customerEntity = customerRepository.findById(profilePictureRequest.getCustomerId());

		if (!customerEntity.isPresent()) {
			throw new CustomerNotFoundException(
					Constants.CUSTOMER_NOT_FOUND_WITH_THIS_ID + profilePictureRequest.getCustomerId());
		}

		ProfilePictureResponse profilePictureResponse = new ProfilePictureResponse();
		Media profilePictureMedia = new Media();
		Customer customer = customerEntity.get();
		profilePictureMedia = customerService.uploadMedia(profilePictureRequest.getProfilePicture(),
				profilePictureRequest.getCustomerId());
		customer.setMedia(profilePictureMedia);
		customer.setUpdatedAt(DateAndTimeUtil.now());

		customerRepository.save(customer);

		profilePictureResponse.setId(customer.getId());
		profilePictureResponse.setStatus(Constants.SUCCESS);
		profilePictureResponse.setMessage(Constants.PROFILE_PICTURE);
		profilePictureResponse.setImageUrl(imageUrl + profilePictureMedia.getOriginalSizePath());

		return profilePictureResponse;

	}

}
