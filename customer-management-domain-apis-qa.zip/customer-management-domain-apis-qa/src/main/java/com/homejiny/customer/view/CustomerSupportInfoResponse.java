package com.homejiny.customer.view;

import com.homejiny.customer.entity.CustomerSupportInfo;

public class CustomerSupportInfoResponse {

	private String status;
	private CustomerSupportInfo data;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public CustomerSupportInfo getData() {
		return data;
	}

	public void setData(CustomerSupportInfo data) {
		this.data = data;
	}


}
