package com.homejiny.customer.view;

import java.math.BigDecimal;

public class WalletDetails {

	private BigDecimal walletTotalAmount;
	private BigDecimal walletAvailableAmount;
	private BigDecimal walletHoldAmount;
	private String walletStatus;
	private String walletMobileNumber;

	public BigDecimal getWalletTotalAmount() {
		return walletTotalAmount;
	}

	public void setWalletTotalAmount(BigDecimal walletTotalAmount) {
		this.walletTotalAmount = walletTotalAmount;
	}

	public BigDecimal getWalletAvailableAmount() {
		return walletAvailableAmount;
	}

	public void setWalletAvailableAmount(BigDecimal walletAvailableAmount) {
		this.walletAvailableAmount = walletAvailableAmount;
	}

	public BigDecimal getWalletHoldAmount() {
		return walletHoldAmount;
	}

	public void setWalletHoldAmount(BigDecimal walletHoldAmount) {
		this.walletHoldAmount = walletHoldAmount;
	}

	public String getWalletStatus() {
		return walletStatus;
	}

	public void setWalletStatus(String walletStatus) {
		this.walletStatus = walletStatus;
	}

	public String getWalletMobileNumber() {
		return walletMobileNumber;
	}

	public void setWalletMobileNumber(String walletMobileNumber) {
		this.walletMobileNumber = walletMobileNumber;
	}

	@Override
	public String toString() {
		return "WalletDetails [walletTotalAmount=" + walletTotalAmount + ", walletAvailableAmount="
				+ walletAvailableAmount + ", walletHoldAmount=" + walletHoldAmount + ", walletStatus=" + walletStatus
				+ ", walletMobileNumber=" + walletMobileNumber + "]";
	}

}
