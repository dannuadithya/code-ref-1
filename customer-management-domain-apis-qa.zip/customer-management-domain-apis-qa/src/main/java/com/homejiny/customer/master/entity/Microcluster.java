package com.homejiny.customer.master.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

/**
 * @author Haripriya.V
 *
 */
@Entity(name = "hj_micro_cluster")
@Table(name = "HJ_MICRO_CLUSTER")
public class Microcluster {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "id")
	private int id;

	@Column(name = "microcluster_name")
	private String microclusterName;

	@Column(name = "code")
	private String code;
	
	@Column(name = "status")
	private String status;

	@Column(name="total_houses")
	private int totalHouses;

	@Column(name = "created_time")
	private LocalDateTime createdAt;

	@Column(name = "updated_time")
	private LocalDateTime updatedAt;
	
	@Column(name = "display_order")
	private long displayOrder;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getTotalHouses() {
		return totalHouses;
	}

	public void setTotalHouses(int totalHouses) {
		this.totalHouses = totalHouses;
	}

	

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getMicroclusterName() {
		return microclusterName;
	}

	public void setMicroclusterName(String microclusterName) {
		this.microclusterName = microclusterName;
	}

	public long getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(long displayOrder) {
		this.displayOrder = displayOrder;
	}

}
