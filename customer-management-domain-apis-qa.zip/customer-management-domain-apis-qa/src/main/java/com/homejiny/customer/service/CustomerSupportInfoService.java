package com.homejiny.customer.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.CustomerSupportInfo;
import com.homejiny.customer.exception.RecordNotFoundException;
import com.homejiny.customer.repository.CustomerSupportInfoRepository;
import com.homejiny.customer.request.CustomerSupportInfoRequest;
import com.homejiny.customer.view.CustomerSupportInfoResponse;

@Service
public class CustomerSupportInfoService {

	@Autowired
	CustomerSupportInfoRepository customerSupportInfoRepository;

	public CustomerSupportInfo customerSupportInfo(Long id) {

		CustomerSupportInfoRequest customerSupportInfoRequest = new CustomerSupportInfoRequest();
		Optional<CustomerSupportInfo> customerSupportInfo = customerSupportInfoRepository.findById(id);
		if (!customerSupportInfo.isPresent()) {
			throw new RecordNotFoundException(Constants.NO_RECORD_FOUND_WITH_ID);
		}
		customerSupportInfoRequest.setEmail(customerSupportInfo.get().getEmail());
		customerSupportInfoRequest.setMobileNumber1(customerSupportInfo.get().getCustomerContactNumber1());
		customerSupportInfoRequest.setMobileNumber2(customerSupportInfo.get().getCustomerContactNumber2());
		return customerSupportInfoRepository.save(customerSupportInfo.get());

	}

	public CustomerSupportInfoResponse getCustomerSupportInfo(Long id) {

		CustomerSupportInfoResponse viewServiceResponse = new CustomerSupportInfoResponse();
		viewServiceResponse.setData(customerSupportInfo(id));
		viewServiceResponse.setStatus(Constants.SUCCESS);
		return viewServiceResponse;
	}

}
