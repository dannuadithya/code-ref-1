package com.homejiny.customer.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "hj_customer_support_info")
public class CustomerSupportInfo {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "native")
	@GenericGenerator(name = "native", strategy = "native")
	@Column(name = "ID")
	private long id;

	@Column(name = "created_time")
	private LocalDateTime createdAt;

	@Column(name = "updated_time")
	private LocalDateTime updatedAt;

	@Column(name = "email")
	private String email;

	@Column(name = "mobilenumber1")
	private String customerContactNumber1;

	@Column(name = "mobilenumber2")
	private String customerContactNumber2;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}

	public String getCustomerContactNumber1() {
		return customerContactNumber1;
	}

	public void setCustomerContactNumber1(String customerContactNumber1) {
		this.customerContactNumber1 = customerContactNumber1;
	}

	public String getCustomerContactNumber2() {
		return customerContactNumber2;
	}

	public void setCustomerContactNumber2(String customerContactNumber2) {
		this.customerContactNumber2 = customerContactNumber2;
	}

}
