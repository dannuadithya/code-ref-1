package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.service.FetchCustomerDeliveryInformationService;
import com.homejiny.customer.view.DeliveryInformationResponse;

@Service
public class FetchCustomerDeliveryInformationCommand implements Command<Long, ResponseEntity<DeliveryInformationResponse>> {

	@Autowired
	FetchCustomerDeliveryInformationService fetchCustomerDeliveryInformationService;
	
	@Override
	public ResponseEntity<DeliveryInformationResponse> excute(Long customerId){
		if (customerId == null) {
			DeliveryInformationResponse deliveryInformationResponse = new DeliveryInformationResponse();
			deliveryInformationResponse.setMessage(Constants.INVALID_INPUTS);
			deliveryInformationResponse.setStatus(Constants.SUCCESS);

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);

		}
		return ResponseEntity.status(HttpStatus.OK)
				.body(fetchCustomerDeliveryInformationService.fetchDeliveryInformation(customerId));
	}

}
