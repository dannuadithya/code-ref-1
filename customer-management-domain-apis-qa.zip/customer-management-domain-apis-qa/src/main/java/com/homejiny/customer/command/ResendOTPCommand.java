package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.homejiny.customer.request.SignInRequest;
import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.Response;

/**
 * @author brahmaiam
 *
 */
@Service
public class ResendOTPCommand implements Command<SignInRequest, ResponseEntity<Response>> {

	@Autowired
	CustomerService customerService;

	public ResponseEntity<Response> excute(SignInRequest request) {

		if (request == null || StringUtils.isEmpty(request.getMobileNumber())) {
			Response response = new Response();
			response.setMessage("Invalid Inputs");
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
		}

		return customerService.resendOTP(request);
	}
}
