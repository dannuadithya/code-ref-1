package com.homejiny.customer.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * @author brahmaiam
 *
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class AreaNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AreaNotFoundException(String message) {
		super(message);
	}

}
