package com.homejiny.customer.entity;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class DeliveryInfoMedia extends com.homejiny.customer.entity.Entity {

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "hj_media")
	private Media media;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "hj_delivery_Info_Media")
	private DeliveryInfoMedia deliveryInfoMedia;

	public Media getMedia() {
		return media;
	}

	public void setMedia(Media media) {
		this.media = media;
	}

	public DeliveryInfoMedia getDeliveryInfoMedia() {
		return deliveryInfoMedia;
	}

	public void setDeliveryInfoMedia(DeliveryInfoMedia deliveryInfoMedia) {
		this.deliveryInfoMedia = deliveryInfoMedia;
	}

}
