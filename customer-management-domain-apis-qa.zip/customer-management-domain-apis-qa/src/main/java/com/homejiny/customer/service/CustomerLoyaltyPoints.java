package com.homejiny.customer.service;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Date;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.homejiny.customer.adapter.PushNotificationAdapter;
import com.homejiny.customer.adapter.WalletAdapter;
import com.homejiny.customer.common.ConditionalConstants;
import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.common.WalletEnum;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerRewardPointLog;
import com.homejiny.customer.entity.CustomerRewardPointsRedemption;
import com.homejiny.customer.entity.CustomerRewardType;
import com.homejiny.customer.entity.CustomerRewardTypeEnum;
import com.homejiny.customer.entity.PushNotifications;
import com.homejiny.customer.entity.RefferalPoints;
import com.homejiny.customer.exception.HjAvailabilityException;
import com.homejiny.customer.exception.RecordNotFoundException;
import com.homejiny.customer.repository.CustomerPointsRedemptionRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.repository.CustomerRewardPointLogRepository;
import com.homejiny.customer.repository.CustomerRewardTypeRepository;
import com.homejiny.customer.repository.PushNotificationRepository;
import com.homejiny.customer.repository.RefferalPointsRepository;
import com.homejiny.customer.request.CustomerRewardPointLogRequest;
import com.homejiny.customer.request.GetRewardPointsByCustomerRequest;
import com.homejiny.customer.request.PointsRedemptionRequest;
import com.homejiny.customer.request.PushNotificationRequest;
import com.homejiny.customer.request.UpdateRewardPointsStatusRequest;
import com.homejiny.customer.request.WalletCreditRequest;
import com.homejiny.customer.response.PushNotificationResponse;
import com.homejiny.customer.response.UpdateRewardPointsRedemptionResponse;
import com.homejiny.customer.response.WalletResponse;
import com.homejiny.customer.view.CustomerRewardPoints;
import com.homejiny.customer.view.RewardPoints;
import com.homejiny.customer.view.RewardTypeAndPoints;
import com.homejiny.customer.view.ViewCustomerRewardLog;

@Service
public class CustomerLoyaltyPoints {

	private static final Logger logger = LoggerFactory.getLogger(CustomerLoyaltyPoints.class);

	@Autowired
	CustomerRewardTypeRepository customerRewardTypeRepository;

	@Autowired
	CustomerRewardPointLogRepository customerRewardPointLogRepository;

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	PushNotificationRepository pushNotificationRepository;

	@Autowired
	PushNotificationAdapter pushNotificationAdapter;

	@Autowired
	CustomerPointsRedemptionRepository customerPointsRedemptionRepository;

	@Autowired
	RefferalPointsRepository refferalPointsRepository;

	@Autowired
	WalletAdapter walletAdapter;

	@Value("${referral.Info}")
	private String referral;

	@Value("${patronage.Info}")
	private String patronage;

	@Value("${sustainability.Info}")
	private String sustainability;

	@Value("${refferal.points.refferdBy}")
	private Long referralPointsForReferrer;

	@Value("${referred.points}")
	private Long referralPoints;

	@Value("${referred.points.for.homejiny}")
	private Long referralPointsForHomejiny;

	@Value("${loyalty.Info}")
	private String loyalty;

	@Value("${redeem.point.worth}")
	private double redeemPointValue;

	@Value("${redeem.point.config}")
	private double customerWalletBalance;

	public ResponseEntity<ViewCustomerRewardLog> createCustomerRewardPointLog(CustomerRewardPointLogRequest request) {
		Optional<Customer> customerEntity = customerRepository.findById(request.getCustomerId());
		if (!customerEntity.isPresent()) {
			throw new RecordNotFoundException(Constants.NO_RECORD_FOUND_WITH_ID + request.getCustomerId());
		}
		logger.info("customer is existed!! we are going to create reward points");

		Customer customer = customerEntity.get();

		CustomerRewardPointLog customerRewardPointLog = new CustomerRewardPointLog();
		customerRewardPointLog.setCustomerId(customer);
		customerRewardPointLog.setOperationType(request.getOperationType());
		customerRewardPointLog.setRewardPoints(request.getRewardPoints());
		customerRewardPointLog.setRewardType(request.getRewardType());
		customerRewardPointLog.setReferralCode(request.getReferralCode());
		customerRewardPointLog.setCreatedAt(DateAndTimeUtil.now());
		customerRewardPointLog.setUpdatedAt(DateAndTimeUtil.now());
		CustomerRewardPointLog customerRewardPointLogEntity = customerRewardPointLogRepository
				.save(customerRewardPointLog);

		logger.info(Constants.CUSTOMER_REWARD_POINTS_CREATED_SUCCESSFULLY_WITH
				+ customerRewardPointLogEntity.getCustomerId());

		CustomerRewardType customerRewardType = customerRewardTypeRepository.findByCustomerIdAndRewardType(customer,
				request.getRewardType());

		customerRewardType.setUpdatedAt(DateAndTimeUtil.now());
		customerRewardType.setRewardPoints(customerRewardType.getRewardPoints() + request.getRewardPoints());
		customerRewardType.setRewardType(customerRewardType.getRewardType());
		customerRewardTypeRepository.save(customerRewardType);

		ViewCustomerRewardLog viewCustomerRewardLog = new ViewCustomerRewardLog();

		viewCustomerRewardLog.setOperationType(customerRewardPointLogEntity.getOperationType());
		viewCustomerRewardLog.setRewardPoints(customerRewardPointLogEntity.getRewardPoints());
		viewCustomerRewardLog.setRewardType(customerRewardPointLogEntity.getRewardType());

		logger.info("Customer rewards points updated ");
		return ResponseEntity.status(HttpStatus.CREATED).body(viewCustomerRewardLog);

	}

	public CustomerRewardPoints getRewardPointsByCustomer(
			GetRewardPointsByCustomerRequest getRewardPointsByCustomerRequest) {

		CustomerRewardPoints customerRewardPoints = new CustomerRewardPoints();
		Optional<Customer> customerEntity = customerRepository
				.findById(getRewardPointsByCustomerRequest.getCustomerId());
		if (!customerEntity.isPresent()) {
			throw new RecordNotFoundException(
					"No record found with- " + getRewardPointsByCustomerRequest.getCustomerId());
		}

		List<CustomerRewardType> customerRewardTypeList = customerRewardTypeRepository
				.findByCustomerIdOrderById(customerEntity.get());
		long totalRewardPoints = customerRewardTypeList.stream().mapToLong(a -> a.getRewardPoints()).sum();
		List<RewardTypeAndPoints> rewardTypeAndPointsList = new ArrayList<>();

		List<CustomerRewardType> customerRewardTypes = customerRewardTypeRepository
				.findByCustomerIdOrderByCreatedAtDesc(customerEntity.get());
		for (CustomerRewardType customerRewardType : customerRewardTypes) {
			RewardTypeAndPoints rewardTypeAndPoints = new RewardTypeAndPoints();
			rewardTypeAndPoints.setPoints(customerRewardType.getRewardPoints());
			rewardTypeAndPoints.setRewardType(customerRewardType.getRewardType());
			rewardTypeAndPointsList.add(rewardTypeAndPoints);
		}
		// List<CustomerRewardPointLog> customerRewardPointLogs =
		// customerRewardPointLogRepository
		// .findByCustomerIdOrderByCreatedAtDesc(customerEntity.get());
		int pageNumber = getRewardPointsByCustomerRequest.getPageNumber();
		int pageLimit = getRewardPointsByCustomerRequest.getPageLimit();
		Page<CustomerRewardPointLog> customerRewardPointLogs = customerRewardPointLogRepository
				.findByCustomerIdOrderByCreatedAtDesc(customerEntity.get(), getPageRequest(pageNumber, pageLimit));

		List<RewardPoints> rewardPointsList = new ArrayList<>();
		for (CustomerRewardPointLog customerRewardPointLog : customerRewardPointLogs) {
			RewardPoints rewardPoints = new RewardPoints();
			rewardPoints.setCreatedAt(customerRewardPointLog.getCreatedAt());
			rewardPoints.setOperationType(customerRewardPointLog.getOperationType());
			rewardPoints.setRewardPoints(customerRewardPointLog.getRewardPoints());
			if (customerRewardPointLog.getRewardType() != null) {
				rewardPoints.setRewardType(customerRewardPointLog.getRewardType());
			}

			/*
			 * totalRewardPoints =
			 * (rewardPoints.getOperationType().toUpperCase().equals(Constants.ADD)) ?
			 * totalRewardPoints + customerRewardPointLog.getRewardPoints() :
			 * totalRewardPoints - customerRewardPointLog.getRewardPoints();
			 */
			rewardPointsList.add(rewardPoints);

		}
		customerRewardPoints.setRewardPointsList(rewardPointsList);
		customerRewardPoints.setTotalRewardPoints(totalRewardPoints);
		customerRewardPoints.setRewardTypeAndPoints(rewardTypeAndPointsList);
		customerRewardPoints.setLoyaltyInfo(loyalty);
		customerRewardPoints.setPatronageInfo(patronage);
		customerRewardPoints.setReferralInfo(referral);
		customerRewardPoints.setSustainabilityInfo(sustainability);

		return customerRewardPoints;

	}

	// @Scheduled(cron = ConditionalConstants.REFERRAL_POINTS_CRON)
	// @Scheduled(cron = "0 0/2 * * * ?")
	public void updateLoyalityPoints() {
		logger.info("Referrel points job started at :: " + DateAndTimeUtil.now());

		Set<Long> firstOrdercustomerIds = new HashSet<>();
		LocalDate localDate = DateAndTimeUtil.now().toLocalDate().minusDays(1);
		List<BigInteger> productOrderCustomers = customerRepository.getProductOrderCustomers(localDate.toString());

		productOrderCustomers.forEach(customerId -> {
			Long id = customerId.longValue();
			Long count = customerRepository.getProductOrderCount(id, localDate.toString());
			if (count == 1) {
				firstOrdercustomerIds.add(id);
			}
		});

		List<BigInteger> serviceOrderCustomers = customerRepository.getServiceOrderCustomers(localDate.toString());
		serviceOrderCustomers.forEach(customerId -> {
			Long id = customerId.longValue();
			Long count = customerRepository.getServiceOrderCount(id, localDate.toString());
			if (count == 1) {
				firstOrdercustomerIds.add(id);
			}
		});

		firstOrdercustomerIds.forEach(customerId -> {
			try {
				Optional<Customer> customerEntity = customerRepository.findById(customerId);
				if (customerEntity.isPresent()) {
					Customer customer = customerEntity.get();
					CustomerRewardType customerRewardType = customerRewardTypeRepository
							.findByCustomerIdAndRewardTypeAndFirstOrder(customer,
									CustomerRewardTypeEnum.REFERRAL.toString(), true);
					if (customerRewardType == null) {
						if (customer.getReferrerbyId() == -1) {
							setRewardPoints(customer, customer.getReferrerCodeUsed(), referralPointsForHomejiny, true);
							sendPushNotigication(customer, null, Constants.HOMEJINY_REFERRED_MESSAGE,
									referralPointsForHomejiny);
						} else if (customer.getReferrerbyId() > 0) {
							Optional<Customer> referredCustomerEntity = customerRepository
									.findById(customer.getReferrerbyId());
							if (referredCustomerEntity.isPresent()) {
								setRewardPoints(referredCustomerEntity.get(),
										referredCustomerEntity.get().getReferrerCode(), referralPointsForReferrer,
										false);
								sendPushNotigication(referredCustomerEntity.get(), customer,
										Constants.REFERRED_BY_MESSAGE, referralPointsForReferrer);
								setRewardPoints(customer, referredCustomerEntity.get().getReferrerCode(),
										referralPoints, true);
								sendPushNotigication(customer, referredCustomerEntity.get(), Constants.REFERRED_MESSAGE,
										referralPoints);
							}
						}
					}
				}
			} catch (Exception exception) {
				logger.info("Failed to process reward points for customer with id :: " + customerId);
			}
		});

		logger.info("Referrel points job ended at :: " + DateAndTimeUtil.now());
	}

	private long getPoints(String type) {
		RefferalPoints refferalPoints = refferalPointsRepository.findByRefferalType(type);
		if (refferalPoints != null) {
			return refferalPoints.getPointsValue();
		} else {
			if (type.equalsIgnoreCase(Constants.REFFEREDBY)) {

			}
			return 0;
		}
	}

	private void sendPushNotigication(Customer customer, Customer referrer, String title, long points) {
		try {
			if (customer.getDeviceToken() != null) {
				PushNotifications pushNotifications = pushNotificationRepository.findByTitleName(title);
				String message = "";
				if (pushNotifications.getMessage() != null) {
					message = pushNotifications.getMessage();
				}
				switch (title) {
				case Constants.REFERRED_MESSAGE:
					message = message.replace("<Points>", String.valueOf(points));
					message = message.replace("<Customer Name>",
							customer.getFirstName() + " " + customer.getLastName());
					if (referrer != null) {
						message = message.replace("<Referrer Name>",
								referrer.getFirstName() + " " + referrer.getLastName());
					}
					break;
				case Constants.REFERRED_BY_MESSAGE:
					message = message.replace("<Points>", String.valueOf(points));
					message = message.replace("<Customer Name>",
							customer.getFirstName() + " " + customer.getLastName());
					if (referrer != null) {
						message = message.replace("<Referred Name>",
								referrer.getFirstName() + " " + referrer.getLastName());
					}
					break;
				case Constants.HOMEJINY_REFERRED_MESSAGE:
					message = message.replace("<Points>", String.valueOf(points));
					message = message.replace("<Customer Name>",
							customer.getFirstName() + " " + customer.getLastName());
					break;
				default:
					message = "";
				}
				logger.info("started to send pushNotification to customer_id:::" + customer.getId());
				PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();
				pushNotificationRequest.setMessage(message);
				pushNotificationRequest.setTitle(title);
				pushNotificationRequest.setToken(customer.getDeviceToken());
				pushNotificationRequest.setTopic("");
				pushNotificationRequest.setScreenflow("Referrel Points");
				PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
						.sendPushNotification(pushNotificationRequest);
				logger.info("pushNotificationResponse inside Referrel points job : " + pushNotificationResponse);
				if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
					logger.info("Failed to call push notification, Reason: " + Constants.REST_API_CALL_FAILED);
				}
			} else {
				logger.info("Device Token not found for that customer :" + customer.getId());
			}
		} catch (Exception exception) {
			logger.info("Failed to send push notification for customerId :: " + customer.getId());
		}
	}

	private void setRewardPoints(Customer customer, String referrelCode, long points, boolean firstOrder) {
		logger.info("Started to add " + points + " points to customer with id:: " + customer.getId());
		CustomerRewardPointLog customerRewardPointLog = new CustomerRewardPointLog();
		customerRewardPointLog.setCustomerId(customer);
		customerRewardPointLog.setOperationType(Constants.ADD);
		customerRewardPointLog.setRewardPoints(points);
		customerRewardPointLog.setRewardType(CustomerRewardTypeEnum.REFERRAL.toString());
		if (referrelCode != null) {
			customerRewardPointLog.setReferralCode(referrelCode);
		}
		customerRewardPointLog.setCreatedAt(DateAndTimeUtil.now());
		customerRewardPointLog.setUpdatedAt(DateAndTimeUtil.now());
		CustomerRewardPointLog customerRewardPointLogEntity = customerRewardPointLogRepository
				.save(customerRewardPointLog);
		logger.info(Constants.CUSTOMER_REWARD_POINTS_CREATED_SUCCESSFULLY_WITH
				+ customerRewardPointLogEntity.getCustomerId());
		CustomerRewardType customerRewardType = customerRewardTypeRepository.findByCustomerIdAndRewardType(customer,
				CustomerRewardTypeEnum.REFERRAL.toString());
		customerRewardType.setUpdatedAt(DateAndTimeUtil.now());
		customerRewardType.setRewardPoints(customerRewardType.getRewardPoints() + points);
		customerRewardType.setRewardType(customerRewardType.getRewardType());
		if (firstOrder && !customerRewardType.isFirstOrder()) {
			customerRewardType.setFirstOrder(firstOrder);
		}
		customerRewardTypeRepository.save(customerRewardType);
	}

	public UpdateRewardPointsRedemptionResponse customerPointsRedemption(PointsRedemptionRequest request) {

		boolean monday = DateAndTimeUtil.now().getDayOfWeek().equals(DayOfWeek.MONDAY);
		LocalDateTime dateTime = LocalDateTime.of(2020, 4, 20, 21, 0);
		/*
		 * if (!monday) { throw new
		 * HjAvailabilityException(Constants.REDEMPTION_ARE_ALLOWED_ONLY_ON_MONDAY); }
		 */
		if (DateAndTimeUtil.now().isAfter(dateTime)) {
			throw new HjAvailabilityException(Constants.REDEMPTION_NOT_ALLOWED);
		}
		Optional<Customer> customerEntity = customerRepository.findById(request.getCustomerId());
		if (!customerEntity.isPresent()) {
			throw new RecordNotFoundException(Constants.NO_RECORD_FOUND_WITH_ID + request.getCustomerId());
		}
		long points = request.getPoints();
		long count = 0;
		double amount = points * redeemPointValue;
		List<CustomerRewardType> customerRewardTypeList = customerRewardTypeRepository
				.findByCustomerIdOrderById(customerEntity.get());
		long total = customerRewardTypeList.stream().mapToLong(a -> a.getRewardPoints()).sum();
		count = customerPointsRedemptionRepository.countByCustomerId(request.getCustomerId());

		if (points > total || points < 200) {
			throw new HjAvailabilityException(Constants.SORRY_YOU_DONT_HAVE_SUFFICIENT_POINTS_IN_YOUR_ACCOUNT);
		}
		for (CustomerRewardType customerRewardType : customerRewardTypeList) {
			if (customerRewardType.getRewardPoints() > 0) {
				if (customerRewardType.getRewardPoints() >= points) {
					customerRewardType.setRewardPoints(customerRewardType.getRewardPoints() - points);
					customerRewardTypeRepository.save(customerRewardType);
					break;
				} else {
					points = points - customerRewardType.getRewardPoints();
					customerRewardType.setRewardPoints(0);
					customerRewardTypeRepository.save(customerRewardType);
				}
			}
		}
		CustomerRewardPointsRedemption customerRewardPointsRedemption = new CustomerRewardPointsRedemption();
		customerRewardPointsRedemption.setCustomerId(request.getCustomerId());
		customerRewardPointsRedemption.setCreatedTime(DateAndTimeUtil.now());
		customerRewardPointsRedemption.setPointsRedemed(request.getPoints());
		customerRewardPointsRedemption.setTransactionId(Constants.DEFAULT + request.getCustomerId());
		customerRewardPointsRedemption.setStatus("REQUESTED");
		customerRewardPointsRedemption.setTransactionDate(Date.valueOf(DateAndTimeUtil.now().toLocalDate().toString()));
		customerRewardPointsRedemption.setAmount(amount);
		customerPointsRedemptionRepository.save(customerRewardPointsRedemption);

		CustomerRewardPointLog customerRewardPointLog = new CustomerRewardPointLog();
		customerRewardPointLog.setCreatedAt(DateAndTimeUtil.now());
		customerRewardPointLog.setCustomerId(customerEntity.get());
		customerRewardPointLog.setUpdatedAt(DateAndTimeUtil.now());
		customerRewardPointLog.setOperationType(Constants.REMOVE);
		customerRewardPointLog.setRewardPoints(request.getPoints());
		customerRewardPointLog.setRewardType(Constants.POINTS_REDEEMED);
		customerRewardPointLogRepository.save(customerRewardPointLog);

		UpdateRewardPointsRedemptionResponse pointsRedemptionResponse = new UpdateRewardPointsRedemptionResponse();
		BigDecimal walletDetails = customerRepository.getWalletDetails(customerEntity.get().getWalletId());
		pointsRedemptionResponse.setMessage("money will be added to your account in 2 to 5days");
		if (walletDetails.doubleValue() + amount > 5000) {
			pointsRedemptionResponse.setMessage("Dear user, your request for " + points
					+ " points redemption has submitted and your wallet will recharge with " + points
					+ " Rs in 2-3 days. As per RBI guideline your wallet limit is 5000 Rs. We'll contact you in case your wallet available balance and redemption request exceed 5000 Rs at the time of processing your request");
		}
		pointsRedemptionResponse.setStatus("success");

		return pointsRedemptionResponse;
	}

	// @Scheduled(cron = "0 0/1 * * * ?")
	public UpdateRewardPointsRedemptionResponse updatePointsRedemptionStatus(
			UpdateRewardPointsStatusRequest updateRewardPointsStatusRequest) {
		String creditMessage = "Homejiny credited money to your wallet on your reward request of rs ";

		Optional<CustomerRewardPointsRedemption> customerRewardPointsRedemptionEntity = customerPointsRedemptionRepository
				.findById(updateRewardPointsStatusRequest.getCustomerRewardPointsRedemptionId());

		if (customerRewardPointsRedemptionEntity.isPresent()) {

			CustomerRewardPointsRedemption customerRewardPointsRedemption = customerRewardPointsRedemptionEntity.get();

			if (updateRewardPointsStatusRequest.getStatus().equalsIgnoreCase(Constants.COMPLETED)) {
				customerRewardPointsRedemption.setMoneyAddedToWalletDate(DateAndTimeUtil.now().toLocalDate());
				customerRewardPointsRedemption.setStatus(updateRewardPointsStatusRequest.getStatus());
				Optional<Customer> customerEntity = customerRepository
						.findById(customerRewardPointsRedemption.getCustomerId());
				if (!customerEntity.isPresent()) {
					throw new RecordNotFoundException(
							Constants.NO_RECORD_FOUND_WITH_ID + customerRewardPointsRedemption.getCustomerId());
				}
				long walletId = customerEntity.get().getWalletId();
				boolean isWalletAmountExceed = false;
				try {
					isWalletAmountExceed = walletAdapter
							.isWalletAmountExceeds(customerRewardPointsRedemption.getAmount(), walletId, 0);
				} catch (Exception e) {
					logger.info("[ALERT] Exception occured while proceessing request from customerId:: "
							+ customerEntity.get().getId(), e.getCause());
				}
				if (isWalletAmountExceed) {
					boolean isMoneyCredited = creditMoneyToWallet(walletId, customerRewardPointsRedemption.getAmount(),
							customerRewardPointsRedemption.getTransactionId(), creditMessage);
					if (isMoneyCredited) {
						customerRewardPointsRedemption.setStatus(Constants.COMPLETED);
						customerPointsRedemptionRepository.save(customerRewardPointsRedemption);
						// pointsRedeemed(customerEntity.get().getId());
						String name = "";
						if (customerEntity.get().getFirstName() != null) {
							name = name + customerEntity.get().getFirstName();
						}
						if (customerEntity.get().getLastName() != null) {
							name = name +" "+ customerEntity.get().getLastName();
						}
						sendPushnotificationPointsRedeemed(customerEntity.get().getId(),
								customerEntity.get().getDeviceToken(), name,
								customerRewardPointsRedemption.getPointsRedemed());
					}
				} else {
					customerRewardPointsRedemption.setStatus(Constants.COMPLETED_PAYMENT_PENDING);
					customerPointsRedemptionRepository.save(customerRewardPointsRedemption);
				}
			}
		}
		UpdateRewardPointsRedemptionResponse pointsRedemptionResponse = new UpdateRewardPointsRedemptionResponse();
		pointsRedemptionResponse.setMessage("Reward points redemption status updated successfully");
		pointsRedemptionResponse.setStatus("success");
		return pointsRedemptionResponse;
	}

	private boolean creditMoneyToWallet(long walletId, double amount, String transactionId, String message) {
		logger.info("[creditMoneyToWallet] started to credit money to wallet id# " + walletId);
		WalletCreditRequest walletDebitRequest = new WalletCreditRequest();
		walletDebitRequest.setComments("YOUR REDEMPTION ID::" + transactionId);
		walletDebitRequest.setCreditAmount(BigDecimal.valueOf(amount));
		walletDebitRequest.setReason(message + amount);
		walletDebitRequest.setTransactionId(String.valueOf(transactionId));
		walletDebitRequest.setWalletId(walletId);
		walletDebitRequest.setTransactionSource(WalletEnum.HJ_REWARD_POINTS.toString());
		boolean isCredited = false;
		WalletResponse walletResponse = null;
		int count = 0;
		do {
			walletResponse = walletAdapter.creditMoneyToWallet(walletDebitRequest);
			count++;
			if (walletResponse != null && walletResponse.getStatus().equalsIgnoreCase(Constants.SUCCESS)) {
				isCredited = true;
				logger.info("[creditMoneyToWallet] successfully credited money to wallet id# " + walletId);
			} else {
				logger.info("[creditMoneyToWallet] Failed credit money to wallet id# " + walletId
						+ " number of attepts ---" + count);
			}
		} while (!isCredited && count < 3 && walletResponse == null);
		return isCredited;
	}

//	@Scheduled(cron = "0 0/1 * * * ?")
	@Scheduled(cron = ConditionalConstants.REDEEM_POINTS_CRON)
	public void addRedeemedAmount() {
		String creditMessage = "Homejiny credited money to your wallet on your reward request of rs ";
		logger.info("Credited rewards points amount job started at " + DateAndTimeUtil.now());
		List<CustomerRewardPointsRedemption> rewardPointsRedemptionList = customerPointsRedemptionRepository
				.findByStatus(Constants.COMPLETED_PAYMENT_PENDING);

		rewardPointsRedemptionList.forEach(rewardPointsRedemption -> {
			try {
				Optional<Customer> customerEntity = customerRepository.findById(rewardPointsRedemption.getCustomerId());
				long walletId = customerEntity.get().getWalletId();
				boolean isWalletAmountExceed = false;
				try {
					isWalletAmountExceed = walletAdapter.isWalletAmountExceeds(rewardPointsRedemption.getAmount(),
							walletId, 0);
				} catch (Exception e) {
					logger.info("[ALERT] Exception occured while proceessing request from customerId:: "
							+ customerEntity.get().getId(), e.getCause());
					BigDecimal amount = pushNotificationRepository.getWalletDetails(walletId);
					sendPushnotificationWalletBalanceExceed(customerEntity.get().getId(),
							customerEntity.get().getDeviceToken(),
							customerEntity.get().getFirstName() + " " + customerEntity.get().getLastName(),
							amount.doubleValue(), rewardPointsRedemption.getPointsRedemed());
				}
				if (isWalletAmountExceed) {
					boolean isMoneyCredited = creditMoneyToWallet(walletId, rewardPointsRedemption.getAmount(),
							rewardPointsRedemption.getTransactionId(), creditMessage);
					if (isMoneyCredited) {
						rewardPointsRedemption.setStatus(Constants.COMPLETED);
						rewardPointsRedemption.setMoneyAddedToWalletDate(DateAndTimeUtil.now().toLocalDate());
						customerPointsRedemptionRepository.save(rewardPointsRedemption);
						logger.info(
								"Successfully credited money to customer id" + rewardPointsRedemption.getCustomerId());
					}
				}
			} catch (Exception exception) {
				logger.info("[ALERT] Exception occures while processing request customer id"
						+ rewardPointsRedemption.getCustomerId());
			}
		});

	}

	private void sendPushnotificationWalletBalanceExceed(long customerId, String deviceToken, String customerName,
			double walletBalance, double points) {

		try {
			logger.info("sendPushnotificationProuctPriceIncreased method started...");
			if (deviceToken != null) {
				PushNotifications pushNotifications = null;
				pushNotifications = pushNotificationRepository.findByTitleName("Wallet Balance Exceeded");

				logger.info("pushNotifications Data :" + pushNotifications.getTitleName() + ","
						+ pushNotifications.getMessage());
				PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();

				String message = pushNotifications.getMessage();
				if (customerName != null) {
					message = message.replace("<Customer>", customerName);
				} else {
					message = message.replace("<Customer Name>", "Customer");
				}
				double walletCheck = customerWalletBalance - points;
				message = message.replace("<Wallet Balance>", "" + walletCheck);
				message = message.replace("<Points>", "" + points);
				double amount = walletBalance + points;
				double actualAmount = amount - customerWalletBalance;
				message = message.replace("<amount>", "" + actualAmount);
				pushNotificationRequest.setScreenflow("Dashboard");
				pushNotificationRequest.setTitle(pushNotifications.getTitleName());
				pushNotificationRequest.setMessage(message);
				pushNotificationRequest.setToken(deviceToken);
				pushNotificationRequest.setTopic("");
				PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
						.sendPushNotification(pushNotificationRequest);
				if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
					logger.info("Rest API call failed : Reason " + Constants.REST_API_CALL_FAILED);
				}
			} else {
				logger.info("Device Token not found for that customer Id : " + customerId);
			}
			logger.info("sendPushNotificationIfOrderDelivered method ended...");
		} catch (Exception e) {
			logger.error("[ALERT] - Error sending pushNotification for the customer - " + customerId + " Cause :: "
					+ e.getCause());
		}
	}

	private void walletBalance(Long customerId, Long points) {

		Object[][] cartUsers = pushNotificationRepository.cartUsers(customerId);
		for (Object[] customer : cartUsers) {
			String deviceToken = "";
			String name = "";
			double walletBalance = 0;
			if (customer[0] != null) {
				customerId = ((BigInteger) customer[0]).longValue();
			}
			if (customer[3] != null) {
				deviceToken = ((String) customer[3]);
			}
			if (customer[1] != null) {
				name = ((String) customer[1]);
			}
			if (customer[2] != null) {
				walletBalance = ((BigDecimal) customer[2]).doubleValue();
			}

			if (deviceToken != null) {

			}
		}

	}

	private void sendPushnotificationPointsRedeemed(long customerId, String deviceToken, String customerName,
			double points) {

		try {
			logger.info("sendPushnotificationPointsRedeemed method started...");
			if (deviceToken != null) {
				PushNotifications pushNotifications = null;
				pushNotifications = pushNotificationRepository.findByTitleName("Customer Redemption Completed");

				logger.info("pushNotifications Data :" + pushNotifications.getTitleName() + ","
						+ pushNotifications.getMessage());
				PushNotificationRequest pushNotificationRequest = new PushNotificationRequest();

				String message = pushNotifications.getMessage();
				if (customerName != null) {
					message = message.replace("<Customer>", customerName);
				}
				message = message.replace("<Points>", "" + points);
				pushNotificationRequest.setScreenflow("Dashboard");
				pushNotificationRequest.setTitle(pushNotifications.getTitleName());
				pushNotificationRequest.setMessage(message);
				pushNotificationRequest.setToken(deviceToken);
				pushNotificationRequest.setTopic("");
				PushNotificationResponse pushNotificationResponse = pushNotificationAdapter
						.sendPushNotification(pushNotificationRequest);
				if (Constants.REST_API_CALL_FAILED.equals(pushNotificationResponse.getMessage())) {
					logger.info("Rest API call failed : Reason " + Constants.REST_API_CALL_FAILED);
				}
			} else {
				logger.info("Device Token not found for that customer Id : " + customerId);
			}
			logger.info("sendPushNotificationIfOrderDelivered method ended...");
		} catch (Exception e) {
			logger.error("[ALERT] - Error sending pushNotification for the customer - " + customerId + " Cause :: "
					+ e.getCause());
		}
	}

	private void pointsRedeemed(long customerId) {

		Object[][] cartUsers = pushNotificationRepository.pointsRedeemed(customerId);
		for (Object[] customer : cartUsers) {
			String deviceToken = "";
			String name = "";
			double points = 0;
			if (customer[0] != null) {
				customerId = ((BigInteger) customer[0]).longValue();
			}
			if (customer[2] != null) {
				deviceToken = ((String) customer[2]);
			}
			if (customer[1] != null) {
				name = ((String) customer[1]);
			}
			if (customer[3] != null) {
				points = ((BigInteger) customer[3]).doubleValue();
			}

			if (deviceToken != null) {
				sendPushnotificationPointsRedeemed(customerId, deviceToken, name, points);

			}
		}

	}

	private PageRequest getPageRequest(Integer pageNumber, Integer pageSize) {
		return PageRequest.of(pageNumber, pageSize);
	}

}
