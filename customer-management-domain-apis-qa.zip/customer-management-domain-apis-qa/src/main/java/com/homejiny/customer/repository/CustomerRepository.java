package com.homejiny.customer.repository;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.entity.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {

	Customer findByMobileNumber(String mobileNumber);

	Optional<Customer> findByReferrerCode(String referralCode);

	List<Customer> findByfirstName(String firstName);

	List<Customer> findBylastName(String lastName);

	void save(Optional<Customer> getReferreralCode);

	List<Customer> findAllByRegistrationStepNot(String registrationStep);

	Customer findByReferrerCodeNotNullOrderByIdDesc();

	@Query(value = "select MAX(referrer_code) from hj_customer", nativeQuery = true)
	Object[][] findByMaxRefferCode();

	@Query(value = "select id,total_amount,available_amount from hj_wallet where  total_amount < 300;", nativeQuery = true)
	Object[][] getAllCustomersWalletBalance();

	Customer findByWalletId(Long WalletId);

	Optional<Customer> findBydeviceToken(String token);

	@Query(value = "select hj_customer_id from hj_orders where status = 'DELIVERED' and date(order_date)=?1", nativeQuery = true)
	List<BigInteger> getProductOrderCustomers(String date);

	@Query(value = "select hj_customer_id from hj_service_orders where status in('COMPLETED','CLOSED – PAYMENT COMPLETED','CLOSED – PAYMENT DENIED','ORDER ASSIGNED - CLOSED') and date(service_end_date_time)=?1", nativeQuery = true)
	List<BigInteger> getServiceOrderCustomers(String date);

	@Query(value = "select count(id) from hj_orders where status = 'DELIVERED' and hj_customer_id=?1 and date(order_date) <=?2", nativeQuery = true)
	Long getProductOrderCount(Long customerId, String date);

	@Query(value = "select count(id) from hj_service_orders where status in('COMPLETED','CLOSED – PAYMENT COMPLETED','CLOSED – PAYMENT DENIED','ORDER ASSIGNED - CLOSED') and hj_customer_id=?1 and date(service_end_date_time) <=?2", nativeQuery = true)
	Long getServiceOrderCount(Long customerId, String date);

	Optional<Customer> findByIdAndReferrerbyIdNot(Long customerId, long i);

	/*
	 * @Query(value =
	 * "select sum(id) as id,CAST(coalesce((amount),0) AS DECIMAL(12,2)),cust_id from\n"
	 * +
	 * "(select count(o.id) id,sum(o.total_price) amount,o.hj_customer_id  cust_id\n"
	 * +
	 * "from hj_orders o  where o.status='DELIVERED' and date(o.order_date)>=?1  and date(o.order_date)<=?2\n"
	 * +
	 * "group by o.hj_customer_id union all  select count(so.id) id,sum(so.total_price) amount ,so.hj_customer_id cust_id\n"
	 * +
	 * "from hj_service_orders so join hj_service_request sr on sr.id=so.hj_service_request_id\n"
	 * +
	 * "join hj_service s on s.id=sr.hj_service_id  join hj_service_schedule_type sst on sst.id=s.hj_service_schedule_type_id\n"
	 * +
	 * "join hj_service_type st on st.id=sst.hj_service_type_id and st.type_name in ('SCHEDULE','UNSCHEDULE')\n"
	 * +
	 * "where so.status in  ('COMPLETED','CLOSED – PAYMENT COMPLETED','CLOSED – PAYMENT DENIED') and\n"
	 * +
	 * "date(so.updated_at)>=?1 and date(so.updated_at)<=?2 group by so.hj_customer_id )as a group by a.cust_id \n"
	 * , nativeQuery = true)
	 */
	@Query(value = "select sum(id) as id,CAST(coalesce(sum(amount),0) AS DECIMAL(12,2)),cust_id from \n"
			+ "(select count(o.id) id,sum(o.total_price) amount,o.hj_customer_id  cust_id \n"
			+ "from hj_orders o  where o.status='DELIVERED' and date(o.order_date)>=?1  and date(o.order_date)<=?2 \n"
			+ "group by o.hj_customer_id union all  select count(so.id) id,sum(so.total_price) amount ,so.hj_customer_id cust_id \n"
			+ "from hj_service_orders so join hj_service_request sr on sr.id=so.hj_service_request_id \n"
			+ "join hj_service s on s.id=sr.hj_service_id  join hj_service_schedule_type sst on sst.id=s.hj_service_schedule_type_id \n"
			+ "join hj_service_type st on st.id=sst.hj_service_type_id and st.type_name in ('SCHEDULE','UNSCHEDULE') \n"
			+ "where so.status in  ('COMPLETED','CLOSED – PAYMENT COMPLETED','ORDER ASSIGNED - CLOSED') and \n"
			+ "date(so.updated_at)>=?3 and date(so.updated_at)<=?4 group by so.hj_customer_id )as a where a.id>=?5 group by a.cust_id order by id", nativeQuery = true)
	Object[][] getCustomerOrders(String startDate, String endDate, String startDate2, String endDate2,
			long minimumOrderCount);

	List<Customer> findAllByHasAddressNot(boolean b);

	List<Customer> findByHasAddressOrHasAddress(boolean b, boolean invalid);

	List<Customer> findByHasAddressOrHasAddressIsNull(boolean b);

	Customer findByWalletIdAndHasAddress(long longValue, boolean b);

	@Query(value = "select coalesce(sum(bag_count),0) from hj_customer_baggage_return where hj_customer_id=?1 and\n" + 
			" date(return_date) >=?2 and date(return_date) <=?3 ", nativeQuery = true)
	Long getOrderBags(long customerId, String startDate, String endDate);

	@Query(value = "select coalesce(sum(bag_count),0) from hj_order_baggage_details where\n" + 
			" hj_customer_id=?1 and date(bag_given_date) >=?2 and date(bag_given_date) <=?3 ", nativeQuery = true)
	Long getOrderBagsReturned(long customerId, String startDate, String endDate);

	@Query(value = "select cast(coalesce((total_amount),0)as decimal(10,2)) as total_amount from hj_wallet where id=?1", nativeQuery = true)
	BigDecimal getWalletDetails(Long walletId);

	@Query(value = "select coalesce(points,0) from hj_reward_points_details  " + "where reward_type=?1 and "
			+ "range_from<=?2 and range_to>?3 order by points desc", nativeQuery = true)
	List<BigInteger> getRewardPoints(String rewardType, double value1, double value2);

	@Query(value = "select coalesce(count(id),0) from hj_orders where hj_customer_id=?1 and status='DELIVERED' and date(order_date)>=?2  and date(order_date)<=?3", nativeQuery = true)
	Long getOrderCount(long customerId, String startDate, String endDate);

	@Query(value = "select hj_customer_id from hj_orders where status='DELIVERED' "
			+ "and date(order_date)>=?1 and date(order_date)<=?2  group by hj_customer_id", nativeQuery = true)
	List<BigInteger> getSustainabilityCustomerIds(String string, String string2);

	@Query(value = "SELECT o.id as id,o.hj_customer_id as customer_id,o.order_id as order_id,o.delivery_date as delivery_date,pc1.name AS SUB_CATEGORY_NAME,pc2.name CATEGORY_NAME,M.original_size_path AS PRODUCT_IMAGE\n" + 
			"			,'PRODUCTS' as type FROM hj_product p\n" + 
			"			join hj_order_items ot on ot.hj_product_id = p.id\n" + 
			"			join hj_orders o on o.id = ot.hj_order_id\n" + 
			"			left join hj_customer_rating_for_products_services crs on crs.id =o.id\n" + 
			"			JOIN hj_product_category pc1 on pc1.id=p.hj_product_category_id \n" + 
			"			JOIN hj_product_category pc2 on pc2.id=pc1.parent_id\n" + 
			"			left JOIN hj_product_media PM ON p.id=PM.hj_product_id\n" + 
			"			left JOIN hj_media M ON M.id=PM.hj_media_id\n" + 
			"			where o.hj_customer_id = ?1 and date(o.delivery_date) = curdate() and o.status = 'DELIVERED' and o.skip_number<1 and o.id not in (select hj_order_id from hj_customer_rating_for_products_services)\n" + 
			"			limit 1          union all\n" + 
			"			select so.id,so.hj_customer_id as customer_id,so.service_order_number as order_id, so.service_end_date_time as delivery_date,sc1.name AS SERVICE_SUB_CATG,sc2.name AS SERV_CATEGORY,M.original_size_path AS SERVICE_IMAGE\n" + 
			"			,'SERVICES' as type from hj_service s \n" + 
			"			left join hj_service_request sr on sr.hj_service_id = s.id\n" + 
			"			left join hj_service_orders so on so.hj_service_request_id = sr.id\n" + 
			"			left join hj_customer_rating_for_products_services crs on crs.hj_service_order_id =so.id\n" + 
			"			JOIN hj_service_category sc1 on sc1.id=s.hj_service_category_id\n" + 
			"			JOIN hj_service_category sc2 on sc2.id=sc1.parent_category_id\n" + 
			"			left JOIN hj_service_images SI ON s.id=SI.hj_service_id\n" + 
			"			left JOIN hj_media M ON M.id=SI.media_id\n" + 
			"			where so.hj_customer_id = ?2 and date(so.service_end_date_time) = curdate() and so.status in ('COMPLETED','CLOSED - PAYMENT COMPLETED','ORDER ASSIGNED - CLOSED','CLOSED - PAYMENT DENIED') and so.skip_number<1 and so.id not in (select hj_service_order_id from hj_customer_rating_for_products_services)", nativeQuery = true)
	Object[][] showCustomerRating(Long customerId, Long customerId1);

	@Query(value = "SELECT Quality_rating,delivery_rating,Price_rating,star_rating,hj_customer_id,hj_order_id,comment\n"
			+ "FROM hj_customer_rating_for_products_services\n" + "where hj_order_id=?1", nativeQuery = true)
	Object[][] showCustomerPopUpRating(Long productOrderId);

	@Query(value = "SELECT Quality_rating,delivery_rating,Price_rating,star_rating,hj_customer_id,hj_order_id,comment\n"
			+ "FROM hj_customer_rating_for_products_services\n" + "where hj_service_order_id=?1", nativeQuery = true)
	Object[][] showCustomerPopUpRatingForService(Long serviceOrderId);

	@Query(value = "select coalesce(min_orders_count,0) from  hj_reward_points_details\n"
			+ " order by min_orders_count limit 1", nativeQuery = true)
	Long getMinimunOrdersCount();

}
