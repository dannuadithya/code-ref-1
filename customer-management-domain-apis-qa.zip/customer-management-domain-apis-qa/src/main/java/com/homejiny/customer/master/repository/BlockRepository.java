package com.homejiny.customer.master.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.homejiny.customer.master.entity.Block;
import com.homejiny.customer.master.entity.Society;

/**
 * @author brahmaiam
 *
 */
@Repository
public interface BlockRepository extends JpaRepository<Block, Long> {

	Block findByBlockName(String blockName);

	List<Block> findBySociety(Society society);

	Block findByBlockNameAndSociety(String blockName, Society society);

	List<Block> findBySocietyOrderByBlockNameAsc(Society society);

	List<Block> findBySocietyAndStatusOrderByBlockNameAsc(Society society, String status);

}
