package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.service.CustomerService;
import com.homejiny.customer.view.ViewCustomerServiceOrdersListDetailsResponse;

/**
 * @author - Chaitanya Mannem
 */
@Service
public class FetchServiceOrdersListCommand implements Command<Long, ResponseEntity<ViewCustomerServiceOrdersListDetailsResponse>> {

    @Autowired
    CustomerService customerService;

    public ResponseEntity<ViewCustomerServiceOrdersListDetailsResponse> excute(Long customerId) {

        ViewCustomerServiceOrdersListDetailsResponse viewCustomerServiceOrdersListDetailsResponse;

        if (customerId == null) {
            viewCustomerServiceOrdersListDetailsResponse = new ViewCustomerServiceOrdersListDetailsResponse();
            viewCustomerServiceOrdersListDetailsResponse.setMessage("Invalid inputs");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(viewCustomerServiceOrdersListDetailsResponse);
        }
        return customerService.fetchServiceOrdersList(customerId);
    }

}
