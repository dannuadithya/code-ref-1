package com.homejiny.customer.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/**
 * @author brahmaiam
 *
 */
@Entity
@Table(name = "HJ_CUSTOMER_KYC_DTLS")
public class CustomerKycDetails extends com.homejiny.customer.entity.Entity {

	@Column(name = "kyc_doc_number")
	private String kycDocNumber;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "hj_kyc_doc_type_id")
	private KycType kycType;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinTable(name = "hj_customer_kyc_details_media", joinColumns = @JoinColumn(name = "hj_customer_kyc_dtls_id"), inverseJoinColumns = @JoinColumn(name = "hj_media_id"))
	private Media media;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "hj_customer_id")
	private Customer customer;

	@Column(name = "kyc_image_view")
	private String imageView;

	public String getImageView() {
		return imageView;
	}

	public void setImageView(String imageView) {
		this.imageView = imageView;
	}

	public String getKycDocNumber() {
		return kycDocNumber;
	}

	public void setKycDocNumber(String kycDocNumber) {
		this.kycDocNumber = kycDocNumber;
	}

	public KycType getKycType() {
		return kycType;
	}

	public void setKycType(KycType kycType) {
		this.kycType = kycType;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public Media getMedia() {
		return media;
	}

	public void setMedia(Media media) {
		this.media = media;
	}

}