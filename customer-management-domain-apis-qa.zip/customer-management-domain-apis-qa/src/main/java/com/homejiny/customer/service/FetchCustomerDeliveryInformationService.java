package com.homejiny.customer.service;

import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerAddress;
import com.homejiny.customer.exception.CustomerAddressNotFoundException;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerAddressRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.view.DeliveryInformationResponse;

@Service
public class FetchCustomerDeliveryInformationService {
	
	@Value("${cloud.aws.image_url}")
	private String imageUrl;
	
	private Logger logger = LogManager.getLogger(FetchCustomerDeliveryInformationService.class);

	@Autowired
	CustomerAddressRepository customerAddressRepository;
	
	@Autowired
	CustomerRepository customerRepository;
	
	public DeliveryInformationResponse fetchDeliveryInformation(Long customerId) {
		Optional<Customer> optionalCustomer = customerRepository.findById(customerId);

		if (!optionalCustomer.isPresent()) {
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}
		
		Optional<CustomerAddress> customerAddress = customerAddressRepository.findByCustomer(optionalCustomer.get());
		if (!customerAddress.isPresent()) {
			logger.info("customer address not found with this id" +customerId);
			throw new CustomerAddressNotFoundException(Constants.CUSTOMER_ADDRESS_NOT_FOUND_WITH_THIS_ID);
			
		}
		DeliveryInformationResponse deliveryInformationResponse = new DeliveryInformationResponse();
		deliveryInformationResponse.setStatus("SUCCESS");
		deliveryInformationResponse.setId(customerAddress.get().getCustomer().getId());
		deliveryInformationResponse.setMessage("fetched deliveryinfo image and QR image path succesfully");
		deliveryInformationResponse.setBagDropLocation(customerAddress.get().getBaggageDropLocation());
		deliveryInformationResponse.setDropLocationImagePath(imageUrl+customerAddress.get().getDropLocationImagePath());
		deliveryInformationResponse.setQrCodeLocation(customerAddress.get().getQrCodeLocation());
		deliveryInformationResponse.setQrCodeLocationImagePath(imageUrl+customerAddress.get().getQrCodeLocationImagePath());
		deliveryInformationResponse.setRingTheBell(customerAddress.get().isRingTheBell());
		logger.info("fetched customer address details successfully with this id" +customerId);
		return deliveryInformationResponse;
	}

}
