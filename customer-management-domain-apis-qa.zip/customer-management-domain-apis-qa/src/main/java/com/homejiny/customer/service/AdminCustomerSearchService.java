package com.homejiny.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.request.CustomerListRequest;
import com.homejiny.customer.view.CustomerSearchResponse;
import com.homejiny.customer.view.ViewCustomerList;

@Service
public class AdminCustomerSearchService {

	@Autowired
	CustomerRepository customerRepository;

	public ResponseEntity<CustomerSearchResponse> getCustomerList(CustomerListRequest request) {
		List<ViewCustomerList> customersList = new ArrayList<>();

		List<Customer> listCustomer = customerRepository.findByfirstName(request.getFirstName());

		CustomerSearchResponse customerSearchResponse = new CustomerSearchResponse();

		for (Customer customer : listCustomer) {
			ViewCustomerList viewCustomerList1 = new ViewCustomerList();

			viewCustomerList1.setFirstName(customer.getFirstName());
			viewCustomerList1.setLastName(customer.getLastName());
			viewCustomerList1.setEmailAddress(customer.getEmail());
			viewCustomerList1.setMobileNumber(customer.getMobileNumber());
			viewCustomerList1.setCustomerId(customer.getId());
			viewCustomerList1.setStatus(customer.getStatus());
			customersList.add(viewCustomerList1);
		}

		List<Customer> listCustomer1 = customerRepository.findBylastName(request.getLastName());

		for (Customer customer : listCustomer1) {
			ViewCustomerList viewCustomerList1 = new ViewCustomerList();
			viewCustomerList1.setFirstName(customer.getFirstName());
			viewCustomerList1.setLastName(customer.getLastName());
			viewCustomerList1.setEmailAddress(customer.getEmail());
			viewCustomerList1.setMobileNumber(customer.getMobileNumber());
			viewCustomerList1.setCustomerId(customer.getId());
			viewCustomerList1.setStatus(customer.getStatus());
			customersList.add(viewCustomerList1);
		}

		Customer listCustomer2 = customerRepository.findByMobileNumber(request.getMobileNumber());

		if (listCustomer2 == null) {
			customerSearchResponse.setStatus(Constants.SUCCESS);

		} else {
			if (!request.getMobileNumber().isEmpty()) {

				ViewCustomerList viewCustomerList1 = new ViewCustomerList();
				viewCustomerList1.setFirstName(listCustomer2.getFirstName());
				viewCustomerList1.setLastName(listCustomer2.getLastName());
				viewCustomerList1.setEmailAddress(listCustomer2.getEmail());
				viewCustomerList1.setMobileNumber(listCustomer2.getMobileNumber());
				viewCustomerList1.setCustomerId(listCustomer2.getId());
				viewCustomerList1.setStatus(listCustomer2.getStatus());
				customersList.add(viewCustomerList1);

			}
		}

		if (request.getCustomerId() != 0) {

			Optional<Customer> customerEntity = customerRepository.findById(request.getCustomerId());

			if (!customerEntity.isPresent()) {
				customerSearchResponse.setStatus(Constants.SUCCESS);

			} else {
				Customer customer = customerEntity.get();
				ViewCustomerList viewCustomerList = new ViewCustomerList();

				viewCustomerList.setFirstName(customer.getFirstName());
				viewCustomerList.setLastName(customer.getLastName());
				viewCustomerList.setEmailAddress(customer.getEmail());
				viewCustomerList.setMobileNumber(customer.getMobileNumber());
				viewCustomerList.setCustomerId(customer.getId());
				viewCustomerList.setStatus(customer.getStatus());
				customersList.add(viewCustomerList);

			}
		}
		customerSearchResponse.setData(customersList);
		customerSearchResponse.setStatus(Constants.SUCCESS);

		return ResponseEntity.status(HttpStatus.OK).body(customerSearchResponse);

	}
}
