package com.homejiny.customer.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.common.DateAndTimeUtil;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.TermsAndConditions;
import com.homejiny.customer.entity.TermsAndConditionsEnum;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.repository.TermsAndConditionsRepository;
import com.homejiny.customer.request.AgreeTermsAndConditionsRequest;
import com.homejiny.customer.response.AgreeTermsAndConditionsReponse;
import com.homejiny.customer.response.ViewTermsAndConditions;
import com.homejiny.customer.view.TermsAndConditionsView;

@Service
public class GetTermsAndConditionsService {

	@Autowired
	TermsAndConditionsRepository termsAndConditionsRepository;

	@Autowired
	CustomerRepository customerRepository;

	private static final Logger LOGGER = LoggerFactory.getLogger(GetTermsAndConditionsService.class);

	public TermsAndConditionsView getTermsAndConditions(TermsAndConditionsEnum request) {

		TermsAndConditions termsAndConditions = termsAndConditionsRepository.findByConditionTo(request);
		ViewTermsAndConditions viewTermsAndConditions = new ViewTermsAndConditions();

		viewTermsAndConditions.setId(termsAndConditions.getId());
		viewTermsAndConditions.setTermsDescripiton(termsAndConditions.getTermsDescripiton());
		TermsAndConditionsView termsAndConditionsView = new TermsAndConditionsView();
		termsAndConditionsView.setStatus("Success");
		termsAndConditionsView.setData(viewTermsAndConditions);
		LOGGER.info("Terms and conditions viewed by new vendor");
		return termsAndConditionsView;
	}

	public ResponseEntity<AgreeTermsAndConditionsReponse> agreeTermsAndConditions(
			AgreeTermsAndConditionsRequest request) {

		Optional<Customer> customer = customerRepository.findById(request.getCustomerId());

		if (!customer.isPresent()) {
			throw new CustomerNotFoundException(
					Constants.NO_CUSTOMER_EXIST_WITH_CUSTOMER_ID_IS + request.getCustomerId());
		}
		AgreeTermsAndConditionsReponse agreeTermsAndConditionsReponse = new AgreeTermsAndConditionsReponse();
		Customer customerEntity = customer.get();
		if (request.getAgreed()) {
			customerEntity.setAgreed(request.getAgreed());
			customerEntity.setUpdatedAt(DateAndTimeUtil.now());
			customerRepository.save(customerEntity);

			agreeTermsAndConditionsReponse.setId(customerEntity.getId());
			agreeTermsAndConditionsReponse.setMessage("Customer has accepted Terms and conditions");
			agreeTermsAndConditionsReponse.setStatus("Success");

			return ResponseEntity.status(HttpStatus.ACCEPTED).body(agreeTermsAndConditionsReponse);
		} else {
			agreeTermsAndConditionsReponse.setId(customerEntity.getId());
			agreeTermsAndConditionsReponse.setMessage("accepting Terms and conditions are manditory to proceed");
			agreeTermsAndConditionsReponse.setStatus("Success");
			return ResponseEntity.status(HttpStatus.OK).body(agreeTermsAndConditionsReponse);
		}

	}

}
