package com.homejiny.customer.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.request.DeliveryInformationRequest;
import com.homejiny.customer.service.CustomerDeliveryInformation;
import com.homejiny.customer.view.Response;

/**
 * @author sridevi
 *
 */
@Service
public class DeliveryInformationCommand implements Command<DeliveryInformationRequest, ResponseEntity<Response>> {

	@Autowired
	CustomerDeliveryInformation customerDeliveryInformation;

	@Override
	public ResponseEntity<Response> excute(DeliveryInformationRequest request) {

		if (request == null) {
			Response response = new Response();
			response.setMessage(Constants.INVALID_INPUTS);
			response.setStatus(Constants.SUCCESS);

			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null);

		}
		return ResponseEntity.status(HttpStatus.CREATED)
				.body(customerDeliveryInformation.createDeliveryInformation(request));
	}

}
