package com.homejiny.customer.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "HJ_REFFERAL_POINTS")
public class RefferalPoints extends com.homejiny.customer.entity.Entity {

	@Column(name = "refferal_type")
	private String refferalType;

	@Column(name = "points_value")
	private int pointsValue;

	public String getRefferalType() {
		return refferalType;
	}

	public void setRefferalType(String refferalType) {
		this.refferalType = refferalType;
	}

	public int getPointsValue() {
		return pointsValue;
	}

	public void setPointsValue(int pointsValue) {
		this.pointsValue = pointsValue;
	}

}
