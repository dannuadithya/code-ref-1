/**
 * 
 */
package com.homejiny.customer.request;

/**
 * @author venkateshwarlu
 *
 */
public class ReferralCodeRequest {
	private String mobileNumber;
	private String referralCode;
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public String getReferralCode() {
		return referralCode;
	}
	public void setReferralCode(String referralCode) {
		this.referralCode = referralCode;
	}

}
