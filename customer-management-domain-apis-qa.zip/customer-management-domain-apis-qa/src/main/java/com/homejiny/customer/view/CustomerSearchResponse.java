package com.homejiny.customer.view;

import java.util.List;

public class CustomerSearchResponse {

	private String status;
	private List<ViewCustomerList> data;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public List<ViewCustomerList> getData() {
		return data;
	}

	public void setData(List<ViewCustomerList> data) {
		this.data = data;
	}

}
