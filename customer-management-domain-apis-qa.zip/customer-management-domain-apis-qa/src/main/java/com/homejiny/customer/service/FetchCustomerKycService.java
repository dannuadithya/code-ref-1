package com.homejiny.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.homejiny.customer.common.Constants;
import com.homejiny.customer.entity.Customer;
import com.homejiny.customer.entity.CustomerKycDetails;
import com.homejiny.customer.exception.CustomerNotFoundException;
import com.homejiny.customer.repository.CustomerKycDetailsRepository;
import com.homejiny.customer.repository.CustomerRepository;
import com.homejiny.customer.repository.KycTypeRepository;
import com.homejiny.customer.view.CustomerKycAndDeliveryInfoResponse;
import com.homejiny.customer.view.KycDetails;
import com.homejiny.customer.view.ViewCustomerKycResponse;
import com.homejiny.customer.view.ViewResponse;

@Service
public class FetchCustomerKycService {

	private Logger logger = LogManager.getLogger(FetchCustomerKycService.class);

	@Autowired
	CustomerRepository customerRepository;

	@Autowired
	KycTypeRepository kycTypeRepository;

	@Autowired
	CustomerKycDetailsRepository customerKycDetailsRepository;

	@Value("${cloud.aws.image_url}")
	private String imageUrl;

	@Autowired
	CustomerService customerService;

	public List<KycDetails> fetchCustomerKyc(Long customerId) {

		logger.info("fetch customer kyc details :");
		List<KycDetails> customers = new ArrayList<>();
		Optional<Customer> customer = customerRepository.findById(customerId);
		if (!customer.isPresent()) {
			logger.info("customer not found with this id :" + customerId);
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}
		List<CustomerKycDetails> customerkyc = customerKycDetailsRepository
				.findByCustomerOrderByCreatedAtAsc(customer.get());
		for (CustomerKycDetails customerKycDetails : customerkyc) {
			KycDetails kycDetails = new KycDetails();
			kycDetails.setKycdocNumber(customerKycDetails.getKycDocNumber());
			kycDetails.setImageView(customerKycDetails.getImageView());
			if (customerKycDetails.getKycType().getCode() != null) {
				kycDetails.setKycCode(customerKycDetails.getKycType().getCode());
			}
			if (customerKycDetails.getKycType().getName() != null) {
				kycDetails.setKycTypeName(customerKycDetails.getKycType().getName());
			}
			if (customerKycDetails.getMedia() != null) {
				kycDetails.setMediaFile(imageUrl + customerKycDetails.getMedia().getOriginalSizePath());
			}
			customers.add(kycDetails);
		}
		return customers;
	}

	public ViewCustomerKycResponse getCustomerKyc(Long customerId) {
		ViewCustomerKycResponse viewResponse = new ViewCustomerKycResponse();
		viewResponse.setCustomerId(customerId);
		viewResponse.setData(fetchCustomerKyc(customerId));
		viewResponse.setStatus(Constants.SUCCESS);
		return viewResponse;
	}

	public ViewResponse getCustomerKycAndDeliveryInfo(long customerId) {

		Optional<Customer> customerEntity= customerRepository.findById(customerId);		
		if(!customerEntity.isPresent()) {
			logger.info("customer not found with this id :" + customerId);
			throw new CustomerNotFoundException(Constants.CUSTOMER_NOT_FOUND);
		}
		CustomerKycAndDeliveryInfoResponse cuatomerKycAndDeliveryInfo = new CustomerKycAndDeliveryInfoResponse();		
		cuatomerKycAndDeliveryInfo.setCustomerId(customerId);
		if(customerEntity.get().getHasDeliveryInformationDetails()!=null) {	
		cuatomerKycAndDeliveryInfo.setHasDeliveryDetails(customerEntity.get().getHasDeliveryInformationDetails());
		}
		if(customerEntity.get().getHasKyc()!=null) {			
		cuatomerKycAndDeliveryInfo.setHasKyc(customerEntity.get().getHasKyc());
		}	
		ViewResponse viewResponse= new ViewResponse();
		viewResponse.setData(cuatomerKycAndDeliveryInfo);
		viewResponse.setStatus(Constants.SUCCESS);
		return viewResponse;
	}

}
