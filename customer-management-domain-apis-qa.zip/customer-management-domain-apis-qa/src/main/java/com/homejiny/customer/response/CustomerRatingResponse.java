package com.homejiny.customer.response;

import com.fasterxml.jackson.annotation.JsonInclude;

import software.amazon.ion.Decimal;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class CustomerRatingResponse {

	private long customerId;
	private double rating;
	private String Quality;
	private String delivery;
	private String Price;
	private String status;
	private String message;

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public String getQuality() {
		return Quality;
	}

	public void setQuality(String quality) {
		Quality = quality;
	}

	public String getDelivery() {
		return delivery;
	}

	public void setDelivery(String delivery) {
		this.delivery = delivery;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

}
