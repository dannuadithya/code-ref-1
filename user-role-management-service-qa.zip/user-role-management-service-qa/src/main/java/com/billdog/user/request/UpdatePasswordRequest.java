package com.billdog.user.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UpdatePasswordRequest {

	@NotNull(message = "UserId must not be null")
	private long userId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "please enter password")
	private String password;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
