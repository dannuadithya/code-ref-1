package com.billdog.user.exception;

public class InternalServerException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InternalServerException(String exception) {
		super(exception);
	}
}
