package com.billdog.user.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.SystemUsers;
import com.billdog.user.entity.SystemUsersAccess;

public interface SystemUsersAccessRepository extends JpaRepository<SystemUsersAccess, Long> {

	Optional<SystemUsersAccess> findByUserIdAndPasscode(SystemUsers user, String passcode);

	Optional<SystemUsersAccess> findByUserId(SystemUsers user);

	Optional<SystemUsersAccess> findByUserIdAndPassword(SystemUsers user, String password);
}
