package com.billdog.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.Organization;
import com.billdog.user.entity.RelationshipMaster;

public interface RelationshipMasterRepository extends JpaRepository<RelationshipMaster, Long> {

	List<RelationshipMaster> findByOrganizationIdAndStatus(Organization organizationId, String active);

}
