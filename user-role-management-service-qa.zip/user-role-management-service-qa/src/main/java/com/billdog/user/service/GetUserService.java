package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.GetUsersRequest;
import com.billdog.user.view.GetUsers;
import com.billdog.user.view.ViewUserInfo;

@Service
public class GetUserService {
	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GetUserService.class);
	@Autowired
	SystemUsersrepository systemUsersrepository;

	public ResponseEntity<GetUsers> getUsersInfo(GetUsersRequest usersRequest) {
		LOGGER.info("getUsersInfo method started");
		List<SystemUsers> users = systemUsersrepository.findAllById(usersRequest.getUserIds());

		List<ViewUserInfo> usersList = new ArrayList<>();
		users.forEach(user -> {
			ViewUserInfo userInfo = new ViewUserInfo();

			userInfo.setId(user.getId());
			if (!StringUtils.isBlank(user.getFirstName())) {
				userInfo.setName(user.getFirstName());
			}
			if (!StringUtils.isBlank(user.getLastName())) {
				userInfo.setName(userInfo.getName() != null ? userInfo.getName() + " " + user.getLastName()
						: user.getLastName());
			}
			usersList.add(userInfo);
		});
		GetUsers getUsers = new GetUsers();
		getUsers.setStatus(Constants.SUCCESS);
		getUsers.setMessage(Constants.USERS_INFO_FETCHED);
		getUsers.setData(usersList);
		LOGGER.info("getUsersInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(getUsers);
	}

}
