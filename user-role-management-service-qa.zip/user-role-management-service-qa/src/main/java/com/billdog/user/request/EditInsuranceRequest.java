package com.billdog.user.request;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class EditInsuranceRequest {

	private long insuranceType;
	private long subType;
	private long carrier;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String groupId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String productName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String providerContactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String customerServiceContactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String memberInsuranceId;
	private List<DeductiablePayInfoRequest> deductiblePayInfoList;
	@NotNull(message = "memberId must not be null")
	private long memberId;
	//@NotNull(message = "userId must not be null")
	private long userId;
	@NotNull(message = "insuranceId must not be null")
	private long insuranceId;

	public String getMemberInsuranceId() {
		return memberInsuranceId;
	}

	public void setMemberInsuranceId(String memberInsuranceId) {
		this.memberInsuranceId = memberInsuranceId;
	}

	public long getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(long insuranceType) {
		this.insuranceType = insuranceType;
	}

	public long getSubType() {
		return subType;
	}

	public void setSubType(long subType) {
		this.subType = subType;
	}

	public long getCarrier() {
		return carrier;
	}

	public void setCarrier(long carrier) {
		this.carrier = carrier;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProviderContactNumber() {
		return providerContactNumber;
	}

	public void setProviderContactNumber(String providerContactNumber) {
		this.providerContactNumber = providerContactNumber;
	}

	public String getCustomerServiceContactNumber() {
		return customerServiceContactNumber;
	}

	public void setCustomerServiceContactNumber(String customerServiceContactNumber) {
		this.customerServiceContactNumber = customerServiceContactNumber;
	}

	public List<DeductiablePayInfoRequest> getDeductiblePayInfoList() {
		return deductiblePayInfoList;
	}

	public void setDeductiblePayInfoList(List<DeductiablePayInfoRequest> deductiblePayInfoList) {
		this.deductiblePayInfoList = deductiblePayInfoList;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getInsuranceId() {
		return insuranceId;
	}

	public void setInsuranceId(long insuranceId) {
		this.insuranceId = insuranceId;
	}

}
