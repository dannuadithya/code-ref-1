package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.entity.ApplicationVersion;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.NavigationScreen;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.OrganizationDomains;
import com.billdog.user.entity.ReleaseNotes;
import com.billdog.user.entity.VersionUpdates;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.repository.ApplicationVersionRepository;
import com.billdog.user.repository.OrganizationAddressRepository;
import com.billdog.user.repository.OrganizationDomainsRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.ReleaseNotesRepository;
import com.billdog.user.repository.VersionUpdatesRepository;
import com.billdog.user.request.CreateOrganization;
import com.billdog.user.view.MemberAppVesrionResponse;
import com.billdog.user.view.ReleaseNotesView;
import com.billdog.user.view.ViewOrganizationResponse;
import com.billdog.user.view.ViewResponse;

@Service
public class OrganizationService {

	private static final Logger LOGGER = LoggerFactory.getLogger(OrganizationService.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	OrganizationAddressRepository organizationAddressRepository;

	@Autowired
	ApplicationVersionRepository applicationVersionRepository;

	@Autowired
	VersionUpdatesRepository versionUpdatesRepository;

	@Autowired
	MemberService memberService;

	@Autowired
	ReleaseNotesRepository releaseNotesRepository;

	@Autowired
	OrganizationDomainsRepository organizationDomainsRepository;

	@Value("${case.pagination.limit}")
	private int casePaginationLimit;

	@Value("${notification.pagination.limit}")
	private int notificationPaginationLimit;

	@Value("${chat.pagination.limit}")
	private int chatPaginationLimit;

	@Value("${resend.passcode.time.seconds}")
	private Long resendPasscodeTime;

	/**
	 * @param createOrganization
	 * @return
	 */
	public ViewResponse createOrganization(CreateOrganization createOrganization) {
		LOGGER.info("createNavigationPage method started..!");

		Organization organization = organizationRepository.findByName(createOrganization.getName());

		LOGGER.debug("creating new organization.!!");
		NavigationScreen navigationScreens = new NavigationScreen();
		navigationScreens.setCreatedAt(DateAndTimeUtil.now());
		navigationScreens.setUpdatedAt(DateAndTimeUtil.now());
		navigationScreens.setOrganizationId(organization);

		LOGGER.info("createNavigationPage method ends..!");
		return null;

	}

	/**
	 * @param url
	 * @return
	 */
	public ViewOrganizationResponse getOrganiation(String url) {
		LOGGER.info("providing organization based on url..!");
		OrganizationDomains organizationDomains = organizationDomainsRepository.findByDomainUrl(url);
		if (organizationDomains == null) {
			throw new NoRecordFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND_BY_URL);
		}
		ViewOrganizationResponse response = new ViewOrganizationResponse();
		if (organizationDomains.getOrganizationId() != null) {
			Organization organization = organizationDomains.getOrganizationId();
			response.setOrganizationId(organization.getId());
			response.setMessage("Organization details found successfully");
			response.setResendPasscodeTime(resendPasscodeTime);
			response.setPasswordMaxValue(Constants.PASSWORD_MAX_LENGTH);
			response.setPasswordMinValue(Constants.PASSWORD_MIN_LENGTH);
			response.setImageNameMaxSize(Constants.IMAGE_NAME_MAX_LENGTH);
			response.setImageNameMinSize(Constants.IMAGE_NAME_MIN_LENGTH);
			response.setTermsAndConditionsUrl(organization.getTermsAndConditionsUrl());
			response.setPrivacyUrl(organization.getPrivacyUrl());
			response.setAboutUsUrl(organization.getAboutUsUrl());
			response.setFaqUrl(organization.getFaqUrl());
			response.setNameMinSize(2l);
			response.setNameMaxSize(30l);
			response.setFileSize(organization.getFileSize());
			response.setCasePaginationLimit(casePaginationLimit);
			response.setChatPaginationLimit(chatPaginationLimit);
			response.setNotificationPaginationLimit(notificationPaginationLimit);
		}

		return response;
	}

	public MemberAppVesrionResponse getAppVesrionResponse(Long memberId) {
		Member member = memberService.getMember(memberId);
		ApplicationVersion applicationVersion = applicationVersionRepository
				.findByOrganizationId(member.getOrganizationId());
		MemberAppVesrionResponse appVesrionResponse = new MemberAppVesrionResponse();
		if (applicationVersion != null) {
			String version = Constants.ANDROID.equalsIgnoreCase(member.getDeviceType())
					? applicationVersion.getAndroidVersion()
					: applicationVersion.getIosVersion();
			appVesrionResponse.setLatestReleaseVersion(version);
			VersionUpdates versionUpdate = versionUpdatesRepository
					.findByVersionAndApplicationVersionId(member.getCurrentVersion(), applicationVersion);

			if (!StringUtils.isBlank(member.getCurrentVersion())
					&& !version.equalsIgnoreCase(member.getCurrentVersion())) {
				String[] appVersions = getVersion(version);
				String[] memberAppVersions = getVersion(member.getCurrentVersion());
				if (Long.valueOf(appVersions[0]) > (Long.valueOf(memberAppVersions[0]))) {
					appVesrionResponse.setUpdateAvailable(true);
				}
				else if (Long.valueOf(appVersions[0]) == (Long.valueOf(memberAppVersions[0]))) {
					if (Long.valueOf(appVersions[1]) > (Long.valueOf(memberAppVersions[1]))) {
						appVesrionResponse.setUpdateAvailable(true);
					}
					else if(Long.valueOf(appVersions[1]) == (Long.valueOf(memberAppVersions[1]))) {
						if (Long.valueOf(appVersions[2]) > (Long.valueOf(memberAppVersions[2]))) {
							appVesrionResponse.setUpdateAvailable(true);
						}
					}
				}
			}

			if (applicationVersion.isGlobalUpdate() || (versionUpdate != null && versionUpdate.isForceUpdate())) {
				appVesrionResponse.setForceUpdate(true);
			}
			appVesrionResponse.setMemberAppVesrion(member.getCurrentVersion());
			appVesrionResponse.setMemberId(memberId);
			appVesrionResponse.setStatusText(Constants.SUCCESS);
		}
		List<ReleaseNotes> releaseNotesEntity = releaseNotesRepository
				.findAllByOrganizationIdAndDeviceType(member.getOrganizationId(), member.getDeviceType());
		LOGGER.debug("fetching list of release notes..");
		List<ReleaseNotesView> releaseNotesList = new ArrayList<>();
		if (!releaseNotesEntity.isEmpty()) {
			// looping through arrayList
			releaseNotesEntity.forEach(release -> {
				ReleaseNotesView releaseNotes = new ReleaseNotesView();
				releaseNotes.setReleaseNotes(release.getReleaseNotes());
				if (!StringUtils.isBlank(releaseNotes.getReleaseNotes())) {
					releaseNotesList.add(releaseNotes);
				}
			});

		}
		appVesrionResponse.setReleaseNotes(releaseNotesList);

		return appVesrionResponse;
	}

	private String[] getVersion(String version) {
		String[] appVersions = version.split("\\.");
		if (appVersions.length < 3) {
			if (appVersions.length == 1) {
				version = version.concat(".0.0");
			}
			if (appVersions.length == 2) {
				version = version.concat(".0");
			}
		}

		return version.split("\\.");
	}

	

}
