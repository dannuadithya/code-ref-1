package com.billdog.user.repository;

import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.billdog.user.entity.CensusUploadFailed;

public interface CensusUploadFailedRespository extends JpaRepository<CensusUploadFailed, Long> {

	Optional<CensusUploadFailed> findByFileNameAndUserIdAndOpportunityIdAndEmail(String fileName, Long user, Long oppId,
			String email);

	@Query(value = "select * from census_failed_data where user_id=?1 and opportunity_id=?2 order by updated_at desc", countQuery = "select * from census_failed_data where user_id=?1 and opportunity_id=?2 order by updated_at desc", nativeQuery = true)
	Page<CensusUploadFailed> getCensusFailedData(Long userId, Long opportunityId, PageRequest pageRequest);
}
