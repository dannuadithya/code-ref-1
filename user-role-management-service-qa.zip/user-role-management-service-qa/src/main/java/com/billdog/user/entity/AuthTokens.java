package com.billdog.user.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "AUTH_TOKENS")
@Table(name = "auth_tokens")
public class AuthTokens extends BaseEntity {

	@Column(name = "TOKEN")
	private String token;

	@ManyToOne
	@JoinColumn(name = "USER_ID")
	private SystemUsers userId;

	@ManyToOne
	@JoinColumn(name = "MEMBER_ID")
	private Member memberId;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Column(name = "EXPIRED_AT")
	private LocalDateTime expiredAt;

	@Column(name = "REFRESH_TOKEN_EXPIRED_AT")
	private LocalDateTime refreshTokenExpiredAt;

	@Column(name = "REFRESH_TOKEN")
	private String refreshToken;

	@Column(name = "REASON")
	private String reason;
	@Column(name = "DEVICE_TOKEN")
	private String deviceToken;

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public SystemUsers getUserId() {
		return userId;
	}

	public void setUserId(SystemUsers userId) {
		this.userId = userId;
	}

	public Member getMemberId() {
		return memberId;
	}

	public void setMemberId(Member memberId) {
		this.memberId = memberId;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public LocalDateTime getExpiredAt() {
		return expiredAt;
	}

	public void setExpiredAt(LocalDateTime expiredAt) {
		this.expiredAt = expiredAt;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public LocalDateTime getRefreshTokenExpiredAt() {
		return refreshTokenExpiredAt;
	}

	public void setRefreshTokenExpiredAt(LocalDateTime refreshTokenExpiredAt) {
		this.refreshTokenExpiredAt = refreshTokenExpiredAt;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

}
