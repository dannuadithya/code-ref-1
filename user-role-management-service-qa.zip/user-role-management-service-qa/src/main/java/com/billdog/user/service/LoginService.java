package com.billdog.user.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.authentication.AesEncryption;
import com.billdog.user.authentication.JWTAuthentication;
import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.common.UserType;
import com.billdog.user.entity.AuthTokens;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.RoleNavigationScreens;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.entity.SystemUsersAccess;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.exception.NavigationScreenAccessException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.exception.PasscodeExpiredException;
import com.billdog.user.repository.AuthTokensRepository;
import com.billdog.user.repository.NamePrefixMasterRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.RoleNavigationScreensRepository;
import com.billdog.user.repository.RolesRepository;
import com.billdog.user.repository.SystemUsersAccessRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.UpdatePasswordRequest;
import com.billdog.user.request.UserSignInRequest;
import com.billdog.user.request.VerifyEmailRequest;
import com.billdog.user.request.VerifyPasscodeRequest;
import com.billdog.user.response.LoginResponse;
import com.billdog.user.view.NavigationPages;
import com.billdog.user.view.NavigationSubPages;
import com.billdog.user.view.ViewResponse;
import com.billdog.user.view.ViewUserNavigation;

@Service
public class LoginService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(LoginService.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	NamePrefixMasterRepository namePrefixMasterRepository;

	@Autowired
	SystemUsersrepository systemUsersRepository;

	@Autowired
	RolesRepository rolesRepository;

	@Autowired
	SystemUsersAccessRepository systemUsersAccessRepository;

	@Autowired
	AesEncryption aesEncryption;

	@Autowired
	NavigationService navigationService;

	@Autowired
	RoleNavigationScreensRepository roleNavigationScreensRepository;

	@Autowired
	CreateUserService createUserService;

	@Autowired
	JWTAuthentication jwtAuthentication;

	@Autowired
	AuthTokensRepository authTokensRepository;

	@Value("${passcode.expired.time.minutes}")
	private int passcodeExpiredTime;

	@Value("${passcode.email.times}")
	private int passcodeTimes;

	@Value("${user.jwt.token.minutes}")
	private Integer userTokenExpiryTime;
	

	@Value("${email.domain.list}")
	private List<String> emialDomains;
	
	@Value("${email.domain.list}")
	private String domains;

	private static final String PASSWORD_REGEX = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[`~!@#$%^&-+=_':|<.,>;?\\[\\]\\)\\({}/])(?=\\S+$).{10,16}$";

	private static final Pattern PASSWORD_PATTERN = Pattern.compile(PASSWORD_REGEX);

	/**
	 * @param createUserRequest
	 * @return
	 */
	public LoginResponse verifyEmail(String domainUrl, VerifyEmailRequest verifyEmailRequest) {
		LOGGER.info("Verify email method started..!");
		validateEmail(verifyEmailRequest.getEmail());

		// This jpa query checks whether the organization is present or not from
		// systemUser table

		LOGGER.debug("checking email present or not in that organization..!");
		SystemUsers user = getInternalSystemUsers(verifyEmailRequest.getEmail(),
				verifyEmailRequest.getOrganizationId());
		// checkUrl(domainUrl, user);
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(user);
		if (systemUsersAccess.isPresent()) {
			if (user.isLocked() && user.isLockedFromWeb()) {
				throw new NoRecordFoundException(getErrorMessage(user.getOrganizationId()));
			} else if ((systemUsersAccess.get().getLasPasscodeVerified() != null
					&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
					&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified()))
					|| (systemUsersAccess.get().getLasPasswordVerified() != null
							&& systemUsersAccess.get().getPasswordIncorrectCount() >= 3
							&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasswordVerified()))) {
				user.setLocked(true);
				systemUsersRepository.save(user);
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}
		}

		if (user.getStatus().equalsIgnoreCase(StatusConstants.ENROLLED)) {
			LOGGER.debug("sending passcode..!");
			createUserService.sendPasscode(user, EmailTitles.UPDATE_PASSWORD);
		}
		if (systemUsersAccess.isPresent() && user.isLocked()) {
			systemUsersAccess.get().getUserId().setLocked(false);
			systemUsersRepository.save(systemUsersAccess.get().getUserId());

		}
		// providing successful response if user data is stores
		LoginResponse loginResponse = new LoginResponse();
		loginResponse.setUserId(user.getId());
		loginResponse.setStatusText(Constants.SUCCESS);
		loginResponse.setMessage(Constants.USER_EXIST);
		loginResponse.setUserStatus(user.getStatus());
		LOGGER.info("Verify email method ends..!");
		return loginResponse;

	}

	private void checkUrl(String domainUrl, SystemUsers user) {
		String url = "dev.billdog.wavelabs.in";
		domainUrl = domainUrl.replace("http://", "");
		domainUrl = domainUrl.replace("https://", "");
		domainUrl = domainUrl.replace("http://www.", "");
		domainUrl = domainUrl.replace("https://www.", "");
		LOGGER.info("host url:: {}", domainUrl);

		if (!url.equalsIgnoreCase(domainUrl) && user.getId() == 1) {
			throw new NoRecordFoundException(ExceptionalMessages.INTERNAL_USER_ACCESS);
		}
	}

	public String getErrorMessage(Organization organization) {
		String message = ExceptionalMessages.WEB_LOCKED;
		if (organization != null && !StringUtils.isBlank(organization.getEmail())) {
			message = message.replace("<Email>", organization.getEmail());
		} else {
			message = message.replace("<Email>", "");
		}
		return message;
	}

	/**
	 * @param id
	 * @return
	 */
	public Organization getOrganization(Long id) {
		LOGGER.info("checking whether organization present or not..!");
		Optional<Organization> orgOptional = organizationRepository.findById(id);
		if (!orgOptional.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		return orgOptional.get();
	}

	/**
	 * @param id
	 * @return
	 */
	public SystemUsers getSystemUsers(Long id) {
		LOGGER.info("checking whether user present or not..!");
		Optional<SystemUsers> orgOptional = systemUsersRepository.findById(id);
		if (!orgOptional.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		return orgOptional.get();
	}

	private SystemUsers getSystemUsers(String email, Long orgId) {
		LOGGER.info("checking whether email present or not..!");
		Optional<SystemUsers> user = systemUsersRepository.findByEmailAndOrganizationId(email, getOrganization(orgId));
		if (!user.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_DOES_NOT_EXITS);
		}
		if (user.get().getStatus() != null && (user.get().getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				|| user.get().getStatus().equalsIgnoreCase(StatusConstants.DELETED))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_ACCESS);
		}
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(user.get());
		if (systemUsersAccess.isPresent()) {
			if (user.get().isLocked() && user.get().isLockedFromWeb()) {
				throw new NoRecordFoundException(getErrorMessage(user.get().getOrganizationId()));
			}
			if (systemUsersAccess.get().getLasPasscodeVerified() != null
					&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
					&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}
		}
		return user.get();
	}

	private SystemUsers getSystemUsersVerifyPasscode(String email, Long orgId) {
		LOGGER.info("checking whether email present or not..!");
		Optional<SystemUsers> user = systemUsersRepository.findByEmailAndOrganizationIdAndUserType(email,
				getOrganization(orgId), UserType.Internal.toString());
		if (!user.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_DOES_NOT_EXITS);
		}
		if (user.get().getStatus() != null && (user.get().getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				|| user.get().getStatus().equalsIgnoreCase(StatusConstants.DELETED))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_ACCESS);
		}
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(user.get());
		if (systemUsersAccess.isPresent()) {
			if (user.get().isLocked() && user.get().isLockedFromWeb()) {
				throw new NoRecordFoundException(getErrorMessage(user.get().getOrganizationId()));
			}
			if (systemUsersAccess.get().getLasPasscodeVerified() != null
					&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
					&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
				user.get().setLocked(true);
				systemUsersRepository.save(user.get());
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}
		}
		return user.get();
	}

	private SystemUsers getInternalSystemUsers(String email, Long orgId) {
		LOGGER.info("checking whether email present or not..!");
		Optional<SystemUsers> user = systemUsersRepository.findByEmailAndOrganizationIdAndUserType(email,
				getOrganization(orgId), UserType.Internal.toString());
		if (!user.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_DOES_NOT_EXITS);
		}
		if (user.get().getStatus() != null && (user.get().getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				|| user.get().getStatus().equalsIgnoreCase(StatusConstants.DELETED))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_ACCESS);
		}
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(user.get());
		if (systemUsersAccess.isPresent()) {
			if (user.get().isLocked() && user.get().isLockedFromWeb()) {
				throw new NoRecordFoundException(getErrorMessage(user.get().getOrganizationId()));
			}
			if (systemUsersAccess.get().getLasPasscodeVerified() != null
					&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
					&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}
		}
		return user.get();
	}

	private SystemUsers getSystemExternalUsers(String email, Long orgId) {
		LOGGER.info("checking whether email present or not..!");
		Optional<SystemUsers> user = systemUsersRepository.findByEmailAndOrganizationIdAndUserType(email,
				getOrganization(orgId), UserType.External.toString());
		if (!user.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_DOES_NOT_EXITS);
		}
		if (user.get().getStatus() != null && (user.get().getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				|| user.get().getStatus().equalsIgnoreCase(StatusConstants.DELETED))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_ACCESS);
		}
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(user.get());
		if (systemUsersAccess.isPresent()) {
			if (user.get().isLocked() && user.get().isLockedFromWeb()) {
				throw new NoRecordFoundException(getErrorMessage(user.get().getOrganizationId()));
			}
			if (systemUsersAccess.get().getLasPasscodeVerified() != null
					&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
					&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
				user.get().setLocked(true);
				systemUsersRepository.save(user.get());
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}
		}
		return user.get();
	}

	/**
	 * @param verifyPasscodeRequest
	 * @return
	 */
	public ViewResponse verifyPasscode(VerifyPasscodeRequest verifyPasscodeRequest) {
		LOGGER.info("verify passcode method started..!");

		// This jpa query checks whether the email is exits or not
		SystemUsers appUser = getSystemUsersVerifyPasscode(verifyPasscodeRequest.getEmail(),
				verifyPasscodeRequest.getOrganizationId());

		// This jpa query checks whether the passcode matched with email sent
		Optional<SystemUsersAccess> loginPasscode = systemUsersAccessRepository.findByUserId(appUser);
		if (!loginPasscode.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND_IN_ORGANISATION);
		}
		if (loginPasscode.get().getLasPasscodeVerified() != null && loginPasscode.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(loginPasscode.get().getLasPasscodeVerified())) {
			appUser.setLocked(true);
			systemUsersRepository.save(appUser);
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}
		String decryption = aesEncryption.decrypt(loginPasscode.get().getPasscode());
		if (!decryption.equalsIgnoreCase(verifyPasscodeRequest.getPasscode())) {
			Long passcodeCount = loginPasscode.get().getPasscodeIncorrectCount() != null
					? loginPasscode.get().getPasscodeIncorrectCount()
					: 0;
			loginPasscode.get().setPasscodeIncorrectCount(passcodeCount + 1);
			loginPasscode.get().setLasPasscodeVerified(LocalDateTime.now());
			systemUsersAccessRepository.save(loginPasscode.get());
			throw new NoRecordFoundException(ExceptionalMessages.PLEASE_ENTER_VALID_PASSCODE);
		}
		LOGGER.info("checking whether user is eligible to send passcode..!");
		checkTime(loginPasscode.get());
		loginPasscode.get().setPasscodeIncorrectCount(0l);
		systemUsersAccessRepository.save(loginPasscode.get());
		systemUsersRepository.save(appUser);
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setUserId(appUser.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.PASSCODE_VERIFIED_SUCCESSFULLY);
		return viewResponse;

	}

	public ViewResponse verifyExternalUserPasscode(VerifyPasscodeRequest verifyPasscodeRequest) {
		LOGGER.info("verify passcode method started..!");

		// This jpa query checks whether the email is exits or not
		SystemUsers appUser = getSystemExternalUsers(verifyPasscodeRequest.getEmail(),
				verifyPasscodeRequest.getOrganizationId());

		// This jpa query checks whether the passcode matched with email sent
		Optional<SystemUsersAccess> loginPasscode = systemUsersAccessRepository.findByUserId(appUser);
		if (!loginPasscode.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND_IN_ORGANISATION);
		}
		if (loginPasscode.get().getLasPasscodeVerified() != null && loginPasscode.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(loginPasscode.get().getLasPasscodeVerified())) {
			appUser.setLocked(true);
			systemUsersRepository.save(appUser);
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}
		String decryption = aesEncryption.decrypt(loginPasscode.get().getPasscode());
		if (!decryption.equalsIgnoreCase(verifyPasscodeRequest.getPasscode())) {
			Long passcodeCount = loginPasscode.get().getPasscodeIncorrectCount() != null
					? loginPasscode.get().getPasscodeIncorrectCount()
					: 0;
			loginPasscode.get().setPasscodeIncorrectCount(passcodeCount + 1);
			loginPasscode.get().setLasPasscodeVerified(LocalDateTime.now());
			systemUsersAccessRepository.save(loginPasscode.get());
			throw new NoRecordFoundException(ExceptionalMessages.PLEASE_ENTER_VALID_PASSCODE);
		}
		LOGGER.info("checking whether user is eligible to send passcode..!");
		checkTime(loginPasscode.get());
		loginPasscode.get().setPasscodeIncorrectCount(0l);
		systemUsersAccessRepository.save(loginPasscode.get());
		systemUsersRepository.save(appUser);
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setUserId(appUser.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.PASSCODE_VERIFIED_SUCCESSFULLY);
		return viewResponse;

	}

	/**
	 * @param loginPasscode
	 */
	private void checkTime(SystemUsersAccess loginPasscode) {
		if (DateAndTimeUtil.now().isAfter(loginPasscode.getMailSent().plusMinutes(passcodeExpiredTime))) {
			String message = ExceptionalMessages.PASSCODE_TIME_EXPIRED.replace("{time}", "" + passcodeExpiredTime);
			throw new PasscodeExpiredException(message);
		}
	}

	/**
	 * @param updatePasswordRequest
	 * @return
	 */
	@Transactional
	public ViewResponse updatePassword(UpdatePasswordRequest updatePasswordRequest) {
		LOGGER.info("edit user details method started..!");
		checkPassword(updatePasswordRequest.getPassword());
		SystemUsers appUser = getSystemUsers(updatePasswordRequest.getUserId());

		// This jpa query checks whether the email is present or not
		Optional<SystemUsersAccess> systemUsersAccessOptional = systemUsersAccessRepository.findByUserId(appUser);

		ViewResponse viewResponse = new ViewResponse();
		if (systemUsersAccessOptional.isPresent()) {
			LOGGER.debug("encripting given password..!");
			String hashedPassword = aesEncryption.passwordHashing(updatePasswordRequest.getPassword());
			if (!StringUtils.isBlank(hashedPassword)
					&& !StringUtils.isBlank(systemUsersAccessOptional.get().getPassword())
					&& hashedPassword.equalsIgnoreCase(systemUsersAccessOptional.get().getPassword())) {
				throw new InValidInputException(ExceptionalMessages.PASSWORD_MATCHED);
			}
			SystemUsersAccess email = systemUsersAccessOptional.get();
			email.setUpdatedAt(DateAndTimeUtil.now());
			if (email.getPassword() == null) {
				viewResponse.setMessage(Constants.PASSWORD_CREATED);
			} else {
				viewResponse.setMessage(Constants.PASSWORD_UPDATED);
			}
			email.setPassword(hashedPassword);
			systemUsersAccessRepository.save(email);
			if (appUser.getStatus() != null && appUser.getStatus().equalsIgnoreCase(StatusConstants.ENROLLED)) {
				appUser.setStatus(StatusConstants.ACTIVE);
				appUser.setUserId(appUser.getId());
				systemUsersRepository.save(appUser);
			}
		}
		LOGGER.info("create password method ends..!");
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setUserId(appUser.getId());
		viewResponse.setData(getNavigationPages(appUser));
		return viewResponse;
	}

	public void checkPassword(String password) {
		if (!PASSWORD_PATTERN.matcher(password).matches()) {
			String message = ExceptionalMessages.USER_INVALID_PASSWORD.replace("<Max>",
					"" + Constants.PASSWORD_MAX_LENGTH);
			message = message.replace("<Min>", "" + Constants.PASSWORD_MIN_LENGTH);
			throw new InValidInputException(message);
		}
	}

	/**
	 * @param signInRequest
	 * @return
	 */
	public ViewResponse signInUser(UserSignInRequest signInRequest) {
		LOGGER.info("verify passcode method started..!");

		// validateEmail(signInRequest.getEmail());

		// This jpa query checks whether the email and password matched or not
		SystemUsers appUser = getInternalSystemUsers(signInRequest.getEmail(), signInRequest.getOrganizationId(),
				UserType.Internal.toString());

		// This jpa query checks whether the password matched with email sent
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(appUser);
		if (!systemUsersAccess.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		Long passcodeCount = systemUsersAccess.get().getPasswordIncorrectCount() == null ? 0
				: systemUsersAccess.get().getPasswordIncorrectCount();
		if (appUser.isLocked() && appUser.isLockedFromWeb()) {
			throw new NoRecordFoundException(getErrorMessage(appUser.getOrganizationId()));
		} else if (systemUsersAccess.get().getLasPasscodeVerified() != null
				&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
			appUser.setLocked(true);
			systemUsersRepository.save(appUser);
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		} else if (systemUsersAccess.get().getLasPasswordVerified() != null && passcodeCount >= 3
				&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasswordVerified())) {
			appUser.setLocked(true);
			systemUsersRepository.save(appUser);
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}
		LOGGER.debug("decrypting password from data-base..!");
		String hashInputPassword = aesEncryption.passwordHashing(signInRequest.getPassword());
		if (!hashInputPassword.equals(systemUsersAccess.get().getPassword())) {
			systemUsersAccess.get()
					.setPasswordIncorrectCount(systemUsersAccess.get().getPasswordIncorrectCount() == null ? 1
							: systemUsersAccess.get().getPasswordIncorrectCount() + 1);
			systemUsersAccess.get().setLasPasswordVerified(LocalDateTime.now());
			systemUsersAccessRepository.save(systemUsersAccess.get());
			throw new NoRecordFoundException(ExceptionalMessages.INCORRECT_PASSWORD);
		}
		systemUsersAccess.get().setPasswordIncorrectCount(0l);
		systemUsersAccessRepository.save(systemUsersAccess.get());
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setUserId(appUser.getId());
		viewResponse.setData(getNavigationPages(appUser));
		return viewResponse;

	}

	private SystemUsers getInternalSystemUsers(String email, Long organizationId, String userType) {
		LOGGER.info("checking whether email present or not..!");
		Optional<SystemUsers> user = systemUsersRepository.findByEmailAndOrganizationIdAndUserType(email,
				getOrganization(organizationId), userType);
		if (!user.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_DOES_NOT_EXITS);
		}
		if (user.get().getStatus() != null && (user.get().getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				|| user.get().getStatus().equalsIgnoreCase(StatusConstants.DELETED))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_ACCESS);
		}
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(user.get());
		if (systemUsersAccess.isPresent()) {
			if (user.get().isLocked() && user.get().isLockedFromWeb()) {
				throw new NoRecordFoundException(getErrorMessage(user.get().getOrganizationId()));
			}
			if (systemUsersAccess.get().getLasPasscodeVerified() != null
					&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
					&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}
		}
		return user.get();
	}

	/**
	 * @param systemUser
	 * @return
	 */
	private ViewUserNavigation getNavigationPages(SystemUsers systemUser) {

		List<RoleNavigationScreens> navigationScreens = roleNavigationScreensRepository.findByRoleIdWithOrganizationId(
				systemUser.getRoleId(), systemUser.getOrganizationId(), systemUser.getRoleId().getUserType());
		List<NavigationPages> navigationPages = new ArrayList<>();

		navigationScreens.forEach(screen -> {
			if (screen != null && (screen.isReadAccess() || screen.isCustom())) {
				List<NavigationSubPages> dashboardTabs = new ArrayList<>();
				NavigationPages navigationPage = new NavigationPages();
				navigationPage.setTitle(screen.getNavigationScreensId().getName());
				navigationPage.setHref(screen.getNavigationScreensId().getUrl());
				navigationPage.setWrite(screen.isWriteAccess());
				navigationPage.setNavigationAccessId(screen.getId());
				List<NavigationSubPages> navigationSubPagesList = new ArrayList<>();
				if (!screen.getNavigationScreensId().getName().equalsIgnoreCase(Constants.DASHBOARD)
						&& screen.getNavigationScreensId().getParentId() == null) {
					screen.getNavigationScreensId().getNavigationScreens().forEach(childScreen -> {
						if (childScreen.getStatus().equalsIgnoreCase(StatusConstants.ACTIVE)) {
							NavigationSubPages subPage = new NavigationSubPages();
							RoleNavigationScreens navigationScreen = navigationService
									.findByScreenIsIn(navigationScreens, childScreen, screen);
							if (navigationScreen != null
									&& (navigationScreen.isReadAccess() || navigationScreen.isCustom())) {
								subPage.setTitle(navigationScreen.getNavigationScreensId().getName());
								subPage.setHref(navigationScreen.getNavigationScreensId().getUrl());
								subPage.setWrite(navigationScreen.isWriteAccess());
								subPage.setNavigationAccessId(navigationScreen.getId());
								subPage.setDisplayOrder(navigationScreen.getNavigationScreensId().getDisplayOrder());
								List<NavigationSubPages> tabs = new ArrayList<>();
								childScreen.getNavigationScreens().forEach(childScreen2 -> {
									if (childScreen2.getStatus().equalsIgnoreCase(StatusConstants.ACTIVE)) {
										RoleNavigationScreens navigationScreen2 = navigationService
												.findByScreenIsIn(navigationScreens, childScreen2, screen);
										if (navigationScreen2 != null && navigationScreen2.isReadAccess()) {
											NavigationSubPages subPages2 = new NavigationSubPages();
											subPages2.setTitle(navigationScreen2.getNavigationScreensId().getName());
											subPages2.setHref(navigationScreen2.getNavigationScreensId().getUrl());
											subPages2.setWrite(navigationScreen2.isWriteAccess());
											subPages2.setNavigationAccessId(navigationScreen2.getId());
											subPage.setDisplayOrder(
													navigationScreen2.getNavigationScreensId().getDisplayOrder());
											tabs.add(subPages2);
										}
									}
								});
								if (!tabs.isEmpty()) {
									subPage.setTabs(tabs.stream()
											.sorted(Comparator.comparing(NavigationSubPages::getDisplayOrder))
											.collect(Collectors.toList()));
								}
								if (subPage != null) {
									navigationSubPagesList.add(subPage);
								}
							}
						}
					});
				} else if (screen.getNavigationScreensId().getName().equalsIgnoreCase(Constants.DASHBOARD)
						&& (screen.isReadAccess() || screen.isCustom())) {
					screen.getNavigationScreensId().getNavigationScreens().forEach(childScreen -> {
						if (childScreen.getStatus().equalsIgnoreCase(StatusConstants.ACTIVE)) {
							RoleNavigationScreens navigationScreen = navigationService
									.findByScreenIsIn(navigationScreens, childScreen, screen);
							if (navigationScreen != null && navigationScreen.isReadAccess()) {
								NavigationSubPages subPage = new NavigationSubPages();
								subPage.setTitle(navigationScreen.getNavigationScreensId().getName());
								subPage.setHref(navigationScreen.getNavigationScreensId().getUrl());
								subPage.setWrite(navigationScreen.isWriteAccess());
								subPage.setNavigationAccessId(navigationScreen.getId());
								dashboardTabs.add(subPage);
							}
						}
					});
				} else {
					return;
				}
				if (!navigationSubPagesList.isEmpty()) {
					navigationPage.setSubPages(navigationSubPagesList.stream()
							.sorted(Comparator.comparing(NavigationSubPages::getDisplayOrder))
							.collect(Collectors.toList()));
				}
				if (!dashboardTabs.isEmpty()) {
					navigationPage.setDashboardTabs(dashboardTabs);
				}
				if (navigationPage != null && !(screen.isCustom() && navigationSubPagesList.isEmpty()
						&& navigationPage.getDashboardTabs() == null)) {
					navigationPages.add(navigationPage);
				}
			}
		});
		String userName = "";
		if (systemUser.getFirstName() != null) {
			userName = userName + systemUser.getFirstName();
		}
		if (systemUser.getLastName() != null) {
			userName = userName + " " + systemUser.getLastName();
		}
		ViewUserNavigation viewUserNavigation = new ViewUserNavigation();
		viewUserNavigation.setId(systemUser.getId());
		viewUserNavigation.setUserName(userName);
		viewUserNavigation.setRole(systemUser.getRoleId().getRole());
		viewUserNavigation.setNavigationPages(navigationPages);
		String token = jwtAuthentication.generateToken(systemUser.getId(), Boolean.TRUE);
		saveToken(token, systemUser);
		viewUserNavigation.setToken(token);
		return viewUserNavigation;
	}

	public void saveToken(String token, SystemUsers systemUser) {
		LOGGER.info("Save user token method started..!");
		LOGGER.info("Checking user is already exists in tokens table");
		Optional<AuthTokens> userTokenOptional = authTokensRepository.findByUserId(systemUser);
		if (userTokenOptional.isPresent()) {
			LOGGER.info("Updating user token info for user id:: {}", systemUser.getId());
			userTokenOptional.get().setExpiredAt(DateAndTimeUtil.now().plusMinutes(userTokenExpiryTime));
			userTokenOptional.get().setToken(token);
			userTokenOptional.get().setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(userTokenOptional.get());
		} else {
			LOGGER.info("Creating user token info for user id:: {}", systemUser.getId());
			AuthTokens authTokens = new AuthTokens();
			authTokens.setCreatedAt(DateAndTimeUtil.now());
			authTokens.setExpiredAt(DateAndTimeUtil.now().plusMinutes(userTokenExpiryTime));
			authTokens.setUserId(systemUser);
			authTokens.setOrganizationId(systemUser.getOrganizationId());
			authTokens.setToken(token);
			authTokens.setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(authTokens);
			LOGGER.info("Created user token info with id:: {}", authTokens.getId());
		}
		LOGGER.info("Save user token method started..!");
	}

	public void validateEmail(String email) {		
		String [] domainsList = email.split("@");
		String domain = domainsList[domainsList.length-1];		
		if(!emialDomains.contains(domain)) {
			throw new NoRecordFoundException(ExceptionalMessages.ENTER_VALID_DOMAINS.replace("<domain names>",domains));
		}
		/*
		 * if (!email.contains(emailValidate1) && !email.contains(emailValidate2) &&
		 * !email.contains(emailValidate3) && !email.contains(emailValidate4)) { throw
		 * new NoRecordFoundException(ExceptionalMessages.ENTER_VALID_DOMAINS.
		 * replace("<domain names>",
		 * "billdog.com, wavelabs.in, wavelabs.ai, gmail.com")); }
		 */

	}

	public LoginResponse verifyExternalUserEmail(VerifyEmailRequest verifyEmailRequest) {
		LOGGER.info("verify External User Email method started..!");

		// This jpa query checks whether the organization is present or not from
		// systemUser table
		LOGGER.debug("checking email present or not in that organization..!");
		SystemUsers user = getSystemExternalUsers(verifyEmailRequest.getEmail(),
				verifyEmailRequest.getOrganizationId());

		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(user);
		if (systemUsersAccess.isPresent()) {
			if (user.isLocked() && user.isLockedFromWeb()) {
				throw new NoRecordFoundException(getErrorMessage(user.getOrganizationId()));
			} else if ((systemUsersAccess.get().getLasPasscodeVerified() != null
					&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
					&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified()))
					|| (systemUsersAccess.get().getLasPasswordVerified() != null
							&& systemUsersAccess.get().getPasswordIncorrectCount() >= 3
							&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasswordVerified()))) {
				user.setLocked(true);
				systemUsersRepository.save(user);
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}
		}

		if (user.getStatus().equalsIgnoreCase(StatusConstants.ENROLLED)) {
			LOGGER.debug("sending passcode..!");
			createUserService.sendPasscode(user, EmailTitles.UPDATE_PASSWORD);
		}
		// providing successful response if user data is stores
		LoginResponse loginResponse = new LoginResponse();
		loginResponse.setUserId(user.getId());
		loginResponse.setStatusText(Constants.SUCCESS);
		loginResponse.setMessage(Constants.USER_EXIST);
		loginResponse.setUserStatus(user.getStatus());
		LOGGER.info("verify External User Email method ends..!");
		return loginResponse;

	}

	public ResponseEntity<ViewResponse> elogin(UserSignInRequest signInRequest) {
		LOGGER.info("verify passcode method started..!");

		// validateEmail(signInRequest.getEmail());

		// This jpa query checks whether the email and password matched or not
		SystemUsers appUser = getSystemExternalUsers(signInRequest.getEmail(), signInRequest.getOrganizationId());

		// This jpa query checks whether the password matched with email sent
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(appUser);
		if (!systemUsersAccess.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		if (appUser.isLocked() && appUser.isLockedFromWeb()) {
			throw new NoRecordFoundException(getErrorMessage(appUser.getOrganizationId()));
		} else if (systemUsersAccess.get().getLasPasscodeVerified() != null
				&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
			appUser.setLocked(true);
			systemUsersRepository.save(appUser);
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		} else if (systemUsersAccess.get().getLasPasswordVerified() != null
				&& systemUsersAccess.get().getPasswordIncorrectCount() >= 3
				&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasswordVerified())) {
			appUser.setLocked(true);
			systemUsersRepository.save(appUser);
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}
		LOGGER.debug("decrypting password from data-base..!");
		String hashInputPassword = aesEncryption.passwordHashing(signInRequest.getPassword());
		if (!hashInputPassword.equals(systemUsersAccess.get().getPassword())) {
			systemUsersAccess.get().setPasswordIncorrectCount(systemUsersAccess.get().getPasswordIncorrectCount() + 1);
			systemUsersAccess.get().setLasPasswordVerified(LocalDateTime.now());
			systemUsersAccessRepository.save(systemUsersAccess.get());
			throw new NoRecordFoundException(ExceptionalMessages.INCORRECT_PASSWORD);
		}
		systemUsersAccess.get().setPasswordIncorrectCount(0l);
		systemUsersAccessRepository.save(systemUsersAccess.get());
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setUserId(appUser.getId());
		viewResponse.setData(getNavigationPages(appUser));
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

}
