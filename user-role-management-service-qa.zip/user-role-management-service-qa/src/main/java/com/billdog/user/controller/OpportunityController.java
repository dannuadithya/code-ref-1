package com.billdog.user.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.billdog.user.authorization.EnableTokenAuthorisation;
import com.billdog.user.command.UploadMembersCommand;
import com.billdog.user.exception.ErrorResponse;
import com.billdog.user.request.AddMemberByEmployerRequest;
import com.billdog.user.service.InsertMembersDataService;
import com.billdog.user.service.MemberOpportunityService;
import com.billdog.user.view.ViewCensusFailedDataResponse;
import com.billdog.user.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class OpportunityController {

	@Autowired
	MemberOpportunityService memberOpportunityService;

	@Autowired
	UserController userController;

	@Autowired
	UploadMembersCommand uploadMembersCommand;

	@Autowired
	InsertMembersDataService insertMembersDataService;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "members fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/membersByEmployer", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> membersByEmployer(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestParam Long userId, @RequestParam Long employerId,
			@RequestParam Long orgaizationId, @RequestParam(value = "pageNumber", required = false) Integer pageNumber,
			@RequestParam(value = "pageLimit", required = false) Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		userController.isValidToken(httpRequest, userId);
		return memberOpportunityService.getMembersByOpportunityId(employerId, orgaizationId, pageNumber, pageLimit);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "members fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/employer-member", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addEmployerMember(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody AddMemberByEmployerRequest request) {
		userController.isValidToken(httpRequest, request.getUserId());
		return ResponseEntity.status(HttpStatus.OK).body(memberOpportunityService.addMember(request));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "members fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/employer-member", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateEmployerMember(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId,
			@Valid @RequestBody AddMemberByEmployerRequest request) {
		userController.isValidToken(httpRequest, request.getUserId());
		return ResponseEntity.status(HttpStatus.OK).body(memberOpportunityService.updateMember(request, memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Members data uploaded successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/upload-member-data", produces = MediaType.APPLICATION_JSON_UTF8_VALUE, consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> uploadMembersData(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam Long employerId,
			@RequestParam Long opportunityId, @RequestParam MultipartFile file, @RequestParam String opportunityType) {
		userController.isValidToken(httpRequest, userId);
		return uploadMembersCommand.excute(userId, employerId, opportunityId, file, opportunityType);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Members data uploaded successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/update-member-employer", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> updateEmployer(@RequestParam Long userId, @RequestParam Long newEmployerId,
			@RequestParam Long oldEmployerId) {
		return ResponseEntity.status(HttpStatus.OK)
				.body(memberOpportunityService.updateEmployer(userId, newEmployerId, oldEmployerId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "members fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/census-failed-data", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewCensusFailedDataResponse> getCensusFailedData(
			@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam Long opportunityId,
			@RequestParam(value = "pageNumber", required = false) Integer pageNumber,
			@RequestParam(value = "pageLimit", required = false) Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		userController.isValidToken(httpRequest, userId);
		return insertMembersDataService.getCensusFailedData(userId, opportunityId, pageNumber, pageLimit);
	}
}
