package com.billdog.user.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.user.authorization.EnableTokenAuthorisation;
import com.billdog.user.command.AddMemberPersonalInfoCommand;
import com.billdog.user.command.UpdateMemberPersonalInfoCommand;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.exception.ErrorResponse;
import com.billdog.user.exception.InvalidAuthTokenException;
import com.billdog.user.request.AddDirectMemberInfoRequest;
import com.billdog.user.request.AddFamilyDetailsListRequest;
import com.billdog.user.request.AddFamilyMemberRequest;
import com.billdog.user.request.AddInsuranceDetailsListRequest;
import com.billdog.user.request.AddMemberPersonalInfoRequest;
import com.billdog.user.request.CheckProductTypeRequest;
import com.billdog.user.request.CreateMemberPassword;
import com.billdog.user.request.EditInsuranceRequest;
import com.billdog.user.request.FamilyMemberRequest;
import com.billdog.user.request.GetMemberCountRequest;
import com.billdog.user.request.GetMembersRequest;
import com.billdog.user.request.LockMemberRequest;
import com.billdog.user.request.MemberPasscodeRequest;
import com.billdog.user.request.MemberPersonalDetails;
import com.billdog.user.request.MemberSearchRequest;
import com.billdog.user.request.ResendPasscodeRequest;
import com.billdog.user.request.SignInRequest;
import com.billdog.user.request.UpdateFamilyMemberRequest;
import com.billdog.user.request.UpdateMemberPassword;
import com.billdog.user.request.UpdatePersonalDetailsRequest;
import com.billdog.user.request.UpdatePrimaryEmailRequest;
import com.billdog.user.request.VerifyMemberEmailRequest;
import com.billdog.user.request.VerifyMemberPasscodeRequest;
import com.billdog.user.response.LoginResponse;
import com.billdog.user.service.DashboardAnalyticalService;
import com.billdog.user.service.FailedEmailTriggerService;
import com.billdog.user.service.GetMemberEmailList;
import com.billdog.user.service.GetMemberService;
import com.billdog.user.service.GetProfileDetails;
import com.billdog.user.service.LogoutService;
import com.billdog.user.service.MemberFamilyService;
import com.billdog.user.service.MemberInsuranceSerivce;
import com.billdog.user.service.MemberLoginService;
import com.billdog.user.service.MemberSearch;
import com.billdog.user.service.MemberService;
import com.billdog.user.service.MemberSfdcService;
import com.billdog.user.service.OrganizationService;
import com.billdog.user.service.UpdatePrimaryEmailService;
import com.billdog.user.view.DashboardResponseView;
import com.billdog.user.view.GetCountryCodeInfo;
import com.billdog.user.view.GetMemberChatInfo;
import com.billdog.user.view.MemberAppVesrionResponse;
import com.billdog.user.view.MemberInfoResponse;
import com.billdog.user.view.MemberResponse;
import com.billdog.user.view.MemberTokenResponse;
import com.billdog.user.view.PasswordResponse;
import com.billdog.user.view.VerifyEmailResponse;
import com.billdog.user.view.VerifyMemberPasscodeResponse;
import com.billdog.user.view.ViewMemberResponse;
import com.billdog.user.view.ViewMembers;
import com.billdog.user.view.ViewPersonalInfoDetails;
import com.billdog.user.view.ViewProfileDetails;
import com.billdog.user.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class MemberController {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MemberController.class);

	@Autowired
	MemberLoginService memberLoginService;

	@Autowired
	MemberService memberService;

	@Autowired
	GetMemberService getMemberService;

	@Autowired

	MemberFamilyService memberFamilyService;

	@Autowired
	MemberSearch memberSearch;

	@Autowired
	UserController userController;

	@Autowired
	AddMemberPersonalInfoCommand addMemberPersonalInfoCommand;

	@Autowired
	MemberInsuranceSerivce memberInsuranceSerivce;

	@Autowired
	GetProfileDetails getProfileDetails;

	@Autowired
	UpdateMemberPersonalInfoCommand updateMemberPersonalInfoCommand;

	@Autowired
	GetMemberEmailList getMemberEmailList;

	@Autowired
	UpdatePrimaryEmailService updatePrimaryEmailService;

	@Autowired
	LogoutService logoutService;

	@Autowired
	OrganizationService organizationService;

	@Autowired
	DashboardAnalyticalService dashboardAnalyticalService;

	@Autowired
	MemberSfdcService memberSfdcService;

	@Autowired
	FailedEmailTriggerService failedEmailTriggerService;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Role created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/memberEmail", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<VerifyEmailResponse> verifyMemberEmail(
			@Valid @RequestBody VerifyMemberEmailRequest verifyMemberEmailRequest) {

		return ResponseEntity.status(HttpStatus.OK)
				.body(memberLoginService.verifyMemberEmail(verifyMemberEmailRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "Passcode sent successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/memberPasscode", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> sendMemberPasscode(
			@Valid @RequestBody ResendPasscodeRequest resendPasscodeRequest) {

		return memberLoginService.sendPasscodeByMember(resendPasscodeRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "passcode verified successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/verifyMemberPasscode", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<VerifyMemberPasscodeResponse> verifyMemberPasscode(
			@Valid @RequestBody VerifyMemberPasscodeRequest verifyMemberPasscodeRequest) {

		return memberLoginService.verifyMemberPasscode(verifyMemberPasscodeRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Password saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Member not found with id"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/memberPassword", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<PasswordResponse> savePassword(@Valid @RequestBody CreateMemberPassword passwordRequest) {
		return ResponseEntity.status(HttpStatus.OK).body(memberService.createPassword(passwordRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Password updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Member not found with id"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/memberPassword", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<PasswordResponse> updatePassword(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody UpdateMemberPassword passwordRequest) {
		isValidToken(httpRequest, passwordRequest.getMemberId());
		return ResponseEntity.status(HttpStatus.OK).body(memberService.updatePassword(passwordRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Password saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Member not found with id"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/memberLogin", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewMemberResponse> memberLogin(@Valid @RequestBody SignInRequest memberLogin) {

		return ResponseEntity.status(HttpStatus.OK).body(memberLoginService.memberLogin(memberLogin));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member personal details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/MemberInfo", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> createMemberPersonalInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody MemberPersonalDetails memberPersonalDetails) {
		isValidToken(httpRequest, memberPersonalDetails.getMemberId());
		return memberService.saveMemberPersonalDetails(memberPersonalDetails);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member personal details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/memberInfo", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateMemberPersonalInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody MemberPersonalDetails memberPersonalDetails) {
		userController.isValidToken(httpRequest, null, memberPersonalDetails.getMemberId());
		return memberService.updateMemberPersonalDetails(memberPersonalDetails);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member personal details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/direct-member-info", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> addDirectMemberInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody AddDirectMemberInfoRequest memberPersonalDetails) {
		userController.isValidToken(httpRequest, null, memberPersonalDetails.getMemberId());
		return memberService.updateDirectMemberInfo(memberPersonalDetails);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member personal details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/direct-member-info", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateDirectMemberInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody AddDirectMemberInfoRequest memberPersonalDetails) {
		userController.isValidToken(httpRequest, null, memberPersonalDetails.getMemberId());
		return memberService.updateDirectMemberInfo(memberPersonalDetails);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member personal details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/direct-member-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateDirectMemberInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId) {
		userController.isValidToken(httpRequest, null, memberId);
		return memberService.getDirectMemberInfo(memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member personal details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/member-logout", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<MemberResponse> memberLogout(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId) {
		isValidToken(httpRequest, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(logoutService.memberLogout(authorization, memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member personal details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/member-token", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<MemberResponse> updateMemberToken(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId) {
		isValidToken(httpRequest, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(logoutService.updateMemberTokenTime(authorization, memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "states fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "state not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllStates", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllStates(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam(required = false) Long userId,
			@RequestParam(required = false) Long memberId, @RequestParam Long countryId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return memberService.getAllStates(countryId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "countries fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "countries not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllCountries", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllCountries(@RequestHeader HttpHeaders headers,
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam(required = false) Long userId, @RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		LOGGER.info("Request url:: {} ", headers.getOrigin());
		return memberService.getAllCountries(userId, memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Gender fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Gender not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllGender", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllGender(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam(required = false) Long userId,
			@RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);

		return memberService.getAllGender(userId, memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Member family details created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/familyMember", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> addMemberFamilyInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody AddFamilyMemberRequest familyMemberRequest) {
		isValidToken(httpRequest, familyMemberRequest.getMemberId());
		return ResponseEntity.status(HttpStatus.OK)
				.body(memberFamilyService.addFamilyMemberInfoForMobile(familyMemberRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Member family details updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/familyMember", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> updateMemberFamilyInfo(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody UpdateFamilyMemberRequest familyMemberRequest, @RequestParam Long familyMemberId) {
		isValidToken(httpRequest, familyMemberRequest.getMemberId());
		return ResponseEntity.status(HttpStatus.OK)
				.body(memberFamilyService.updateFamilyMemberForMobile(familyMemberRequest, familyMemberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Member family details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/familyMember", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getFamilyMembers(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId) {
		isValidToken(httpRequest, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(memberFamilyService.getFamilyMembers(memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Member family details created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/user-familyMember", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> addMemberFamilyInfoByUser(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody AddFamilyDetailsListRequest addFamilyDetailsListRequest) {
		userController.isValidToken(httpRequest, addFamilyDetailsListRequest.getUserId());
		return ResponseEntity.status(HttpStatus.OK)
				.body(memberFamilyService.addFamilyMemberInfo(addFamilyDetailsListRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Member family details created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/user-familyMember", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> updateMemberFamilyInfoByUser(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long familyMemberId,
			@Valid @RequestBody FamilyMemberRequest familyMemberRequest) {
		userController.isValidToken(httpRequest, userId);

		return ResponseEntity.status(HttpStatus.OK)
				.body(memberFamilyService.updateFamilyMemberByUser(familyMemberRequest, familyMemberId, userId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Member family details created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/user-familyMember", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getFamilyMembersByUserId(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long userId, @RequestParam Long memberId) {
		userController.isValidToken(httpRequest, userId);
		return ResponseEntity.status(HttpStatus.OK).body(memberFamilyService.getFamilyMembers(memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "All relationship names are fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/relationship", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getRelationshipInfoByUser(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam(required = false) Long userId, @RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(memberFamilyService.getRelationshipInfo(userId, memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Member perdo successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Member not found with id"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/member", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> memberProfileInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId) {
		isValidToken(httpRequest, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(memberService.getMemberInfo(memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "members details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchMembers", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchMembers(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestBody MemberSearchRequest memberSearchRequest) {
		userController.isValidToken(httpRequest, memberSearchRequest.getUserId());
		return memberSearch.searchMembers(memberSearchRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "members details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/namePrefix", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getNamePrefix(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam(required = false) Long userId,
			@RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(memberFamilyService.getNamePrefix(memberId, userId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "product fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "product not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllProduct", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllProduct(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam(required = false) Long userId,
			@RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return memberService.getAllProduct(userId, memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "opportunity fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "opportunity not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllOpportunity", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllOpportunity(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam(required = false) Long userId,
			@RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return memberService.getAllOpportunity(userId, memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Country phone code fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Country phone code not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllCountryphoneCode", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllCountryphoneCode(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam(required = false) Long userId, @RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return memberService.getAllPhoneCodeMaster(userId, memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Member token verified successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/member-token", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	// @EnableTokenAuthorisation
	public ResponseEntity<MemberInfoResponse> verifyMemberToken(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId) {
		// isValidToken(httpRequest, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(memberService.getMemberInfo(authorization, memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Member token verified successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/member-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<MemberInfoResponse> verifyMemberInfo(@RequestParam(required = false) Long userId,
			@RequestParam Long memberId) {

		return ResponseEntity.status(HttpStatus.OK).body(memberService.getMemberDetails(null, memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Member token verified successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/members", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewMembers> getMembers(
			@RequestBody GetMembersRequest getMembersRequest) {

		return ResponseEntity.status(HttpStatus.OK).body(memberService.getMembers(getMembersRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member insurance details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/createMemberInsuranceInfoForWeb", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> createMemberInsuranceInfoForWeb(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody AddInsuranceDetailsListRequest addInsuranceDetailsListRequest) {
		userController.isValidToken(httpRequest, addInsuranceDetailsListRequest.getUserId(),
				addInsuranceDetailsListRequest.getMemberId());
		return memberInsuranceSerivce.createMemberInsurance(addInsuranceDetailsListRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member personal details saved successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/createMemberPersonalInfoForWeb", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> createMemberPersonalInfoForWeb(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody AddMemberPersonalInfoRequest addMemberRequest) {
		userController.isValidToken(httpRequest, addMemberRequest.getUserId());
		return addMemberPersonalInfoCommand.excute(addMemberRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "insurance type fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "insurance type not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllInsuranceType", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllInsuranceType(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam(required = false) Long userId,
			@RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return memberInsuranceSerivce.getAllInsuranceType(userId, memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "insurance sub type fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "insurance sub type not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllInsuranceSubType", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllInsuranceSubType(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam(required = false) Long userId, @RequestParam(required = false) Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return memberInsuranceSerivce.getAllInsuranceSubType(userId, memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "member profile fetced fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "member profile not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getMemberProfile", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewProfileDetails> getMemberProfile(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam Long memberId) {
		userController.isValidToken(httpRequest, userId);
		return getProfileDetails.getMemberProfileInfo(memberId);
	}

	private void isValidToken(HttpServletRequest httpRequest, long requestMemberId) {
		try {
			Long memberId = Long.parseLong(httpRequest.getAttribute("memberId").toString());
			LOGGER.info("Requested Member Id : {}", memberId);
			LOGGER.info("Based on AccessToken {}", memberId);
			if (memberId != requestMemberId) {
				throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
			}
		} catch (Exception e) {
			throw new InvalidAuthTokenException(e.getMessage());
		}
	}

	private boolean isUser(HttpServletRequest httpRequest) {
		try {
			String type = httpRequest.getAttribute("type").toString();
			LOGGER.info("Token type:: {}", httpRequest.getAttribute("type"));
			if (type.equals("USER")) {
				return true;
			}
		} catch (Exception e) {
			throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
		}
		return false;
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "member personal info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "member personal info not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getMemberPersonalInfo", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewPersonalInfoDetails> getMemberPersonalInfo(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam(required = false) Long userId, @RequestParam Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return getProfileDetails.getMemberPersonalInfo(memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "member personal info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "member personal info not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/memberPersonalInfo", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getMemberPersonalInfo(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long memberId) {
		isValidToken(httpRequest, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(getProfileDetails.getMemberInfo(memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Member family details removed successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/familyMemberStatus", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> updateFamilyMemberStatus(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam(required = false) Long userId, @RequestParam Long memberId,
			@RequestParam Long familyMemberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return ResponseEntity.status(HttpStatus.OK)
				.body(memberFamilyService.updateFamilyMemberStatus(memberId, familyMemberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = VerifyEmailResponse.class, message = "Member personal details updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/editMemberProfile", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation(env = "WEB")
	public ResponseEntity<ViewMemberResponse> updateMemberProfileDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody UpdatePersonalDetailsRequest updatePersonalDetailsRequest) {
		userController.isValidToken(httpRequest, updatePersonalDetailsRequest.getUserId());
		return updateMemberPersonalInfoCommand.excute(updatePersonalDetailsRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "member emails fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "member emails info not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getmemberEmails", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation(env = "MOBILE")
	public ResponseEntity<ViewMemberResponse> getmemberEmails(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long memberId) {
		isValidToken(httpRequest, memberId);
		return getMemberEmailList.getMemberEmailList(memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Insurance fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Insurance not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getAllInsurance", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllInsuranceDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam(required = false) Long userId, @RequestParam Long memberId) {
		userController.isValidToken(httpRequest, userId, memberId);
		return memberInsuranceSerivce.getInsuranceDetails(memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Insurance fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Insurance not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/member-insurance", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> getAllInsuranceDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam Long memberId) {
		isValidToken(httpRequest, memberId);
		return memberInsuranceSerivce.getInsuranceDetailsByMember(memberId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "emails updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "member info not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/updateEmail", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation(env = "MOBILE")
	public ResponseEntity<VerifyEmailResponse> updateEmailToMember(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody UpdatePrimaryEmailRequest updatePrimaryEmailRequest) {
		isValidToken(httpRequest, updatePrimaryEmailRequest.getMemberId());
		return updatePrimaryEmailService.updateMemberEmail(updatePrimaryEmailRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "Email added successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/verifyUpdatedEmailPasscode", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> verifyUpdatedEmailPasscode(
			@Valid @RequestBody VerifyMemberPasscodeRequest verifyMemberPasscodeRequest) {

		return memberLoginService.verifyUpdatedEmailPasscode(verifyMemberPasscodeRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member insurance details updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/editMemberInsuranceInfoForWeb", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> editMemberInsuranceInfoForWeb(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody EditInsuranceRequest editInsuranceRequest) {
		userController.isValidToken(httpRequest, editInsuranceRequest.getUserId(), editInsuranceRequest.getMemberId());
		return memberInsuranceSerivce.editMemberInsurance(editInsuranceRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "country code fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "country code not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getCountryCode", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<GetCountryCodeInfo> getCountryCode(@RequestParam Long countryCodeId,
			@RequestParam Long organizationId) {
		return memberService.getCountryCodeId(countryCodeId, organizationId);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "Passcode sent successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/memberForgotPassword", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> memberForgotPassword(
			@Valid @RequestBody MemberPasscodeRequest memberPasscodeRequest) {
		return memberLoginService.sendPasscodeForForgotPassword(memberPasscodeRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "country code fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "country code not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/member-chat-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<GetMemberChatInfo> getMemberInfo(@RequestParam Long memberId) {
		return ResponseEntity.status(HttpStatus.OK).body(memberService.getMemberChatInfo(memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "Fetched app update info successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/app-update-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<MemberAppVesrionResponse> getAppVersionInfo(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@RequestParam long memberId) {
		isValidToken(httpRequest, memberId);
		return ResponseEntity.status(HttpStatus.OK).body(organizationService.getAppVesrionResponse(memberId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member product details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/checkMemberProduct", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> checkMemberProductType(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody CheckProductTypeRequest checkProductTypeRequest) {
		userController.isValidToken(httpRequest, checkProductTypeRequest.getUserId(),
				checkProductTypeRequest.getMemberId());
		return ResponseEntity.status(HttpStatus.OK).body(getProfileDetails.checkProductType(checkProductTypeRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Dashboard Analytical Data fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "Dashboard Analytical Data not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/getdashboardAnalytical", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public DashboardResponseView getdashboardAnalyticalDetails(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {
		userController.isValidToken(httpRequest, userId, null);
		return dashboardAnalyticalService.dashboardAnalyticalData();
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member locked successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/lockUnlockMember", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewMemberResponse> lockUnlockMember(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody LockMemberRequest lockMemberRequest) {
		userController.isValidToken(httpRequest, lockMemberRequest.getUserId());
		return ResponseEntity.status(HttpStatus.OK).body(logoutService.lockMember(lockMemberRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member product details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	// @GetMapping(value = "/getSfConnection", produces =
	// MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> getSfConnection() {

		return ResponseEntity.status(HttpStatus.OK).body(memberSfdcService.getSFConnection());
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member product details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/sfdc-queue", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getSfdcQueueInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {
		userController.isValidToken(httpRequest, userId);
		return ResponseEntity.status(HttpStatus.OK).body(memberSfdcService.getSfdcQueueResponse(userId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member product details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/sfdc-queue-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getSfdcQueueDetails(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {
		userController.isValidToken(httpRequest, userId);
		return ResponseEntity.status(HttpStatus.OK).body(memberSfdcService.getSfdcQueueInfo(userId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "member product details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/sfdc-failed-queue", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getSfdcFailedQueueInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {
		userController.isValidToken(httpRequest, userId);
		return ResponseEntity.status(HttpStatus.OK).body(memberSfdcService.getSfdcFailedQueueInfo(userId));
	}

	/*
	 * @ApiResponses(value = {
	 * 
	 * @ApiResponse(code = HttpServletResponse.SC_OK, response =
	 * LoginResponse.class, message = "failed emails fetched successfully"),
	 * 
	 * @ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response =
	 * ErrorResponse.class, message = "Invalid parameters") })
	 * 
	 * @GetMapping(value = "/failedEmailTrigger", produces =
	 * MediaType.APPLICATION_JSON_UTF8_VALUE)
	 * 
	 * @EnableTokenAuthorisation public ResponseEntity<ViewResponse>
	 * failedEmailTrigger(@RequestHeader("authorization") String authorization,
	 * HttpServletRequest httpRequest, @RequestParam Long userId) {
	 * userController.isValidToken(httpRequest, userId); return
	 * failedEmailTriggerService.saveFailedEmails(); }
	 */

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "Member status successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/member-status", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> updateMemberStatus(@RequestParam Long memberId,
			@RequestParam(required = false) Long userId) {
		return ResponseEntity.status(HttpStatus.OK).body(memberService.updateMemberStatus(memberId, userId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "Member count successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/member-employer-count", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> getMemberCountByEmployer(
			@RequestBody GetMemberCountRequest getMemberCountRequest) {
		return ResponseEntity.status(HttpStatus.OK).body(memberService.getMemberCount(getMemberCountRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "Member token generated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/member-access-token", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<MemberTokenResponse> getMemberToken(@RequestHeader("refreshToken") String refreshToken,
			HttpServletRequest httpRequest,
			@RequestParam Long memberId) {
		return ResponseEntity.status(HttpStatus.OK).body(memberService.getMemberToken(memberId, refreshToken));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "opportunities fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/get-opportunities", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getOpportunities(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam String opportunityName) {
		userController.isValidToken(httpRequest, userId);
		return ResponseEntity.status(HttpStatus.OK).body(memberService.getOpportunities(opportunityName));
	}
}
