package com.billdog.user.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.request.GetRoleScreens;
import com.billdog.user.service.NavigationService;
import com.billdog.user.view.ViewResponse;

@Service
public class GetRoleScreensCommand implements Command<GetRoleScreens, ResponseEntity<ViewResponse>> {


	@Autowired
	NavigationService navigationService;

	@Override
	public ResponseEntity<ViewResponse> excute(GetRoleScreens getRoleScreens) {

		return ResponseEntity.status(HttpStatus.OK).body(navigationService.getRoleScreens(getRoleScreens));

	}
}
