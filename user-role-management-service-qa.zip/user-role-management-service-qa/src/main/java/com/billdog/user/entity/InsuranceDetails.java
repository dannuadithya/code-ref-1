package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "INSURANCE_DETAILS")
@Table(name = "insurance_details", indexes = { @Index(name = "id_index", columnList = "ID", unique = true) })
public class InsuranceDetails extends BaseEntity {

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "INSURANCE_TYPE_ID")
	private InsuranceTypes insuranceTypeId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "INSURANCE_SUB_TYPE_ID")
	private InsuranceSubTypeMaster insuranceSubTypeId;

	@Audited
	@Column(name = "CARRIER_ID")
	private long carrierId;

	@Audited
	@Column(name = "GROUP_ID")
	private String groupId;

	@Audited
	@Column(name = "PRODUCT_NAME")
	private String productName;

	@Audited
	@Column(name = "PROVIDER_CONTACT_NUMBER")
	private String providerContactNumber;

	@Audited
	@Column(name = "CUSTOMER_SERVICE_CONTACT_NUMBER")
	private String customerServiceContactNumber;

	@ManyToOne
	@JoinColumn(name = "MEMBER_ID")
	private Member memberId;

	@Audited
	@Column(name = "MEMBER_INSURANCE_ID")
	private String memberInsuranceId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "USER_ID")
	private SystemUsers userId;

	@Audited
	@Column(name = "audit_id")
	private String auditId;

	public String getMemberInsuranceId() {
		return memberInsuranceId;
	}

	public void setMemberInsuranceId(String memberInsuranceId) {
		this.memberInsuranceId = memberInsuranceId;
	}

	public InsuranceTypes getInsuranceTypeId() {
		return insuranceTypeId;
	}

	public void setInsuranceTypeId(InsuranceTypes insuranceTypeId) {
		this.insuranceTypeId = insuranceTypeId;
	}

	public InsuranceSubTypeMaster getInsuranceSubTypeId() {
		return insuranceSubTypeId;
	}

	public void setInsuranceSubTypeId(InsuranceSubTypeMaster insuranceSubTypeId) {
		this.insuranceSubTypeId = insuranceSubTypeId;
	}

	public long getCarrierId() {
		return carrierId;
	}

	public void setCarrierId(long carrierId) {
		this.carrierId = carrierId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProviderContactNumber() {
		return providerContactNumber;
	}

	public void setProviderContactNumber(String providerContactNumber) {
		this.providerContactNumber = providerContactNumber;
	}

	public String getCustomerServiceContactNumber() {
		return customerServiceContactNumber;
	}

	public void setCustomerServiceContactNumber(String customerServiceContactNumber) {
		this.customerServiceContactNumber = customerServiceContactNumber;
	}

	public Member getMemberId() {
		return memberId;
	}

	public void setMemberId(Member memberId) {
		this.memberId = memberId;
	}

	public SystemUsers getUserId() {
		return userId;
	}

	public void setUserId(SystemUsers userId) {
		this.userId = userId;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

}
