package com.billdog.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.ApplicationVersion;
import com.billdog.user.entity.Organization;

@Repository
public interface ApplicationVersionRepository extends JpaRepository<ApplicationVersion, Long> {

	ApplicationVersion findByOrganizationId(Organization organizationId);

}
