package com.billdog.user.request;

import java.util.List;

import javax.validation.constraints.NotNull;

public class AddFamilyDetailsListRequest {

	private List<FamilyMemberRequest> familyDetailsList;

	@NotNull(message = "Member id must not be null")
	private long memberId;

	@NotNull(message = "User id must not be null")
	private long userId;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public List<FamilyMemberRequest> getFamilyDetailsList() {
		return familyDetailsList;
	}

	public void setFamilyDetailsList(List<FamilyMemberRequest> familyDetailsList) {
		this.familyDetailsList = familyDetailsList;
	}

}
