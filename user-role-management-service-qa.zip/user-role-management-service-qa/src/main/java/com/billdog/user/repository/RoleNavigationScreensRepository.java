package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.Organization;
import com.billdog.user.entity.RoleNavigationScreens;
import com.billdog.user.entity.Roles;

@Repository
public interface RoleNavigationScreensRepository extends JpaRepository<RoleNavigationScreens,Long> {


	@Query(value = "select nsrp.* from navigation_screens_role_mapping nsrp\n"
			+ "join navigation_screens ns on ns.id=nsrp.navigation_screens_access_id\n"
			+ "where nsrp.role_id=?1 and nsrp.organization_id=?2 and ns.type=?3 and ns.status='ACTIVE' order by ns.display_order", nativeQuery = true)
	List<RoleNavigationScreens> findByRoleIdWithOrganizationId(Roles role, Organization organizationId, String type);

	Optional<RoleNavigationScreens> findByIdAndRoleId(long id, Roles roles);

}