package com.billdog.user.request;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class SearchUsersRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String name;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String email;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String mobileNumber;
	private long roleId;
	private long userId;
	private int pageNumber;
	private int pageLimit;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String userType;

	public int getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(int pageNumber) {
		this.pageNumber = pageNumber;
	}

	public int getPageLimit() {
		return pageLimit;
	}

	public void setPageLimit(int pageLimit) {
		this.pageLimit = pageLimit;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public long getRoleId() {
		return roleId;
	}

	public void setRoleId(long roleId) {
		this.roleId = roleId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

}
