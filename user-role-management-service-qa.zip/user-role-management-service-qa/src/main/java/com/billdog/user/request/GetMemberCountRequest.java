package com.billdog.user.request;

import java.util.List;

public class GetMemberCountRequest {

	private List<Long> employerIds;

	public List<Long> getEmployerIds() {
		return employerIds;
	}

	public void setEmployerIds(List<Long> employerIds) {
		this.employerIds = employerIds;
	}

}
