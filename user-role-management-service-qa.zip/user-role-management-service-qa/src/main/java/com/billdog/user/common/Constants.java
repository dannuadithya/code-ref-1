package com.billdog.user.common;

public class Constants {

	// scheduler jobs
	public static final String MEMBER_SFDC_JOB = "Member sfdc job";
	public static final String MEMBER_EMAIL_JOB = "Member email job";

	public static final String FAILED = "FAILED";

	public static final String SUCCESS = "SUCCESS";

	public static final String FIRST_NAME = "Please enter first name!";

	public static final String LAST_NAME = "Please enter first name!";

	public static final String MIDDLE_NAME = "Please enter middle name!";

	public static final String ORGANIZATION_NOT_FOUND = "Something went wrong. Please try again";
	public static final String SCREESN_NOT_FOUND = "Screen not found";

	// public static final String NAVIGATION_NOT_FOUND_WITH_ID = "No navigation
	// screen exists with id:: ";

	public static final String NAVIGATION_SCREEN_CREATED = "Navigation screen created successfully..!";

	public static final String ROLE_CREATED = "Role created successfully..!";

	public static final String USER_CREATED = "User created successfully";

	public static final String USER_DETAILS_FETCHED = "User details fetched successfully";
	public static final String NO_RESULTS_FOUND = "No Results Found";

	public static final String USER_UPDATED = "User updated successfully";

	public static final String PASSCODE_VERIFIED_SUCCESSFULLY = "Passcode verified successfully";

	public static final String PASSWORD_UPDATED = "Password updated successfully";

	public static final String NAVIGATION_SCREEN_ACCESS_UPDATED = "Privileges changed successfully for ";

	public static final String INVALID = "Invalid";

	public static final String SENT_PASSCODE = "Please check your email for passcode.!!";
	public static final String SENT_PASSCODE_EMAIL = "Please check your email for the passcode. If you do not see it, please check your spam folder.";

	public static final String PASSWORD_CREATED = "Password created successfully";

	public static final String PASSWORD_VERIFIED_SUCCESSFULLY = "Password verified successfully";

	public static final String USER_EXIST = "User exists in the system";
	public static final String EMAIL_EXIST = "This email already exists. Please try logging in";
	public static final String PASSCODE_SENT = "Passcode sent successfully";

	public static final String DIRECT_MEMBER = "Direct to Consumer";

	public static final String MEMBER_CREATED_SUCESSFULLY = "Member created sucessfully";

	public static final String MEMBER_PERSONAL_DETAILS_UPDATED = "Your member profile has been updated.";
	public static final String MEMBER_PERSONAL_DETAILS_CREATED = "Your member profile has been created.";

	public static final String ACTIVE = "ACTIVE";

	public static final String STATES_FETCHED = "State fetched successfully";

	public static final String COUNTRIES_FETCHED = "Countries fetched successfully";

	public static final String GENDER_FETCHED = "Gender fetched successfully";

	public static final String MEMBER_FAMILY_DETAILS = "Family member has been added.";

	public static final String FAMILY_MEMBER_INFO_UPDATED = "Family member has been updated.";

	public static final String FAMILY_MEMBER_REMOVED = "Family member details removed successfully";

	public static final String MEMBER_PERSONAL_INFO = "Member personal info saved successfully";

	public static final String PRODUCT_FETCHED = "Product fetched successfully";

	public static final String OPPORTUNITY_FETCHED = "Opportunity fetched successfully";

	public static final String PHONE_CODE_FETCHED = "country Phone number code fetched successfully";
	public static final String MEMBER_TOKEN_VERIFIED = "Member token verified successfully";

	public static final String USER_TOKEN_VERIFIED = "User token verified successfully";

	public static final String MEMBER_INSURANCE = "Member insurance added successfully";

	public static final String INSURANCE_FETCHED = "Insurance type fetched successfully";

	public static final String INSURANCES_SUB_TYPE_FETCHED = "Insurance SUB type fetched successfully";

	public static final String CARRIER_TYPE_FETCHED = "Carrier type fetched successfully";

	public static final String MEMBER_PROFILE = "Member profile fetched successfully";

	public static final String MEMBER_PERSONAL = "Member personal info fetched successfully";

	public static final String MEMBER_PROFILE_UPDATED = "Member personal details updated successfully";
	public static final String WELCOME_MEMBER = "Welcome Email sent successfully";

	public static final String MEMBER_ID = "100000000";

	public static final String EMAIL_SCREEN_MESSAGE = "This is your User ID and will be used for all email communications with Bill Dog";
	public static final String INSURANCE_DETAILS = "Insurance Details fetched successfully";
	public static final String EMAIL_ADDED_SUCCESSFULLY = "Email Added successfully";

	public static final String SUCCESS_RESPONSE_FROM_EMAIL_SERVICE = "Returning success response from email service";

	public static final String USER = "userId";

	public static final String MEMBER = "memberId";

	public static final String MEMBERS_LIST_FETCHED = "Members list fetched successfully";

	public static final String MEMBER_INSURANCE_UPDATED = "Insurance details updated successfully";

	public static final int DESCRIPTION_MIN_LENGTH = 25;
	public static final int DESCRIPTION_MAX_LENGTH = 500;
	public static final int PASSWORD_MIN_LENGTH = 10;
	public static final int PASSWORD_MAX_LENGTH = 16;
	public static final int IMAGE_NAME_MAX_LENGTH = 30;
	public static final int IMAGE_NAME_MIN_LENGTH = 1;

	public static final String MEMBER_FAMILY_ADDED = "Family member has been added.";

	public static final String DASHBOARD = "Dashboard";

	public static final String MEMBER_LOGOUT = "Member logout Successfully";

	public static final String USER_LOGOUT = "User logout Successfully";

	public static final String USER_TOKEN_EXPIRED_TIME_UPDATED = "User token expired time updated successfully";

	public static final String MEMBER_TOKEN_EXPIRED_TIME_UPDATED = "Member token expired time updated successfully";

	public static final String PRODUCT_MESSAGE_MOBILE = "You currently have family members attached to your plan. Changing Product Type will result in the removal of your family members. Are you sure you want to continue?";

	public static final String PRODUCT_MESSAGE_WEB = "There are currently family members attached to the member. Would you like to remove the family members?";

	public static final String FAMILY_TO_MARRIED = "You currently have Children attached to your plan. Changing Product Type will result in the removal of your children. Are you sure you want to continue?";

	public static final String MARRIED_TO_SINGLE = "You currently have family members attached to your plan. Changing Product Type will result in the removal of your family members. Are you sure you want to continue?";

	public static final String TRUE = "TRUE";

	public static final String FAMILY_TO_SINGLE = "You currently have family members attached to your plan. Changing Product Type will result in the removal of your family members. Are you sure you want to continue?";

	public static final String FALSE = "FALSE";

	public static final String DASHBOARD_ANALYTICS = "Dashboard analtics fetched successfully";

	public static final long HUNDRED = 100;

	public static final String USER_PASSWORD_UPDATED = "Your password has been changed.";

	public static final String MEMBER_LOCKED = "Member locked successfully";

	public static final String MEMBER_UNLOCK = "Member unlocked successfully";

	public static final String SFDC_FAILED_QUEUE_FETCHED = "Sfdc failed queue list fetched successfully";
	public static final String SFDC_QUEUE_FETCHED = "Sfdc queue details fetched successfully";
	public static final String SFDC_QUEUE_LIST_FETCHED = "Sfdc queue list fetched successfully";

	public static final String INSURANCE_EXCEPTION_MESSAGE = "You have Exceeded maximum limit for adding a new Insurance";

	public static final String COPYRIGHT = "Copyright @<Year>";

	public static final String INDIRECT_MEMBER_POPUP = "Do you want to update your profile?";

	public static final Object SPECIFIER = "%s";

	public static final String MEMBERS_DATA_UPLOADED = "Members data uploaded successfully";

	public static final String EMPLOYER_UPDATED_SUCESSFULLY = "Employer updated sucessfully";

	public static final String MEMBER_UPDATED = "Member updated sucessfully";

	public static final String EXTERNAL_ROLE_CREATED = "External Role created successfully";

	public static final String INTERNAL_ROLE_CREATED = "Internal Role created successfully";

	public static final String USER_TYPE_FETCHED = "User types fetched successfully";
	public static final String EXTERNAL_USER = "External User created successfully";
	public static final String INTERNAL_USER = "Internal User created successfully";
	public static final String EMAIL_JOB = "Email job";
	public static final String MEMBER_STATUS_UPDATED = "Member status updated";
	public static final String MEMBER_TOKEN = "Member token generated successfully";
	public static final String EXTERNAL = "External";
	public static final String UPDATED = "Updated";
	public static final String CREATED = "Created";
	public static final String DELETED = "Deleted";
	public static final String OPPORTUNITY_NOT_FOUND = "Opportunity not found";
	public static final String MEMBER_AUDIT_FETCHED = "Member audit fetched successfully";
	public static final String AUDIT_TIME_PERIOD_LIST_FETCHED = "Audit time period info fetch successfully";
	public static final String AUDIT_SUB_MODULE_LIST_FETCHED = "Audit sub modules info fetch successfully";
	public static final String AUDIT_MODULE_LIST_FETCHED = "Audit modules fetch successfully";
	public static final String AUDIT_ACTION_LIST_FETCHED = "Audit Action info fetch successfully";
	public static final String USERS_INFO_FETCHED = "Users info fetch successfully";
	public static final String ROLE_AUDIT_FETCHED = "Role audit fetched successfuly";

	public static final String CENSUS_FAILED_RECORDS = "Census upload failed members fetched successfully";
	public static final String NO_CHANGE = "No records were modified in this transaction";
	public static final int MESSAGE_SUB_MIN_LENGTH = 4;
	public static final int MESSAGE_SUB_MAX_LENGTH = 44;
	public static final int MESSAGE_DESCRIPTION_MIN_LENGTH = 4;
	public static final int MESSAGE_DESCRIPTION_MAX_LENGTH = 150;
	public static final String MODIFIED = "Modified";
	public static final String EXTERNAL_USER_UPDATE = "External user updated successfully";
	public static final String COUNTRY_CODE = "+1";

	public static final CharSequence AUD = "Aud_";
	public static final String ANDROID = "Android";
}
