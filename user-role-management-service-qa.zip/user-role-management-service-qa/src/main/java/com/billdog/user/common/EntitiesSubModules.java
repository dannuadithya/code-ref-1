package com.billdog.user.common;

public enum EntitiesSubModules {
	Broker_Company, Individual_Provider, Individual_Broker, Employer, Company_Provider, Insurance_Company

}
