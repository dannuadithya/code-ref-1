package com.billdog.user.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.user.authorization.EnableTokenAuthorisation;
import com.billdog.user.command.CreateNavigationScreenCommand;
import com.billdog.user.command.CreateRoleCommand;
import com.billdog.user.command.CreateUserCommand;
import com.billdog.user.command.EditUserDetailsCommand;
import com.billdog.user.command.ExternalSendPasscodeCommand;
import com.billdog.user.command.GetRoleScreensCommand;
import com.billdog.user.command.GetRolesCommand;
import com.billdog.user.command.SearchUsersCommand;
import com.billdog.user.command.SendPasscodeCommand;
import com.billdog.user.command.SignInCommand;
import com.billdog.user.command.UpdateNavigationScreenAccessCommand;
import com.billdog.user.command.UpdatePasswordCommand;
import com.billdog.user.command.VerifyEmailCommand;
import com.billdog.user.command.VerifyPasscodeCommand;
import com.billdog.user.command.ViewUserDetailsByIdCommand;
import com.billdog.user.common.Constants;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusType;
import com.billdog.user.common.UserType;
import com.billdog.user.exception.ErrorResponse;
import com.billdog.user.exception.InvalidAuthTokenException;
import com.billdog.user.request.CreateNavigationScreen;
import com.billdog.user.request.CreateRoleRequest;
import com.billdog.user.request.CreateUserRequest;
import com.billdog.user.request.EditUserDetailsRequest;
import com.billdog.user.request.ExternalUserDetailsRequest;
import com.billdog.user.request.ExternalUserUpdateRequest;
import com.billdog.user.request.GetRoleScreens;
import com.billdog.user.request.GetUserRequest;
import com.billdog.user.request.GetUsersRequest;
import com.billdog.user.request.SearchDirectMember;
import com.billdog.user.request.SearchUsersRequest;
import com.billdog.user.request.UpdateExternalUser;
import com.billdog.user.request.UpdateNavigationScreen;
import com.billdog.user.request.UpdatePasswordRequest;
import com.billdog.user.request.UpdateUserPasswordRequest;
import com.billdog.user.request.UserSignInRequest;
import com.billdog.user.request.VerifyEmailRequest;
import com.billdog.user.request.VerifyExternalUser;
import com.billdog.user.request.VerifyPasscodeRequest;
import com.billdog.user.response.CreateUserResponse;
import com.billdog.user.response.LoginResponse;
import com.billdog.user.response.UpdateUserDetailsResponse;
import com.billdog.user.service.CreateRoleService;
import com.billdog.user.service.CreateUserService;
import com.billdog.user.service.GetMemberService;
import com.billdog.user.service.GetRoleService;
import com.billdog.user.service.GetUserService;
import com.billdog.user.service.LoginService;
import com.billdog.user.service.LogoutService;
import com.billdog.user.service.MemberService;
import com.billdog.user.view.GetUsers;
import com.billdog.user.view.MemberInfoResponse;
import com.billdog.user.view.MemberResponse;
import com.billdog.user.view.UserPasswordResponse;
import com.billdog.user.view.ViewMemberResponse;
import com.billdog.user.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.models.Response;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UserController {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(UserController.class);

	@Autowired
	CreateUserCommand createUserCommand;

	@Autowired
	EditUserDetailsCommand editUserDetailsCommand;

	@Autowired
	CreateNavigationScreenCommand createNavigationScreenCommand;

	@Autowired
	CreateRoleCommand createRoleCommand;

	@Autowired
	GetRolesCommand getRolesCommand;

	@Autowired
	GetRoleScreensCommand getRoleScreensCommand;

	@Autowired
	SearchUsersCommand searchUsersCommand;

	@Autowired
	ViewUserDetailsByIdCommand viewUserDetailsByIdCommand;

	@Autowired
	VerifyPasscodeCommand verifyPasscodeCommand;

	@Autowired
	UpdatePasswordCommand updatePasswordCommand;

	@Autowired
	UpdateNavigationScreenAccessCommand updateNavigationScreenAccessCommand;

	@Autowired
	SignInCommand signInCommand;

	@Autowired
	VerifyEmailCommand verifyEmailCommand;

	@Autowired
	SendPasscodeCommand sendPasscodeCommand;

	@Autowired
	CreateUserService createUserService;

	@Autowired
	GetMemberService getMemberService;

	@Autowired
	MemberService memberService;

	@Autowired
	CreateRoleService createRoleService;

	@Autowired
	LogoutService logoutService;

	@Autowired
	LoginService loginService;
	@Autowired
	GetRoleService getRoleService;

	@Autowired
	GetUserService getUserService;

	@Autowired
	ExternalSendPasscodeCommand externalSendPasscodeCommand;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Role created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/roles", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> createRole(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody CreateRoleRequest createRole) {
		isValidToken(httpRequest, createRole.getUserId());
		return createRoleCommand.excute(createRole);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Fetch all roles by userId"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/{userId}/roles", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getRoles(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @PathVariable long userId,
			@RequestParam(required = false) UserType roleType) {
		roleType = roleType != null ? roleType : UserType.External;
		isValidToken(httpRequest, userId);
		return ResponseEntity.status(HttpStatus.OK).body(getRoleService.getRoles(userId, roleType));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Fetch all navigation screens by roleId"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/navigationscreens", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getRoleScreens(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam long userId, @RequestParam long roleId) {
		isValidToken(httpRequest, userId);
		GetRoleScreens getRoleScreens = new GetRoleScreens();
		getRoleScreens.setRoleId(roleId);
		getRoleScreens.setUserId(userId);
		return getRoleScreensCommand.excute(getRoleScreens);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Role navigation screen access updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/navigationscreens", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> updateRoleScreenAccess(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody UpdateNavigationScreen request) {
		isValidToken(httpRequest, request.getUserId());
		return updateNavigationScreenAccessCommand.excute(request);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "user created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/users", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<CreateUserResponse> createUser(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody CreateUserRequest createUserRequest) {
		isValidToken(httpRequest, createUserRequest.getUserId());
		return createUserCommand.excute(createUserRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = UpdateUserDetailsResponse.class, message = "user updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/users", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<UpdateUserDetailsResponse> editUserDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody EditUserDetailsRequest editUserDetailsRequest) {
		isValidToken(httpRequest, editUserDetailsRequest.getUserId());
		return editUserDetailsCommand.excute(editUserDetailsRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "user created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/navigationScreen", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> createUserNavigation(
			@Valid @RequestBody CreateNavigationScreen createNavigationScreen) {
		return createNavigationScreenCommand.excute(createNavigationScreen);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "user details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/searchUsers", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> searchUsers(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestBody SearchUsersRequest searchUsersRequest) {
		isValidToken(httpRequest, searchUsersRequest.getUserId());
		return searchUsersCommand.excute(searchUsersRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "User details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	// @GetMapping(value = "/users", produces =
	// MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getUser(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam long id, @RequestParam long userId) {
		isValidToken(httpRequest, userId);
		GetUserRequest getUserRequest = new GetUserRequest();
		getUserRequest.setId(id);
		getUserRequest.setUserId(userId);
		return viewUserDetailsByIdCommand.excute(getUserRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "passcode verified successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/verifyPasscode", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> verifyPasscode(
			@Valid @RequestBody VerifyPasscodeRequest verifyPasscodeRequest) {
		return verifyPasscodeCommand.excute(verifyPasscodeRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "passcode verified successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/verifyPasscodeExternalUser", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> verifyPasscodeExternalUser(
			@Valid @RequestBody VerifyPasscodeRequest verifyPasscodeRequest) {
		return ResponseEntity.status(HttpStatus.OK)
				.body(loginService.verifyExternalUserPasscode(verifyPasscodeRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "password updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/updatePassword", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> createPassword(
			@Valid @RequestBody UpdatePasswordRequest updatePasswordRequest) {
		return updatePasswordCommand.excute(updatePasswordRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/verifyEmail", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<LoginResponse> verifyEmail(@RequestHeader HttpHeaders headers,
			@Valid @RequestBody VerifyEmailRequest emailRequest) {

		return ResponseEntity.status(HttpStatus.OK).body(loginService.verifyEmail(headers.getOrigin(), emailRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user signed in successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/signInUser", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> signInUser(@Valid @RequestBody UserSignInRequest signInRequest) {

		return signInCommand.excute(signInRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user signed in successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/passcode", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> sendPasscode(@Valid @RequestBody VerifyEmailRequest email) {

		return sendPasscodeCommand.excute(email);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user signed in successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/externalPasscode", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> externalSendPasscode(@Valid @RequestBody VerifyEmailRequest email) {

		return externalSendPasscodeCommand.excute(email);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "User details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/status", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getUserStatus(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam long userId, @RequestParam StatusType type) {
		isValidToken(httpRequest, userId);
		return ResponseEntity.status(HttpStatus.OK).body(createUserService.getUserStatus(userId, type));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Member details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "User not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/deirectMember", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getDirectMembers(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestBody SearchDirectMember searchDirectMember) {
		isValidToken(httpRequest, searchDirectMember.getUserId());
		return ResponseEntity.status(HttpStatus.OK).body(getMemberService.getDirectMembers(searchDirectMember));
	}

	public void isValidToken(HttpServletRequest httpRequest, Long requestUserId, Long requestmemberId) {
		requestUserId = requestUserId == null ? 0l : requestUserId;
		requestmemberId = requestmemberId == null ? 0l : requestmemberId;
		try {
			long userId = 0;
			if (httpRequest.getAttribute(Constants.USER) != null) {
				userId = Long.parseLong(httpRequest.getAttribute(Constants.USER).toString());
				String email = httpRequest.getAttribute("email").toString();
				LOGGER.info("Requested User Id :{}", userId);
				LOGGER.info("Based on AccessToken userId {}, email: {}", userId, email);
				if (userId != requestUserId) {
					throw new InvalidAuthTokenException(ExceptionalMessages.USER_SESSION_EXPIRED);
				}
			} else if (httpRequest.getAttribute(Constants.MEMBER) != null) {
				Long memberId = Long.parseLong(httpRequest.getAttribute(Constants.MEMBER).toString());
				LOGGER.info("Requested Member Id : {}", memberId);
				LOGGER.info("Based on AccessToken {}", memberId);
				if (!memberId.equals(requestmemberId)) {
					throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
				}
			} else {
				throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
			}

		} catch (Exception e) {
			if (e.getMessage().equalsIgnoreCase(ExceptionalMessages.USER_SESSION_EXPIRED)) {
				throw new InvalidAuthTokenException(ExceptionalMessages.USER_SESSION_EXPIRED);
			} else {
				throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
			}

		}
	}

	public void isValidToken(HttpServletRequest httpRequest, long requestUserId) {
		long userId = 0;
		try {
			userId = Long.parseLong(httpRequest.getAttribute(Constants.USER).toString());
			String email = httpRequest.getAttribute("email").toString();
			LOGGER.info("Requested User Id : {}", userId);
			LOGGER.info("Based on AccessToken userId {}, email: {}", userId, email);
			if (userId != requestUserId) {
				throw new InvalidAuthTokenException(ExceptionalMessages.USER_SESSION_EXPIRED);
			}
		} catch (Exception e) {
			throw new InvalidAuthTokenException(ExceptionalMessages.USER_SESSION_EXPIRED);
		}
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "members details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/user-token", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<MemberInfoResponse> verifyUserToken(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {
		return ResponseEntity.status(HttpStatus.OK).body(memberService.verifyUserToken(authorization, userId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewMemberResponse.class, message = "Password updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "user not found with id"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/userPassword", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<UserPasswordResponse> updatePassword(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody UpdateUserPasswordRequest passwordRequest) {
		isValidToken(httpRequest, passwordRequest.getUserId());
		return ResponseEntity.status(HttpStatus.OK).body(createRoleService.updatePassword(passwordRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "User logout Successfully"),
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ErrorResponse.class, message = "User not found"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/user-logout", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<MemberResponse> userLogout(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {
		isValidToken(httpRequest, userId);
		return ResponseEntity.status(HttpStatus.OK).body(logoutService.userLogout(authorization, userId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user signed in successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/signInUserTo", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> signInUserTo(@Valid @RequestBody UserSignInRequest signInRequest) {

		return signInCommand.excute(signInRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "user details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/user-types", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> userTypes(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {
		return ResponseEntity.status(HttpStatus.OK).body(createRoleService.userType(userId));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = UpdateUserDetailsResponse.class, message = "External user updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/external-users", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<UpdateUserDetailsResponse> editExternalUserDetails(
			@RequestHeader("authorization") String authorization, HttpServletRequest httpRequest,
			@Valid @RequestBody UpdateExternalUser updateExternalUser) {
		isValidToken(httpRequest, updateExternalUser.getUserId());
		return createUserService.updateExternalUserDetails(updateExternalUser);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "user created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/verify-external-user", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<CreateUserResponse> verifyExternalUser(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody VerifyExternalUser verifyExternalUser) {
		isValidToken(httpRequest, verifyExternalUser.getUserId());
		return createUserService.verifyExternalEmail(verifyExternalUser);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "user created successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/create-external-user", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<CreateUserResponse> createExternalUser(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @Valid @RequestBody ExternalUserDetailsRequest externalUserDetailsRequest) {
		isValidToken(httpRequest, externalUserDetailsRequest.getUserId());
		return createUserService.createExternalUser(externalUserDetailsRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user details fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/verifyExternalEmail", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<LoginResponse> verifyExternalUserEmail(@RequestHeader HttpHeaders headers,
			@Valid @RequestBody VerifyEmailRequest emailRequest) {

		return ResponseEntity.status(HttpStatus.OK)
				.body(loginService.verifyExternalUserEmail(emailRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user signed in successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/eLogin", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> eLogin(@Valid @RequestBody UserSignInRequest signInRequest) {
		return loginService.elogin(signInRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user signed in successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/users-info", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<GetUsers> getUsersInfo(@RequestBody GetUsersRequest usersRequest) {
		return getUserService.getUsersInfo(usersRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = Response.class, message = "user updated successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PutMapping(value = "/updateExternalUser", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<CreateUserResponse> updateExternalUserEmail(
			@Valid @RequestBody ExternalUserUpdateRequest externalUserUpdateRequest) {
		return createUserService.updateExternalUserEmail(externalUserUpdateRequest);
	}

}
