package com.billdog.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.Organization;
import com.billdog.user.entity.StatusMaster;


@Repository
public interface StatusMasterRepository extends JpaRepository<StatusMaster, Long> {

	List<StatusMaster> findByStatusTypeAndOrganizationIdAndActive(String tyype, Organization organizationId,
			Boolean active);

}
