package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "STATE_MASTER")
@Table(name = "state_master", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "status_org_index", columnList = "STATUS,ORGANIZATION_ID", unique = false),
		@Index(name = "status_country_index", columnList = "STATUS,COUNTRY_ID", unique = false),
		@Index(name = "status_index", columnList = "STATUS", unique = false) })
public class StateMaster extends BaseEntity {

	@Column(name = "STATE_NAME")
	private String name;

	@Column(name = "STATE_CODE")
	private String code;

	@Column(name = "STATUS")
	private String status;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@ManyToOne
	@JoinColumn(name = "COUNTRY_ID")
	private CountryMaster countryId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public CountryMaster getCountryId() {
		return countryId;
	}

	public void setCountryId(CountryMaster countryId) {
		this.countryId = countryId;
	}


}
