package com.billdog.user.request;

import javax.validation.constraints.NotBlank;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class CreateRoleRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Role name should be Minimum 4 & Maximum 30 Characters")
	private String name;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String roleType;

	private long userId;

	public String getRoleType() {
		return roleType;
	}

	public void setRoleType(String roleType) {
		this.roleType = roleType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

}
