package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.common.UserType;
import com.billdog.user.entity.Roles;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.repository.NamePrefixMasterRepository;
import com.billdog.user.repository.NavigationScreenRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.RoleNavigationScreensRepository;
import com.billdog.user.repository.RolesRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.view.ViewResponse;
import com.billdog.user.view.ViewRole;

@Service
public class GetRoleService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CreateRoleService.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	NamePrefixMasterRepository namePrefixMasterRepository;

	@Autowired
	SystemUsersrepository systemUsersrepository;

	@Autowired
	RoleNavigationScreensRepository roleNavigationScreensRepository;

	@Autowired
	RolesRepository rolesRepository;

	@Autowired
	NavigationScreenRepository navigationScreenRepository;

	@Autowired
	LoginService loginService;

	/*
	 * This method will take userId as input and provide all all roles present in an
	 * organization.
	 */
	public ViewResponse getRoles(Long userId, UserType roleType) {
		LOGGER.info("Fetching all roles for user id:: " + userId);
		SystemUsers appUser = loginService.getSystemUsers(userId);
		String roleName = appUser.getRoleId().getRole();
		List<Roles> roles = new ArrayList<>();
		if (roleName.equalsIgnoreCase(StatusConstants.SUPER_ADMIN)
				|| roleName.equalsIgnoreCase(StatusConstants.SYSTEM_ADMIN)) {
			List<String> rolesList = new ArrayList<>();
			rolesList.add(StatusConstants.SUPER_ADMIN);
			roles = rolesRepository.findByRoleNotInAndOrganizationIdAndUserTypeOrderByRole(rolesList,
					appUser.getOrganizationId(), roleType.toString());
		} else {
			List<String> rolesList = new ArrayList<>();
			rolesList.add(StatusConstants.SUPER_ADMIN);
			rolesList.add(StatusConstants.SYSTEM_ADMIN);
			roles = rolesRepository.findByRoleNotInAndOrganizationIdAndUserTypeOrderByRole(rolesList,
					appUser.getOrganizationId(), roleType.toString());
		}
		List<ViewRole> viewRoles = roles.stream().map(role -> getRole(role)).collect(Collectors.toList());
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewRoles);
		LOGGER.info("Fetched all roles for user id:: " + userId);
		return viewResponse;
	}

	private ViewRole getRole(Roles role) {
		ViewRole viewRole = new ViewRole();
		viewRole.setName(role.getRole());
		viewRole.setRoleId(role.getId());
		return viewRole;
	}

}
