package com.billdog.user.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.AuditAction;
import com.billdog.user.common.AuditMemberModules;
import com.billdog.user.common.AuditModules;
import com.billdog.user.common.CaseAuditModules;
import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EntitiesSubModules;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.MemberAuditModules;
import com.billdog.user.common.OpportunitySubModule;
import com.billdog.user.common.RecordsTime;
import com.billdog.user.common.RoleAuditModule;
import com.billdog.user.common.UserAuditModule;
import com.billdog.user.entity.AuditRecords;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.repository.AuditRecordsRepository;
import com.billdog.user.request.AuditRequest;
import com.billdog.user.view.ViewAuditAction;
import com.billdog.user.view.ViewAuditModule;
import com.billdog.user.view.ViewAuditTimeModule;
import com.billdog.user.view.ViewResponse;

@Service

public class AuditService {

	@Autowired
	MemberAuditService memberAuditService;

	@Autowired
	EntityService entityService;

	@Autowired
	UserAuditService userAuditService;

	@Autowired
	RoleAuditService roleAuditService;

	@Autowired
	CaseService caseService;

	@Autowired
	CreateUserService createUserService;

	@Autowired
	AuditRecordsRepository auditRecordsRepository;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AuditService.class);

	public ResponseEntity<ViewResponse> getAuditTimeperiods() {
		LOGGER.info("getAuditTimeperiods method started");
		List<ViewAuditTimeModule> auditModules = new ArrayList<>();
		Arrays.asList(RecordsTime.values()).forEach(time -> {
			if (!time.equals(RecordsTime.Custom)) {
				ViewAuditTimeModule timeModule = new ViewAuditTimeModule();
				timeModule.setTimePeriod(time.toString().replace("_", " "));
				auditModules.add(timeModule);
			}

		});
		ViewResponse response = new ViewResponse();
		response.setData(auditModules);
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.AUDIT_TIME_PERIOD_LIST_FETCHED);
		if (auditModules.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getAuditTimeperiods method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getAuditModules() {
		LOGGER.info("getAuditModules method started");
		List<ViewAuditModule> auditModules = new ArrayList<>();
		Arrays.asList(AuditModules.values()).forEach(module -> {
			ViewAuditModule auditModule = new ViewAuditModule();
			auditModule.setModuleName(module.toString());
			auditModules.add(auditModule);
		});
		ViewResponse response = new ViewResponse();
		response.setData(auditModules);
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.AUDIT_MODULE_LIST_FETCHED);
		if (auditModules.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getAuditModules method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getAuditSubModules(String moduleName) {
		LOGGER.info("getAuditSubModules method started");
		List<ViewAuditModule> auditModules = new ArrayList<>();
		if (moduleName.equalsIgnoreCase(AuditModules.Members.toString())) {
			Arrays.asList(AuditMemberModules.values()).forEach(module -> {
				ViewAuditModule auditModule = new ViewAuditModule();
				auditModule.setModuleName(module.toString().replace("_", " "));
				auditModules.add(auditModule);
			});
		}
		if (moduleName.equalsIgnoreCase(AuditModules.Users.toString())) {
			Arrays.asList(UserAuditModule.values()).forEach(module -> {
				ViewAuditModule auditModule = new ViewAuditModule();
				auditModule.setModuleName(module.toString());
				auditModules.add(auditModule);
			});
		}
		if (moduleName.equalsIgnoreCase(AuditModules.Entities.toString())) {
			Arrays.asList(EntitiesSubModules.values()).forEach(module -> {
				ViewAuditModule auditModule = new ViewAuditModule();
				auditModule.setModuleName(module.toString().replace("_", " "));
				auditModules.add(auditModule);
			});
		}
		if (moduleName.equalsIgnoreCase(AuditModules.Opportunities.toString())) {
			Arrays.asList(OpportunitySubModule.values()).forEach(module -> {
				ViewAuditModule auditModule = new ViewAuditModule();
				auditModule.setModuleName(module.toString().replace("_", " "));
				auditModules.add(auditModule);
			});
		}
		if (moduleName.equalsIgnoreCase(AuditModules.Cases.toString())) {
			Arrays.asList(CaseAuditModules.values()).forEach(module -> {
				ViewAuditModule auditModule = new ViewAuditModule();
				auditModule.setModuleName(module.toString().replace("_", " "));
				auditModules.add(auditModule);
			});
		}
		if (moduleName.equalsIgnoreCase(AuditModules.Roles.toString())) {
			Arrays.asList(RoleAuditModule.values()).forEach(module -> {
				ViewAuditModule auditModule = new ViewAuditModule();
				auditModule.setModuleName(module.toString());
				auditModules.add(auditModule);
			});
		}

		ViewResponse response = new ViewResponse();
		response.setData(auditModules);
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.AUDIT_SUB_MODULE_LIST_FETCHED);
		if (auditModules.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getAuditSubModules method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getAuditActionInfo() {
		LOGGER.info("getAuditActionInfo method started");
		List<ViewAuditAction> auditModules = new ArrayList<>();
		Arrays.asList(AuditAction.values()).forEach(action -> {
			ViewAuditAction auditAction = new ViewAuditAction();
			auditAction.setAction(action.toString());
			auditModules.add(auditAction);
		});
		ViewResponse response = new ViewResponse();
		response.setData(auditModules);
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.AUDIT_ACTION_LIST_FETCHED);
		if (auditModules.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getAuditActionInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getAuditInfo(AuditRequest auditRequest) {
		LOGGER.info("getAuditInfo method started");
		SystemUsers systemUsers = createUserService.getSystemUsers(auditRequest.getUserId());
		if (systemUsers.getOrganizationId() != null) {
			auditRequest.setOrganizationId(systemUsers.getOrganizationId().getId());
		}
		if (auditRequest.getTimePeriod() != null
				&& auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.Custom.toString())
				&& !StringUtils.isBlank(auditRequest.getStartDate())
				&& !StringUtils.isBlank(auditRequest.getEndDate())) {
			auditRequest.setStartDate(DateAndTimeUtil.stringDateToLocalDate(auditRequest.getStartDate()).toString());
			auditRequest.setEndDate(DateAndTimeUtil.stringDateToLocalDate(auditRequest.getEndDate()).toString());
		}

		List<Long> revtypes = memberAuditService.getRevtypes(auditRequest);
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;
		auditRequest.setPageLimit(pageLimit);
		if (StringUtils.isBlank(auditRequest.getModuleName())) {
			throw new BadRequestException(ExceptionalMessages.PLEASE_PROVIDE_MODULE);
		}

		if (auditRequest.getModuleName().equalsIgnoreCase(AuditModules.Members.toString())) {
			if (auditRequest.getSubModuleName().isEmpty() && auditRequest.getSubModuleName() == null) {
				throw new BadRequestException(ExceptionalMessages.SUB_MODULE);
			}
			if (auditRequest.getSubModuleName()
					.equalsIgnoreCase(MemberAuditModules.Member_info.toString().replace("_", " "))) {
				return memberAuditService.getMemberAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName()
					.equalsIgnoreCase(MemberAuditModules.Member_family.toString().replace("_", " "))) {
				return memberAuditService.getMemberFamilyAuditInfo(auditRequest, revtypes);
			}

			if (auditRequest.getSubModuleName()
					.equalsIgnoreCase(MemberAuditModules.Member_insurance.toString().replace("_", " "))) {
				return memberAuditService.getMemberInsuranceAuditInfo(auditRequest, revtypes);
			}
		}
		if (auditRequest.getModuleName().equalsIgnoreCase(AuditModules.Entities.toString())
				|| auditRequest.getModuleName().equalsIgnoreCase(AuditModules.Opportunities.toString())) {
			return ResponseEntity.status(HttpStatus.OK).body(entityService.getAuditInfo(auditRequest));
		}
		if (auditRequest.getModuleName().equalsIgnoreCase(AuditModules.Users.toString())) {
			if (auditRequest.getSubModuleName().isEmpty() && auditRequest.getSubModuleName() == null) {
				throw new BadRequestException(ExceptionalMessages.SUB_MODULE);
			}
			if (auditRequest.getSubModuleName().equalsIgnoreCase(MemberAuditModules.User.toString())) {
				return userAuditService.getUserAuditInfo(auditRequest, revtypes);
			}
		}
		if (auditRequest.getModuleName().equalsIgnoreCase(AuditModules.Cases.toString())) {
			return ResponseEntity.status(HttpStatus.OK).body(caseService.getAuditInfo(auditRequest));
		}

		if (auditRequest.getModuleName().equalsIgnoreCase(AuditModules.Roles.toString())) {
			if (auditRequest.getSubModuleName().isEmpty() && auditRequest.getSubModuleName() == null) {
				throw new BadRequestException(ExceptionalMessages.SUB_MODULE);
			}
			if (auditRequest.getSubModuleName().equalsIgnoreCase(MemberAuditModules.Role.toString())) {
				return roleAuditService.getRolesAuditInfo(auditRequest, revtypes);
			}
		}

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.NO_RESULTS_FOUND);
		response.setData(new ArrayList<String>());
		LOGGER.info("getAuditInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getAuditInfoById(Long recordId, String moduleName, String subModuleName,
			Integer pageNumber, Integer pageLimit) {
		LOGGER.info("getAuditInfoById method started");
		if (moduleName.equalsIgnoreCase(AuditModules.Members.toString())) {

			if (subModuleName.equalsIgnoreCase(MemberAuditModules.Member_info.toString().replace("_", " "))) {
				return memberAuditService.getMemberAuditInfoById(recordId, pageNumber, pageLimit);
			}

			if (subModuleName.equalsIgnoreCase(MemberAuditModules.Member_family.toString().replace("_", " "))) {
				return memberAuditService.getMemberFamilyAuditInfoById(recordId, pageNumber, pageLimit);
			}

			if (subModuleName.equalsIgnoreCase(MemberAuditModules.Member_insurance.toString().replace("_", " "))) {
				return memberAuditService.getMemberInsuranceAuditInfoById(recordId, pageNumber, pageLimit);
			}
		}

		if (moduleName.equalsIgnoreCase(AuditModules.Entities.toString())
				|| moduleName.equalsIgnoreCase(AuditModules.Opportunities.toString())) {
			return ResponseEntity.status(HttpStatus.OK)
					.body(entityService.getAuditInfoById(recordId, subModuleName, pageNumber, pageLimit));
		}
		if (moduleName.equalsIgnoreCase(AuditModules.Users.toString())) {
			if (subModuleName.equalsIgnoreCase(UserAuditModule.User.toString())) {
				return userAuditService.getUserAuditInfoById(recordId, pageNumber, pageLimit);
			}

		}
		if (moduleName.equalsIgnoreCase(AuditModules.Roles.toString())) {
			if (subModuleName.equalsIgnoreCase(MemberAuditModules.Role.toString())) {
				return roleAuditService.getRoleAuditInfoById(recordId, pageNumber, pageLimit);
			}
		}

		if (moduleName.equalsIgnoreCase(AuditModules.Cases.toString())) {
			return ResponseEntity.status(HttpStatus.OK)
					.body(caseService.getAuditInfoById(recordId, subModuleName, pageNumber, pageLimit));
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.NO_RESULTS_FOUND);
		response.setData(new ArrayList<String>());
		LOGGER.info("getAuditInfoById method ended");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public String getAuditId() {
		String auditId = null;
		Long maxAuditId = auditRecordsRepository.getAuditId();
		long number = 0;
		int count = 1;
		do {
			if (maxAuditId != null) {
				number = maxAuditId + count;
				auditId = Constants.AUD + "" + number;
				count++;
			} else {
				number = count;
				auditId = Constants.AUD + "" + number;
			}
		} while (auditRecordsRepository.findByAuditId(auditId) != null);
		AuditRecords records = new AuditRecords();
		records.setAuditId(auditId);
		records.setCreatedAt(DateAndTimeUtil.now());
		auditRecordsRepository.save(records);
		return auditId;
	}
}
