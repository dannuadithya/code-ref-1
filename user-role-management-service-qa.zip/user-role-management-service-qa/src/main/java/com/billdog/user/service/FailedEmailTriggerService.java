package com.billdog.user.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.entity.FailedEmailTrigger;
import com.billdog.user.entity.SchedulerJob;
import com.billdog.user.repository.FailedEmailTriggerRepository;
import com.billdog.user.repository.SchedulerJobRepository;
import com.billdog.user.request.PasscodeEmailRequest;
import com.billdog.user.request.UpdateEmailRequest;
import com.billdog.user.request.UpdateMemberEmailRequest;
import com.billdog.user.request.WelcomeEmailMemberRequest;
import com.billdog.user.view.ViewResponse;

import net.javacrumbs.shedlock.core.SchedulerLock;

@Service
public class FailedEmailTriggerService {

	private static final Logger LOGGER = LoggerFactory.getLogger(FailedEmailTriggerService.class);

	@Autowired
	EmailService emailService;

	@Autowired
	FailedEmailTriggerRepository failedEmailTriggerRepository;

	@Autowired
	SchedulerJobRepository schedulerJobRepository;

	@Scheduled(cron = "0 0/30 * * * ?")
	@SchedulerLock(name = "emailTrigger", lockAtLeastForString = "PT5M", lockAtMostForString = "PT30M")
	public void saveFailedEmails() {
		LOGGER.info("scheduler job for failed email method started..!");
		SchedulerJob schedulerJob = schedulerJobRepository.findByName(Constants.EMAIL_JOB);
		if (schedulerJob != null && schedulerJob.getStatus().equalsIgnoreCase(Constants.ACTIVE)
				&& !schedulerJob.isRunning()) {
			long beginTs = System.currentTimeMillis();
			schedulerJob.setRunning(true);
			schedulerJob.setLastStartedAt(DateAndTimeUtil.now());
			LOGGER.info("saving scheduler job starting time..!");
			schedulerJobRepository.save(schedulerJob);
			try {
				List<FailedEmailTrigger> emailTriggersOptional = failedEmailTriggerRepository
						.findByIsEmailTriggered(false);
				LOGGER.info("Fetching list of failed email records..!");
				emailTriggersOptional.forEach(emailTrigger -> {
					try {
						String emailTitle = emailTrigger.getEmailTitle();
						EmailTitles emailTitlesEnum = EmailTitles.valueOf(emailTitle);
						if (emailTrigger.getEmailTitle().equals(EmailTitles.WELCOME_USER.toString())) {
							PasscodeEmailRequest passcodeEmailRequest = new PasscodeEmailRequest();
							passcodeEmailRequest.setEmail(emailTrigger.getEmail());
							passcodeEmailRequest.setUsername(emailTrigger.getFirstName());
							passcodeEmailRequest.setEmailTitle(emailTitlesEnum);
							passcodeEmailRequest.setOrganizationId(emailTrigger.getOrganizationId());
							emailService.sendEamil(passcodeEmailRequest);
							emailTrigger.setEmailTriggered(true);
							failedEmailTriggerRepository.save(emailTrigger);
						}
						if (emailTrigger.getEmailTitle().equals(EmailTitles.MEMBER_WELCOME.toString())) {
							WelcomeEmailMemberRequest welcomeEmailMemberRequest = new WelcomeEmailMemberRequest();
							welcomeEmailMemberRequest.setEmail(emailTrigger.getEmail());
							welcomeEmailMemberRequest.setFirstName(emailTrigger.getFirstName());
							welcomeEmailMemberRequest.setEmailTitle(emailTitlesEnum);
							welcomeEmailMemberRequest.setOrgId(emailTrigger.getOrganizationId());
							emailService.sendWelcomeEamilToMember(welcomeEmailMemberRequest);
							emailTrigger.setEmailTriggered(true);
							failedEmailTriggerRepository.save(emailTrigger);
						}
						if (emailTrigger.getEmailTitle().equals(EmailTitles.PROFILE_UPDATED.toString())
								|| emailTrigger.getEmailTitle().equals(EmailTitles.PASSWORD_RESET.toString())
								|| emailTrigger.getEmailTitle().equals(EmailTitles.PROFILE_UPDATED_WEB.toString())) {
							WelcomeEmailMemberRequest welcomeEmailMemberRequest = new WelcomeEmailMemberRequest();
							welcomeEmailMemberRequest.setEmail(emailTrigger.getEmail());
							welcomeEmailMemberRequest.setFirstName(emailTrigger.getFirstName());
							welcomeEmailMemberRequest.setEmailTitle(emailTitlesEnum);
							welcomeEmailMemberRequest.setOrgId(emailTrigger.getOrganizationId());
							emailService.sendEamilToMember(welcomeEmailMemberRequest);
							emailTrigger.setEmailTriggered(true);
							failedEmailTriggerRepository.save(emailTrigger);
						}

						if (emailTrigger.getEmailTitle().equals(EmailTitles.OLD_EMAIL.toString())) {
							UpdateMemberEmailRequest updateMemberEmailRequest = new UpdateMemberEmailRequest();
							updateMemberEmailRequest.setOldEmail(emailTrigger.getOldEmail());
							updateMemberEmailRequest.setFirstName(emailTrigger.getFirstName());
							updateMemberEmailRequest.setEmailTitle(emailTitlesEnum);
							updateMemberEmailRequest.setNewEmail(emailTrigger.getNewEmail());
							updateMemberEmailRequest.setOrgId(emailTrigger.getOrganizationId());
							emailService.sendUpdatedEamilToMember(updateMemberEmailRequest);
							emailTrigger.setEmailTriggered(true);
							failedEmailTriggerRepository.save(emailTrigger);
						}

						if (emailTrigger.getEmailTitle().equals(EmailTitles.NEW_EMAIL.toString())) {
							UpdateEmailRequest updateEmailRequest = new UpdateEmailRequest();
							updateEmailRequest.setFirstName(emailTrigger.getFirstName());
							updateEmailRequest.setLastName(emailTrigger.getLastName());
							updateEmailRequest.setEmailTitle(emailTitlesEnum);
							updateEmailRequest.setUserName(emailTrigger.getEmail());
							updateEmailRequest.setOrgId(emailTrigger.getOrganizationId());
							emailService.sendUpdatedEamil(updateEmailRequest);
							emailTrigger.setEmailTriggered(true);
							failedEmailTriggerRepository.save(emailTrigger);
						}
					} catch (Exception e) {
						LOGGER.info("Exception occurred while calling email service, message:: {}", e.getMessage());
					}
				});
				long endTs = System.currentTimeMillis();
				schedulerJob.setTimeTaken("" + ((endTs - beginTs) / 1000));
				schedulerJob.setLastCompletedAt(DateAndTimeUtil.now());
			} catch (Exception e) {
				LOGGER.info("Exception occurred while calling email service, message:: {}", e.getMessage());
			} finally {
				LOGGER.info("Updating scheduler job status in finally block");
				schedulerJob.setRunning(false);
				schedulerJobRepository.save(schedulerJob);
			}
			LOGGER.info("scheduler job for failed email method ended..!");
		} else {
			LOGGER.info("Job is already running");
		}
	}
}