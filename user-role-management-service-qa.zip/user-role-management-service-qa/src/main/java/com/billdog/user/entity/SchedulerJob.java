package com.billdog.user.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "scheduler_job")
@Table(name = "scheduler_job")
public class SchedulerJob extends BaseEntity {

	@Column(name = "name")
	private String name;

	@Column(name = "is_running")
	private boolean running;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "last_started_time")
	private LocalDateTime lastStartedAt;

	@Column(name = "last_completed_time")
	private LocalDateTime lastCompletedAt;

	@Column(name = "time_taken_secs")
	private String timeTaken;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isRunning() {
		return running;
	}

	public void setRunning(boolean running) {
		this.running = running;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getLastStartedAt() {
		return lastStartedAt;
	}

	public void setLastStartedAt(LocalDateTime lastStartedAt) {
		this.lastStartedAt = lastStartedAt;
	}

	public LocalDateTime getLastCompletedAt() {
		return lastCompletedAt;
	}

	public void setLastCompletedAt(LocalDateTime lastCompletedAt) {
		this.lastCompletedAt = lastCompletedAt;
	}

	public String getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(String timeTaken) {
		this.timeTaken = timeTaken;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

}
