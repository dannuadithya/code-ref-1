package com.billdog.user.exception;

public class MemberNotFoundException extends NoRecordFoundException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public MemberNotFoundException(String exception) {
		super(exception);
	}

}
