package com.billdog.user.service;

import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.billdog.user.authentication.AesEncryption;
import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.MemberTypeMaster;
import com.billdog.user.entity.Organization;
import com.billdog.user.exception.EmailLimitExceededException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.request.PasscodeEmailMemberRequest;
import com.billdog.user.request.ResendPasscodeRequest;
import com.billdog.user.request.VerifyMemberEmailRequest;
import com.billdog.user.view.ViewResponse;

@Service
public class CreateMemberDetails {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CreateMemberDetails.class);

	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Value("${passcode.email.times}")
	private int passcodeTimes;

	@Value("${passcode.length}")
	private int passcodeLength;

	@Autowired
	EmailService emailService;

	@Autowired
	CreateUserService createUserService;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	MemberTypeMasterRepository memberTypeMasterRepository;

	@Autowired
	MemberLoginService memberLoginService;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	AesEncryption aesEncryption;

	@Autowired
	AuditService auditService;

	public ViewResponse sendPasscode(VerifyMemberEmailRequest verifyMemberEmailRequest, EmailTitles emailTitle,
			Optional<MemberEmail> memberEmail, Organization organization) {
		LOGGER.info("Send passcode method started..!");
		LOGGER.info("Checking email passcode limit to email new passcode to member");
		if (memberEmail.isPresent() && memberEmail.get().getEmailCount() != null
				&& memberEmail.get().getEmailCount() >= passcodeTimes
				&& createUserService.checkDate(memberEmail.get().getMailSent().toLocalDate())) {
			String message = ExceptionalMessages.PASSCODE_EMAIL_LIMIT_EXCEEDED.replace("{times}", "" + passcodeTimes);
			throw new EmailLimitExceededException(message);
		}

		String passcode = createUserService.generatePasscode(passcodeLength);
		LOGGER.debug("Generated new passcode for login purpose");
		String auditId = auditService.getAuditId();
		MemberEmail savePasscode = savePasscode(verifyMemberEmailRequest, memberEmail, passcode, organization, auditId);
		LOGGER.info("Creting passcode email member request object for calling email service");
		PasscodeEmailMemberRequest passcodeEmailMemberRequest = new PasscodeEmailMemberRequest();
		passcodeEmailMemberRequest.setEmail(verifyMemberEmailRequest.getEmail());
		passcodeEmailMemberRequest.setPasscode(passcode);
		passcodeEmailMemberRequest.setEmailTitle(emailTitle);
		passcodeEmailMemberRequest.setOrgId(organization.getId());
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send passcode email");
			viewResponse = emailService.sendEamilToMember(passcodeEmailMemberRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: ", exception.getCause());
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send passcode email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.SENT_PASSCODE);
			viewResponse.setMemberId(savePasscode.getMemberId().getId());
		} else {
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}
		return viewResponse;
	}

	private Member createMember(MemberTypeMaster memberTypeMaster, String fcmToken, String auditId) {
		Member member = new Member();
		member.setCreatedAt(DateAndTimeUtil.now());
		member.setUpdatedAt(DateAndTimeUtil.now());
		member.setStatus(StatusConstants.PENDING);
		member.setMemberTypeMasterId(memberTypeMaster);
		if (fcmToken != null) {
			member.setFcmToken(fcmToken);
		}
		member.setAuditId(auditId);
		member.setOrganizationId(memberTypeMaster.getOrganizationId());
		member.setMemberId(memberLoginService.getMemberId(memberTypeMaster.getOrganizationId().getId()));
		return memberRepository.save(member);
	}

	/*
	 * this method used to save member new passcode
	 */
	private MemberEmail savePasscode(VerifyMemberEmailRequest verifyMemberEmailRequest, Optional<MemberEmail> optional,
			String passcode, Organization orOptional, String auditId) {
		LOGGER.info("savePasscode method started");
		MemberEmail memberEmail = new MemberEmail();
		if (optional.isPresent()) {
			LOGGER.info("Updating member recent passcode for login verification");
			memberEmail = optional.get();
			LOGGER.info("Checking last passcode email date for updating passcode email limit count");
			if (memberEmail.getMailSent() != null
					&& memberEmail.getMailSent().toLocalDate().isEqual(DateAndTimeUtil.now().toLocalDate())) {
				memberEmail.setEmailCount(memberEmail.getEmailCount() + 1);
			} else {
				memberEmail.setEmailCount(1l);
			}
		} else {
			LOGGER.info("Creating member with type:: {}", Constants.DIRECT_MEMBER);
			Optional<MemberTypeMaster> memberTypeMaster = memberTypeMasterRepository
					.findByTypeNameAndOrganizationId(Constants.DIRECT_MEMBER, orOptional);
			if (!memberTypeMaster.isPresent()) {
				throw new NoRecordFoundException(ExceptionalMessages.NO_DIRECT_MEMBER);
			}
			memberEmail
					.setMemberId(createMember(memberTypeMaster.get(), verifyMemberEmailRequest.getFcmToken(), auditId));
			LOGGER.info("Created member with status::{}", memberEmail.getMemberId().getStatus());
			LOGGER.info("Saving for the first time member recent passcode for login verification");
			memberEmail.setCreatedAt(DateAndTimeUtil.now());
			memberEmail.setEmail(verifyMemberEmailRequest.getEmail());
			memberEmail.setEmailCount(0l);
			memberEmail.setOrganizationId(orOptional);
			memberEmail.setPrimary(Boolean.TRUE);
		}
		memberEmail.setAuditId(auditId);
		memberEmail.setUpdatedAt(DateAndTimeUtil.now());
		memberEmail.setMailSent(DateAndTimeUtil.now());
		String encryptedPassword = aesEncryption.encrypt(passcode);
		memberEmail.setPasscode(encryptedPassword);
		LOGGER.info("savePasscode method ended");
		return memberEmailRepository.save(memberEmail);
	}

	public ViewResponse resendPasscode(ResendPasscodeRequest resendPasscodeRequest, EmailTitles emailTitle,
			Optional<MemberEmail> memberEmail, Organization organization, Member member) {
		LOGGER.info("Send passcode method started..!");
		LOGGER.info("Checking email passcode limit to email new passcode to member");
		if (memberEmail.isPresent() && memberEmail.get().getEmailCount() != null
				&& memberEmail.get().getEmailCount() >= passcodeTimes
				&& createUserService.checkDate(memberEmail.get().getMailSent().toLocalDate())) {
			String message = ExceptionalMessages.PASSCODE_EMAIL_LIMIT_EXCEEDED.replace("{times}", "" + passcodeTimes);
			throw new EmailLimitExceededException(message);
		}

		String passcode = createUserService.generatePasscode(passcodeLength);
		LOGGER.debug("Generated new passcode for login purpose");
		saveResentPasscode(resendPasscodeRequest, memberEmail, passcode, organization);
		LOGGER.info("Creting passcode email member request object for calling email service");
		PasscodeEmailMemberRequest passcodeEmailMemberRequest = new PasscodeEmailMemberRequest();
		passcodeEmailMemberRequest.setEmail(resendPasscodeRequest.getEmail());
		passcodeEmailMemberRequest.setPasscode(passcode);
		passcodeEmailMemberRequest.setEmailTitle(emailTitle);
		passcodeEmailMemberRequest.setFirstName(member.getFirstName());
		passcodeEmailMemberRequest.setOrgId(organization.getId());
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send passcode email");
			viewResponse = emailService.sendEamilToMember(passcodeEmailMemberRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: ", exception.getCause());
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send passcode email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessageTitle("Success!");
			viewResponse.setMessage(Constants.SENT_PASSCODE_EMAIL);
			viewResponse.setMemberId(resendPasscodeRequest.getMemberId());
		} else {
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}
		return viewResponse;
	}

	private MemberEmail saveResentPasscode(ResendPasscodeRequest verifyMemberEmailRequest,
			Optional<MemberEmail> optional, String passcode, Organization orOptional) {
		LOGGER.info("savePasscode method started");
		MemberEmail memberEmail = new MemberEmail();
		if (optional.isPresent()) {
			LOGGER.info("Updating member recent passcode for login verification");
			memberEmail = optional.get();
			LOGGER.info("Checking last passcode email date for updating passcode email limit count");
			if (memberEmail.getMailSent() != null
					&& memberEmail.getMailSent().toLocalDate().isEqual(DateAndTimeUtil.now().toLocalDate())) {
				memberEmail.setEmailCount(memberEmail.getEmailCount() + 1);
			} else {
				memberEmail.setEmailCount(1l);
			}
		} else {
			LOGGER.info("Creating member with type:: {}", Constants.DIRECT_MEMBER);
			Optional<MemberTypeMaster> memberTypeMaster = memberTypeMasterRepository
					.findByTypeNameAndOrganizationId(Constants.DIRECT_MEMBER, orOptional);
			if (!memberTypeMaster.isPresent()) {
				throw new NoRecordFoundException(ExceptionalMessages.NO_DIRECT_MEMBER);
			}
			memberEmail.setMemberId(createMember(memberTypeMaster.get(), null, null));
			LOGGER.info("Created member with status::{}", memberEmail.getMemberId().getStatus());
			LOGGER.info("Saving for the first time member recent passcode for login verification");
			memberEmail.setCreatedAt(DateAndTimeUtil.now());
			memberEmail.setEmail(verifyMemberEmailRequest.getEmail());
			memberEmail.setEmailCount(0l);
			memberEmail.setOrganizationId(orOptional);
			memberEmail.setPrimary(Boolean.TRUE);
		}
		memberEmail.setUpdatedAt(DateAndTimeUtil.now());
		memberEmail.setMailSent(DateAndTimeUtil.now());
		String encryptedPassword = aesEncryption.encrypt(passcode);
		memberEmail.setPasscode(encryptedPassword);
		LOGGER.info("savePasscode method ended");
		return memberEmailRepository.save(memberEmail);
	}

}
