package com.billdog.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.SchedulerJob;

@Repository
public interface SchedulerJobRepository extends JpaRepository<SchedulerJob, Long> {

	SchedulerJob findByName(String memberSfdcJob);

}
