package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.CountryMaster;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.StateMaster;

@Repository
public interface StateMasterRepository extends JpaRepository<StateMaster, Long> {

	List<StateMaster> findAllByStatus(String active);

	List<StateMaster> findByCountryIdAndStatus(CountryMaster countryMaster, String active);

	List<StateMaster> findByOrganizationIdAndCountryIdAndStatus(Organization organizationId,
			CountryMaster country, String active);

	Optional<StateMaster> findByIdAndStatus(long stateId, String active);

}
