package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.FailedEmailTrigger;

public interface FailedEmailTriggerRepository extends JpaRepository<FailedEmailTrigger, Long> {

	Optional<FailedEmailTrigger> findByEmailAndEmailTitle(String email, String emailTitle);

	List<FailedEmailTrigger> findByIsEmailTriggered(boolean b);

}
