package com.billdog.user.authorization;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.billdog.user.authentication.JWTAuthentication;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.entity.AuthTokens;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.InvalidAuthTokenException;
import com.billdog.user.repository.AuthTokensRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.service.LogoutService;

import io.jsonwebtoken.Claims;

public class RequestProcessingInterceptorAdapter extends HandlerInterceptorAdapter {
	private final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	JWTAuthentication jwtAuthentication;

	@Autowired
	SystemUsersrepository systemUsersrepository;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	AuthTokensRepository authTokensRepository;

	@Autowired
	LogoutService logoutService;

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		logger.info("Token verification method started at :: {}", DateAndTimeUtil.now());
		if (handler instanceof HandlerMethod) {
			long beginTs = System.currentTimeMillis();
			HandlerMethod method = (HandlerMethod) handler;
			EnableTokenAuthorisation methodAnnotation = method.getMethodAnnotation(EnableTokenAuthorisation.class);
			if (methodAnnotation != null) {
				String header = request.getHeader("Authorization");
				if (header != null) {
					Claims verifyToken = jwtAuthentication.verifyToken(header);
					if (verifyToken != null) {
						String[] token = verifyToken.getSubject().split("-");
						long id = 0;
						try {
							id = Long.valueOf(token[token.length - 1]);
						} catch (Exception e) {
							throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
						}

						if (token[0].equals("USER")) {
							Optional<SystemUsers> userExists = systemUsersrepository.findById(id);
							if (userExists.isPresent()) {
								Optional<AuthTokens> userTokenOptional = authTokensRepository
										.findByTokenAndUserId(header, userExists.get());
								if (!userTokenOptional.isPresent()) {
									throw new InvalidAuthTokenException(ExceptionalMessages.USER_SESSION_EXPIRED);
								}
								if (userTokenOptional.get().getExpiredAt() == null
										|| (userTokenOptional.get().getExpiredAt().isBefore(DateAndTimeUtil.now()))) {
									String message = logoutService.getExceptionMessage(userTokenOptional.get());
									if (!StringUtils.isBlank(message)
											&& message.equalsIgnoreCase(ExceptionalMessages.SESSION_EXPIRED)) {
										message = ExceptionalMessages.USER_SESSION_EXPIRED;
									}
									throw new InvalidAuthTokenException(message);
								}

								request.setAttribute("userId", id);
								request.setAttribute("email", userExists.get().getEmail());
								logger.info("Auth Token verified for MOBILE: {}", verifyToken.getSubject());
							} else {
								throw new InvalidAuthTokenException(ExceptionalMessages.USER_SESSION_EXPIRED);
							}
						} else if (token[0].equals("MEMBER")) {
							List<Object[]> memberInfo = memberRepository.getMemberTokenInfo(id, header);
							if (memberInfo.isEmpty()) {
								throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
							}
							memberInfo.forEach(member -> {
								if (member[1] != null) {
									LocalDateTime date = ((Timestamp) member[1]).toLocalDateTime();
									if (date.isBefore(DateAndTimeUtil.now())) {
										throw new InvalidAuthTokenException(logoutService.getExceptionMessage((String) member[2],
												(String) member[3], (String) member[4]));
									}									
								} else {
									throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
								}
							});
							request.setAttribute("memberId", id);
						} else {
							throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
						}
					}
				} else {
					throw new AuthTokenMissingException(ExceptionalMessages.SESSION_EXPIRED);
				}
			}
			long endTs = System.currentTimeMillis();
			logger.info("Time taken to verify token: {} Millis", (endTs - beginTs));
		}
		logger.info("Token verification method ended at :: {}", DateAndTimeUtil.now());
		return super.preHandle(request, response, handler);
	}

}
