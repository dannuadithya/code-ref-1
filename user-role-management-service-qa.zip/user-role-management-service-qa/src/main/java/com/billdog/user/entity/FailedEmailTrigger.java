package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name = "FAILED_EMAIL_TRIGGER")
@Table(name = "failed_email_trigger")
public class FailedEmailTrigger extends BaseEntity {

	@Column(name = "email_title")
	private String emailTitle;

	@Column(name = "email")
	private String email;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "new_email")
	private String newEmail;

	@Column(name = "old_email")
	private String oldEmail;

	@Column(name = "member_Id")
	private Long memberId;

	@Column(name = "user_Id")
	private Long userId;

	@Column(name = "is_email_triggered")
	private boolean isEmailTriggered;

	@Column(name = "organization_Id")
	private Long organizationId;

	public boolean isEmailTriggered() {
		return isEmailTriggered;
	}

	public void setEmailTriggered(boolean isEmailTriggered) {
		this.isEmailTriggered = isEmailTriggered;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public String getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(String emailTitle) {
		this.emailTitle = emailTitle;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNewEmail() {
		return newEmail;
	}

	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}

	public String getOldEmail() {
		return oldEmail;
	}

	public void setOldEmail(String oldEmail) {
		this.oldEmail = oldEmail;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

}
