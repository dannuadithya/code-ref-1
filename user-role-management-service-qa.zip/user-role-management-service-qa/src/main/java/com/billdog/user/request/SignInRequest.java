package com.billdog.user.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class SignInRequest {
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter Email")
	@Email(message = "Invalid email format")
	private String email;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "please enter password")
	private String password;
	@NotNull(message = "Something went wrong. Please try again")
	private Long organizationId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String appVersion;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String deviceToken;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String fcmToken;	
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String deviceType;

	public String getFcmToken() {
		return fcmToken;
	}

	public void setFcmToken(String fcmToken) {
		this.fcmToken = fcmToken;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public String getAppVersion() {
		return appVersion;
	}

	public void setAppVersion(String appVersion) {
		this.appVersion = appVersion;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

}
