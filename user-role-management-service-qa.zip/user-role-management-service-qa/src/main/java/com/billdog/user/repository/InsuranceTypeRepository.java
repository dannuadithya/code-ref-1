package com.billdog.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.InsuranceTypes;
import com.billdog.user.entity.Organization;

public interface InsuranceTypeRepository extends JpaRepository<InsuranceTypes, Long>{

	List<InsuranceTypes> findAllByStatus(String active);

	List<InsuranceTypes> findByOrganizationIdAndStatus(Organization organization, String active);

}
