package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.CountryMaster;
import com.billdog.user.entity.Organization;

@Repository
public interface CountryMasterRepository extends JpaRepository<CountryMaster, Long> {

	List<CountryMaster> findAllByStatus(String active);

	Optional<CountryMaster> findByIdAndStatus(long countryId, String active);

	List<CountryMaster> findByOrganizationIdAndStatus(Organization organization, String active);

}
