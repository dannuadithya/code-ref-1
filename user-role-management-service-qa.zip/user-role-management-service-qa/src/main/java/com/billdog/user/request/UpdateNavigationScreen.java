package com.billdog.user.request;

import java.util.List;

import javax.validation.constraints.NotNull;

import com.billdog.user.view.ViewRoleScreens;

public class UpdateNavigationScreen {

	private Long userId;

	@NotNull(message = "Role id must not be null")
	private Long roleId;

	@NotNull(message = "data object must not be null")
	private List<ViewRoleScreens> data;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public List<ViewRoleScreens> getData() {
		return data;
	}

	public void setData(List<ViewRoleScreens> data) {
		this.data = data;
	}

	public Long getRoleId() {
		return roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
}
