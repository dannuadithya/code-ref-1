package com.billdog.user.request;

import javax.validation.constraints.NotNull;

import com.billdog.user.common.UserType;
import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class CreateNavigationScreen {

	private long parentId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotNull(message = "Screen name must not be null")
	private String name;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotNull(message = "Screen url must not be null")
	private String url;
	@NotNull(message = "Something went wrong. Please try again")
	private long organizationId;

	private UserType type;

	public long getParentId() {
		return parentId;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(long organizationId) {
		this.organizationId = organizationId;
	}

	public UserType getType() {
		return type;
	}

	public void setType(UserType type) {
		this.type = type;
	}

}
