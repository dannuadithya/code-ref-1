package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.MemberTypeMaster;
import com.billdog.user.entity.Organization;

public interface MemberTypeMasterRepository extends JpaRepository<MemberTypeMaster, Long>{

	Optional<MemberTypeMaster> findByIdAndStatus(long opportunityTypeId, String active);

	List<MemberTypeMaster> findAllByStatus(String active);

	List<MemberTypeMaster> findByOrganizationIdAndStatus(Organization organization, String active);

	Optional<MemberTypeMaster> findByTypeNameAndOrganizationId(String blockOpportunity, Organization organizationId);

	List<MemberTypeMaster> findByTypeName(String opportunityName);

}
