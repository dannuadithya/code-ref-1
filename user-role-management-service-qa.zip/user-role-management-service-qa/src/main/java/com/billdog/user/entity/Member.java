package com.billdog.user.entity;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "MEMBER")
@Table(name = "member", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "SFDCID_INDEX", columnList = "SFDC_ID", unique = true),
		@Index(name = "org_index", columnList = "ORGANIZATION_ID", unique = false) })
public class Member extends BaseEntity {

	@Audited
	@Column(name = "FIRST_NAME")
	private String firstName;

	@Audited
	@Column(name = "MIDDLE_NAME")
	private String middleName;

	@Audited
	@Column(name = "LAST_NAME")
	private String lastName;

	@Audited
	@Column(name = "STATUS")
	private String status;

	@Column(name = "member_id")
	private String memberId;

	@Audited
	@Column(name = "SFDC_ID")
	private String sfdcId;

	@Column(name = "SFDC_UPDATED_TIME")
	private LocalDateTime sfdcUpdatedTime;

	@Audited
	@Column(name = "LOCKED")
	private boolean locked;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@ManyToOne
	@JoinColumn(name = "MEMBER_TYPE_MASTER_ID")
	private MemberTypeMaster memberTypeMasterId;

	@ManyToOne
	@JoinColumn(name = "COUNTRY_PHONE_CODE_MASTER_ID")
	private CountryPhoneCodeMaster countryPhoneCodeMasterId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "NAME_PREFIX_MASTER_ID")
	private NamePrefixMaster namePrefixMasterId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "GENDER_MASTER_ID")
	private GenderMaster genderId;

	@Audited
	@Column(name = "PHONE_NUMBER")
	private String phoneNumber;

	@Audited
	@Column(name = "date_of_birth")
	private LocalDate dateOfBirth;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "PRODUCT_ID")
	private MemberProduct productId;

	@Column(name = "PROFILE_UPDATED")
	private boolean profileUpdated;

	@Column(name = "APP_OLD_VERSION")
	private String oldVersion;

	@Column(name = "APP_CURRENT_VERSION")
	private String currentVersion;

	@Column(name = "DEVICE_TOKEN")
	private String deviceToken;
	
	@Column(name = "DEVICE_TYPE")
	private String deviceType;
	

	@Audited
	@Column(name = "locked_from_web")
	private boolean lockedFromWeb;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "USER_ID")
	private SystemUsers userId;

	@Column(name = "FCM_TOKEN")
	private String fcmToken;

	@Audited
	@Column(name = "employer_Id")
	private Long employerId;

	@Audited
	@Column(name = "audit_id")
	private String auditId;

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public String getFcmToken() {
		return fcmToken;
	}

	public void setFcmToken(String fcmToken) {
		this.fcmToken = fcmToken;
	}

	public boolean isLockedFromWeb() {
		return lockedFromWeb;
	}

	public void setLockedFromWeb(boolean lockedFromWeb) {
		this.lockedFromWeb = lockedFromWeb;
	}

	public MemberProduct getProductId() {
		return productId;
	}

	public void setProductId(MemberProduct productId) {
		this.productId = productId;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public GenderMaster getGenderId() {
		return genderId;
	}

	public void setGenderId(GenderMaster genderId) {
		this.genderId = genderId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public LocalDateTime getSfdcUpdatedTime() {
		return sfdcUpdatedTime;
	}

	public void setSfdcUpdatedTime(LocalDateTime sfdcUpdatedTime) {
		this.sfdcUpdatedTime = sfdcUpdatedTime;
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public MemberTypeMaster getMemberTypeMasterId() {
		return memberTypeMasterId;
	}

	public void setMemberTypeMasterId(MemberTypeMaster memberTypeMasterId) {
		this.memberTypeMasterId = memberTypeMasterId;
	}

	public CountryPhoneCodeMaster getCountryPhoneCodeMasterId() {
		return countryPhoneCodeMasterId;
	}

	public void setCountryPhoneCodeMasterId(CountryPhoneCodeMaster countryPhoneCodeMasterId) {
		this.countryPhoneCodeMasterId = countryPhoneCodeMasterId;
	}

	public NamePrefixMaster getNamePrefixMasterId() {
		return namePrefixMasterId;
	}

	public void setNamePrefixMasterId(NamePrefixMaster namePrefixMasterId) {
		this.namePrefixMasterId = namePrefixMasterId;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public boolean isProfileUpdated() {
		return profileUpdated;
	}

	public void setProfileUpdated(boolean profileUpdated) {
		this.profileUpdated = profileUpdated;
	}

	public String getOldVersion() {
		return oldVersion;
	}

	public void setOldVersion(String oldVersion) {
		this.oldVersion = oldVersion;
	}

	public String getCurrentVersion() {
		return currentVersion;
	}

	public void setCurrentVersion(String currentVersion) {
		this.currentVersion = currentVersion;
	}

	public String getDeviceToken() {
		return deviceToken;
	}

	public void setDeviceToken(String deviceToken) {
		this.deviceToken = deviceToken;
	}

	public SystemUsers getUserId() {
		return userId;
	}

	public void setUserId(SystemUsers userId) {
		this.userId = userId;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

	public String getDeviceType() {
		return deviceType;
	}

	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}

}
