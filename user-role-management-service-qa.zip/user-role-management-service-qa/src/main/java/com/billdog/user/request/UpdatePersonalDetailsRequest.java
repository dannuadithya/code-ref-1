package com.billdog.user.request;

import javax.validation.constraints.Email;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UpdatePersonalDetailsRequest {

	private long prefixId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String firstName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String lastName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String middleName;
	private long genderId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String mobileNumber;

	private String dateOfBirth;
	private long productId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Email(message = "Invalid primary email format")
	private String primaryEmailId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Email(message = "Invalid secoundary email format")
	private String secoundaryEmailId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String addressLine1;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String addressLine2;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String street;
	private long stateId;
	private long countryId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String zipcode;
	private long countryPhoneCodeId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String cityName;
	private long userId;
	private long memberId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String status;
	private Long employerId;
	private Long opportunityId;

	public Long getOpportunityId() {
		return opportunityId;
	}

	public void setOpportunityId(Long opportunityId) {
		this.opportunityId = opportunityId;
	}

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public long getPrefixId() {
		return prefixId;
	}

	public void setPrefixId(long prefixId) {
		this.prefixId = prefixId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public long getGenderId() {
		return genderId;
	}

	public void setGenderId(long genderId) {
		this.genderId = genderId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public String getPrimaryEmailId() {
		return primaryEmailId;
	}

	public void setPrimaryEmailId(String primaryEmailId) {
		this.primaryEmailId = primaryEmailId;
	}

	public String getSecoundaryEmailId() {
		return secoundaryEmailId;
	}

	public void setSecoundaryEmailId(String secoundaryEmailId) {
		this.secoundaryEmailId = secoundaryEmailId;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public long getStateId() {
		return stateId;
	}

	public void setStateId(long stateId) {
		this.stateId = stateId;
	}

	public long getCountryId() {
		return countryId;
	}

	public void setCountryId(long countryId) {
		this.countryId = countryId;
	}

	

	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	public long getCountryPhoneCodeId() {
		return countryPhoneCodeId;
	}

	public void setCountryPhoneCodeId(long countryPhoneCodeId) {
		this.countryPhoneCodeId = countryPhoneCodeId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

}
