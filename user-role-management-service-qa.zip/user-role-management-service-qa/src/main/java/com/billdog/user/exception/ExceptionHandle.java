package com.billdog.user.exception;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.billdog.user.common.Constants;
import com.billdog.user.common.ExceptionalMessages;

@RestControllerAdvice
public class ExceptionHandle extends ResponseEntityExceptionHandler {

	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandle.class);

	@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex,
			HttpHeaders headers, HttpStatus status, WebRequest request) {
		List<String> errors = ex.getBindingResult().getFieldErrors().stream().map(x -> x.getDefaultMessage())
				.collect(Collectors.toList());
		String title = getTitle(errors.get(0));
		return ResponseEntity.status(HttpStatus.BAD_REQUEST)
				.body(new ErrorResponse(Constants.FAILED, errors.get(0), request.getDescription(false), title));
	}

	@ExceptionHandler(value = { ConstraintViolationException.class })
	public ResponseEntity<Object> handleResourceNotFoundException(ConstraintViolationException e, WebRequest request) {
		Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
		List<ConstraintViolation<?>> errors = constraintViolations.stream().collect(Collectors.toList());
		String title = getTitle(errors.get(0).getMessage());
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(
				new ErrorResponse(Constants.FAILED, errors.get(0).getMessage(), request.getDescription(false), title));
	}

	private static ResponseEntity<ErrorResponse> sendResponse(RuntimeException exception, WebRequest request,
			HttpStatus status) {
		LOGGER.error("Exception cause: " + exception.getMessage());
		String title = getTitle(exception.getMessage());
		ErrorResponse errorResponse = new ErrorResponse(Constants.FAILED, exception.getLocalizedMessage(),
				request.getDescription(false), title);
		return new ResponseEntity<>(errorResponse, status);

	}

	private static String getTitle(String message) {
		String title = "";
		if (!StringUtils.isBlank(message)) {
			if (message.equalsIgnoreCase(ExceptionalMessages.INCORRECT_USERNAME_PASSWORD)) {
				title = "Problem logging in";
			}
			if (message.equalsIgnoreCase(ExceptionalMessages.PLEASE_ENTER_VALID_PASSCODE)
					|| message.equalsIgnoreCase(ExceptionalMessages.EMAIL_EXITS)) {
				title = "There is a problem";
			}
			if (message.equalsIgnoreCase(ExceptionalMessages.SESSION_EXPIRED)) {
				title = "Your Session is Expired.";
			}
			if (message.equalsIgnoreCase(ExceptionalMessages.PRODUCT_NOT_FOUND)
					|| message.equalsIgnoreCase(ExceptionalMessages.DATE_FORMAT)
					|| message.equalsIgnoreCase(ExceptionalMessages.RELATIONSHIP)
					|| message.equalsIgnoreCase("Your first name must contains 2-20 characters")
					|| message.equalsIgnoreCase("Your last name must contains 2-20 characters")) {
				title = "Almost done!";
			}

		}
		return title;
	}

	@ExceptionHandler(BadRequestException.class)
	public final ResponseEntity<ErrorResponse> handleBadRequestException(BadRequestException exception,
			WebRequest request) {
		return sendResponse(exception, request, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(NoRecordFoundException.class)
	public final ResponseEntity<ErrorResponse> handleNoRecordFoundException(NoRecordFoundException exception,
			WebRequest request) {
		return sendResponse(exception, request, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(RecordExistsException.class)
	public final ResponseEntity<ErrorResponse> handleRecordExistsException(RecordExistsException exception,
			WebRequest request) {
		return sendResponse(exception, request, HttpStatus.CONFLICT);
	}

	@ExceptionHandler(InternalServerException.class)
	public final ResponseEntity<ErrorResponse> handleInternalServerException(InvalidDateException exception,
			WebRequest request) {
		return sendResponse(exception, request, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(PasscodeExpiredException.class)
	public final ResponseEntity<ErrorResponse> handlePasscodeExpiredException(PasscodeExpiredException exception,
			WebRequest request) {
		return sendResponse(exception, request, HttpStatus.GONE);
	}

	@ExceptionHandler(ServiceUnavailableException.class)
	public final ResponseEntity<ErrorResponse> handleServiceUnavailableException(ServiceUnavailableException exception,
			WebRequest request) {
		return sendResponse(exception, request, HttpStatus.SERVICE_UNAVAILABLE);
	}

	@ExceptionHandler(ServiceGatewayTimeoutException.class)
	public final ResponseEntity<ErrorResponse> handleServiceGatewayTimeoutException(
			ServiceGatewayTimeoutException exception, WebRequest request) {
		return sendResponse(exception, request, HttpStatus.GATEWAY_TIMEOUT);
	}

	@ExceptionHandler(UnauthorizedException.class)
	public final ResponseEntity<ErrorResponse> handleUnauthorizedException(UnauthorizedException exception,
			WebRequest request) {
		return sendResponse(exception, request, HttpStatus.UNAUTHORIZED);
	}

}