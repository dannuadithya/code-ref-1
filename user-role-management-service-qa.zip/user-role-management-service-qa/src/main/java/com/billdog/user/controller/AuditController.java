package com.billdog.user.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.user.authorization.EnableTokenAuthorisation;
import com.billdog.user.exception.ErrorResponse;
import com.billdog.user.request.AuditRequest;
import com.billdog.user.response.LoginResponse;
import com.billdog.user.service.AuditService;
import com.billdog.user.service.MemberAuditService;
import com.billdog.user.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*")
public class AuditController {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AuditController.class);

	@Autowired
	MemberAuditService memberAuditService;

	@Autowired
	AuditService auditService;

	@Autowired
	UserController userController;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "Member audit info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/audit-info", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getMemberAudit(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestBody AuditRequest auditRequest) {
		userController.isValidToken(httpRequest, auditRequest.getUserId());
		return auditService.getAuditInfo(auditRequest);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Individual provider audit info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/audit-info", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getAuditInfoById(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam Long recordId,
			@RequestParam String moduleName, @RequestParam String subModuleName,
			@RequestParam(required = false) Integer pageNumber, @RequestParam(required = false) Integer pageLimit) {
		userController.isValidToken(httpRequest, userId);
		return auditService.getAuditInfoById(recordId, moduleName, subModuleName, pageNumber, pageLimit);
	}


	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Audit time info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/audit-time", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getAuditTimeperiods(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {

		userController.isValidToken(httpRequest, userId);
		return auditService.getAuditTimeperiods();
	}


	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Audit modules fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/audit-module", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getAuditModules(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {

		userController.isValidToken(httpRequest, userId);
		return auditService.getAuditModules();
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Audit sub modules fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/audit-sub-module", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getAuditSubModules(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId, @RequestParam String moduleName) {

		userController.isValidToken(httpRequest, userId);
		return auditService.getAuditSubModules(moduleName);
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Audit action info fetched successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/audit-action", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@EnableTokenAuthorisation
	public ResponseEntity<ViewResponse> getAuditActionInfo(@RequestHeader("authorization") String authorization,
			HttpServletRequest httpRequest, @RequestParam Long userId) {

		userController.isValidToken(httpRequest, userId);
		return auditService.getAuditActionInfo();
	}

}
