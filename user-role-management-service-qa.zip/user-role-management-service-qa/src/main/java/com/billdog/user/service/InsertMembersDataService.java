package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.CensusUploadFailed;
import com.billdog.user.entity.CountryPhoneCodeMaster;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.MemberProduct;
import com.billdog.user.entity.MemberTypeMaster;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.exception.RecordExistsException;
import com.billdog.user.repository.CensusUploadFailedRespository;
import com.billdog.user.repository.CountryPhoneCodeMasterRepository;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberProductRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.request.UploadMemberRequest;
import com.billdog.user.view.ErrorRecord;
import com.billdog.user.view.ViewCensusFailedDataResponse;
import com.billdog.user.view.ViewCensusFailedResponse;

@Service
public class InsertMembersDataService {

	private static final Logger LOGGER = LoggerFactory.getLogger(InsertMembersDataService.class);

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	MemberEmailRepository emailRepository;

	@Autowired
	MemberProductRepository memberProductRepository;

	@Autowired
	LoginService loginService;

	@Autowired
	MemberLoginService memberLoginService;

	@Autowired
	EntityService entityService;

	@Autowired
	MemberTypeMasterRepository typeMasterRepository;

	@Autowired
	AddMember addMember;

	@Autowired
	CensusUploadFailedRespository censusUploadFailedRespository;

	@Autowired
	CreateUserService createUserService;

	@Autowired
	CountryPhoneCodeMasterRepository countryPhoneCodeMasterRepository;

	@Autowired
	AuditService auditService;

	public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$",
			Pattern.CASE_INSENSITIVE);

	public static boolean validate(String emailStr) {
		Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(emailStr);
		return matcher.find();
	}

	public ErrorRecord insertMember(UploadMemberRequest request, Long employerId, SystemUsers systemUser,
			Optional<MemberTypeMaster> memberType) {
		try {
			if (StringUtils.isBlank(request.getFirstName())
					|| (request.getFirstName().length() < 2 && request.getFirstName().length() > 30)) {
				throw new BadRequestException(ExceptionalMessages.FIRST_NAME_LIMIT);
			}
			if (StringUtils.isBlank(request.getLastName())
					|| (request.getLastName().length() < 2 && request.getLastName().length() > 30)) {
				throw new BadRequestException(ExceptionalMessages.LAST_NAME_LIMIT);
			}

			/*
			 * if (StringUtils.isBlank(request.getCountryPhoneCode())) { throw new
			 * BadRequestException(ExceptionalMessages.PLEASE_PROVIDE_COUNTRY_CODE); }
			 */
			if (StringUtils.isBlank(request.getCountryPhoneCode())) {
				request.setCountryPhoneCode(Constants.COUNTRY_CODE);
			} else {
				int countMatches = StringUtils.countMatches(request.getCountryPhoneCode(), "+");
				if (countMatches == 0 && StringUtils.isNumeric(request.getCountryPhoneCode())) {
					request.setCountryPhoneCode("+" + request.getCountryPhoneCode());
				} else if (countMatches == 1
						&& !StringUtils.isNumeric(request.getCountryPhoneCode().replace("+", ""))) {
					throw new BadRequestException(ExceptionalMessages.PLEASE_PROVIDE_COUNTRY_CODE);
				} else if (countMatches > 1) {
					throw new BadRequestException(ExceptionalMessages.PLEASE_PROVIDE_COUNTRY_CODE);
				} else {
					throw new BadRequestException(ExceptionalMessages.PLEASE_PROVIDE_COUNTRY_CODE);
				}
			}

			if (!StringUtils.isBlank(request.getContactNumber())
					&& !StringUtils.isNumeric(request.getContactNumber())) {
				throw new BadRequestException(ExceptionalMessages.CONTACT_NUMBER);
			}

			if (request.getContactNumber() != null && !request.getContactNumber().isEmpty()
					&& (request.getContactNumber().length() <= 9 || request.getContactNumber().length() > 10)) {
				throw new BadRequestException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
			}
			if (StringUtils.isBlank(request.getEmail()) || !validate(request.getEmail())) {
				throw new BadRequestException(ExceptionalMessages.VALID_EMAIL);
			}

			Optional<MemberEmail> emailOptional = emailRepository
					.findByEmailAndPrimaryAndOrganizationId(request.getEmail(), true, systemUser.getOrganizationId());
			if (emailOptional.isPresent()) {
				throw new RecordExistsException(ExceptionalMessages.EMAIL_ALREADY_EXITS);
			}
			Optional<CountryPhoneCodeMaster> countryPhoneCode = countryPhoneCodeMasterRepository
					.findByPhoneNumberCodeAndOrganizationId(request.getCountryPhoneCode(),
							systemUser.getOrganizationId());
			if (!countryPhoneCode.isPresent()) {
				throw new BadRequestException(ExceptionalMessages.COUNTRY_CODE_NOT_FOUND);
			}
			Optional<MemberProduct> productOptional = memberProductRepository
					.findByProductNameAndOrganizationId(request.getProductType(), systemUser.getOrganizationId());

			if (!productOptional.isPresent()) {
				throw new NoRecordFoundException(ExceptionalMessages.PRODUCT_INVALID);
			}

			String auditId = auditService.getAuditId();
			Member member = saveMember(request, systemUser, productOptional.get(), memberType, employerId,
					countryPhoneCode, auditId);
			saveMemberEmail(request, member, auditId);
			// addMember.sendWelcomeEmail(request.getFirstName(), request.getEmail(),
			// EmailTitles.MEMBER_WELCOME);
		}

		catch (Exception e) {
			ErrorRecord errorRecord = new ErrorRecord();
			errorRecord.setMessage(e.getMessage());
			return errorRecord;
		}
		return null;
	}

	private void saveMemberEmail(UploadMemberRequest request, Member member, String auditId) {
		MemberEmail memberEmail = new MemberEmail();
		memberEmail.setCreatedAt(DateAndTimeUtil.now());
		memberEmail.setUpdatedAt(DateAndTimeUtil.now());
		memberEmail.setDeleted(false);
		memberEmail.setCreatedAt(DateAndTimeUtil.now());
		memberEmail.setUpdatedAt(DateAndTimeUtil.now());
		memberEmail.setMemberId(member);
		memberEmail.setEmail(request.getEmail());
		memberEmail.setPrimary(true);
		memberEmail.setOrganizationId(member.getOrganizationId());
		memberEmail.setUserId(member.getUserId());
		memberEmail.setAuditId(auditId);
		emailRepository.save(memberEmail);
	}

	private Member saveMember(UploadMemberRequest request, SystemUsers systemUsers, MemberProduct memberProduct,
			Optional<MemberTypeMaster> memberType, Long employerId, Optional<CountryPhoneCodeMaster> countryPhoneCode,
			String auditId) {
		Member member = new Member();
		member.setCreatedAt(DateAndTimeUtil.now());
		member.setFirstName(WordUtils.capitalizeFully(request.getFirstName()));
		member.setLastName(WordUtils.capitalizeFully(request.getLastName()));
		member.setOrganizationId(systemUsers.getOrganizationId());
		member.setUserId(systemUsers);
		member.setProductId(memberProduct);
		member.setStatus(StatusConstants.ENROLLED);
		member.setEmployerId(employerId);
		member.setPhoneNumber(request.getContactNumber());
		member.setMemberId(memberLoginService.getMemberId(systemUsers.getOrganizationId().getId()));
		member.setUpdatedAt(DateAndTimeUtil.now());
		if (memberType.isPresent()) {
			member.setMemberTypeMasterId(memberType.get());
		}
		if (countryPhoneCode.isPresent()) {
			member.setCountryPhoneCodeMasterId(countryPhoneCode.get());
		}
		member.setProfileUpdated(true);
		member.setAuditId(auditId);
		return memberRepository.save(member);
	}

	public void saveErrorRecord(UploadMemberRequest request, String message, SystemUsers systemUser, Long opportunityId,
			String fileName, Long employerId, String oppType) {
		LOGGER.info("saveErrorRecord method started");
		Optional<CensusUploadFailed> errorRecord = censusUploadFailedRespository
				.findByFileNameAndUserIdAndOpportunityIdAndEmail(fileName, systemUser.getId(), opportunityId,
						request.getEmail());
		if (errorRecord.isPresent()) {
			LOGGER.info("Updating existing error record with id::  {}", errorRecord.get().getId());
			if (!StringUtils.isBlank(request.getContactNumber())) {
				errorRecord.get().setContactNumber(request.getContactNumber());
			}
			if (!StringUtils.isBlank(request.getCountryPhoneCode())) {
				errorRecord.get().setCountryPhoneCode(request.getCountryPhoneCode());
			}

			if (!StringUtils.isBlank(request.getFirstName())) {
				errorRecord.get().setFirstName(request.getFirstName());
			}
			if (!StringUtils.isBlank(request.getLastName())) {
				errorRecord.get().setLastName(request.getLastName());
			}
			if (employerId != null) {
				errorRecord.get().setEmployerId(employerId);
			}
			if (!StringUtils.isBlank(message) && !StringUtils.isBlank(errorRecord.get().getErrorMessage())
					&& !StringUtils.contains(errorRecord.get().getErrorMessage(), message)) {
				errorRecord.get().setErrorMessage(errorRecord.get().getErrorMessage() + ", " + message);
			}
			errorRecord.get().setOpportunityType(oppType);
			if (!StringUtils.isBlank(request.getProductType())) {
				errorRecord.get().setProductType(request.getProductType());
			}
			errorRecord.get().setUpdatedAt(DateAndTimeUtil.now());

			censusUploadFailedRespository.save(errorRecord.get());
		} else {
			LOGGER.info("Creating error record");
			CensusUploadFailed uploadFailed = new CensusUploadFailed();
			if (!StringUtils.isBlank(request.getContactNumber())) {
				uploadFailed.setContactNumber(request.getContactNumber());
			}

			if (!StringUtils.isBlank(request.getCountryPhoneCode())) {
				uploadFailed.setCountryPhoneCode(request.getCountryPhoneCode());
			}
			if (!StringUtils.isBlank(request.getEmail())) {
				uploadFailed.setEmail(request.getEmail());
			}
			if (!StringUtils.isBlank(request.getFirstName())) {
				uploadFailed.setFirstName(request.getFirstName());
			}
			if (!StringUtils.isBlank(request.getLastName())) {
				uploadFailed.setLastName(request.getLastName());
			}
			if (employerId != null) {
				uploadFailed.setEmployerId(employerId);
			}
			if (!StringUtils.isBlank(message)) {
				uploadFailed.setErrorMessage(message);
			}
			uploadFailed.setOpportunityType(oppType);
			uploadFailed.setFileName(fileName);
			uploadFailed.setOpportunityId(opportunityId);
			uploadFailed.setUserId(systemUser.getId());
			uploadFailed.setOrganizationId(
					systemUser.getOrganizationId() != null ? systemUser.getOrganizationId().getId() : null);
			if (!StringUtils.isBlank(request.getProductType())) {
				uploadFailed.setProductType(request.getProductType());
			}
			uploadFailed.setCreatedAt(DateAndTimeUtil.now());
			uploadFailed.setUpdatedAt(DateAndTimeUtil.now());
			censusUploadFailedRespository.save(uploadFailed);
		}
		LOGGER.info("saveErrorRecord method ended");
	}

	public ResponseEntity<ViewCensusFailedDataResponse> getCensusFailedData(Long userId, Long opportunityId,
			Integer pageNumber, Integer pageLimit) {
		SystemUsers systemUsers = createUserService.getSystemUsers(userId);
		Page<CensusUploadFailed> records = censusUploadFailedRespository.getCensusFailedData(userId, opportunityId,
				getPageRequest(pageNumber, pageLimit));
		List<ViewCensusFailedResponse> data = new ArrayList<>();
		String userName = getUserName(systemUsers);
		records.forEach(record -> {
			ViewCensusFailedResponse failedResponse = new ViewCensusFailedResponse();
			failedResponse.setContactNumber(record.getContactNumber());
			failedResponse.setCountryPhoneCode(record.getCountryPhoneCode());
			failedResponse.setEmail(record.getEmail());
			failedResponse.setEmployerId(record.getEmployerId());
			failedResponse.setErrorMessage(record.getErrorMessage());
			failedResponse.setFileName(record.getFileName());
			failedResponse.setFirstName(record.getFirstName());
			failedResponse.setLastName(record.getLastName());
			failedResponse.setOpportunityType(record.getOpportunityType());
			failedResponse.setProductType(record.getProductType());
			failedResponse.setUpdatedAt(DateAndTimeUtil.convertLocalDateToMMDDYYYY(record.getUpdatedAt().toLocalDate())
					+ " " + DateAndTimeUtil.getTime(record.getUpdatedAt().toLocalTime()));
			failedResponse.setUpdatedBy(userName);
			data.add(failedResponse);
		});

		ViewCensusFailedDataResponse response = new ViewCensusFailedDataResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.CENSUS_FAILED_RECORDS);
		if (data.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(data);
		response.setTotalElements(records.getTotalElements());

		LOGGER.info("search member details method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private String getUserName(SystemUsers systemUsers) {
		String userName = null;
		if (!StringUtils.isBlank(systemUsers.getFirstName())) {
			userName = systemUsers.getFirstName();
		}
		if (!StringUtils.isBlank(systemUsers.getLastName())) {
			userName = userName + " " + systemUsers.getLastName();
		}
		return userName;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}
}
