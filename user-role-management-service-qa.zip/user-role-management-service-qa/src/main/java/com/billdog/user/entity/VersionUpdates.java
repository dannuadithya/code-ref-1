package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "VERSION_UPDATES")
@Table(name = "version_updates")
public class VersionUpdates extends BaseEntity {

	@Column(name = "VERSION")
	private String version;

	@ManyToOne
	@JoinColumn(name = "application_version_id")
	private ApplicationVersion applicationVersionId;

	@Column(name = "FORCE_UPDATE")
	private boolean forceUpdate;

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public ApplicationVersion getApplicationVersionId() {
		return applicationVersionId;
	}

	public void setApplicationVersionId(ApplicationVersion applicationVersionId) {
		this.applicationVersionId = applicationVersionId;
	}

	public boolean isForceUpdate() {
		return forceUpdate;
	}

	public void setForceUpdate(boolean forceUpdate) {
		this.forceUpdate = forceUpdate;
	}

}
