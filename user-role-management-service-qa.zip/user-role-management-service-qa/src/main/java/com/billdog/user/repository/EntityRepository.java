package com.billdog.user.repository;

import com.billdog.user.request.AuditRequest;
import com.billdog.user.request.ExternalUserRequest;
import com.billdog.user.request.UpdateExternalUserRequest;
import com.billdog.user.response.UpdateUserDetailsResponse;
import com.billdog.user.view.GetCarrierInfo;
import com.billdog.user.view.GetEmployerInfo;
import com.billdog.user.view.ViewExternalUser;
import com.billdog.user.view.ViewResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;

public interface EntityRepository {

	@GET("/entity/v1/carrierTypeInfo")
	public Call<GetCarrierInfo> getCarrierInfo(@Query("carrierTypeId") long carrierTypeId,
			@Query("organizationId") long organizationId);

	@GET("/entity/v1/employer-info")
	public Call<GetEmployerInfo> getEmployerInfo(@Query("employerId") long employerId);

	@POST("/entity/v1/external-user")
	public Call<ViewExternalUser> getExternalUserInfo(@Body ExternalUserRequest externalUserRequest);

	@PUT("/entity/v1/update-external-user") 
	public Call<UpdateUserDetailsResponse> updateExternalUser(@Body UpdateExternalUserRequest updateExternalUserRequest);

	@POST("/entity/v1/audit-info")
	public Call<ViewResponse> getAuditInfo(@Body AuditRequest auditRequest);

	@GET("/entity/v1/audit-info")
	public Call<ViewResponse> getAuditInfoById(@Query("recordId") Long recordId,
			@Query("moduleName") String moduleName, @Query("pageNumber") Integer pageNumber,
			@Query("pageLimit") Integer pageLimit);

}
