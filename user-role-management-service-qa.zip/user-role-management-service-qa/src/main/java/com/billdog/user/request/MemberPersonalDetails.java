package com.billdog.user.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class MemberPersonalDetails {

	private Long memberId;

	private Long memberprefixId;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Size(min = 2, max = 30, message = "Your first name must contains 2-30 characters")
	@NotBlank(message = "please enter First name")
	private String firstName;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Size(min = 2, max = 30, message = "Your last name must contains 2-30 characters")
	@NotBlank(message = "please enter last name")
	private String lastName;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String middleName;

	private Long memberGenderId;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
//	@Pattern(regexp = "/^[A-Za-z]+$/", message = "Invalid mobile number")
	private String mobileNumber;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String addressLine1;

	private Long stateId;

	private Long countryId;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String city;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	// @Size(max = 5, message = "zip code can be max 5 characters")
	private String zipCode;

	private Long countryPhoneCodeId;

	private String dateOfBirth;

	@NotNull(message = "productId must not be null")
	private Long productId;

	private String addressLine2;

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getStateId() {
		return stateId;
	}

	public void setStateId(Long stateId) {
		this.stateId = stateId;
	}

	public Long getCountryId() {
		return countryId;
	}

	public void setCountryId(Long countryId) {
		this.countryId = countryId;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public Long getMemberprefixId() {
		return memberprefixId;
	}

	public void setMemberprefixId(Long memberprefixId) {
		this.memberprefixId = memberprefixId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public Long getMemberGenderId() {
		return memberGenderId;
	}

	public void setMemberGenderId(Long memberGenderId) {
		this.memberGenderId = memberGenderId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Long getCountryPhoneCodeId() {
		return countryPhoneCodeId;
	}

	public void setCountryPhoneCodeId(Long countryPhoneCodeId) {
		this.countryPhoneCodeId = countryPhoneCodeId;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

}
