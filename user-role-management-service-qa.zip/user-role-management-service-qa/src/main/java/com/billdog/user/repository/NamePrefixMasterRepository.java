package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.NamePrefixMaster;
import com.billdog.user.entity.Organization;

public interface NamePrefixMasterRepository extends JpaRepository<NamePrefixMaster, Long> {

	List<NamePrefixMaster> findByOrganizationIdAndStatus(Organization organizationId, String active);

	Optional<NamePrefixMaster> findByIdAndStatus(long prefixId, String active);

}
