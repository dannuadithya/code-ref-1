package com.billdog.user.service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.NavigationScreen;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.RoleNavigationScreens;
import com.billdog.user.entity.Roles;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.exception.NavigationScreenAccessException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.repository.NavigationScreenRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.RoleNavigationScreensRepository;
import com.billdog.user.repository.RolesRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.CreateNavigationScreen;
import com.billdog.user.request.GetRoleScreens;
import com.billdog.user.request.UpdateNavigationScreen;
import com.billdog.user.view.ViewResponse;
import com.billdog.user.view.ViewRoleScreens;
import com.billdog.user.view.ViewRoleSubScreens;

@Service
public class NavigationService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(NavigationService.class);
	@Autowired
	NavigationScreenRepository navigationScreenRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	SystemUsersrepository systemUsersrepository;

	@Autowired
	RoleNavigationScreensRepository roleNavigationScreensRepository;

	@Autowired
	RolesRepository rolesRepository;

	@Autowired
	LogoutService logoutService;

	@Autowired
	AuditService auditService;

	/*
	 * This method is used to create new navigation screen
	 */
	@Transactional
	public ViewResponse createNavigationPage(CreateNavigationScreen screen) {
		LOGGER.info("createNavigationPage method started..!");

		Optional<Organization> organizationOpt = organizationRepository.findById(screen.getOrganizationId());

		LOGGER.debug("providing organization based on given input..!");

		if (!organizationOpt.isPresent()) {
			throw new NoRecordFoundException(Constants.ORGANIZATION_NOT_FOUND);
		}
		NavigationScreen navigationScreen = new NavigationScreen();
		if (screen.getParentId() > 0) {
			Optional<NavigationScreen> optional = navigationScreenRepository.findByIdAndType(screen.getParentId(),
					screen.getType().toString());
			if (!optional.isPresent()) {
				throw new NoRecordFoundException(Constants.SCREESN_NOT_FOUND);
			}
			LOGGER.debug("saving data into table if parentId greater then zero..!");
			navigationScreen.setParentId(optional.get());
		}
		navigationScreen.setCreatedAt(LocalDateTime.now());
		navigationScreen.setUpdatedAt(LocalDateTime.now());
		navigationScreen.setOrganizationId(organizationOpt.get());
		navigationScreen.setName(screen.getName());
		navigationScreen.setStatus(Constants.ACTIVE);
		navigationScreen.setType(screen.getType().toString());
		navigationScreen.setUrl(screen.getUrl());
		navigationScreenRepository.save(navigationScreen);
		setScreenAccess(navigationScreen, screen.getType().toString());
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setId(navigationScreen.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.NAVIGATION_SCREEN_CREATED);
		LOGGER.info("createNavigationPage method ends..!");
		return viewResponse;

	}

	/**
	 * @param navigationScreen
	 */
	public void setScreenAccess(NavigationScreen navigationScreen, String type) {
		LOGGER.info("saving screen access..!");
		List<Roles> roles = rolesRepository.findByOrganizationIdAndUserType(navigationScreen.getOrganizationId(), type);
		LOGGER.debug("fetching list of roles based on organization..!");
		List<RoleNavigationScreens> roleNavigationScreens = new ArrayList<>();
		roles.forEach(role -> {
			RoleNavigationScreens roleNavigationScreen = new RoleNavigationScreens();
			roleNavigationScreen.setCreatedAt(LocalDateTime.now());
			roleNavigationScreen.setUpdatedAt(LocalDateTime.now());
			roleNavigationScreen.setReadAccess(false);
			roleNavigationScreen.setWriteAccess(false);
			roleNavigationScreen.setRoleId(role);
			roleNavigationScreen.setOrganizationId(role.getOrganizationId());
			roleNavigationScreen.setNavigationScreensId(navigationScreen);
			roleNavigationScreens.add(roleNavigationScreen);
		});
		roleNavigationScreensRepository.saveAll(roleNavigationScreens);
	}

	/*
	 * this method takes list of role UpdateScreenRequest objects to update screen
	 * access by role
	 * 
	 */
	@Transactional
	public ViewResponse updateScreenAccess(UpdateNavigationScreen request) {
		LOGGER.info("updateScreenAccess method starts..!");
		Optional<SystemUsers> appUser = systemUsersrepository.findById(request.getUserId());
		if (!appUser.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		Optional<Roles> roleOptional = rolesRepository.findById(request.getRoleId());
		if (!roleOptional.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		LOGGER.debug("checking if user as previlege to update..!");
		// checkUser(appUser.get(), roleOptional.get());

		List<RoleNavigationScreens> screenRequests = new ArrayList<>();
		ViewResponse viewResponse = new ViewResponse();
		String auditId = auditService.getAuditId();
		request.getData().forEach(screen -> {
			Optional<RoleNavigationScreens> optional = roleNavigationScreensRepository.findByIdAndRoleId(screen.getId(),
					roleOptional.get());
			if (!optional.isPresent()) {
				throw new NoRecordFoundException(ExceptionalMessages.ROLE_SCREEN_MAPPING);
			}
			LOGGER.debug("updating read and write access..!");
			RoleNavigationScreens navigationScreens = optional.get();
			if (screen.isCustom() != optional.get().isCustom() || screen.isRead() != optional.get().isReadAccess()
					|| screen.isWrite() != optional.get().isWriteAccess()) {
				navigationScreens.setWriteAccess(screen.isWrite());
				navigationScreens.setReadAccess(screen.isRead());
				navigationScreens.setCustom(screen.isCustom());
				viewResponse.setPopup(true);
				navigationScreens.setAuditId(auditId);
				navigationScreens.setUserId(request.getUserId());
			}
			if (screen.getSubPage() != null && !screen.getSubPage().isEmpty()) {
				screen.getSubPage().forEach(screen2 -> {
					Optional<RoleNavigationScreens> optionalscreen2 = roleNavigationScreensRepository
							.findByIdAndRoleId(screen2.getId(), roleOptional.get());
					if (!optionalscreen2.isPresent()) {
						throw new NoRecordFoundException(ExceptionalMessages.ROLE_SCREEN_MAPPING);
					}
					RoleNavigationScreens navigationScreens2 = optionalscreen2.get();
					if (screen2.isCustom() != optionalscreen2.get().isCustom()
							|| screen2.isRead() != optionalscreen2.get().isReadAccess()
							|| screen2.isWrite() != optionalscreen2.get().isWriteAccess()) {
						navigationScreens2.setWriteAccess(screen2.isWrite());
						navigationScreens2.setReadAccess(screen2.isRead());
						navigationScreens2.setCustom(screen2.isCustom());
						viewResponse.setPopup(true);
						navigationScreens2.setAuditId(auditId);
						navigationScreens2.setUserId(request.getUserId());
					}
					if (screen2.getTabs() != null && !screen2.getTabs().isEmpty()) {
						screen2.getTabs().forEach(screen3 -> {
							Optional<RoleNavigationScreens> optionalscreen3 = roleNavigationScreensRepository
									.findByIdAndRoleId(screen3.getId(), roleOptional.get());
							if (!optionalscreen3.isPresent()) {
								throw new NoRecordFoundException(
										ExceptionalMessages.ROLE_SCREEN_MAPPING);
							}
							RoleNavigationScreens navigationScreens3 = optionalscreen3.get();
							if (screen3.isCustom() != optionalscreen3.get().isCustom()
									|| screen3.isRead() != optionalscreen3.get().isReadAccess()
									|| screen3.isWrite() != optionalscreen3.get().isWriteAccess()) {
								navigationScreens3.setWriteAccess(screen3.isWrite());
								navigationScreens3.setReadAccess(screen3.isRead());
								navigationScreens3.setCustom(screen3.isCustom());
								viewResponse.setPopup(true);
								navigationScreens3.setAuditId(auditId);
								navigationScreens3.setUserId(request.getUserId());
							}
							screenRequests.add(navigationScreens3);
						});
					}
					screenRequests.add(navigationScreens2);
				});
			}
			screenRequests.add(navigationScreens);
		});
		if (viewResponse.isPopup()) {
			roleOptional.get().setAuditId(auditId);
			roleOptional.get().setUpdatedAt(DateAndTimeUtil.now());
			roleOptional.get().setUserId(appUser.get().getId());
			roleNavigationScreensRepository.saveAll(screenRequests);
			logoutService.logoutRoleUsers(roleOptional.get());
			rolesRepository.save(roleOptional.get());
		}
		viewResponse.setUserId(request.getUserId());
		viewResponse.setPopup(false);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.NAVIGATION_SCREEN_ACCESS_UPDATED + roleOptional.get().getRole());
		LOGGER.info("updateScreenAccess method ends..!");
		return viewResponse;
	}

	private void checkUser(SystemUsers systemUsers, Roles role) {
		LOGGER.info("checking if user as previlege to update..!");
		if (systemUsers.getRoleId().getRole().equalsIgnoreCase(role.getRole())) {
			String message = ExceptionalMessages.OWN_PREVILEGES.replace("<ROLE>", role.getRole());
			throw new NavigationScreenAccessException(message);
		} else if (systemUsers.getRoleId().getRole().equalsIgnoreCase(StatusConstants.SUPER_ADMIN)) {
			if (!role.getRole().equalsIgnoreCase(StatusConstants.SYSTEM_ADMIN)) {
				String message = ExceptionalMessages.SUPER_ADMIN_CAN_NOT_UPDATE_EXCEPT_SYSTEM_ADMIN.replace("<ROLE>",
						role.getRole());
				throw new NavigationScreenAccessException(message);
			}
		} else if (systemUsers.getRoleId().getRole().equalsIgnoreCase(StatusConstants.SYSTEM_ADMIN)) {
			if (role.getRole().equalsIgnoreCase(StatusConstants.SUPER_ADMIN)) {
				String message = ExceptionalMessages.SYSTEM_ADMIN_CAN_NOT_UPDATE_PRIVILEGES.replace("<ROLE>",
						role.getRole());
				throw new NavigationScreenAccessException(message);
			}
		} else {
			String message = ExceptionalMessages.OWN_PREVILEGES.replace("<ROLE>", role.getRole());
			throw new NavigationScreenAccessException(message);
		}
	}

	/*
	 * This method will take userId and roleId as input and provide all screens that
	 * are mapped with a role in an organization.
	 */
	@Transactional
	public ViewResponse getRoleScreens(GetRoleScreens getRoleScreens) {
		LOGGER.info("getRolesScreens method started..!");
		Optional<SystemUsers> appUser = systemUsersrepository.findById(getRoleScreens.getUserId());
		if (!appUser.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}

		Optional<Roles> roles = rolesRepository.findById(getRoleScreens.getRoleId());
		if (!roles.isPresent()) {
			throw new InValidInputException(ExceptionalMessages.ROLE_NOT_FOUND);
		}
		checkUserAccess(appUser.get().getRoleId().getRole(), roles.get().getRole());
		LOGGER.debug("Fetching all screens for role id:: " + roles.get().getId());
		List<RoleNavigationScreens> navigationScreens = roleNavigationScreensRepository
				.findByRoleIdWithOrganizationId(roles.get(), roles.get().getOrganizationId(),
						roles.get().getUserType());

		List<ViewRoleScreens> roleScreensList = getNavigationScreens(navigationScreens);

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setUserId(getRoleScreens.getUserId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(roleScreensList);
		viewResponse.setRoleId(getRoleScreens.getRoleId());
		return viewResponse;
	}

	private void checkUserAccess(String userRole, String role) {
		String message = ExceptionalMessages.OWN_PREVILEGES_ACCESS.replace("<ROLE>", role);
		if (userRole.equalsIgnoreCase(role)) {
			throw new NavigationScreenAccessException(message);
		} else if (!userRole.equalsIgnoreCase(StatusConstants.SYSTEM_ADMIN)
				&& !userRole.equalsIgnoreCase(StatusConstants.SUPER_ADMIN)) {
			throw new NavigationScreenAccessException(message);
		} else if (userRole.equalsIgnoreCase(StatusConstants.SYSTEM_ADMIN)) {
			if (role.equalsIgnoreCase(StatusConstants.SUPER_ADMIN)) {
				throw new NavigationScreenAccessException(message);
			}
		}
	}

	/*
	 * this method is used to set the navigation screens data in nested list format
	 */
	private List<ViewRoleScreens> getNavigationScreens(List<RoleNavigationScreens> navigationScreens) {
		LOGGER.info("getNavigationScreens method started..!");
		List<ViewRoleScreens> roleScreensList = new ArrayList<>();
		LOGGER.debug("fetching list of screens and there access..!");
		navigationScreens.forEach(screen -> {
			if (screen.getNavigationScreensId().getParentId() == null) {
				ViewRoleScreens roleScreens = new ViewRoleScreens();
				roleScreens.setId(screen.getId());
				roleScreens.setNavigation(screen.getNavigationScreensId().getName());
				roleScreens.setRead(screen.isReadAccess());
				roleScreens.setWrite(screen.isWriteAccess());
				roleScreens.setCustom(screen.isCustom());
				List<ViewRoleSubScreens> roleScreenList = new ArrayList<>();
				screen.getNavigationScreensId().getNavigationScreens().forEach(childScreen -> {
					if (childScreen.getStatus().equalsIgnoreCase(StatusConstants.ACTIVE)) {
						ViewRoleSubScreens roleScreen = new ViewRoleSubScreens();
						RoleNavigationScreens navigationScreen = findByScreenIsIn(navigationScreens, childScreen,
								screen);
						if (navigationScreen != null) {
							roleScreen.setRead(navigationScreen.isReadAccess());
							roleScreen.setWrite(navigationScreen.isWriteAccess());
							roleScreen.setId(navigationScreen.getId());
							roleScreen.setDisplayOrder(childScreen.getDisplayOrder());
							roleScreen.setCustom(navigationScreen.isCustom());
							if (!screen.isCustom()) {
								roleScreen.setEnable(true);
							}
						}
						roleScreen.setPageName(childScreen.getName());

						List<ViewRoleSubScreens> roleScreensList2 = new ArrayList<>();
						childScreen.getNavigationScreens().forEach(childScreen2 -> {
							if (childScreen2.getStatus().equalsIgnoreCase(StatusConstants.ACTIVE)) {
								ViewRoleSubScreens roleScreen2 = new ViewRoleSubScreens();
								RoleNavigationScreens navigationScreen2 = findByScreenIsIn(navigationScreens,
										childScreen2, screen);
								if (navigationScreen2 != null) {
									roleScreen2.setRead(navigationScreen2.isReadAccess());
									roleScreen2.setWrite(navigationScreen2.isWriteAccess());
									roleScreen2.setId(navigationScreen2.getId());
									roleScreen2.setDisplayOrder(childScreen2.getDisplayOrder());
									if (!roleScreen.isCustom()) {
										roleScreen2.setEnable(true);
									}
								}
								roleScreen2.setPageName(childScreen2.getName());
								roleScreensList2.add(roleScreen2);
							}
						});
						if (!roleScreensList2.isEmpty()) {
							roleScreen.setTabs(roleScreensList2.stream()
									.sorted(Comparator.comparing(ViewRoleSubScreens::getDisplayOrder))
									.collect(Collectors.toList()));
						}
						roleScreenList.add(roleScreen);
					}
				});
				if (!roleScreenList.isEmpty()) {
					roleScreens.setSubPage(
							roleScreenList.stream().sorted(Comparator.comparing(ViewRoleSubScreens::getDisplayOrder))
									.collect(Collectors.toList()));
				}
				roleScreensList.add(roleScreens);
			} else {
				return;
			}
		});
		LOGGER.info("getNavigationScreens method ended..!");
		return roleScreensList;
	}

	/*
	 * this method is used to get RoleNavigationScreen object to get read and write
	 * access.
	 */
	public RoleNavigationScreens findByScreenIsIn(Collection<RoleNavigationScreens> navigationScreens,
			NavigationScreen navigationScreen, RoleNavigationScreens roleNavigationScreens) {
		return navigationScreens.stream()
				.filter(screen -> screen.getNavigationScreensId().equals(navigationScreen)
						&& screen.getRoleId().equals(roleNavigationScreens.getRoleId())
						&& screen.getOrganizationId().equals(roleNavigationScreens.getOrganizationId()))
				.findFirst().orElse(null);
	}

}
