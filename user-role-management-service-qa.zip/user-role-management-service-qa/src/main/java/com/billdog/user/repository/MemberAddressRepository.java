package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.history.RevisionRepository;

import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberAddress;

public interface MemberAddressRepository
		extends JpaRepository<MemberAddress, Long>, RevisionRepository<MemberAddress, Long, Integer> {

	Optional<MemberAddress> findByMemberId(Member member);

	List<MemberAddress> findAllByMemberIdIn(List<Member> membersList);

}
