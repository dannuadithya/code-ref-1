package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.AuthTokens;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.Roles;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.InvalidAuthTokenException;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.repository.AuthTokensRepository;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.LockMemberRequest;
import com.billdog.user.view.MemberResponse;
import com.billdog.user.view.ViewMemberResponse;

@Service
public class LogoutService {

	private static final Logger LOGGER = LoggerFactory.getLogger(LogoutService.class);

	@Autowired
	AuthTokensRepository authTokensRepository;

	@Autowired
	MemberService memberService;

	@Autowired
	LoginService loginService;

	@Value("${user.jwt.token.minutes}")
	private Integer userTokenExpiryTime;

	@Value("${member.jwt.token.minutes}")
	private Integer memberTokenExpiryTime;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Autowired
	SystemUsersrepository systemUsersRepository;

	public MemberResponse memberLogout(String token, long memberId) {
		LOGGER.info("Member logout method started..!");
		Member member = memberService.getMember(memberId);
		Optional<AuthTokens> memberTokenOptional = authTokensRepository.findByTokenAndMemberId(token, member);
		if (memberTokenOptional.isPresent()) {
			memberTokenOptional.get().setExpiredAt(DateAndTimeUtil.now());
			authTokensRepository.save(memberTokenOptional.get());
		} else {
			throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
		}
		MemberResponse logoutResponse = new MemberResponse();
		logoutResponse.setStatusText(Constants.SUCCESS);
		logoutResponse.setMessage(Constants.MEMBER_LOGOUT);
		LOGGER.info("Member logout method ended..!");
		return logoutResponse;
	}

	public MemberResponse userLogout(String token, long userId) {
		LOGGER.info("User logout method started..!");
		SystemUsers user = loginService.getSystemUsers(userId);
		Optional<AuthTokens> userTokenOptional = authTokensRepository.findByTokenAndUserId(token, user);
		if (userTokenOptional.isPresent()) {

			userTokenOptional.get().setExpiredAt(DateAndTimeUtil.now());
			authTokensRepository.save(userTokenOptional.get());
		} else {
			throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
		}
		MemberResponse logoutResponse = new MemberResponse();
		logoutResponse.setStatusText(Constants.SUCCESS);
		logoutResponse.setMessage(Constants.USER_LOGOUT);
		LOGGER.info("User logout method ended..!");
		return logoutResponse;
	}

	public MemberResponse updateMemberTokenTime(String token, long memberId) {
		
		LOGGER.info("Update member token time method started..!");
		Member member = memberService.getMember(memberId);
		Optional<AuthTokens> memberTokenOptional = authTokensRepository.findByTokenAndMemberId(token, member);
		if (memberTokenOptional.isPresent()) {
			memberTokenOptional.get()
					.setExpiredAt(memberTokenOptional.get().getExpiredAt().plusMinutes(memberTokenExpiryTime));
			authTokensRepository.save(memberTokenOptional.get());
		} else {
			throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
		}
		MemberResponse logoutResponse = new MemberResponse();
		logoutResponse.setStatusText(Constants.SUCCESS);
		logoutResponse.setMessage(Constants.MEMBER_TOKEN_EXPIRED_TIME_UPDATED);
		LOGGER.info("Update member token time method ended..!");
		return logoutResponse;
	}

	public ViewMemberResponse lockMember(LockMemberRequest lockMemberRequest) {
		LOGGER.info("lock Member method started..!");

		Optional<Member> member = memberRepository.findById(lockMemberRequest.getMemberId());
		if (!member.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		if (lockMemberRequest.isLock()) {
			member.get().setLocked(lockMemberRequest.isLock());
			member.get().setLockedFromWeb(true);
		} else {
			member.get().setLocked(lockMemberRequest.isLock());
			member.get().setLockedFromWeb(false);
			Optional<MemberEmail> memberEmail = memberEmailRepository.findByMemberIdAndEmail(member.get(),
					lockMemberRequest.getEmail());
			if (memberEmail.isPresent()) {
				memberEmail.get().setPasscodeIncorrectCount(0l);
				memberEmail.get().setPasswordIncorrectCount(0l);
				memberEmailRepository.save(memberEmail.get());
			}
		}
		member.get().setUpdatedAt(DateAndTimeUtil.now());
		memberRepository.save(member.get());

		ViewMemberResponse response = new ViewMemberResponse();
		response.setStatusText(Constants.SUCCESS);
		if (lockMemberRequest.isLock()) {
			memberService.expireToken(member.get());
			response.setMessage(Constants.MEMBER_LOCKED);
		} else {
			response.setMessage(Constants.MEMBER_UNLOCK);
		}
		LOGGER.info("lock Member method ended..!");
		return response;
	}

	public void logoutRoleUsers(Roles role) {
		List<SystemUsers> usersList = systemUsersRepository.findAllByRoleId(role);
		List<AuthTokens> userTokenList = authTokensRepository.findAllByUserIdIn(usersList);
		List<AuthTokens> updatedTokens = new ArrayList<>();
		userTokenList.forEach(token -> {
			token.setExpiredAt(DateAndTimeUtil.now());
			token.setReason(StatusConstants.ROLE_ACCESS_UPDATED);
			token.setUpdatedAt(DateAndTimeUtil.now());
			updatedTokens.add(token);
		});
		authTokensRepository.saveAll(updatedTokens);
	}

	public void logoutUserByReason(SystemUsers user, String reason) {
		Optional<AuthTokens> userToken = authTokensRepository.findByUserId(user);
		if (userToken.isPresent()) {
			userToken.get().setExpiredAt(DateAndTimeUtil.now());
			userToken.get().setReason(reason);
			userToken.get().setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(userToken.get());
		}
	}

	public void logoutMemberByReason(Member member, String reason) {
		Optional<AuthTokens> memberToken = authTokensRepository.findByMemberId(member);
		if (memberToken.isPresent()) {
			memberToken.get().setExpiredAt(DateAndTimeUtil.now());
			memberToken.get().setReason(reason);
			memberToken.get().setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(memberToken.get());
		}
	}

	public String getExceptionMessage(AuthTokens authTokens) {
		String message = "";
		String organization = "<Organisation email>";
		String status = "<Status>";
		if (authTokens != null && authTokens.getReason() != null) {
			switch (authTokens.getReason()) {
			case StatusConstants.ROLE_ACCESS_UPDATED:
				message = ExceptionalMessages.USER_ROLE_UPDATED;
				break;
			case StatusConstants.ROLE_UPDATED:
				message = ExceptionalMessages.ROLE_PRIVILEGE_UPDATED;
				break;
			case StatusConstants.INACTIVE:
				if (authTokens.getMemberId() != null) {
					message = ExceptionalMessages.MEMBER_ACCOUNT_DISABLED.replace(status,
							authTokens.getMemberId().getStatus());
					message = message.replace(organization, authTokens.getMemberId().getOrganizationId().getEmail());
				}
				if (authTokens.getUserId() != null) {
					message = ExceptionalMessages.USER_ACCOUNT_DISABLED.replace(status,
							authTokens.getUserId().getStatus());
					message = message.replace(organization, authTokens.getUserId().getOrganizationId().getEmail());
				}
				break;
			case StatusConstants.TERMINATED:
				if (authTokens.getMemberId() != null || authTokens.getUserId() != null) {
					message = ExceptionalMessages.MEMBER_ACCOUNT_DISABLED.replace(status,
							authTokens.getMemberId().getStatus());
					message = ExceptionalMessages.MEMBER_ACCOUNT_DISABLED.replace(organization,
							authTokens.getMemberId().getOrganizationId().getEmail());
				}
				break;
			default:
				message = ExceptionalMessages.SESSION_EXPIRED;
			}
		}

		else {
			message = ExceptionalMessages.SESSION_EXPIRED;
		}
		return message;
	}
	
	public String getExceptionMessage(String reason, String email,String userStatus) {
		String message = "";
		String organization = "<Organisation email>";
		String status = "<Status>";
		if (reason!= null) {
			switch (reason) {
			case StatusConstants.ROLE_ACCESS_UPDATED:
				message = ExceptionalMessages.USER_ROLE_UPDATED;
				break;
			case StatusConstants.ROLE_UPDATED:
				message = ExceptionalMessages.ROLE_PRIVILEGE_UPDATED;
				break;
			case StatusConstants.INACTIVE:
				if (reason != null) {
					message = ExceptionalMessages.MEMBER_ACCOUNT_DISABLED.replace(status,
							userStatus);
					message = message.replace(organization, email);
				}
				if (userStatus != null) {
					message = ExceptionalMessages.USER_ACCOUNT_DISABLED.replace(status,
							userStatus);
					message = message.replace(organization, email);
				}
				break;
			case StatusConstants.TERMINATED:
				if (userStatus != null) {
					message = ExceptionalMessages.MEMBER_ACCOUNT_DISABLED.replace(status,
							userStatus);
					message = ExceptionalMessages.MEMBER_ACCOUNT_DISABLED.replace(organization,
							email);
				}
				break;
			default:
				message = ExceptionalMessages.SESSION_EXPIRED;
			}
		}

		else {
			message = ExceptionalMessages.SESSION_EXPIRED;
		}
		return message;
	}

	public void updateMemberToken(Member member) {
		Optional<AuthTokens> memberToken = authTokensRepository.findByMemberId(member);
		if (memberToken.isPresent()) {
			memberToken.get().setReason(null);
			memberToken.get().setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(memberToken.get());
		}
	}

	public void updateUserToken(SystemUsers user) {
		Optional<AuthTokens> userToken = authTokensRepository.findByUserId(user);
		if (userToken.isPresent()) {
			userToken.get().setUpdatedAt(DateAndTimeUtil.now());
			userToken.get().setReason(null);
			authTokensRepository.save(userToken.get());
		}
	}
}
