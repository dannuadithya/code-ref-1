package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.text.WordUtils;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.common.UserType;
import com.billdog.user.request.CreateUserRequest;

@Entity(name = "systemUsers")
@Table(name = "system_users", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "email_org_index", columnList = "EMAIL,ORGANIZATION_ID", unique = false) })
public class SystemUsers extends BaseEntity {

	@Audited
	@Column(name = "FIRST_NAME")
	private String firstName;

	@Audited
	@Column(name = "MIDDLE_NAME")
	private String middleName;

	@Audited
	@Column(name = "LAST_NAME")
	private String lastName;

	@Audited
	@Column(name = "EMAIL")
	private String email;

	@Audited
	@Column(name = "MOBILE_NUMBER")
	private String mobileNumber;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "ROLE_ID")
	private Roles roleId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "NAME_PREFIX_MASTER_ID")
	private NamePrefixMaster namePrefixMasterid;

	@Audited
	@Column(name = "status")
	private String status;

	@Column(name = "locked")
	private boolean locked;

	@Audited
	@Column(name = "locked_from_web")
	private boolean lockedFromWeb;

	@Audited
	@Column(name = "user_type")
	private String userType;

	@Audited
	@Column(name = "user_Id")
	private Long userId;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public boolean isLockedFromWeb() {
		return lockedFromWeb;
	}

	public void setLockedFromWeb(boolean lockedFromWeb) {
		this.lockedFromWeb = lockedFromWeb;
	}

	public SystemUsers(CreateUserRequest createUserRequest, Roles role, NamePrefixMaster namePrefixMaster) {
		this.email = createUserRequest.getEmail().toLowerCase();
		this.firstName = WordUtils.capitalizeFully(createUserRequest.getFirstName());
		this.lastName = WordUtils.capitalizeFully(createUserRequest.getLastName());
		this.middleName = WordUtils.capitalizeFully(createUserRequest.getMiddleName());
		this.mobileNumber = createUserRequest.getMobileNumber();
		this.namePrefixMasterid = namePrefixMaster;
		this.organizationId = role.getOrganizationId();
		this.roleId = role;
		this.userId = createUserRequest.getUserId();
		this.status = StatusConstants.ENROLLED;
		this.userType = UserType.Internal.toString();
		setCreatedAt(DateAndTimeUtil.now());
		setUpdatedAt(DateAndTimeUtil.now());
	}

	public SystemUsers() {
	}

	public boolean isLocked() {
		return locked;
	}

	public void setLocked(boolean locked) {
		this.locked = locked;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public NamePrefixMaster getNamePrefixMasterid() {
		return namePrefixMasterid;
	}

	public void setNamePrefixMasterid(NamePrefixMaster namePrefixMasterid) {
		this.namePrefixMasterid = namePrefixMasterid;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Roles getRoleId() {
		return roleId;
	}

	public void setRoleId(Roles roleId) {
		this.roleId = roleId;
	}

}