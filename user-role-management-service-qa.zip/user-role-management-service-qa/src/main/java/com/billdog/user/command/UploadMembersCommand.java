package com.billdog.user.command;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.IntStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.billdog.user.common.Constants;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.entity.MemberTypeMaster;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberProductRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.request.UploadMemberRequest;
import com.billdog.user.service.EntityService;
import com.billdog.user.service.InsertMembersDataService;
import com.billdog.user.service.LoginService;
import com.billdog.user.service.MemberLoginService;
import com.billdog.user.util.UploadMembersExcelLoader;
import com.billdog.user.view.ErrorRecord;
import com.billdog.user.view.GetEmployerInfo;
import com.billdog.user.view.ViewCensusUploadResponse;
import com.billdog.user.view.ViewResponse;

@Service
public class UploadMembersCommand {

	private static final Logger LOGGER = LoggerFactory.getLogger(UploadMembersCommand.class);

	@Autowired
	InsertMembersDataService insertMembersDataService;


	@Autowired
	MemberRepository memberRepository;

	@Autowired
	MemberEmailRepository emailRepository;

	@Autowired
	MemberProductRepository memberProductRepository;

	@Autowired
	LoginService loginService;

	@Autowired
	MemberLoginService memberLoginService;

	@Autowired
	EntityService entityService;

	@Autowired
	MemberTypeMasterRepository typeMasterRepository;

	private void checkEmployer(Long employerId) {
		GetEmployerInfo employerInfo = entityService.getEmployerInfo(employerId);
		if (!employerInfo.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			throw new NoRecordFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
		}
	}

	public ResponseEntity<ViewResponse> excute(Long userId, Long employerId, Long opportunityId, MultipartFile request,
			String opportunityType) {
		long startTime = System.currentTimeMillis();

		ViewCensusUploadResponse censusUploadResponse = new ViewCensusUploadResponse();
		censusUploadResponse.setFailedRecordsCount(0l);
		censusUploadResponse.setSuccessRecordsCount(0l);
		UploadMembersExcelLoader membersExcelLoader = new UploadMembersExcelLoader(request);
		// check whether the given sheet is valid sheet or not.
		membersExcelLoader.isValidSheet();
		String fileName = membersExcelLoader.getFileName();
		List<ErrorRecord> errors = new ArrayList<>();
		List<UploadMemberRequest> requests = new ArrayList<>();
		checkEmployer(employerId);
		SystemUsers systemUser = loginService.getSystemUsers(userId);
		Optional<MemberTypeMaster> memberType = typeMasterRepository
				.findByTypeNameAndOrganizationId(opportunityType, systemUser.getOrganizationId());
		if (!memberType.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.OPPORTUNITY_TYPE_NOT_FOUND);
		}

		IntStream.range(1, membersExcelLoader.totalNumberOfRows()).forEach(productIndex -> {
			LOGGER.info("Started processing row ------> {}", (productIndex + 1));
			// read row of the sheet from row 2
			Optional<UploadMemberRequest> uploadProductRequest = membersExcelLoader.next();
			// if row is empty read next row
			if (!uploadProductRequest.isPresent()) {
				LOGGER.info("Data not present in row ------> {}", (productIndex + 1));
				return;
			}
			// if row is not empty process the data.
			UploadMemberRequest uploadProductsRequest = uploadProductRequest.get();
			requests.add(uploadProductsRequest);
			// If any exception is thrown while reading data save the error to the list
			if (uploadProductsRequest.getErrorRecord() != null) {
				errors.add(uploadProductsRequest.getErrorRecord());
				insertMembersDataService.saveErrorRecord(uploadProductsRequest,
						uploadProductsRequest.getErrorRecord().getMessage(), systemUser, opportunityId, fileName,
						employerId, opportunityType);
				censusUploadResponse.setFailedRecordsCount(censusUploadResponse.getFailedRecordsCount() + 1);
			} else {
				ErrorRecord insertData = insertMembersDataService.insertMember(uploadProductsRequest, employerId,
						systemUser, memberType);
				if (insertData != null) {
					insertData.setRowId(productIndex + 1);
					errors.add(insertData);
					insertMembersDataService.saveErrorRecord(uploadProductsRequest,
							insertData.getMessage(), systemUser, opportunityId, fileName, employerId, opportunityType);
					censusUploadResponse.setFailedRecordsCount(censusUploadResponse.getFailedRecordsCount() + 1);
					return;
				} else {
					censusUploadResponse.setSuccessRecordsCount(censusUploadResponse.getSuccessRecordsCount() + 1);
				}
			}
			LOGGER.info("Finished processing row ------> {}", (productIndex + 1));
		});
		LOGGER.info("Total rows ------> {}", requests.size());
		LOGGER.info("Number of rows with errors ------> {}", errors.size());
		LOGGER.info("Total rows uploaded successfully ------> {}", (requests.size() - errors.size()));
		LOGGER.info(
				"Total time to upload the sheet ------> {} milliseconds", (System.currentTimeMillis() - startTime));
		censusUploadResponse.setErrors(errors);
		censusUploadResponse.setTotalRecordsCount(
				censusUploadResponse.getFailedRecordsCount() + censusUploadResponse.getSuccessRecordsCount());
		ViewResponse response = new ViewResponse();
		response.setMessage(Constants.MEMBERS_DATA_UPLOADED);
		response.setStatusText(Constants.SUCCESS);
		response.setData(censusUploadResponse);
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}
}