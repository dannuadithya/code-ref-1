package com.billdog.user.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.RecordsTime;
import com.billdog.user.repository.RolesRepository;
import com.billdog.user.request.AuditRequest;
import com.billdog.user.view.ViewAuditData;
import com.billdog.user.view.ViewResponse;

@Service
public class RoleAuditService {

	@Autowired
	RolesRepository rolesRepository;

	@Autowired
	MemberAuditService memberAuditService;

	private static final Logger LOGGER = LoggerFactory.getLogger(RoleAuditService.class);

	public ResponseEntity<ViewResponse> getRolesAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getMemberAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.Custom.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}
		Page<Object[]> empObjects = rolesRepository.getRoleAuditInfo(name, name, startDate, endDate, revtypes,
				auditRequest.getOrganizationId(), getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getData(empObjects.getContent());
		response.setTotalElements(empObjects.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getData(List<Object[]> roles) {
		List<ViewAuditData> viewAuditData = new ArrayList<>();

		roles.forEach(item -> {
			ViewAuditData auditResponse = new ViewAuditData();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> roleObj = rolesRepository.getRoleAuditInfoByIdAndRev(((BigInteger) item[0]).longValue(),
						((Integer) item[8]).longValue());
				if (roleObj != null && !roleObj.isEmpty()) {
					for (Object[] item2 : roleObj) {
						auditResponse = setUpdatedRoleValues(item, item2, auditResponse);
					}
				}
				if (auditResponse != null && (!StringUtils.isBlank(auditResponse.getOldValue())
						|| !StringUtils.isBlank(auditResponse.getNewValue()))) {
					viewAuditData.add(auditResponse);
				} else {
					auditResponse.setNewValue(Constants.NO_CHANGE);
					auditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditData.add(auditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				auditResponse = setCreatedRole(item, auditResponse);
				if (auditResponse != null && !StringUtils.isBlank(auditResponse.getNewValue())) {
					viewAuditData.add(auditResponse);
				}
			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(roles.size());
		response.setData(viewAuditData);
		response.setMessage(Constants.MEMBER_AUDIT_FETCHED);
		if (viewAuditData.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getMemberAuditInfo method ended");
		return response;
	}

	private ViewAuditData setUpdatedRoleValues(Object[] item, Object[] item2, ViewAuditData viewAuditData) {
		String newValue = null;
		String oldValue = null;
		boolean updated = false;
		Timestamp updatedAt = (Timestamp) item[2];
		if (!StringUtils.isBlank((String) item[3]) && !StringUtils.isBlank((String) item2[3])) {
			updated = true;
			oldValue = "Role: " + item2[3];
			newValue = "Role: " + item[3];
		}
		/*
		 * if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String)
		 * item2[5])) { updated = true; oldValue = "Role type : " + item2[5]; newValue =
		 * "Role type: " + item[5]; }
		 */

		ViewAuditData viewAuditData2 = getRoleAccess(((BigInteger) item[0]).longValue(), (String) item[7]);
		if (viewAuditData2 != null) {
			if (!StringUtils.isBlank(viewAuditData2.getOldValue())) {
				updated = true;
				oldValue = oldValue != null ? oldValue + ", " + viewAuditData2.getOldValue()
						: viewAuditData2.getOldValue();
			}
			if (!StringUtils.isBlank(viewAuditData2.getNewValue())) {
				newValue = newValue != null ? newValue + ", " + viewAuditData2.getNewValue()
						: viewAuditData2.getNewValue();
			}
		}

		if (updated) {
			viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
			viewAuditData.setAction(getAction(item[1]));
			viewAuditData.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate())
									+ " " + DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			if (item[5] != null) {
				viewAuditData.setModifiedBy(((String) item[6]));
				viewAuditData.setMemberOrUser("User");
			}
			viewAuditData.setOldValue(oldValue);
			viewAuditData.setNewValue(newValue);
			return viewAuditData;
		}
		viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
		viewAuditData.setAction(getAction(item[1]));
		viewAuditData.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		if (item[5] != null) {
			viewAuditData.setModifiedBy(((String) item[6]));
			viewAuditData.setMemberOrUser("User");
		}
		viewAuditData.setOldValue(oldValue);
		viewAuditData.setNewValue(newValue);
		return viewAuditData;
	}

	private ViewAuditData getRoleAccess(long roleId, String auditId) {
		String oldValue = null;
		String newValue = null;
		ViewAuditData auditResponse = new ViewAuditData();

		List<Object[]> roleAccessDetails = rolesRepository.getRoleAccessByRoleId(roleId, auditId);

		for (Object[] roleAccess : roleAccessDetails) {
			if (getAction(roleAccess[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> roleAccessDetails2 = rolesRepository.getRoleAccessById(
						((BigInteger) roleAccess[0]).longValue(), ((Integer) roleAccess[7]).longValue());
				if (roleAccessDetails2 != null && !roleAccessDetails2.isEmpty()) {
					for (Object[] roleAccess2 : roleAccessDetails2) {
						String oldAccessValue = null;
						String newAccessValue = null;
						if (roleAccess[3] != null && roleAccess2[3] != null && Boolean.TRUE.equals(roleAccess[4])
								&& !Boolean.TRUE.equals(roleAccess2[4])) {
							oldAccessValue = oldAccessValue != null ? oldAccessValue + ", read: " + roleAccess2[4]
									: "read: " + roleAccess2[4];
							newAccessValue = newAccessValue != null ? newAccessValue + ", read: " + roleAccess[4]
									: "read: " + roleAccess[4];
						}
						if (roleAccess[3] != null && roleAccess2[3] != null && !Boolean.TRUE.equals(roleAccess[4])
								&& Boolean.TRUE.equals(roleAccess2[4])) {
							oldAccessValue = oldAccessValue != null ? oldAccessValue + ", read: " + roleAccess2[4]
									: "read: " + roleAccess2[4];
							newAccessValue = newAccessValue != null ? newAccessValue + ", read: " + roleAccess[4]
									: "read: " + roleAccess[4];
						}
						if (roleAccess[5] != null && roleAccess2[5] != null && Boolean.TRUE.equals(roleAccess[5])
								&& !Boolean.TRUE.equals(roleAccess2[5])) {
							oldAccessValue = oldAccessValue != null ? oldAccessValue + ", write: " + roleAccess2[5]
									: "write: " + roleAccess2[5];
							newAccessValue = newAccessValue != null ? newAccessValue + ", write: " + roleAccess[5]
									: "write: " + roleAccess[5];
						}
						if (roleAccess[5] != null && roleAccess2[5] != null && !Boolean.TRUE.equals(roleAccess[5])
								&& Boolean.TRUE.equals(roleAccess2[5])) {
							oldAccessValue = oldAccessValue != null ? oldAccessValue + ", write: " + roleAccess2[5]
									: "write: " + roleAccess2[5];
							newAccessValue = newAccessValue != null ? newAccessValue + ", write: " + roleAccess[5]
									: "write: " + roleAccess[5];
						}
						if (roleAccess[6] != null && roleAccess2[6] != null && Boolean.TRUE.equals(roleAccess[6])
								&& !Boolean.TRUE.equals(roleAccess2[6])) {
							oldAccessValue = oldAccessValue != null ? oldAccessValue + ", custom: " + roleAccess2[6]
									: "custom: " + roleAccess2[6];
							newAccessValue = newAccessValue != null ? newAccessValue + ", custom: " + roleAccess[6]
									: "custom: " + roleAccess[6];
						}
						if (roleAccess[6] != null && roleAccess2[6] != null && !Boolean.TRUE.equals(roleAccess[6])
								&& Boolean.TRUE.equals(roleAccess2[6])) {
							oldAccessValue = oldAccessValue != null ? oldAccessValue + ", custom: " + roleAccess2[6]
									: "custom: " + roleAccess2[6];
							newAccessValue = newAccessValue != null ? newAccessValue + ", custom: " + roleAccess[6]
									: "custom: " + roleAccess[6];
						}

						if (oldAccessValue != null) {
							oldValue = oldValue != null
									? oldValue + ", navigation page: " + (String) roleAccess2[3] + ", " + oldAccessValue
									: "navigation page: " + (String) roleAccess2[3] + ", " + oldAccessValue;
						}
						if (newAccessValue != null) {
							newValue = newValue != null
									? newValue + ", navigation page: " + (String) roleAccess[3] + ", " + newAccessValue
									: "navigation page: " + (String) roleAccess[3] + ", " + newAccessValue;
						}
					}
				}
			}
			if (getAction(roleAccess[1]).equalsIgnoreCase(Constants.CREATED)) {
				String newAccessValue = null;
				newAccessValue = newAccessValue != null ? newAccessValue + ", read: " + roleAccess[4]
						: "read: " + roleAccess[4];
				newAccessValue = newAccessValue != null ? newAccessValue + ", write: " + roleAccess[5]
						: "write: " + roleAccess[5];
				newAccessValue = newAccessValue != null ? newAccessValue + ", custom: " + roleAccess[6]
						: "custom: " + roleAccess[6];

				if (newAccessValue != null) {
					newValue = newValue != null
							? newValue + ", navigation page: " + (String) roleAccess[3] + ", " + newAccessValue
							: "navigation page: " + (String) roleAccess[3] + ", " + newAccessValue;
				}
			}

		}
		auditResponse.setOldValue(oldValue);
		auditResponse.setNewValue(newValue);
		return auditResponse;
	}

	public ResponseEntity<ViewResponse> getRoleAuditInfoById(Long id, Integer pageNumber, Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		Page<Object[]> roleObj = rolesRepository.getRoleAuditInfoById(id, getPageRequest(pageNumber, pageLimit));
		return ResponseEntity.status(HttpStatus.OK).body(getData(roleObj.getContent()));
	}

	public LocalDate getDate(String time) {
		LocalDate date = LocalDate.now();
		if (time.equalsIgnoreCase(RecordsTime.Last_Week.toString().replace("_", " "))) {
			date = LocalDate.now().minusDays(7);
		} else if (time.equalsIgnoreCase(RecordsTime.Last_Month.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(1);
		} else if (time.equalsIgnoreCase(RecordsTime.Last_3_Months.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(3);
		} else if (time.equalsIgnoreCase(RecordsTime.Last_6_Months.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(6);
		} else if (time.equalsIgnoreCase(RecordsTime.Last_Year.toString().replace("_", " "))) {
			date = LocalDate.now().minusYears(1);
		} else {
			date = LocalDate.of(2020, 01, 01);
		}
		return date;
	}

	private ViewAuditData setCreatedRole(Object[] item, ViewAuditData viewAuditData) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];
		if (!StringUtils.isBlank((String) item[3])) {
			newValue = "Role: " + item[3];
		}
		ViewAuditData viewAuditData2 = getRoleAccess(((BigInteger) item[0]).longValue(), (String) item[7]);
		if (viewAuditData2 != null && !StringUtils.isBlank(viewAuditData2.getNewValue())) {
			newValue = newValue != null ? newValue + ", " + viewAuditData2.getNewValue() : viewAuditData2.getNewValue();

		}

		viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
		viewAuditData.setAction(getAction(item[1]));
		viewAuditData.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		if (item[5] != null) {
			viewAuditData.setModifiedBy(((String) item[6]));
			viewAuditData.setMemberOrUser("User");
		}
		viewAuditData.setNewValue(newValue);
		return viewAuditData;
	}


	private String getAction(Object item) {
		String action = "";
		int actionValue = ((Byte) item);
		if (actionValue == 0) {
			action = Constants.CREATED;
		}
		if (actionValue == 1) {
			action = Constants.UPDATED;
		}
		if (actionValue == 2) {
			action = Constants.DELETED;
		}
		return action;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

}
