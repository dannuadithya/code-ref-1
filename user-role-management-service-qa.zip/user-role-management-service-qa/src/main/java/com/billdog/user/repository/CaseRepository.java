package com.billdog.user.repository;

import com.billdog.user.request.AuditRequest;
import com.billdog.user.request.MemberCaseCountRequest;
import com.billdog.user.view.CasesSummaryView;
import com.billdog.user.view.GetMemberCaseCount;
import com.billdog.user.view.ViewResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface CaseRepository {

	@POST("/case/v1/member-cases")
	public Call<GetMemberCaseCount> getMemberCaseCount(@Body MemberCaseCountRequest caseCountRequest);

	@GET("/case/v1/dashboardCase")
	public Call<CasesSummaryView> getCaseInfo();

	@POST("/case/v1/audit-info")
	public Call<ViewResponse> getAuditInfo(@Body AuditRequest auditRequest);

	@GET("/case/v1/audit-info")
	public Call<ViewResponse> getAuditInfoById(@Query("recordId") Long recordId,
			@Query("moduleName") String moduleName, @Query("pageNumber") Integer pageNumber,
			@Query("pageLimit") Integer pageLimit);

}
