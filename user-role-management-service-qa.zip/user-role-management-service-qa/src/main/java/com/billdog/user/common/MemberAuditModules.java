package com.billdog.user.common;

public enum MemberAuditModules {

	Member_info,Member_family,Member_insurance,Member,User,Role

}
