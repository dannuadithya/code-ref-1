package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.billdog.user.entity.InsuranceDetails;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberInsuranceDetails;

public interface MemberInsuranceDetailRepository extends JpaRepository<MemberInsuranceDetails, Long> {

	List<MemberInsuranceDetails> findByMemberIdAndInsuranceDetails(Member member, InsuranceDetails insurance);

	List<MemberInsuranceDetails> findAllByInsuranceDetails(InsuranceDetails insuranceDetails);

	Optional<MemberInsuranceDetails> findAllByInsuranceDetailsAndTypeName(InsuranceDetails insuranceDetails,
			String string);

	@Query(value = "select miu.id,miu.revtype,miu.updated_at,miu.carrier_id,miu.customer_service_contact_number,miu.group_id, miu.member_insurance_id,miu.product_name,miu.provider_contact_number,miu.insurance_sub_type_id,\n"
			+ "miu.insurance_type_id,miu.rev,miu.user_id,concat(m.first_name ,' ',m.last_name) as memberName,\n"
			+ "istm.INSURANCE_SUB_TYPE_NAME,it.INSURANCE_TYPE_NAME, concat(su.first_name ,' ',su.last_name) as userName,miu.audit_id, m.organization_id \n"
			+ "from insurance_details_aud miu\n" + "left join insurance_details id on id.id = miu.id\n"
			+ "left join  member m on m.id = id.member_id\n" + "left join system_users su on su.id = miu.user_id\n"
			+ "left join insurance_sub_type_master istm on istm.id = miu.insurance_sub_type_id\n"
			+ "left join insurance_types it on it.id = miu.insurance_type_id \n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN m.first_name ELSE '' END LIKE COALESCE(?2,'') and\n"
			+ "      CASE WHEN COALESCE(?3,'') <> '' THEN m.last_name ELSE '' END LIKE COALESCE(?4,'') \n"
			+ "and date(miu.updated_at) BETWEEN ?5 AND ?6 and revtype in ?7 and m.organization_id = ?8 order by miu.updated_at desc, miu.rev desc", countQuery = "select miu.id,miu.revtype,miu.updated_at,miu.carrier_id,miu.customer_service_contact_number,miu.group_id, miu.member_insurance_id,miu.product_name,miu.provider_contact_number,miu.insurance_sub_type_id,\n"
					+ "miu.insurance_type_id,miu.rev,miu.user_id,concat(m.first_name ,' ',m.last_name) as memberName,\n"
					+ "istm.INSURANCE_SUB_TYPE_NAME,it.INSURANCE_TYPE_NAME, concat(su.first_name ,' ',su.last_name) as userName, miu.audit_id, m.organization_id\n"
					+ "from insurance_details_aud miu\n"
					+ "left join insurance_details id on id.id = miu.id\n"
					+ "left join  member m on m.id = id.member_id\n"
					+ "left join system_users su on su.id = miu.user_id\n"
					+ "left join insurance_sub_type_master istm on istm.id = miu.insurance_sub_type_id\n"
					+ "left join insurance_types it on it.id = miu.insurance_type_id \n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN m.first_name ELSE '' END LIKE COALESCE(?2,'') and\n"
					+ "      CASE WHEN COALESCE(?3,'') <> '' THEN m.last_name ELSE '' END LIKE COALESCE(?4,'') \n"
					+ "and date(miu.updated_at) BETWEEN ?5 AND ?6 and revtype in ?7 and m.organization_id = ?8 order by miu.updated_at desc, miu.rev desc", nativeQuery = true)
	Page<Object[]> getMemberInsuranceAuditInfo(String name, String name2, String name3, String name4, String string,
			String endDate, List<Long> revtypes, long organizationId, PageRequest pageRequest);

	@Query(value = "select miu.id,miu.revtype,miu.updated_at,miu.carrier_id,miu.customer_service_contact_number,miu.group_id, miu.member_insurance_id,miu.product_name,miu.provider_contact_number,miu.insurance_sub_type_id,\n"
			+ "miu.insurance_type_id,miu.rev,miu.user_id,concat(m.first_name ,' ',m.last_name) as memberName,istm.INSURANCE_SUB_TYPE_NAME,it.INSURANCE_TYPE_NAME, concat(su.first_name ,' ',su.last_name) as userName, miu.audit_id, su.organization_id \n"
			+ "from insurance_details_aud miu\n" + "left join  member m on m.id = miu.member_id \n"
			+ "left join system_users su on su.id = miu.user_id\n"
			+ "left join insurance_sub_type_master istm on istm.id = miu.insurance_sub_type_id\n"
			+ "left join insurance_types it on it.id = miu.insurance_type_id \n"
			+ "where miu.member_id = ?1  and miu.audit_id = ?2 order by updated_at desc limit 2", countQuery = "select miu.id,miu.revtype,miu.updated_at,miu.carrier_id,miu.customer_service_contact_number,miu.group_id, miu.member_insurance_id,miu.product_name,miu.provider_contact_number,miu.insurance_sub_type_id,\n"
					+ "miu.insurance_type_id,miu.rev,miu.user_id,concat(m.first_name ,' ',m.last_name) as memberName,istm.INSURANCE_SUB_TYPE_NAME,it.INSURANCE_TYPE_NAME, concat(su.first_name ,' ',su.last_name) as userName, miu.audit_id, su.organization_id \n"
					+ "from insurance_details_aud miu\n" + "left join  member m on m.id = miu.member_id \n"
					+ "left join system_users su on su.id = miu.user_id\n"
					+ "left join insurance_sub_type_master istm on istm.id = miu.insurance_sub_type_id\n"
					+ "left join insurance_types it on it.id = miu.insurance_type_id \n"
					+ "where miu.member_id = ?1 and miu.audit_id = ?2  order by updated_at desc limit 2", nativeQuery = true)
	List<Object[]> getInsuranceById(long longValue, String auditId);

	@Query(value = "select miu.id,miu.revtype,miu.updated_at,miu.carrier_id,miu.customer_service_contact_number,miu.group_id, miu.member_insurance_id,miu.product_name,miu.provider_contact_number,miu.insurance_sub_type_id,\n"
			+ "miu.insurance_type_id,miu.rev,miu.user_id,concat(m.first_name ,' ',m.last_name) as memberName,istm.INSURANCE_SUB_TYPE_NAME,it.INSURANCE_TYPE_NAME, concat(su.first_name ,' ',su.last_name) as userName\n"
			+ "from insurance_details_aud miu\n" +
			"left join  member m on m.id = miu.member_id \n"
			+ "left join system_users su on su.id = miu.user_id\n"
			+ "left join insurance_sub_type_master istm on istm.id = miu.insurance_sub_type_id\n"
			+ "left join insurance_types it on it.id = miu.insurance_type_id left join member_carrier mc on mc.id = miu.carrier_id\n"
			+ "where miu.id =?1 and miu.rev<?2 order by miu.rev desc limit 1", countQuery = "select miu.id,miu.revtype,miu.updated_at,miu.carrier_id,miu.customer_service_contact_number,miu.group_id, miu.member_insurance_id,miu.product_name,miu.provider_contact_number,miu.insurance_sub_type_id,\n"
					+ "miu.insurance_type_id,miu.rev,miu.user_id,concat(m.first_name ,' ',m.last_name) as memberName,istm.INSURANCE_SUB_TYPE_NAME,it.INSURANCE_TYPE_NAME, concat(su.first_name ,' ',su.last_name) as userName\n"
					+ "from insurance_details_aud miu\n" + "left join  member m on m.id = miu.member_id \n"
					+ "left join system_users su on su.id = miu.user_id\n"
					+ "left join insurance_sub_type_master istm on istm.id = miu.insurance_sub_type_id\n"
					+ "left join insurance_types it on it.id = miu.insurance_type_id left join member_carrier mc on mc.id = miu.carrier_id\n"
					+ "where miu.id =?1 and miu.rev<?2 order by miu.rev desc limit 1", nativeQuery = true)
	List<Object[]> getMemberAuditInfoByIdAndRev(long longValue, long longValue2);

	@Query(value = "select miu.id,miu.revtype,miu.updated_at,miu.carrier_id,miu.customer_service_contact_number,miu.group_id, miu.member_insurance_id,miu.product_name,miu.provider_contact_number,miu.insurance_sub_type_id,\n"
			+ "miu.insurance_type_id,miu.rev,miu.user_id,concat(m.first_name ,' ',m.last_name) as memberName,\n"
			+ "istm.INSURANCE_SUB_TYPE_NAME,it.INSURANCE_TYPE_NAME, concat(su.first_name ,' ',su.last_name) as userName,miu.audit_id, m.organization_id \n"
			+ "from insurance_details_aud miu\n" + "left join insurance_details id on id.id = miu.id\n"
			+ "left join  member m on m.id = id.member_id\n" + "left join system_users su on su.id = miu.user_id\n"
			+ "left join insurance_sub_type_master istm on istm.id = miu.insurance_sub_type_id\n"
			+ "left join insurance_types it on it.id = miu.insurance_type_id \n"
			+ "where miu.id=?1 order by miu.rev desc", countQuery = "select miu.id,miu.revtype,miu.updated_at,miu.carrier_id,miu.customer_service_contact_number,miu.group_id, miu.member_insurance_id,miu.product_name,miu.provider_contact_number,miu.insurance_sub_type_id,\n"
					+ "miu.insurance_type_id,miu.rev,miu.user_id,concat(m.first_name ,' ',m.last_name) as memberName,\n"
					+ "istm.INSURANCE_SUB_TYPE_NAME,it.INSURANCE_TYPE_NAME, concat(su.first_name ,' ',su.last_name) as userName,miu.audit_id, m.organization_id \n"
					+ "from insurance_details_aud miu\n" + "left join insurance_details id on id.id = miu.id\n"
					+ "left join  member m on m.id = id.member_id\n" + "left join system_users su on su.id = miu.user_id\n"
					+ "left join insurance_sub_type_master istm on istm.id = miu.insurance_sub_type_id\n"
					+ "left join insurance_types it on it.id = miu.insurance_type_id \n"
					+ "where miu.id=?1 order by miu.rev desc", nativeQuery = true)
	Page<Object[]> getMemberInsuranceAuditInfoById(Long id, PageRequest pageRequest);

	@Query(value = "select id, insurance_type_name, spec, pcp, er, ded, rev, revType  from member_insurance_details_aud"
			+ " where insurance_details_id=?1 and audit_id = ?2 order by rev desc, updated_at desc", countQuery = "select id, insurance_type_name, spec, pcp, er, ded, rev, revType  from member_insurance_details_aud"
					+ " where insurance_details_id=?1 and audit_id = ?2 order by rev desc, updated_at desc", nativeQuery = true)
	List<Object[]> getMemberInsuranceInfoByInsuranceId(long longValue, String string);

	@Query(value = "select id, insurance_type_name, spec, pcp, er, ded, rev, revType  from member_insurance_details_aud"
			+ " where id=?1 and rev<?2 order by rev desc, updated_at desc limit 1", countQuery = "select id, insurance_type_name, spec, pcp, er, ded, rev, revType  from member_insurance_details_aud"
					+ " where id=?1 and rev<?2 order by rev desc, updated_at desc limit 1", nativeQuery = true)
	List<Object[]> getMemberInsuranceDetailsById(long id, long rev);

	List<MemberInsuranceDetails> findAllByMemberIdAndInsuranceDetailsIn(Member member,
			List<InsuranceDetails> insuranceDetails);

}
