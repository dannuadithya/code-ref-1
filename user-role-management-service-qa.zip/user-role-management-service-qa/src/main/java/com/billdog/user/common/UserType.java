package com.billdog.user.common;

public enum UserType {
	
	External, Internal
}
