package com.billdog.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.Organization;
import com.billdog.user.entity.ReleaseNotes;

public interface ReleaseNotesRepository extends JpaRepository<ReleaseNotes, Long> {

	List<ReleaseNotes> findAllByOrganizationId(Organization organizationId);

	List<ReleaseNotes> findAllByOrganizationIdAndDeviceType(Organization organizationId, String deviceType);

}
