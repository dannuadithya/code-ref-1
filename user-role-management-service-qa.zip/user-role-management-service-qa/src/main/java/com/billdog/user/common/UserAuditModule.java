package com.billdog.user.common;

public enum UserAuditModule {
	
	User

}
