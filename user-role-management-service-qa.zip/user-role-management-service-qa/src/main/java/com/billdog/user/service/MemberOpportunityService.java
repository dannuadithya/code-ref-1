package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.CountryPhoneCodeMaster;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.MemberFamily;
import com.billdog.user.entity.MemberProduct;
import com.billdog.user.entity.MemberTypeMaster;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.exception.RecordExistsException;
import com.billdog.user.repository.CountryPhoneCodeMasterRepository;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberFamilyRepository;
import com.billdog.user.repository.MemberProductRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.request.AddMemberByEmployerRequest;
import com.billdog.user.request.MemberCaseCountRequest;
import com.billdog.user.view.GetEmployerInfo;
import com.billdog.user.view.GetMemberCaseCount;
import com.billdog.user.view.MemberCaseCount;
import com.billdog.user.view.ViewMembersByOpportunity;
import com.billdog.user.view.ViewResponse;

@Service
public class MemberOpportunityService {

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	MemberEmailRepository emailRepository;

	@Autowired
	MemberProductRepository memberProductRepository;

	@Autowired
	LoginService loginService;

	@Autowired
	MemberLoginService memberLoginService;

	@Autowired
	EntityService entityService;

	@Autowired
	MemberTypeMasterRepository typeMasterRepository;

	@Autowired
	AddMember addMember;

	@Autowired
	CaseService caseService;

	@Autowired
	MemberFamilyRepository memberFamilyRepository;

	@Autowired
	GetProfileDetails getProfileDetails;

	@Autowired
	CountryPhoneCodeMasterRepository countryPhoneCodeMasterRepository;

	@Autowired
	AuditService auditService;

	private static final Logger LOGGER = LoggerFactory.getLogger(MemberOpportunityService.class);

	public ResponseEntity<ViewResponse> getMembersByOpportunityId(Long employerId, Long organizationId, int pageNo,
			int limit) {
		LOGGER.info("getMembersByOpportunityId method started..!");
		ViewResponse viewResponse = new ViewResponse();
		List<ViewMembersByOpportunity> viewMembersByOpportunityList = new ArrayList<>();

		// checking whether members with OpportunityId id present or not
		Page<Member> membersData = memberRepository.getMembersByEmployer(employerId, getPageRequest(pageNo, limit));
		GetMemberCaseCount members = getMemberCaseCount(membersData, organizationId);
		membersData.forEach(member -> {
			ViewMembersByOpportunity viewMembersByOpportunity = new ViewMembersByOpportunity();
			viewMembersByOpportunity.setContact(member.getPhoneNumber());
			Optional<MemberEmail> email = emailRepository.findByMemberIdAndDeletedAndPrimary(member, false, true);
			if (email.isPresent()) {
				viewMembersByOpportunity.setEmail(email.get().getEmail());
			}
			viewMembersByOpportunity.setMemberId(member.getMemberId());
			viewMembersByOpportunity.setId(member.getId());
			viewMembersByOpportunity.setMemberName(member.getFirstName() + " " + member.getLastName());
			viewMembersByOpportunity.setFirstName(member.getFirstName());
			viewMembersByOpportunity.setLastName(member.getLastName());
			viewMembersByOpportunity.setProductId(member.getProductId().getId());
			Optional<MemberProduct> memberProduct = memberProductRepository.findById(member.getProductId().getId());
			if (memberProduct.isPresent()) {
				viewMembersByOpportunity.setProduct(memberProduct.get().getProductName());
			}
			viewMembersByOpportunity.setSfdcId(member.getSfdcId());
			viewMembersByOpportunity.setStatus(member.getStatus());
			MemberCaseCount caseCount = getCaseCount(member.getId(), members.getMemberCaseCount());
			if (caseCount != null) {
				viewMembersByOpportunity.setOpenCases(caseCount.getCaseCount());
			}
			if (member.getCountryPhoneCodeMasterId() != null) {
				viewMembersByOpportunity.setCountryCode(member.getCountryPhoneCodeMasterId().getPhoneNumberCode());
				viewMembersByOpportunity.setCountryCodeId(member.getCountryPhoneCodeMasterId().getId());
			}
			if (member.getMemberTypeMasterId() != null && member.getMemberTypeMasterId().getTypeName() != null) {
				viewMembersByOpportunity.setOpportunityName(member.getMemberTypeMasterId().getTypeName());
			}
			viewMembersByOpportunityList.add(viewMembersByOpportunity);
		});
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.MEMBER_PROFILE);
		if (viewMembersByOpportunityList.isEmpty()) {
			viewResponse.setMessage(Constants.NO_RESULTS_FOUND);
		}
		viewResponse.setData(viewMembersByOpportunityList);
		viewResponse.setTotal(membersData.getTotalElements());
		LOGGER.info("getMembersByOpportunityId method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	private GetMemberCaseCount getMemberCaseCount(Page<Member> memberEntity, long organizationId) {
		MemberCaseCountRequest caseCountRequest = new MemberCaseCountRequest();
		caseCountRequest.setOrganizationId(organizationId);
		caseCountRequest.setMemberIds(getMemberIds(memberEntity));
		GetMemberCaseCount memberCaseCount = caseService.getMemberCaseCount(caseCountRequest);
		return memberCaseCount;
	}

	private List<Long> getMemberIds(Page<Member> memberEntity) {
		List<Long> memberIds = new ArrayList<>();
		memberEntity.forEach(member -> {
			Long memberId = member.getId();
			memberIds.add(memberId);
		});
		return memberIds;
	}

	private MemberCaseCount getCaseCount(Long memberId, List<MemberCaseCount> memberCaseCount) {
		return memberCaseCount.stream().filter(member -> member.getMemberId() == memberId).findFirst().orElse(null);
	}

	public ViewResponse addMember(AddMemberByEmployerRequest request) {
		if (request.getContactNumber() != null && !request.getContactNumber().isEmpty()
				&& !StringUtils.isNumeric(request.getContactNumber())) {
			throw new BadRequestException(ExceptionalMessages.CONTACT_NUMBER);
		}

		if (request.getContactNumber() != null && !request.getContactNumber().isEmpty()
				&& (request.getContactNumber().length() <= 9 || request.getContactNumber().length() > 10)) {
			throw new BadRequestException(ExceptionalMessages.CONTACT_NUMBER_RESTRICTION);
		}
		checkEmployer(request.getEmployerId());
		SystemUsers systemUsers = loginService.getSystemUsers(request.getUserId());
		Optional<MemberEmail> emailOptional = emailRepository.findByEmailAndPrimaryAndOrganizationId(request.getEmail(),
				true, systemUsers.getOrganizationId());
		if (emailOptional.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMAIL_ALREADY_EXITS_IN_ORGANIZATION);
		}
		Optional<MemberProduct> productOptional = memberProductRepository.findById(request.getProductId());
		if (!productOptional.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.PRODUCT_NOT_FOUND);
		}
		Optional<MemberTypeMaster> memberType = typeMasterRepository
				.findByTypeNameAndOrganizationId(request.getOpportunityType(), systemUsers.getOrganizationId());
		if (!memberType.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.OPPORTUNITY_TYPE_NOT_FOUND);
		}
		Optional<CountryPhoneCodeMaster> countryPhoneCode = countryPhoneCodeMasterRepository
				.findByIdAndStatus(request.getCountryCodeId(), Constants.ACTIVE);
		String auditId = auditService.getAuditId();
		Member member = saveMember(request, systemUsers, productOptional.get(), memberType, countryPhoneCode, auditId);
		saveMemberEmail(request, member, auditId);
	//	addMember.sendWelcomeEmail(request.getFirstName(), request.getEmail(), EmailTitles.MEMBER_WELCOME);
		ViewResponse response = new ViewResponse();
		response.setMessage(Constants.MEMBER_CREATED_SUCESSFULLY);
		response.setStatusText(Constants.SUCCESS);
		response.setMemberId(member.getId());
		return response;
	}

	private void checkEmployer(Long employerId) {
		GetEmployerInfo employerInfo = entityService.getEmployerInfo(employerId);
		if (!employerInfo.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			throw new NoRecordFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND);
		}
	}

	private void saveMemberEmail(AddMemberByEmployerRequest request, Member member, String auditId) {
		MemberEmail memberEmail = new MemberEmail();
		memberEmail.setCreatedAt(DateAndTimeUtil.now());
		memberEmail.setUpdatedAt(DateAndTimeUtil.now());
		memberEmail.setDeleted(false);
		memberEmail.setCreatedAt(DateAndTimeUtil.now());
		memberEmail.setUpdatedAt(DateAndTimeUtil.now());
		memberEmail.setMemberId(member);
		memberEmail.setEmail(request.getEmail());
		memberEmail.setPrimary(true);
		memberEmail.setOrganizationId(member.getOrganizationId());
		memberEmail.setUserId(member.getUserId());
		memberEmail.setAuditId(auditId);
		emailRepository.save(memberEmail);
	}

	private Member saveMember(AddMemberByEmployerRequest request, SystemUsers systemUsers, MemberProduct memberProduct,
			Optional<MemberTypeMaster> memberType, Optional<CountryPhoneCodeMaster> countryPhoneCode, String auditId) {
		Member member = new Member();
		member.setCreatedAt(DateAndTimeUtil.now());
		member.setFirstName(WordUtils.capitalizeFully(request.getFirstName()));
		member.setLastName(WordUtils.capitalizeFully(request.getLastName()));
		member.setOrganizationId(systemUsers.getOrganizationId());
		member.setUserId(systemUsers);
		member.setProductId(memberProduct);
		member.setEmployerId(request.getEmployerId());
		member.setPhoneNumber(request.getContactNumber());
		member.setUpdatedAt(DateAndTimeUtil.now());
		member.setProfileUpdated(true);
		member.setStatus(StatusConstants.ENROLLED);
		member.setMemberId(memberLoginService.getMemberId(systemUsers.getOrganizationId().getId()));
		if (memberType.isPresent()) {
			member.setMemberTypeMasterId(memberType.get());
		}
		if (countryPhoneCode.isPresent()) {
			member.setCountryPhoneCodeMasterId(countryPhoneCode.get());
		}
		member.setAuditId(auditId);
		return memberRepository.save(member);
	}

	public ViewResponse updateEmployer(Long userId, Long newEmployerId, Long oldEmployerId) {
		SystemUsers systemUsers = loginService.getSystemUsers(userId);
		checkEmployer(oldEmployerId);
		checkEmployer(newEmployerId);
		List<Member> members = memberRepository.findByEmployerIdAndOrganizationId(oldEmployerId,
				systemUsers.getOrganizationId());
		List<Member> membersList = new ArrayList<>();
		members.forEach(member -> {
			member.setEmployerId(newEmployerId);
			member.setUserId(systemUsers);
			membersList.add(member);
		});
		memberRepository.saveAll(membersList);
		ViewResponse response = new ViewResponse();
		response.setMessage(Constants.EMPLOYER_UPDATED_SUCESSFULLY);
		response.setStatusText(Constants.SUCCESS);
		return response;
	}

	public ViewResponse updateMember(AddMemberByEmployerRequest request, Long memberId) {
		SystemUsers systemUser = loginService.getSystemUsers(request.getUserId());
		Optional<Member> memberOptional = memberRepository.findByIdAndEmployerId(memberId, request.getEmployerId());
		if (!memberOptional.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.MEMBER_NOT_FOUND);
		}
		Member member = memberOptional.get();

		Optional<MemberEmail> emailOptional = emailRepository.findByEmailAndPrimaryAndOrganizationId(request.getEmail(),
				true, member.getOrganizationId());
		if (emailOptional.isPresent() && emailOptional.get().getMemberId().getId() != member.getId()) {
			throw new RecordExistsException(ExceptionalMessages.EMAIL_ALREADY_EXITS_IN_ORGANIZATION);
		}

		if (request.getProductId() != member.getProductId().getId()) {
			Optional<MemberProduct> memberProduct = memberProductRepository.findByIdAndStatus(request.getProductId(),
					Constants.ACTIVE);
			if (member.getProductId() != null && memberProduct.isPresent()) {
				// soft deleting family members if product type is changing
				if (member.getProductId().getProductName().equalsIgnoreCase("Family")
						|| memberProduct.get().getProductName().equalsIgnoreCase("Married")) {
					List<MemberFamily> memberFamilyList = new ArrayList<>();
					List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndIsDeleted(member, false);
					if (!memberFamily.isEmpty()) {
						memberFamily.forEach(family -> {
							if (family.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Child")) {
								family.setDeleted(true);
							}
							memberFamilyList.add(family);
						});
						memberFamilyRepository.saveAll(memberFamilyList);
					}
				}
				if ((member.getProductId().getProductName().equalsIgnoreCase("Married")
						|| member.getProductId().getProductName().equalsIgnoreCase("Family"))
						&& memberProduct.get().getProductName().equalsIgnoreCase("Single")) {
					List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberId(member);
					List<MemberFamily> memberFamilyList = new ArrayList<>();
					if (!memberFamily.isEmpty()) {
						memberFamily.forEach(family -> {
							family.setDeleted(true);
							memberFamilyList.add(family);
						});
						memberFamilyRepository.saveAll(memberFamilyList);
					}
				}
				member.setProductId(memberProduct.get());
			}
		}

		Optional<MemberEmail> memberEmailentityOptional = emailRepository.findByMemberIdAndDeletedAndPrimary(member,
				false, true);
		if (!memberEmailentityOptional.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		String auditId = auditService.getAuditId();
		if (!StringUtils.isBlank(request.getEmail()) && !StringUtils.isBlank(memberEmailentityOptional.get().getEmail())
				&& !memberEmailentityOptional.get().getEmail().equalsIgnoreCase(request.getEmail())) {
			getProfileDetails.updateMemberToken(member);
			getProfileDetails.saveMemberEmail(member, memberEmailentityOptional, systemUser, request.getEmail(),
					auditId);
			memberLoginService.sendUpdatedEmail(EmailTitles.OLD_EMAIL, member, memberEmailentityOptional.get(),
					request.getEmail());
		}

		if (member.getCountryPhoneCodeMasterId() != null
				&& member.getCountryPhoneCodeMasterId().getId() != request.getCountryCodeId()) {
			Optional<CountryPhoneCodeMaster> countryPhoneCode = countryPhoneCodeMasterRepository
					.findByIdAndStatus(request.getCountryCodeId(), Constants.ACTIVE);
			if (countryPhoneCode.isPresent()) {
				member.setCountryPhoneCodeMasterId(countryPhoneCode.get());
			}
		}
		member.setFirstName(WordUtils.capitalizeFully(request.getFirstName()));
		member.setLastName(WordUtils.capitalizeFully(request.getLastName()));
		member.setUserId(systemUser);
		member.setEmployerId(request.getEmployerId());
		member.setPhoneNumber(request.getContactNumber());
		member.setUpdatedAt(DateAndTimeUtil.now());
		member.setAuditId(auditId);
		memberRepository.save(member);
		ViewResponse response = new ViewResponse();
		response.setMessage(Constants.MEMBER_UPDATED);
		response.setStatusText(Constants.SUCCESS);
		response.setMemberId(memberId);
		return response;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

}
