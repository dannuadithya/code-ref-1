package com.billdog.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.Organization;
import com.billdog.user.entity.OrganizationDomains;

@Repository
public interface OrganizationDomainsRepository extends JpaRepository<OrganizationDomains, Long> {

	OrganizationDomains findByOrganizationId(Organization organization);

	OrganizationDomains findByDomainUrl(String url);

}
