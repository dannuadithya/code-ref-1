package com.billdog.user.common;

public enum AuditMemberModules {

	Member_info, Member_family, Member_insurance
}
