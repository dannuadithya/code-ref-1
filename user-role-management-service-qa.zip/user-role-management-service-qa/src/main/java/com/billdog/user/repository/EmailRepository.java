package com.billdog.user.repository;

import com.billdog.user.request.PasscodeEmailMemberRequest;
import com.billdog.user.request.PasscodeEmailRequest;
import com.billdog.user.request.UpdateEmailRequest;
import com.billdog.user.request.UpdateMemberEmailRequest;
import com.billdog.user.request.WelcomeEmailMemberRequest;
import com.billdog.user.view.ViewResponse;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

public interface EmailRepository {

	@POST("/email/v1/email")
	public Call<ViewResponse> sendPasscodeEmail(@Body PasscodeEmailRequest passcodeEmailRequest);

	@POST("/email/v1/emailMember")
	public Call<ViewResponse> sendPasscodeEmailToMember(@Body PasscodeEmailMemberRequest passcodeEmailMemberRequest);
	
	@POST("/email/v1/welcomeEmailMember")
	public Call<ViewResponse> welcomeEmailMember(@Body WelcomeEmailMemberRequest welcomeEmailMemberRequest);

	@POST("/email/v1/UpdateEmailMember")
	public Call<ViewResponse> updatedEmail(@Body UpdateMemberEmailRequest updateMemberEmailRequest);

	@POST("/email/v1/UpdateEmailForMobile")
	public Call<ViewResponse> updatedEmailToMember(@Body UpdateEmailRequest updateEmailRequest);

}
