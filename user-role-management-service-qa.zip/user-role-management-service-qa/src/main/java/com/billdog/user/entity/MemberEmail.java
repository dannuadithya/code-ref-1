package com.billdog.user.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "MEMBER_EMAIL")
@Table(name = "member_email", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "org_member_index", columnList = "MEMBER_ID,ORGANIZATION_ID", unique = false),
		@Index(name = "member_primary_email_index", columnList = "MEMBER_ID,IS_PRIMARY", unique = false),
		@Index(name = "email_primary_index", columnList = "EMAIL,IS_PRIMARY", unique = false),
		@Index(name = "email_org_primary_index", columnList = "EMAIL,ORGANIZATION_ID,IS_PRIMARY", unique = false),
		@Index(name = "email_org_index", columnList = "EMAIL,ORGANIZATION_ID", unique = false) })
public class MemberEmail extends BaseEntity {

	@Audited
	@Column(name = "EMAIL")
	private String email;

	@Audited
	@Column(name = "IS_PRIMARY")
	private boolean primary;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "MEMBER_ID")
	private Member memberId;

	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "PASSCODE")
	private String passcode;

	@Column(name = "EMAIL_COUNT")
	private Long emailCount;

	@Column(name = "LAST_EMAIL_SENT")
	private LocalDateTime mailSent;

	@Audited
	@Column(name = "IS_DELETED")
	private boolean deleted;

	@Column(name = "IS_VERIFIED")
	private boolean verified;

	@Column(name = "IS_SECONDARY")
	private boolean secondary;

	@Column(name = "PASSCODE_INCORRECT_COUNT")
	private long passcodeIncorrectCount;

	@Column(name = "LAST_PASSCODE_VERIFIED")
	private LocalDateTime lasPasscodeVerified;

	@Column(name = "PASSWORD_INCORRECT_COUNT")
	private long passwordIncorrectCount;

	@Column(name = "LAST_PASSWORD_VERIFIED")
	private LocalDateTime lasPasswordVerified;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "USER_ID")
	private SystemUsers userId;

	@Audited
	@Column(name = "audit_id")
	private String auditId;

	public long getPasscodeIncorrectCount() {
		return passcodeIncorrectCount;
	}

	public void setPasscodeIncorrectCount(long passcodeIncorrectCount) {
		this.passcodeIncorrectCount = passcodeIncorrectCount;
	}

	public LocalDateTime getLasPasscodeVerified() {
		return lasPasscodeVerified;
	}

	public void setLasPasscodeVerified(LocalDateTime lasPasscodeVerified) {
		this.lasPasscodeVerified = lasPasscodeVerified;
	}

	public long getPasswordIncorrectCount() {
		return passwordIncorrectCount;
	}

	public void setPasswordIncorrectCount(long passwordIncorrectCount) {
		this.passwordIncorrectCount = passwordIncorrectCount;
	}

	public LocalDateTime getLasPasswordVerified() {
		return lasPasswordVerified;
	}

	public void setLasPasswordVerified(LocalDateTime lasPasswordVerified) {
		this.lasPasswordVerified = lasPasswordVerified;
	}

	public boolean isSecondary() {
		return secondary;
	}

	public void setSecondary(boolean secondary) {
		this.secondary = secondary;
	}

	public boolean isVerified() {
		return verified;
	}

	public void setVerified(boolean verified) {
		this.verified = verified;
	}

	public boolean isDeleted() {
		return deleted;
	}

	public void setDeleted(boolean deleted) {
		this.deleted = deleted;
	}

	public LocalDateTime getMailSent() {
		return mailSent;
	}

	public void setMailSent(LocalDateTime mailSent) {
		this.mailSent = mailSent;
	}

	public Long getEmailCount() {
		return emailCount;
	}

	public void setEmailCount(Long emailCount) {
		this.emailCount = emailCount;
	}

	public String getPasscode() {
		return passcode;
	}

	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isPrimary() {
		return primary;
	}

	public void setPrimary(boolean isPrimary) {
		this.primary = isPrimary;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public Member getMemberId() {
		return memberId;
	}

	public void setMemberId(Member memberId) {
		this.memberId = memberId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public SystemUsers getUserId() {
		return userId;
	}

	public void setUserId(SystemUsers userId) {
		this.userId = userId;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

}
