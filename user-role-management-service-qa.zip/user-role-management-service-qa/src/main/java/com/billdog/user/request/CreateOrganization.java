package com.billdog.user.request;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class CreateOrganization {
	
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String name;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String faxNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String phoneNumber;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFaxNumber() {
		return faxNumber;
	}
	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	
}
