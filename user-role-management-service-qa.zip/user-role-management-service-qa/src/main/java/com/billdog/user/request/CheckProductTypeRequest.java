package com.billdog.user.request;

import javax.validation.constraints.NotNull;

public class CheckProductTypeRequest {

	private long memberId;
	private long userId;
	@NotNull(message = "product Id must not be null")
	private long productId;

	public long getProductId() {
		return productId;
	}

	public void setProductId(long productId) {
		this.productId = productId;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

}
