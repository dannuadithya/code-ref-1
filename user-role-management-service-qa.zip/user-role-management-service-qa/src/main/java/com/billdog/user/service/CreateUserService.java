package com.billdog.user.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.authentication.AesEncryption;
import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.common.StatusType;
import com.billdog.user.common.UserType;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.Roles;
import com.billdog.user.entity.StatusMaster;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.entity.SystemUsersAccess;
import com.billdog.user.exception.EmailLimitExceededException;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.exception.NavigationScreenAccessException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.exception.RecordExistsException;
import com.billdog.user.repository.NamePrefixMasterRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.RolesRepository;
import com.billdog.user.repository.StatusMasterRepository;
import com.billdog.user.repository.SystemUsersAccessRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.CreateUserRequest;
import com.billdog.user.request.EditUserDetailsRequest;
import com.billdog.user.request.ExternalUserDetailsRequest;
import com.billdog.user.request.ExternalUserRequest;
import com.billdog.user.request.ExternalUserUpdateRequest;
import com.billdog.user.request.GetUserRequest;
import com.billdog.user.request.PasscodeEmailRequest;
import com.billdog.user.request.SearchUsersRequest;
import com.billdog.user.request.UpdateExternalUser;
import com.billdog.user.request.VerifyEmailRequest;
import com.billdog.user.request.VerifyExternalUser;
import com.billdog.user.request.WelcomeEmailMemberRequest;
import com.billdog.user.response.CreateUserResponse;
import com.billdog.user.response.UpdateUserDetailsResponse;
import com.billdog.user.response.ViewUsersResponse;
import com.billdog.user.view.SearchUserDetailsResponse;
import com.billdog.user.view.ViewExternalUser;
import com.billdog.user.view.ViewResponse;
import com.billdog.user.view.ViewStatus;

/**
 * @author adithya
 *
 */
@Service
public class CreateUserService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CreateUserService.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	NamePrefixMasterRepository namePrefixMasterRepository;

	@Autowired
	SystemUsersrepository systemUsersrepository;

	@Autowired
	RolesRepository rolesRepository;

	@Autowired
	SystemUsersAccessRepository systemUsersAccessRepository;

	@Autowired
	AesEncryption aesEncryption;

	@Autowired
	EmailService emailService;

	@Autowired
	StatusMasterRepository statusMasterRepository;

	@Value("${passcode.length}")
	private int passcodeLength;

	@Value("${passcode.email.times}")
	private int passcodeTimes;

	@Autowired
	CreateRoleService createRoleService;

	@Autowired
	CreateUserService createUserService;

	@Autowired
	LoginService loginService;

	@Autowired
	AddMember addMember;

	@Autowired
	LogoutService logoutService;

	@Autowired
	EntityService entityService;

	@Autowired
	MemberLoginService memberLoginService;

	private Random rndmMethod = new Random();

	public SystemUsers getSystemUsers(Long id) {
		LOGGER.info("Fecthing user details with id:: " + id);
		// This jpa query checks whether the organization is present or not from
		// systemUser table
		Optional<SystemUsers> orgOptional = systemUsersrepository.findById(id);
		if (!orgOptional.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		if (orgOptional.get().getStatus() != null
				&& (orgOptional.get().getStatus().equalsIgnoreCase(StatusConstants.DELETED)
						|| orgOptional.get().getStatus().equalsIgnoreCase(StatusConstants.INACTIVE))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_ACCESS);
		}
		LOGGER.info("Fecthed user details with id:: " + id);
		return orgOptional.get();
	}

	
	/**
	 * @param createUserRequest
	 * @return
	 */
	@Transactional
	public CreateUserResponse createUser(CreateUserRequest createUserRequest) {
		LOGGER.info("create user method started..!");

		loginService.validateEmail(createUserRequest.getEmail());

		SystemUsers appUser = getSystemUsers(createUserRequest.getUserId());

		Optional<SystemUsers> user = systemUsersrepository.findByEmailAndOrganizationIdAndUserTypeAndStatusNot(
				createUserRequest.getEmail(), appUser.getOrganizationId(), UserType.Internal.toString(),
				StatusConstants.DELETED);
		if (user.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMAIL_ALREADY_EXITS_IN_ORGANIZATION);
		}
		LOGGER.info("Fecthing role details with role id:: " + createUserRequest.getRoleId());
		Optional<Roles> role = rolesRepository.findById(createUserRequest.getRoleId());
		if (!role.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ROLE_NOT_FOUND);
		}

		LOGGER.info("Creating new user in the system");
		SystemUsers systemUsers = saveSystemUser(appUser.getOrganizationId(), createUserRequest, role.get());

		sendWelcomeEmail(createUserRequest, EmailTitles.WELCOME_USER, appUser.getOrganizationId().getId());

		// providing successful response if user data is stores
		CreateUserResponse createUserResponse = new CreateUserResponse();
		createUserResponse.setUserId(systemUsers.getId());
		createUserResponse.setStatusText(Constants.SUCCESS);
		createUserResponse.setMessage(Constants.INTERNAL_USER);
		LOGGER.info("user is created successfully");
		return createUserResponse;

	}

	public ViewResponse sendWelcomeEmail(CreateUserRequest createUserRequest, EmailTitles emailTitles, long orgId) {
		LOGGER.info("Send welcome mail method started..!");

		WelcomeEmailMemberRequest welcomeEmailMemberRequest = new WelcomeEmailMemberRequest();
		welcomeEmailMemberRequest.setEmail(createUserRequest.getEmail());
		welcomeEmailMemberRequest.setEmailTitle(emailTitles);
		welcomeEmailMemberRequest.setFirstName(createUserRequest.getFirstName());
		welcomeEmailMemberRequest.setOrgId(orgId);
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send welcome email");
			viewResponse = emailService.sendWelcomeEamilToMember(welcomeEmailMemberRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: {} ", exception.getMessage());
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send welcome email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.WELCOME_MEMBER);
		} else {
			LOGGER.debug("We are unable to send email");
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
		}

		return viewResponse;
	}

	private SystemUsers saveSystemUser(Organization organization, CreateUserRequest createUserRequest, Roles role) {
		// entering into creating new user
		SystemUsers systemUsers = new SystemUsers(createUserRequest, role, null);
		return systemUsersrepository.save(systemUsers);
	}

	private SystemUsers saveSystemExternalUser(Organization organization,
			ExternalUserDetailsRequest externalUserDetailsRequest, Roles role) {
		// entering into creating new user
		SystemUsers systemUsers = new SystemUsers();
		systemUsers.setEmail(externalUserDetailsRequest.getEmail().toLowerCase());
		systemUsers.setCreatedAt(DateAndTimeUtil.now());
		systemUsers.setUpdatedAt(DateAndTimeUtil.now());
		systemUsers.setFirstName(externalUserDetailsRequest.getFirstName());
		systemUsers.setLastName(externalUserDetailsRequest.getLastName());
		systemUsers.setOrganizationId(organization);
		systemUsers.setRoleId(role);
		systemUsers.setStatus(StatusConstants.ENROLLED);
		systemUsers.setUserType(UserType.External.toString());
		systemUsers.setMobileNumber(externalUserDetailsRequest.getContactNumber());
		systemUsers.setUserId(externalUserDetailsRequest.getUserId());
		return systemUsersrepository.save(systemUsers);
	}

	private ViewResponse sendWelcomeMail(SystemUsers systemUser) {
		LOGGER.info("Send welcome mail method is started..!");
		Optional<SystemUsersAccess> appUser = systemUsersAccessRepository.findByUserId(systemUser);
		if (appUser.isPresent() && appUser.get().getEmailCount() != null
				&& appUser.get().getEmailCount() >= passcodeTimes) {
			String message = ExceptionalMessages.PASSCODE_EMAIL_LIMIT_EXCEEDED.replace("{times}", "" + passcodeTimes);
			throw new EmailLimitExceededException(message);
		}
		String passcode = generatePasscode(passcodeLength);
		savePasscode(systemUser, appUser, passcode);
		PasscodeEmailRequest passcodeEmailRequest = new PasscodeEmailRequest(systemUser, passcode,
				EmailTitles.WELCOME_USER);

		ViewResponse response = new ViewResponse();
		try {
			response = emailService.sendEamil(passcodeEmailRequest);
		} catch (Exception exception) {
			LOGGER.info("Exception occured while connecting email service, cause:: ", exception.getCause());
			systemUser.setStatus(StatusConstants.DELETED);
			systemUsersrepository.save(systemUser);
		}
		ViewResponse viewResponse = new ViewResponse();
		if (response != null && response.getStatusText() != null
				&& response.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Welcome email send to user successfully");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.SENT_PASSCODE);
		} else {
			LOGGER.info("Send welcome mail to user failed, updating user status");
			systemUser.setStatus(StatusConstants.DELETED);
			systemUsersrepository.save(systemUser);
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}
		viewResponse.setUserId(systemUser.getId());
		return viewResponse;
	}

	/**
	 * @param editUserDetailsRequest
	 * @param role
	 * @return
	 */
	@Transactional
	public UpdateUserDetailsResponse updateUserDetails(EditUserDetailsRequest editUserDetailsRequest, Roles role) {
		LOGGER.info("edit user details method started..!");

		loginService.validateEmail(editUserDetailsRequest.getEmail());
		SystemUsers appUser = getSystemUsers(editUserDetailsRequest.getUserId());

		// This jpa query checks whether the user is present or not from systemUser
		// table
		Optional<SystemUsers> systemUserEntity = systemUsersrepository.findById(editUserDetailsRequest.getId());
		if (!systemUserEntity.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		if (systemUserEntity.get().getEmail() != null
				&& !systemUserEntity.get().getEmail().equalsIgnoreCase(editUserDetailsRequest.getEmail())) {
			Optional<SystemUsers> emailExists = systemUsersrepository
					.findByEmailAndOrganizationIdAndUserTypeAndStatusNot(editUserDetailsRequest.getEmail(),
							appUser.getOrganizationId(), UserType.Internal.toString(), StatusConstants.DELETED);
			if (emailExists.isPresent()) {
				throw new NoRecordFoundException(ExceptionalMessages.USER_EMAIL_ALREADY_EXITS);
			}
		}
		// This condition checks whether the user's organization and updating user
		// organization is same or not from systemUser table
		if (systemUserEntity.get().getOrganizationId().getId() != appUser.getOrganizationId().getId()) {
			throw new InValidInputException(ExceptionalMessages.THIS_USER_DOES_NOT_BELONG_TO_SAME_ORGANIZATION);
		}

		// entering into updating user as per request
		boolean roleUpdated = false;
		boolean diabled = false;
		boolean isActivated = false;
		SystemUsers user = systemUserEntity.get();
		user.setUpdatedAt(DateAndTimeUtil.now());
		user.setFirstName(WordUtils.capitalizeFully(editUserDetailsRequest.getFirstName()));
		user.setLastName(WordUtils.capitalizeFully(editUserDetailsRequest.getLastName()));
		user.setMiddleName(WordUtils.capitalizeFully(editUserDetailsRequest.getMiddleName()));
		user.setEmail(editUserDetailsRequest.getEmail().toLowerCase());
		user.setMobileNumber(editUserDetailsRequest.getMobileNumber());
		user.setUserId(editUserDetailsRequest.getUserId());
		if (role.getId() != user.getRoleId().getId()) {
			roleUpdated = true;
		}
		if (!user.getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				&& editUserDetailsRequest.getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)) {
			diabled = true;
		}
		if (user.getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				&& !editUserDetailsRequest.getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)) {
			isActivated = true;
		}
		user.setStatus(editUserDetailsRequest.getStatus());
		user.setRoleId(role);
		Optional<SystemUsersAccess> sysUser = systemUsersAccessRepository.findByUserId(systemUserEntity.get());
		if (sysUser.isPresent()) {
			if (!editUserDetailsRequest.isLockStatus()) {
				sysUser.get().setPasscodeIncorrectCount(0l);
				sysUser.get().setPasswordIncorrectCount(0l);
				systemUsersAccessRepository.save(sysUser.get());
				user.setLockedFromWeb(false);
				systemUsersrepository.save(user);
			}
		}
		if (editUserDetailsRequest.isLockStatus()) {
			user.setLockedFromWeb(true);
			systemUsersrepository.save(user);
			createRoleService.expireToken(user);
		}
		user.setLocked(editUserDetailsRequest.isLockStatus());
		systemUsersrepository.save(user);

		if (roleUpdated) {
			logoutService.logoutUserByReason(user, StatusConstants.ROLE_UPDATED);
		}
		if (diabled) {
			logoutService.logoutUserByReason(user, StatusConstants.INACTIVE);
		}
		if (isActivated) {
			logoutService.updateUserToken(user);
		}
		// providing successful response if user data is stores
		UpdateUserDetailsResponse updateUserDetails = new UpdateUserDetailsResponse();
		updateUserDetails.setUserId(editUserDetailsRequest.getId());
		updateUserDetails.setStatusText(Constants.SUCCESS);
		updateUserDetails.setMessage(Constants.USER_UPDATED);
		LOGGER.info("edit user details method ends..!");
		return updateUserDetails;

	}

	/**
	 * @param searchUsersRequest
	 * @return
	 */
	public ViewResponse searchUsers(SearchUsersRequest searchUsersRequest) {
		LOGGER.info("search user details method started..!");

		SystemUsers appUser = getSystemUsers(searchUsersRequest.getUserId());

		// checkUserAccess(appUser.getRoleId().getRole());
		// creating arraylist for response class
		String userFirstName = null;
		String userLastName = null;
		String mobileNumber = null;
		String email = null;
		String userType = null;

		if (searchUsersRequest.getName() != null && !searchUsersRequest.getName().equals("")) {
			userFirstName = "%" + searchUsersRequest.getName() + "%";
		} else {
			userFirstName = searchUsersRequest.getName();
		}

		if (searchUsersRequest.getName() != null && !searchUsersRequest.getName().equals("")) {
			userLastName = "%" + searchUsersRequest.getName() + "%";
		} else {
			userLastName = searchUsersRequest.getName();
		}

		if (searchUsersRequest.getEmail() != null && !searchUsersRequest.getEmail().equals("")) {
			email = "%" + searchUsersRequest.getEmail() + "%";
		} else {
			email = searchUsersRequest.getEmail();
		}

		if (searchUsersRequest.getMobileNumber() != null && !searchUsersRequest.getMobileNumber().equals("")) {
			mobileNumber = "%" + searchUsersRequest.getMobileNumber() + "%";
		} else {
			mobileNumber = searchUsersRequest.getMobileNumber();
		}
		if (searchUsersRequest.getUserType() != null && !searchUsersRequest.getUserType().equals("")) {
			userType = "%" + searchUsersRequest.getUserType() + "%";
		} else {
			userType = "";
		}

		Long roleId = searchUsersRequest.getRoleId();
		if (roleId == 0) {
			roleId = -999l;
		}

		Integer pageNumber = searchUsersRequest.getPageNumber() > 0 ? searchUsersRequest.getPageNumber() : 0;
		Integer pageLimit = searchUsersRequest.getPageLimit() > 0 ? searchUsersRequest.getPageLimit() : 20;
		// native query for searching users and assigning parameters respectively
		Page<Object[][]> userDetails = systemUsersrepository.getUserDetails(userFirstName, userFirstName, userLastName,
				userLastName, mobileNumber, mobileNumber, email, email, roleId, roleId, userType, userType,
				appUser.getOrganizationId().getId(), getPageRequest(pageNumber, pageLimit));

		// for loop for users searched with native query and assigning values
		// respectively

		List<SearchUserDetailsResponse> viewUserDetailsResponseList = getUsersList(userDetails,
				searchUsersRequest.getUserId());

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.USER_DETAILS_FETCHED);
		if (viewUserDetailsResponseList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewUserDetailsResponseList);
		response.setTotal(userDetails.getTotalElements());

		return response;

	}

	private List<SearchUserDetailsResponse> getUsersList(Page<Object[][]> userDetails, long userId) {
		List<SearchUserDetailsResponse> viewUserDetailsResponseList = new ArrayList<>();
		for (Object[] objects : userDetails) {
			SearchUserDetailsResponse searchUserDetailsResponse = new SearchUserDetailsResponse();
			searchUserDetailsResponse.setFirstName(((String) objects[1]));
			searchUserDetailsResponse.setLastName(((String) objects[2]));
			searchUserDetailsResponse.setEmail((String) objects[3]);
			searchUserDetailsResponse.setMobileNumber((String) objects[4]);
			searchUserDetailsResponse.setRoleId(((BigInteger) objects[5]).longValue());
			searchUserDetailsResponse.setStatus((String) objects[6]);
			searchUserDetailsResponse.setId(((BigInteger) objects[0]).longValue());
			searchUserDetailsResponse.setRole((String) objects[8]);

			Timestamp passcodeVerifiedDate = (Timestamp) objects[10];
			Timestamp passwordVerifiedDate = (Timestamp) objects[11];
			searchUserDetailsResponse.setUserType((String) objects[13]);
			String userType = objects[13].toString();
			if (userType.equalsIgnoreCase(UserType.External.toString())) {
				ExternalUserRequest externalUserRequest = new ExternalUserRequest();
				externalUserRequest.setEmail(objects[3].toString());
				ViewExternalUser externalUserInfo = entityService.getExternalUserInfo(externalUserRequest);
				if (externalUserInfo != null) {
					externalUserInfo.setBrokerCompanyName(externalUserInfo.getBrokerCompanyName());
					externalUserInfo.setName(externalUserInfo.getName());
					externalUserInfo.setFirstName(externalUserInfo.getFirstName());
					externalUserInfo.setLastName(externalUserInfo.getLastName());
					externalUserInfo
							.setExternalUserBlockOpportunity(externalUserInfo.getExternalUserBlockOpportunity());
					externalUserInfo
							.setExternalUserGroupOpportunity(externalUserInfo.getExternalUserGroupOpportunity());
					searchUserDetailsResponse.setBrokerCompanyDetails(externalUserInfo);
				}

			}
			if (objects[12].equals(Boolean.TRUE)) {
				searchUserDetailsResponse.setLocked((Boolean) objects[9]);
			} else {
				if (objects[9].equals(Boolean.TRUE)) {
					if (passcodeVerifiedDate != null) {
						if (LocalDateTime.now().minusHours(24).isAfter(passcodeVerifiedDate.toLocalDateTime())) {
							searchUserDetailsResponse.setLocked(false);
						} else {
							searchUserDetailsResponse.setLocked(true);
						}
					}
					if (passwordVerifiedDate != null) {
						if (LocalDateTime.now().minusHours(24).isAfter(passwordVerifiedDate.toLocalDateTime())) {
							searchUserDetailsResponse.setLocked(false);
						} else {
							searchUserDetailsResponse.setLocked(true);
						}
					}

				} else {
					searchUserDetailsResponse.setLocked(false);
				}
			}

			viewUserDetailsResponseList.add(searchUserDetailsResponse);
		}
		return viewUserDetailsResponseList;
	}

	/**
	 * @param getUserRequest
	 * @return
	 */
	public ViewResponse getUserById(GetUserRequest getUserRequest) {
		LOGGER.info("edit user details method started..!");

		SystemUsers appUser = getSystemUsers(getUserRequest.getUserId());
		// checkUserAccess(appUser.getRoleId().getRole());
		// This jpa query checks whether the user is present or not
		Optional<SystemUsers> sysUser = systemUsersrepository.findByIdAndOrganizationId(getUserRequest.getUserId(),
				appUser.getOrganizationId());
		if (!sysUser.isPresent()) {
			throw new NoRecordFoundException(
					ExceptionalMessages.USER_NOT_FOUND_IN_ORGANISATION + getUserRequest.getUserId());
		}

//		if (!(userEntity.get().getOrganizationId().getId() == sysUser.get().getOrganizationId().getId())) {
//			throw new NoRecordFoundException(ExceptionalMessages.USERS_NOT_FOUND + getUserRequest.getUserId());
//		}

		// entering into assigning values respectively

		SystemUsers user = sysUser.get();
		ViewUsersResponse viewUsersResponse = new ViewUsersResponse(user);
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.USER_DETAILS_FETCHED);
		viewResponse.setData(viewUsersResponse);
		return viewResponse;

	}

	/*
	 * This method will take userId as input and generates new passcode to send
	 * mail.
	 */
	public ViewResponse sendPasscodeByUserId(VerifyEmailRequest email, EmailTitles emailTitle) {
		Optional<SystemUsers> appUser = systemUsersrepository.findByEmailAndStatusNotAndUserType(email.getEmail(),
				StatusConstants.DELETED, UserType.Internal.toString());
		if (!appUser.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND_WITH_EMAIL);
		}
		if (appUser.get().getStatus() != null && (appUser.get().getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				|| appUser.get().getStatus().equalsIgnoreCase(StatusConstants.DELETED))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_ACCESS);
		}
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(appUser.get());
		if (!systemUsersAccess.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}

		if (appUser.get().isLocked() && appUser.get().isLockedFromWeb()) {
			String message = ExceptionalMessages.WEB_LOCKED;
			if (!StringUtils.isBlank(appUser.get().getOrganizationId().getEmail())) {
				message = message.replace("<Email>", appUser.get().getOrganizationId().getEmail());
			} else {
				message = message.replace("<Email>", appUser.get().getOrganizationId().getName());
			}
			throw new NoRecordFoundException(message);
		} else if (systemUsersAccess.get().getLasPasscodeVerified() != null
				&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
			appUser.get().setLocked(true);
			systemUsersrepository.save(appUser.get());
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		} else if (systemUsersAccess.get().getLasPasswordVerified() != null
				&& systemUsersAccess.get().getPasswordIncorrectCount() >= 3
				&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasswordVerified())) {
			appUser.get().setLocked(true);
			systemUsersrepository.save(appUser.get());
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}
		return sendPasscode(appUser.get(), emailTitle);
	}

	public ViewResponse externalSendPasscodeByUserId(VerifyEmailRequest email, EmailTitles emailTitle) {
		Optional<SystemUsers> appUser = systemUsersrepository.findByEmailAndStatusNotAndUserType(email.getEmail(),
				StatusConstants.DELETED, UserType.External.toString());
		if (!appUser.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND_WITH_EMAIL);
		}
		if (appUser.get().getStatus() != null && (appUser.get().getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				|| appUser.get().getStatus().equalsIgnoreCase(StatusConstants.DELETED))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_ACCESS);
		}
		Optional<SystemUsersAccess> systemUsersAccess = systemUsersAccessRepository.findByUserId(appUser.get());
		if (!systemUsersAccess.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}

		if (appUser.get().isLocked() && appUser.get().isLockedFromWeb()) {
			String message = ExceptionalMessages.WEB_LOCKED;
			if (!StringUtils.isBlank(appUser.get().getOrganizationId().getEmail())) {
				message = message.replace("<Email>", appUser.get().getOrganizationId().getEmail());
			} else {
				message = message.replace("<Email>", appUser.get().getOrganizationId().getName());
			}
			throw new NoRecordFoundException(message);
		} else if (systemUsersAccess.get().getLasPasscodeVerified() != null
				&& systemUsersAccess.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasscodeVerified())) {
			appUser.get().setLocked(true);
			systemUsersrepository.save(appUser.get());
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		} else if (systemUsersAccess.get().getLasPasswordVerified() != null
				&& systemUsersAccess.get().getPasswordIncorrectCount() >= 3
				&& createUserService.checkDateTime(systemUsersAccess.get().getLasPasswordVerified())) {
			appUser.get().setLocked(true);
			systemUsersrepository.save(appUser.get());
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}
		return sendPasscode(appUser.get(), emailTitle);
	}

	public ViewResponse sendPasscode(SystemUsers systemUser, EmailTitles emailTitle) {
		ViewResponse response = new ViewResponse();
		Optional<SystemUsersAccess> appUserAccess = systemUsersAccessRepository.findByUserId(systemUser);
		if (appUserAccess.isPresent() && appUserAccess.get().getEmailCount() != null
				&& appUserAccess.get().getEmailCount() >= passcodeTimes
				&& checkDate(appUserAccess.get().getMailSent().toLocalDate())) {
			String message = ExceptionalMessages.PASSCODE_EMAIL_LIMIT_EXCEEDED.replace("{times}", "" + passcodeTimes);
			throw new EmailLimitExceededException(message);
		}
		String passcode = generatePasscode(passcodeLength);

		savePasscode(systemUser, appUserAccess, passcode);
		PasscodeEmailRequest passcodeEmailRequest = new PasscodeEmailRequest(systemUser, passcode, emailTitle);

		try {
			response = emailService.sendEamil(passcodeEmailRequest);
		} catch (Exception exception) {
			LOGGER.info("Exception occured while connecting email service, cause:: ", exception.getCause());

		}
		ViewResponse viewResponse = new ViewResponse();
		if (response != null && response.getStatusText() != null
				&& response.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.SENT_PASSCODE);
		} else {
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}
		viewResponse.setId(systemUser.getId());
		return viewResponse;
	}

	public boolean checkDate(LocalDate localDate) {
		if (localDate.isEqual(DateAndTimeUtil.now().toLocalDate())) {
			return true;
		}
		return false;
	}

	public boolean checkDateTime(LocalDateTime localDateTime) {
		if (LocalDateTime.now().isBefore(localDateTime.plusHours(24))) {
			return true;
		}
		return false;
	}

	/*
	 * this method used to save user new passcode
	 */
	private SystemUsersAccess savePasscode(SystemUsers systemUser, Optional<SystemUsersAccess> optional,
			String passcode) {
		LOGGER.info("savePasscode method started");
		SystemUsersAccess systemUsersAccess = new SystemUsersAccess();
		if (optional.isPresent()) {
			LOGGER.info("Updating user recent passcode for login verification");
			systemUsersAccess = optional.get();
			LOGGER.info("Checking last passcode email date for updating passcode email limit count");
			if (systemUsersAccess.getMailSent().toLocalDate().isEqual(DateAndTimeUtil.now().toLocalDate())) {
				systemUsersAccess.setEmailCount(systemUsersAccess.getEmailCount() + 1);
			} else {
				systemUsersAccess.setEmailCount(1l);
			}
		} else {
			LOGGER.info("creating user recent passcode for login verification");
			systemUsersAccess.setCreatedAt(DateAndTimeUtil.now());
			systemUsersAccess.setUserId(systemUser);
			systemUsersAccess.setEmailCount(0l);
			systemUsersAccess.setOrganizationId(systemUser.getOrganizationId());
		}
		systemUsersAccess.setUpdatedAt(DateAndTimeUtil.now());
		systemUsersAccess.setMailSent(DateAndTimeUtil.now());
		String encryptedPassword = aesEncryption.encrypt(passcode);
		systemUsersAccess.setPasscode(encryptedPassword);
		LOGGER.info("savePasscode method ended");
		return systemUsersAccessRepository.save(systemUsersAccess);
	}

	/*
	 * this method hold passcode generation logic with required length
	 */
	public String generatePasscode(int length) {
		LOGGER.info("Generating new passcode for login purpose");
		String numbers = "0123456789";
		char[] passcode = new char[length];
		for (int i = 0; i < length; i++) {
			passcode[i] = numbers.charAt(rndmMethod.nextInt(numbers.length()));
		}
		if (passcode[0] == '0') {
			passcode[0] = '1';
		}
		return String.valueOf(passcode);
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public void checkUserAccess(String roleName) {
		LOGGER.info("Checking user have privileges or not");
		if (roleName == null || (!roleName.equalsIgnoreCase(StatusConstants.SYSTEM_ADMIN)
				&& !roleName.equalsIgnoreCase(StatusConstants.SUPER_ADMIN))) {
			throw new NavigationScreenAccessException(ExceptionalMessages.DON_NOT_HAVE_PREVILEGES_ACCESS);
		}
	}

	public ViewResponse getUserStatus(Long userId, StatusType type) {
		LOGGER.info("getUserStatus method started");
		SystemUsers user = getSystemUsers(userId);
		List<StatusMaster> statusMasterList = statusMasterRepository
				.findByStatusTypeAndOrganizationIdAndActive(type.toString(), user.getOrganizationId(), Boolean.TRUE);
		LOGGER.info("Fetched status list for {}", type);
		List<ViewStatus> viewStatusList = new ArrayList<>();
		statusMasterList.forEach(status -> {
			ViewStatus viewStatus = new ViewStatus();
			viewStatus.setStatusId(status.getId());
			viewStatus.setStatusName(status.getStatusName());
			if (status.getStatusName().equalsIgnoreCase("Lock")) {
				viewStatus.setLockStatus(true);
			}
			if (status.getStatusName().equalsIgnoreCase("unlock")) {
				viewStatus.setLockStatus(false);
			}
			viewStatusList.add(viewStatus);
		});
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewStatusList.stream().sorted(Comparator.comparing(ViewStatus::getStatusName))
				.collect(Collectors.toList()));
		LOGGER.info("getUserStatus method ended");
		return viewResponse;
	}

	@Transactional
	public ResponseEntity<UpdateUserDetailsResponse> updateExternalUserDetails(UpdateExternalUser updateExternalUser) {
		LOGGER.info("edit external user details method started..!");

		// loginService.validateEmail(editUserDetailsRequest.getEmail());
		SystemUsers appUser = getSystemUsers(updateExternalUser.getUserId());

		// This jpa query checks whether the user is present or not from systemUser
		// table
		Optional<SystemUsers> systemUserEntity = systemUsersrepository.findById(updateExternalUser.getId());
		if (!systemUserEntity.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		// This condition checks whether the user's organization and updating user
		// organization is same or not from systemUser table
		if (systemUserEntity.get().getOrganizationId().getId() != appUser.getOrganizationId().getId()) {
			throw new InValidInputException(ExceptionalMessages.THIS_USER_DOES_NOT_BELONG_TO_SAME_ORGANIZATION);
		}

		updateExternalUser(updateExternalUser, systemUserEntity.get());

		// providing successful response if user data is stores
		UpdateUserDetailsResponse updateUserDetails = new UpdateUserDetailsResponse();
		updateUserDetails.setUserId(updateExternalUser.getId());
		updateUserDetails.setStatusText(Constants.SUCCESS);
		updateUserDetails.setMessage(Constants.USER_UPDATED);
		LOGGER.info("edit user details method ends..!");
		return ResponseEntity.status(HttpStatus.OK).body(updateUserDetails);

	}

	private void updateExternalUser(UpdateExternalUser updateExternalUser, SystemUsers systemUsers) {

		boolean roleUpdated = false;
		boolean diabled = false;
		boolean isActivated = false;
		// entering into updating user as per request
		systemUsers.setUpdatedAt(DateAndTimeUtil.now());
		Optional<Roles> role = rolesRepository.findById(updateExternalUser.getRoleId());
		if (!role.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ROLE_NOT_FOUND);
		}
		if (role.get().getId() != systemUsers.getRoleId().getId()) {
			roleUpdated = true;
		}
		if (!systemUsers.getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				&& updateExternalUser.getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)) {
			diabled = true;
		}
		if (systemUsers.getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)
				&& !updateExternalUser.getStatus().equalsIgnoreCase(StatusConstants.INACTIVE)) {
			isActivated = true;
		}
		systemUsers.setRoleId(role.get());
		systemUsers.setStatus(updateExternalUser.getStatus());
		systemUsers.setUserId(updateExternalUser.getUserId());
		Optional<SystemUsersAccess> sysUser = systemUsersAccessRepository.findByUserId(systemUsers);
		if (sysUser.isPresent()) {
			if (!updateExternalUser.isLockStatus()) {
				sysUser.get().setPasscodeIncorrectCount(0l);
				sysUser.get().setPasswordIncorrectCount(0l);
				systemUsersAccessRepository.save(sysUser.get());
				systemUsers.setLockedFromWeb(false);
			}
		}
		if (updateExternalUser.isLockStatus()) {
			systemUsers.setLockedFromWeb(true);
			createRoleService.expireToken(systemUsers);
		}
		systemUsers.setLocked(updateExternalUser.isLockStatus());
		systemUsersrepository.save(systemUsers);

		if (roleUpdated) {
			logoutService.logoutUserByReason(systemUsers, StatusConstants.ROLE_UPDATED);
		}
		if (diabled) {
			logoutService.logoutUserByReason(systemUsers, StatusConstants.INACTIVE);
		}
		if (isActivated) {
			logoutService.updateUserToken(systemUsers);
		}

	}

	@Transactional
	public ResponseEntity<CreateUserResponse> verifyExternalEmail(VerifyExternalUser verifyExternalUser) {
		LOGGER.info("create External User method started..!");

		SystemUsers appUser = getSystemUsers(verifyExternalUser.getUserId());

		Optional<SystemUsers> user = systemUsersrepository.findByEmailAndOrganizationIdAndUserTypeAndStatusNot(
				verifyExternalUser.getEmail(), appUser.getOrganizationId(), UserType.External.toString(),
				StatusConstants.DELETED);
		if (user.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMAIL_ALREADY_EXITS_IN_ORGANIZATION);
		}
		CreateUserResponse createUserResponse = new CreateUserResponse();
		LOGGER.info("Creating new user in the system");

		ExternalUserRequest externalUserRequest = new ExternalUserRequest();
		externalUserRequest.setEmail(verifyExternalUser.getEmail());
		ViewExternalUser externalUserInfo = entityService.getUserInfo(externalUserRequest);
		if (externalUserInfo != null) {
			externalUserInfo.setBrokerCompanyName(externalUserInfo.getBrokerCompanyName());
			externalUserInfo.setName(externalUserInfo.getName());
			externalUserInfo.setFirstName(externalUserInfo.getFirstName());
			externalUserInfo.setLastName(externalUserInfo.getLastName());
			externalUserInfo.setExternalUserBlockOpportunity(externalUserInfo.getExternalUserBlockOpportunity());
			externalUserInfo.setExternalUserGroupOpportunity(externalUserInfo.getExternalUserGroupOpportunity());
			externalUserInfo.setContactNumber(externalUserInfo.getContactNumber());
		}
		createUserResponse.setData(externalUserInfo);

		// providing successful response if user data is stores
		createUserResponse.setStatusText(Constants.SUCCESS);
		createUserResponse.setMessage(Constants.EXTERNAL_USER);
		createUserResponse.setEmail(verifyExternalUser.getEmail());
		LOGGER.info("create External User method ends..!");
		return ResponseEntity.status(HttpStatus.OK).body(createUserResponse);

	}

	@Transactional
	public ResponseEntity<CreateUserResponse> createExternalUser(
			ExternalUserDetailsRequest externalUserDetailsRequest) {
		LOGGER.info("create user method started..!");

		SystemUsers appUser = getSystemUsers(externalUserDetailsRequest.getUserId());

		Optional<SystemUsers> user = systemUsersrepository.findByEmailAndOrganizationIdAndStatusNotAndUserType(
				externalUserDetailsRequest.getEmail(), appUser.getOrganizationId(), StatusConstants.DELETED,
				UserType.External.toString());
		if (user.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.EMAIL_ALREADY_EXITS);
		}
		LOGGER.info("Fecthing role details with role id:: " + externalUserDetailsRequest.getRoleId());
		Optional<Roles> role = rolesRepository.findById(externalUserDetailsRequest.getRoleId());
		if (!role.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ROLE_NOT_FOUND);
		}

		LOGGER.info("Creating new user in the system");
		SystemUsers systemUsers = saveSystemExternalUser(appUser.getOrganizationId(), externalUserDetailsRequest,
				role.get());

		// providing successful response if user data is stores
		CreateUserResponse createUserResponse = new CreateUserResponse();
		createUserResponse.setUserId(systemUsers.getId());
		createUserResponse.setStatusText(Constants.SUCCESS);
		createUserResponse.setMessage(Constants.EXTERNAL_USER);
		LOGGER.info("user is created successfully");
		return ResponseEntity.status(HttpStatus.OK).body(createUserResponse);

	}

	public ResponseEntity<CreateUserResponse> updateExternalUserEmail(
			ExternalUserUpdateRequest externalUserUpdateRequest) {
		LOGGER.info("updateExternalUserEmail method started..!");

		Optional<Organization> optional = organizationRepository
				.findById(externalUserUpdateRequest.getOrganizationId());
		if (!optional.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		CreateUserResponse createUserResponse = new CreateUserResponse();
		Optional<SystemUsers> systemUsers = systemUsersrepository.findByEmailAndOrganizationIdAndUserType(
				externalUserUpdateRequest.getOldEmail(), optional.get(), externalUserUpdateRequest.getType());
		if (systemUsers.isPresent()) {
			if (externalUserUpdateRequest.getNewEmail() != null) {
				systemUsers.get().setEmail(externalUserUpdateRequest.getNewEmail());
			}
			if (externalUserUpdateRequest.getFirstName() != null) {
				systemUsers.get().setFirstName(externalUserUpdateRequest.getFirstName());
			}
			if (externalUserUpdateRequest.getLastName() != null) {
				systemUsers.get().setLastName(externalUserUpdateRequest.getLastName());
			}
			if (externalUserUpdateRequest.getContactNumber() != null) {
				systemUsers.get().setMobileNumber(externalUserUpdateRequest.getContactNumber());
			}
			systemUsers.get().setUpdatedAt(DateAndTimeUtil.now());
			systemUsersrepository.save(systemUsers.get());
			createUserResponse.setUserId(systemUsers.get().getId());
			createUserResponse.setStatusText(Constants.SUCCESS);
			createUserResponse.setMessage(Constants.EXTERNAL_USER_UPDATE);
		} else {
			createUserResponse.setStatusText(Constants.SUCCESS);
			createUserResponse.setMessage(Constants.NO_RESULTS_FOUND);
		}
		return ResponseEntity.status(HttpStatus.OK).body(createUserResponse);

	}
}
