package com.billdog.user.request;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class FamilyMemberRequest {

//	@NotNull(message = "Relationship id must not be null")
	private Long relationshipId;

	@NotNull(message = "Salutation id must not be null")
	private long prefixId;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter First name")
	@Size(min = 2, max = 30, message = "First name must be 2 to 30 characters")
	private String firstName;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter Last name")
	@Size(min = 2, max = 30, message = "Last name must be 2 to 30 characters")
	private String lastName;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String middleName;

	@NotNull(message = "Please enter Date of birth")
	private String dateOfBirth;

	public Long getRelationshipId() {
		return relationshipId;
	}

	public void setRelationshipId(Long relationshipId) {
		this.relationshipId = relationshipId;
	}

	public Long getPrefixId() {
		return prefixId;
	}

	public void setPrefixId(Long prefixId) {
		this.prefixId = prefixId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setPrefixId(long prefixId) {
		this.prefixId = prefixId;
	}

}
