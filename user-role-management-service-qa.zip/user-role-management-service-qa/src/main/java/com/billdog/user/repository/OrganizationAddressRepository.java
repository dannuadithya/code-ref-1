package com.billdog.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.Organization;
import com.billdog.user.entity.OrganizationAddress;

@Repository
public interface OrganizationAddressRepository extends JpaRepository<OrganizationAddress,Long> {

	OrganizationAddress findByOrganizationId(Organization organization);


}
