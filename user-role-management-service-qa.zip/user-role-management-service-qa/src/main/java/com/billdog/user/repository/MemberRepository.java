package com.billdog.user.repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.history.RevisionRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberProduct;
import com.billdog.user.entity.Organization;

@Repository
public interface MemberRepository extends JpaRepository<Member, Long>, RevisionRepository<Member, Long, Integer> {
	@Query(value = "SELECT m.id, m.first_name,m.last_name,me.email,m.phone_number,m.sfdc_id as sfdc_id,m.status,m.organization_id as organization_Id, m.member_id FROM member m  "
			+ "JOIN member_types_master mt on mt.id= m.member_type_master_id JOIN member_email me on me.member_id=m.id and me.is_primary=true where ((CASE WHEN COALESCE(?1,'') <> '' THEN m.first_name ELSE '' END LIKE COALESCE(?2,'') OR CASE WHEN COALESCE(?3,'') <> '' THEN m.last_name ELSE '' END LIKE COALESCE(?4,'')) AND CASE WHEN COALESCE(?5,'') <> '' THEN m.phone_number ELSE '' END LIKE COALESCE(?6,'') AND CASE WHEN COALESCE(?7,'') <> '' THEN me.email ELSE '' END LIKE COALESCE(?8,'') AND CASE WHEN COALESCE(?9,'') <> '' THEN m.sfdc_id ELSE '' END LIKE COALESCE(?10,'') "
			+ "AND CASE WHEN COALESCE(?11,'') <> '' THEN m.status ELSE '' END LIKE COALESCE(?12,'')   "
			+ "AND CASE WHEN COALESCE(?13,'') <> '' THEN m.member_id ELSE '' END = COALESCE(?14,'')) "
			+ "AND m.organization_id = ?15 and mt.member_types_name=?16 order by m.created_at desc", countQuery = "SELECT m.id, m.first_name,m.last_name,me.email,m.phone_number,m.sfdc_id as sfdc_id,m.status,m.organization_id as organization_Id, m.member_id FROM member m  "
					+ "JOIN member_types_master mt on mt.id= m.member_type_master_id JOIN member_email me on me.member_id=m.id and me.is_primary=true where ((CASE WHEN COALESCE(?1,'') <> '' THEN m.first_name ELSE '' END LIKE COALESCE(?2,'') OR CASE WHEN COALESCE(?3,'') <> '' THEN m.last_name ELSE '' END LIKE COALESCE(?4,'')) AND CASE WHEN COALESCE(?5,'') <> '' THEN m.phone_number ELSE '' END LIKE COALESCE(?6,'') AND CASE WHEN COALESCE(?7,'') <> '' THEN me.email ELSE '' END LIKE COALESCE(?8,'') AND CASE WHEN COALESCE(?9,'') <> '' THEN m.sfdc_id ELSE '' END LIKE COALESCE(?10,'') "
					+ "AND CASE WHEN COALESCE(?11,'') <> '' THEN m.status ELSE '' END LIKE COALESCE(?12,'')   "
					+ "AND CASE WHEN COALESCE(?13,'') <> '' THEN m.member_id ELSE '' END = COALESCE(?14,'')) "
					+ "AND m.organization_id = ?15 and mt.member_types_name=?16 order by m.created_at desc", nativeQuery = true)
	Page<Object[][]> getAllDirectMembers(String firstName, String firstName2, String lastName, String lastName2,
			String mobileNumber, String mobileNumber2, String email, String email2, String sfdcId, String sfdcId2,
			String status, String status2, String memberId, String memberId2, Long organizationId, String memberType,
			PageRequest pageRequest);

	@Query(value = "SELECT  m.first_name,m.last_name,m.sfdc_id,m.PHONE_NUMBER,m.status,me.email,m.id,m.member_id,mp.product_name,m.locked,me.last_passcode_verified,me.last_password_verified,m.locked_from_web,mtm.member_types_name,m.member_type_master_id"
			+ " FROM member m join member_email me on me.member_id = m.id and me.is_primary=true and IS_DELETED = false left join member_product mp on mp.id = m.product_id join member_types_master mtm on mtm.id = m.member_type_master_id"
			+ " where (CASE WHEN COALESCE(?1,'') <> '' THEN m.first_name ELSE '' END LIKE COALESCE(?2,'') or"
			+ " CASE WHEN COALESCE(?3,'') <> '' THEN m.last_name ELSE '' END LIKE COALESCE(?4,'')) and "
			+ " CASE WHEN COALESCE(?5,'') <> '' THEN m.PHONE_NUMBER ELSE '' END LIKE COALESCE(?6,'') and "
			+ " CASE WHEN COALESCE(?7,'') <> '' THEN me.email ELSE '' END LIKE COALESCE(?8,'') and "
			+ " CASE WHEN COALESCE(?9,'') <> '' THEN m.status ELSE '' END LIKE COALESCE(?10,'') and "
			+ " CASE WHEN COALESCE(?11,'') <> '' THEN m.sfdc_id ELSE '' END LIKE COALESCE(?12,'') and "
			+ " CASE WHEN COALESCE(?13,'') <> '' THEN m.member_id ELSE '' END = COALESCE(?14,'') and "
			+ " CASE WHEN COALESCE(?15,-999) <> -999 THEN m.MEMBER_TYPE_MASTER_ID ELSE -999 END = COALESCE(?16,-999)  order by m.created_at desc", countQuery = "SELECT  m.first_name,m.last_name,m.sfdc_id,m.PHONE_NUMBER,m.status,me.email,m.id,m.member_id,mp.product_name,m.locked,me.last_passcode_verified,me.last_password_verified,locked_from_web,mtm.member_types_name,m.member_type_master_id"
					+ " FROM member m "
					+ " join member_email me on me.member_id = m.id and me.is_primary=true and IS_DELETED = false left join member_product mp on mp.id = m.product_id join member_types_master mtm on mtm.id = m.member_type_master_id"

					+ " where (CASE WHEN COALESCE(?1,'') <> '' THEN m.first_name ELSE '' END LIKE COALESCE(?2,'') or "
					+ " CASE WHEN COALESCE(?3,'') <> '' THEN m.last_name ELSE '' END LIKE COALESCE(?4,'')) and "
					+ " CASE WHEN COALESCE(?5,'') <> '' THEN m.PHONE_NUMBER ELSE '' END LIKE COALESCE(?6,'') and "
					+ " CASE WHEN COALESCE(?7,'') <> '' THEN me.email ELSE '' END LIKE COALESCE(?8,'') and "
					+ " CASE WHEN COALESCE(?9,'') <> '' THEN m.status ELSE '' END LIKE COALESCE(?10,'') and "
					+ " CASE WHEN COALESCE(?11,'') <> '' THEN m.sfdc_id ELSE '' END LIKE COALESCE(?12,'') and "
					+ " CASE WHEN COALESCE(?13,'') <> '' THEN m.member_id ELSE '' END = COALESCE(?14,'') and "
					+ " CASE WHEN COALESCE(?15,-999) <> -999 THEN m.MEMBER_TYPE_MASTER_ID ELSE -999 END = COALESCE(?16,-999)  order by m.created_at desc", nativeQuery = true)
	Page<Object[][]> getMemberDetails(String memberFirstName, String memberFirstName2, String memberLastName,
			String memberLastName2, String mobileNumber, String mobileNumber2, String email, String email2,
			String status, String status2, String sfdcId, String sfdcId2, String memberId, String memberId2,
			Long opportunity, Long opportunity2, PageRequest pageRequest);

	@Query(value = "SELECT member_id FROM member where organization_id=?1 ORDER BY member_id DESC LIMIT 1", nativeQuery = true)
	String getMaxMemberId(Long orgId);

	List<Member> findByMemberId(String memberId);

	List<Member> findByStatus(String pending);

	@Query(value = "SELECT count(*) FROM billdog_user.member\n"
			+ "where created_at between ?1 and ?2", nativeQuery = true)
	Long getSumOfMembers(LocalDate currentMonthDate, LocalDate localDate);

	@Query(value = "SELECT count(*) FROM billdog_user.member_family\n"
			+ "where created_at between ?1 and ?2", nativeQuery = true)
	Long getSumOfFamilyMembers(LocalDate currentMonthDate, LocalDate localDate);

	Optional<Member> findByIdAndLocked(long id, boolean b);

	List<Member> findByProductId(MemberProduct productId);

	@Query(value = "SELECT count(*) FROM member m \n" + "join member_product mp on mp.id = m.product_Id\n"
			+ "where mp.product_name = 'Single'", nativeQuery = true)
	Long getSingleMembers();

	@Query(value = "SELECT count(*) FROM member m \n" + "join member_product mp on mp.id = m.product_Id\n"
			+ "where mp.product_name = 'Married'", nativeQuery = true)
	Long getMarriedMembers();

	@Query(value = "SELECT count(*) FROM member m \n" + "join member_product mp on mp.id = m.product_Id\n"
			+ "where mp.product_name = 'Family'", nativeQuery = true)
	Long getFamilyMembers();

	Optional<Member> findByIdAndLockedAndLockedFromWeb(long id, boolean b, boolean c);

	List<Member> findAllBySfdcId(String object);

	long countBySfdcIdNotNull();

	long countBySfdcIdNotNullAndOrganizationId(Organization organizationId);

	long countByOrganizationId(Organization organizationId);

	List<Member> findAllByOrganizationId(Organization organizationId);

	List<Member> findAllBySfdcIdNullAndOrganizationId(Organization organizationId);

	@Query(value = "SELECT * FROM member where employer_Id = ?1", nativeQuery = true)
	Page<Member> getMembersByopportunity(Long employerId, PageRequest pageRequest);

	List<Member> findByEmployerIdAndOrganizationId(Long oldEmployerId, Organization organizationId);

	Optional<Member> findByIdAndEmployerId(Long memberId, Long employerId);

	@Query(value = "SELECT * FROM member where employer_Id = ?1 order by created_at desc", countQuery = "SELECT * FROM member where employer_Id = ?1 order by created_at desc", nativeQuery = true)
	Page<Member> getMembersByEmployer(Long employerId, PageRequest pageRequest);

	@Query(value = "SELECT  count(*) memberCount,employer_Id FROM billdog_user.member where employer_Id in (?1) and status in ('Active','Activated') group by employer_Id ", countQuery = "SELECT  count(*) memberCount,employer_Id FROM billdog_user.member where employer_Id in (?1) and status in ('Active','Activated') group by employer_Id ", nativeQuery = true)
	Object[][] getEmployerCount(List<Long> list);

	@Query(value = "select ma.id,ma.revtype,ma.updated_at,ma.updated_by,ma.last_name,ma.first_name,ma.date_of_birth,\n"
			+ "ma.phone_number,ma.status,ma.gender_master_id,ma.name_prefix_master_id,ma.product_id,ma.middle_name,\n"
			+ "ma.rev,ma.user_id,concat(su.first_name ,' ',su.last_name) as userName,gm.gender,npm.prefix,\n"
			+ "mp.product_name,ma.audit_id,ma.sfdc_id, ma.locked, ma.locked_from_web from member_aud ma left join system_users su on su.id = ma.user_id\n"
			+ "left join gender_master gm on gm.id = ma.gender_master_id\n"
			+ "left join name_prefix_master npm on npm.id = ma.name_prefix_master_id\n"
			+ "left join member_product mp on mp.id = ma.product_id\n"
			+ "    left join member m on m.id = ma.id\n"
			+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN ma.first_name ELSE '' END LIKE COALESCE(?2,'') or \n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN ma.last_name ELSE '' END LIKE COALESCE(?4,'')) \n"
			+ "and date(ma.updated_at) BETWEEN ?5 AND ?6 and ma.revtype in ?7 and m.organization_id = ?8\n"
			+ "order by ma.rev desc,ma.updated_at desc", countQuery = "select ma.id,ma.revtype,ma.updated_at,ma.updated_by,ma.last_name,ma.first_name,ma.date_of_birth,\n"
					+ "ma.phone_number,ma.status,ma.gender_master_id,ma.name_prefix_master_id,ma.product_id,ma.middle_name,\n"
					+ "ma.rev,ma.user_id,concat(su.first_name ,' ',su.last_name) as userName,gm.gender,npm.prefix,\n"
					+ "mp.product_name,ma.audit_id,ma.sfdc_id, ma.locked, ma.locked_from_web from member_aud ma left join system_users su on su.id = ma.user_id\n"
					+ "left join gender_master gm on gm.id = ma.gender_master_id\n"
					+ "left join name_prefix_master npm on npm.id = ma.name_prefix_master_id\n"
					+ "left join member_product mp on mp.id = ma.product_id\n"
					+ "    left join member m on m.id = ma.id\n"
					+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN ma.first_name ELSE '' END LIKE COALESCE(?2,'') or \n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN ma.last_name ELSE '' END LIKE COALESCE(?4,'')) \n"
					+ "and date(ma.updated_at) BETWEEN ?5 AND ?6 and ma.revtype in ?7 and m.organization_id = ?8\n"
					+ "order by ma.rev desc,ma.updated_at desc", nativeQuery = true)
	Page<Object[]> getMemberAuditInfo(String name, String name2, String name3, String name4, String startDate,
			String endDate, List<Long> revtypes, long organizationId, PageRequest pageRequest);

	@Query(value = "select ma.id,ma.revtype,ma.updated_at,ma.updated_by,ma.last_name,ma.first_name,ma.date_of_birth,\n"
			+ "ma.phone_number,ma.status,ma.gender_master_id,ma.name_prefix_master_id,ma.product_id,ma.middle_name,\n"
			+ "ma.rev,ma.user_id,concat(su.first_name ,' ',su.last_name) as userName,gm.gender,npm.prefix,\n"
			+ "mp.product_name,ma.audit_id,ma.sfdc_id, ma.locked, ma.locked_from_web from member_aud ma left join system_users su on su.id = ma.user_id\n"
			+ "left join gender_master gm on gm.id = ma.gender_master_id\n"
			+ "left join name_prefix_master npm on npm.id = ma.name_prefix_master_id\n"
			+ "left join member_product mp on mp.id = ma.product_id\n"
			+ "    left join member m on m.id = ma.id\n"
			+ "where ma.id =?1 and ma.rev<?2 order by ma.rev desc, ma.updated_at desc limit 1", countQuery = "select ma.id,ma.revtype,ma.updated_at,ma.updated_by,ma.last_name,ma.first_name,ma.date_of_birth,\n"
					+ "ma.phone_number,ma.status,ma.gender_master_id,ma.name_prefix_master_id,ma.product_id,ma.middle_name,\n"
					+ "ma.rev,ma.user_id,concat(su.first_name ,' ',su.last_name) as userName,gm.gender,npm.prefix,\n"
					+ "mp.product_name,ma.audit_id,ma.sfdc_id, ma.locked, ma.locked_from_web from member_aud ma left join system_users su on su.id = ma.user_id\n"
					+ "left join gender_master gm on gm.id = ma.gender_master_id\n"
					+ "left join name_prefix_master npm on npm.id = ma.name_prefix_master_id\n"
					+ "left join member_product mp on mp.id = ma.product_id\n"
					+ "    left join member m on m.id = ma.id\n"
					+ "where ma.id =?1 and ma.rev<?2 order by ma.rev desc, ma.updated_at desc limit 1", nativeQuery = true)
	List<Object[]> getMemberAuditInfoByIdAndRev(long id, long rev);

	@Query(value = "select id, revtype,updated_at, updated_by, address_line1, address_line2,city_name,\n"
			+ "street,zip_code,user_id from billdog_user.member_address_aud \n"
			+ "where id = ?1 and updated_at<?2 limit 1", countQuery = "select id, revtype,updated_at, updated_by, address_line1, address_line2,city_name,\n"
					+ "street,zip_code,user_id from billdog_user.member_address_aud \n"
					+ "where id = ?1 and updated_at<?2 limit 1", nativeQuery = true)
	List<Object[]> getMemberAddressAuditInfoById(long id, String updatedAt);

	@Query(value = "select mau.id, mau.revtype,mau.updated_at, mau.updated_by, mau.address_line1, mau.address_line2,mau.city_name,mau.street,mau.zip_code,mau.user_id,concat(su.first_name ,' ',su.last_name) as userName\n"
			+ "from member_address_aud mau\n"
			+ "left join system_users su on su.id = mau.user_id where mau.member_id = ?1 and mau.audit_id=?2  order by mau.updated_at desc limit 2", countQuery = "select mau.id, mau.revtype,mau.updated_at, mau.updated_by, mau.address_line1, mau.address_line2,mau.city_name,mau.street,mau.zip_code,mau.user_id,concat(su.first_name ,' ',su.last_name) as userName\n"
					+ "from member_address_aud mau\n"
					+ "left join system_users su on su.id = mau.user_id where mau.member_id = ?1 and mau.audit_id=?2 order by mau.updated_at desc limit 2", nativeQuery = true)
	List<Object[]> getMemberAddressAuditInfo(long memberId, String auditId);

	@Query(value = "select mea.id, mea.revtype,mea.is_deleted, mea.email,mea.is_primary, mea.rev from member_email_aud mea\n"
			+ "left join system_users su on su.id = mea.user_id where mea.member_id = ?1 and mea.audit_id=?2 order by mea.updated_at desc, mea.rev desc",
			countQuery = "select mea.id, mea.revtype,mea.is_deleted, mea.email,mea.is_primary, mea.rev from member_email_aud mea\n"
					+ "left join system_users su on su.id = mea.user_id where mea.member_id = ?1 and mea.audit_id=?2 order by mea.updated_at desc, mea.rev desc", nativeQuery = true)
	List<Object[]> getMemberEmailAuditInfo(long memberId, String auditId);
	
	
	@Query(value = "select mea.id, mea.revtype,mea.is_deleted, mea.email,mea.is_primary, mea.rev\n"
			+ "from member_email_aud mea\n"
			+ "left join system_users su on su.id = mea.user_id where mea.id = ?1 and mea.rev<?2 order by mea.rev desc limit 1", countQuery = "select mea.id, mea.revtype,mea.is_deleted, mea.email,mea.is_primary, mea.rev from member_email_aud mea\n"
					+ "left join system_users su on su.id = mea.user_id where mea.id = ?1 and mea.rev<?2 order by mea.rev desc limit 1", nativeQuery = true)
	List<Object[]> getMemberEmailAuditById(long id, long rev);

	@Query(value = "select ma.id,ma.revtype,ma.updated_at,ma.updated_by,ma.last_name,ma.first_name,ma.date_of_birth,\n"
			+ "ma.phone_number,ma.status,ma.gender_master_id,ma.name_prefix_master_id,ma.product_id,ma.middle_name,\n"
			+ "ma.rev,ma.user_id,concat(su.first_name ,' ',su.last_name) as userName,gm.gender,npm.prefix,\n"
			+ "mp.product_name,ma.audit_id,ma.sfdc_id, ma.locked, ma.locked_from_web  from member_aud ma left join system_users su on su.id = ma.user_id\n"
			+ "left join gender_master gm on gm.id = ma.gender_master_id\n"
			+ "left join name_prefix_master npm on npm.id = ma.name_prefix_master_id\n"
			+ "left join member_product mp on mp.id = ma.product_id\n"
			+ "    left join member m on m.id = ma.id\n"
			+ "where ma.id=?1 order by ma.rev desc", countQuery = "select ma.id,ma.revtype,ma.updated_at,ma.updated_by,ma.last_name,ma.first_name,ma.date_of_birth,\n"
					+ "ma.phone_number,ma.status,ma.gender_master_id,ma.name_prefix_master_id,ma.product_id,ma.middle_name,\n"
					+ "ma.rev,ma.user_id,concat(su.first_name ,' ',su.last_name) as userName,gm.gender,npm.prefix,\n"
					+ "mp.product_name,ma.audit_id,ma.sfdc_id, ma.locked, ma.locked_from_web  from member_aud ma left join system_users su on su.id = ma.user_id\n"
					+ "left join gender_master gm on gm.id = ma.gender_master_id\n"
					+ "left join name_prefix_master npm on npm.id = ma.name_prefix_master_id\n"
					+ "left join member_product mp on mp.id = ma.product_id\n"
					+ "    left join member m on m.id = ma.id\n"
					+ "where ma.id=?1 order by ma.rev desc", nativeQuery = true)
	Page<Object[]> getMemberAuditInfoById(Long id, PageRequest pageRequest);

	List<Member> findAllBySfdcIdNullAndOrganizationIdOrderByCreatedAtDesc(Organization organizationId);

	@Query(value = "select maa.id, maa.revType,maa.rev, maa.address_line1, maa.address_line2,maa.city_name, maa.street, maa.zip_code,\n"
			+ "			cm.country_name, sm.state_name\n"
			+ "from member_address_aud maa\n"
			+ "left join state_master sm on sm.id=maa.state_master_id\n"
			+ "left join country_master cm on cm.id=maa.country_master_id where maa.audit_id=?1 order by maa.rev desc", countQuery = "select maa.id, maa.revType,maa.rev, maa.address_line1, maa.address_line2,maa.city_name, maa.street, maa.zip_code,\n"
					+ "			cm.country_name, sm.state_name\n"
					+ "from member_address_aud maa\n"
					+ "left join state_master sm on sm.id=maa.state_master_id\n"
					+ "left join country_master cm on cm.id=maa.country_master_id where maa.audit_id=?1 order by maa.rev desc", nativeQuery = true)
	List<Object[]> getMemberAddressInfo(String auditId);
	
	
	@Query(value = "select maa.id, maa.revType,maa.rev, maa.address_line1, maa.address_line2,maa.city_name, maa.street, maa.zip_code,\n"
			+ "			cm.country_name, sm.state_name\n"
			+ "from member_address_aud maa\n"
			+ "left join state_master sm on sm.id=maa.state_master_id\n"
			+ "left join country_master cm on cm.id=maa.country_master_id \n"
			+ "where maa.id=?1 and maa.rev<?2 order by maa.rev desc limit 1", countQuery = "select maa.id, maa.revType,maa.rev, maa.address_line1, maa.address_line2,maa.city_name, maa.street, maa.zip_code,\n"
					+ "			cm.country_name, sm.state_name\n"
					+ "from member_address_aud maa\n"
					+ "left join state_master sm on sm.id=maa.state_master_id\n"
					+ "left join country_master cm on cm.id=maa.country_master_id \n"
					+ "where maa.id=?1 and maa.rev<?2 order by maa.rev desc limit 1", nativeQuery = true)
	List<Object[]> getMemberAddressInfoById(long id, long rev);




@Query(value = "select m.id,m.first_name, concat(m.first_name,' ',m.last_name) member_name,\n"
		+ "       m.member_id, me.email,m.fcm_token, m.status,o.name,o.email org_email, o.phone_number,o.file_size,\n"
		+ "       ma.expired_at, ma.reason, o.id org_id\n"
		+ "       from member m\n"
		+ "left join member_email me on me.member_id = m.id and me.is_primary=true\n"
		+ "left join auth_tokens ma on ma.member_id =m.id\n"
		+ "left join organization o on o.id =m.organization_id\n"
		+ "where m.id=?1 and ma.token=?2", countQuery = "select m.id,m.first_name, concat(m.first_name,' ',m.last_name) member_name,\n"
				+ "       m.member_id, me.email,m.fcm_token, m.status,o.name,o.email org_email, o.phone_number,o.file_size,\n"
				+ "       ma.expired_at, ma.reason, o.id org_id\n"
				+ "       from member m\n"
				+ "left join member_email me on me.member_id = m.id and me.is_primary=true\n"
				+ "left join auth_tokens ma on ma.member_id =m.id\n"
				+ "left join organization o on o.id =m.organization_id\n"
				+ "where m.id=?1 and ma.token=?2", nativeQuery = true)
List<Object[]> getMemberInfo(long memberId, String token);

@Query(value = "select m.id, ma.expired_at, ma.reason, o.email org_email, m.status from member m\n"
		+ "left join auth_tokens ma on ma.member_id =m.id\n"
		+ "left join organization o on o.id =m.organization_id\n"
		+ "where m.id =?1 and ma.token=?2\n"
		+ "order by ma.id desc limit 1", countQuery ="select m.id, ma.expired_at, ma.reason, o.email org_email, m.status from member m\n"
				+ "left join auth_tokens ma on ma.member_id =m.id\n"
				+ "left join organization o on o.id =m.organization_id\n"
				+ "where m.id =?1 and ma.token=?2\n"
				+ "order by ma.id desc limit 1", nativeQuery = true)
List<Object[]> getMemberTokenInfo(long id, String token);

}
