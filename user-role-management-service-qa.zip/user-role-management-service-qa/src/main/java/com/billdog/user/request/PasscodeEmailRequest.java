package com.billdog.user.request;

import com.billdog.user.common.EmailTitles;
import com.billdog.user.entity.SystemUsers;

public class PasscodeEmailRequest {

	private String passcode;

	private String email;

	private EmailTitles emailTitle;

	private Long userId;

	private String username;

	private String senderName;

	private Long organizationId;

	public PasscodeEmailRequest(SystemUsers systemUser, String passcode2, EmailTitles emailTitle2) {
		this.email = systemUser.getEmail();
		this.passcode = passcode2;
		this.emailTitle = emailTitle2;
		this.userId = systemUser.getId();
		this.username = systemUser.getFirstName();
		this.senderName = systemUser.getOrganizationId().getName();
		this.organizationId = systemUser.getOrganizationId().getId();
	}

	public PasscodeEmailRequest() {

	}

	public String getPasscode() {
		return passcode;
	}

	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public EmailTitles getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(EmailTitles emailTitle) {
		this.emailTitle = emailTitle;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

}
