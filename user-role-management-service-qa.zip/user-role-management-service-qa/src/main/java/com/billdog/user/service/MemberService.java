package com.billdog.user.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.authentication.AesEncryption;
import com.billdog.user.authentication.JWTAuthentication;
import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.AuthTokens;
import com.billdog.user.entity.CountryMaster;
import com.billdog.user.entity.CountryPhoneCodeMaster;
import com.billdog.user.entity.GenderMaster;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberAddress;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.MemberFamily;
import com.billdog.user.entity.MemberProduct;
import com.billdog.user.entity.MemberTypeMaster;
import com.billdog.user.entity.NamePrefixMaster;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.OrganizationAddress;
import com.billdog.user.entity.StateMaster;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.exception.InvalidAuthTokenException;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.repository.AuthTokensRepository;
import com.billdog.user.repository.CountryMasterRepository;
import com.billdog.user.repository.CountryPhoneCodeMasterRepository;
import com.billdog.user.repository.GenderMasterRepository;
import com.billdog.user.repository.MemberAddressRepository;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberFamilyRepository;
import com.billdog.user.repository.MemberProductRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.repository.NamePrefixMasterRepository;
import com.billdog.user.repository.OrganizationAddressRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.StateMasterRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.AddDirectMemberInfoRequest;
import com.billdog.user.request.CreateMemberPassword;
import com.billdog.user.request.GetMemberCountRequest;
import com.billdog.user.request.GetMembersRequest;
import com.billdog.user.request.MemberCaseCountRequest;
import com.billdog.user.request.MemberPersonalDetails;
import com.billdog.user.request.UpdateMemberPassword;
import com.billdog.user.request.WelcomeEmailMemberRequest;
import com.billdog.user.view.GetCountryCodeInfo;
import com.billdog.user.view.GetEmployerInfo;
import com.billdog.user.view.GetMemberCaseCount;
import com.billdog.user.view.GetMemberChatInfo;
import com.billdog.user.view.MemberCaseCount;
import com.billdog.user.view.MemberInfo;
import com.billdog.user.view.MemberInfoResponse;
import com.billdog.user.view.MemberTokenResponse;
import com.billdog.user.view.PasswordResponse;
import com.billdog.user.view.PhoneCodeMasterView;
import com.billdog.user.view.ViewCountries;
import com.billdog.user.view.ViewDirectMemberInfo;
import com.billdog.user.view.ViewGender;
import com.billdog.user.view.ViewMember;
import com.billdog.user.view.ViewMemberCountByEmployer;
import com.billdog.user.view.ViewMemberProduct;
import com.billdog.user.view.ViewMemberResponse;
import com.billdog.user.view.ViewMembers;
import com.billdog.user.view.ViewOpportunities;
import com.billdog.user.view.ViewOpportunityDetails;
import com.billdog.user.view.ViewResponse;
import com.billdog.user.view.ViewStates;

@Service
public class MemberService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MemberService.class);

	@Value("${member.jwt.token.minutes}")
	private Integer memberTokenExpiryTime;

	@Value("${member.refresh.token.minutes}")
	private Integer memberRefreshTokenExpiryTime;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	LoginService loginService;

	@Autowired
	AesEncryption aesEncryption;

	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Autowired
	JWTAuthentication jwtAuthentication;

	@Autowired
	NamePrefixMasterRepository namePrefixMasterRepository;

	@Autowired
	GenderMasterRepository genderMasterRepository;

	@Autowired
	CountryPhoneCodeMasterRepository countryPhoneCodeMasterRepository;

	@Autowired
	CountryMasterRepository countryMasterRepository;

	@Autowired
	StateMasterRepository stateMasterRepository;

	@Autowired
	MemberAddressRepository memberAddressRepository;

	@Autowired
	MemberProductRepository memberProductRepository;

	@Autowired
	MemberTypeMasterRepository memberTypeMasterRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	AuthTokensRepository authTokensRepository;

	@Autowired
	MemberFamilyRepository memberFamilyRepository;

	@Autowired
	OrganizationAddressRepository organizationAddressRepository;

	@Autowired
	EmailService emailService;
	@Autowired
	GetProfileDetails getProfileDetails;

	@Autowired
	LogoutService logoutService;

	@Autowired
	EntityService entityService;

	@Autowired
	SystemUsersrepository systemUsersrepository;

	@Autowired
	CaseService caseService;

	@Autowired
	AuditService auditService;

	private static final String PASSWORD_REGEX = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[`~!@#$%^&-+=_':|<.,>;?\\[\\]\\)\\({}/])(?=\\S+$).{10,16}$";

	private static final Pattern PASSWORD_PATTERN = Pattern.compile(PASSWORD_REGEX);

	/*
	 * This method will take email and password to
	 */
	public PasswordResponse createPassword(CreateMemberPassword memberPassword) {
		LOGGER.info("createPassword strated..");
		checkPassword(memberPassword.getPassword());
		Member member = getMember(memberPassword.getMemberId());
		MemberEmail memberEmail = getMemberEmail(member);

		String encryptedPassword = aesEncryption.passwordHashing(memberPassword.getPassword());
		if (!StringUtils.isBlank(encryptedPassword) && !StringUtils.isBlank(memberEmail.getPassword())
				&& encryptedPassword.equalsIgnoreCase(memberEmail.getPassword())) {
			throw new InValidInputException(ExceptionalMessages.PASSWORD_MATCHED);
		}

		String message = savePassword(memberPassword.getPassword(), member, memberEmail);

		PasswordResponse viewResponse = new PasswordResponse();
		viewResponse.setMemberId(member.getId());
		viewResponse.setMessage(message);
		viewResponse.setMessageTitle("Success!");
		LOGGER.debug("Generating jwttoken for member with id:: {}", member.getId());
		MemberCaseCountRequest caseCountRequest = new MemberCaseCountRequest();
		caseCountRequest.setOrganizationId(member.getOrganizationId().getId());
		List<Long> memberIds = new ArrayList<>();
		memberIds.add(member.getId());
		caseCountRequest.setMemberIds(memberIds);
		String status = member.getStatus();

		if (member.getStatus() == null || member.getStatus().equalsIgnoreCase(StatusConstants.PENDING)) {
			member.setStatus(StatusConstants.ENROLLED);
		} else if ((member.isProfileUpdated() && !member.getStatus().equalsIgnoreCase(StatusConstants.ACTIVE))
				|| (member.getStatus().equalsIgnoreCase(StatusConstants.ENROLLED)
						&& !member.getMemberTypeMasterId().getTypeName().equalsIgnoreCase(StatusConstants.DIRECT))) {
			member.setStatus(StatusConstants.ACTIVATED);
		}

		if (!member.getStatus().equalsIgnoreCase(StatusConstants.ACTIVE)) {
			GetMemberCaseCount memberCaseCount = caseService.getMemberCaseCount(caseCountRequest);
			if (memberCaseCount != null && memberCaseCount.getMemberCaseCount() != null
					&& !memberCaseCount.getMemberCaseCount().isEmpty()) {
				MemberCaseCount memberCaseCount2 = memberCaseCount.getMemberCaseCount().get(0);
				if (memberCaseCount2.getCaseCount() > 0) {
					member.setStatus(StatusConstants.ACTIVE);
				}
			}
		}

		if ((StringUtils.isBlank(member.getStatus()) && !StringUtils.isBlank(status))
				|| (!StringUtils.isBlank(status) && !status.equalsIgnoreCase(member.getStatus()))) {
			if (memberPassword.getDeviceToken() != null) {
				member.setDeviceToken(memberPassword.getDeviceToken());
			}
			member.setAuditId(auditService.getAuditId());
			member.setUpdatedAt(DateAndTimeUtil.now());
			if(!StringUtils.isBlank(memberPassword.getDeviceType())) {
				member.setDeviceType(memberPassword.getDeviceType());
			}
			memberRepository.save(member);
		}

		String token = jwtAuthentication.generateToken(member.getId(), Boolean.FALSE);
		String refreshToken = jwtAuthentication.generateRefreshToken(member.getId());
		saveToken(token, refreshToken, member);
		viewResponse.setRefreshToken(refreshToken);
		viewResponse.setToken(token);
		viewResponse.setProfileUpdated(member.isProfileUpdated());
		if (member.isProfileUpdated()) {
			viewResponse.setIndirectMemberPopUp(Constants.INDIRECT_MEMBER_POPUP);
		} else {
			viewResponse.setIndirectMemberPopUp(null);
		}
		viewResponse.setIndirectMember(member.getMemberTypeMasterId() != null
				&& !member.getMemberTypeMasterId().getTypeName().equalsIgnoreCase(StatusConstants.DIRECT));
		viewResponse.setStatusText(Constants.SUCCESS);
		LOGGER.info("createPassword ended..");
		return viewResponse;
	}

	public void saveToken(String token, String refreshToken, Member member) {
		LOGGER.info("Save token method started..!");
		LOGGER.info("Checking member is already exists in tokens table");
		Optional<AuthTokens> memberTokenOptional = authTokensRepository.findByMemberId(member);
		if (memberTokenOptional.isPresent()) {
			LOGGER.info("Updating member token info for member id:: {}", member.getId());
			memberTokenOptional.get().setExpiredAt(DateAndTimeUtil.now().plusMinutes(memberTokenExpiryTime));
			memberTokenOptional.get().setToken(token);
			memberTokenOptional.get().setUpdatedAt(DateAndTimeUtil.now());
			memberTokenOptional.get().setRefreshToken(refreshToken);
			memberTokenOptional.get()
					.setRefreshTokenExpiredAt(DateAndTimeUtil.now().plusMinutes(memberRefreshTokenExpiryTime));
			if (member.getDeviceToken() != null) {
				memberTokenOptional.get().setDeviceToken(member.getDeviceToken());
			}
			authTokensRepository.save(memberTokenOptional.get());
		} else {
			LOGGER.info("Creating member token info for member id:: {}", member.getId());
			AuthTokens authTokens = new AuthTokens();
			authTokens.setCreatedAt(DateAndTimeUtil.now());
			authTokens.setExpiredAt(DateAndTimeUtil.now().plusMinutes(memberTokenExpiryTime));
			authTokens.setMemberId(member);
			authTokens.setOrganizationId(member.getOrganizationId());
			authTokens.setToken(token);
			authTokens.setRefreshToken(refreshToken);
			authTokens.setRefreshTokenExpiredAt(DateAndTimeUtil.now().plusMinutes(memberRefreshTokenExpiryTime));
			if (member.getDeviceToken() != null) {
				authTokens.setDeviceToken(member.getDeviceToken());
			}
			authTokens.setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(authTokens);
			LOGGER.info("Created member token info with id:: {}", authTokens.getId());
		}
		LOGGER.info("Save token method ended..!");
	}

	public PasswordResponse updatePassword(UpdateMemberPassword updateMemberPassword) {
		LOGGER.info("updatePassword strated..");
		if (!updateMemberPassword.getNewPassword().equals(updateMemberPassword.getConfirmNewPassword())) {
			throw new InValidInputException(ExceptionalMessages.MEMBER_CONFIRM_PASSWORD);
		}
		checkPassword(updateMemberPassword.getNewPassword());
		Member member = getMember(updateMemberPassword.getMemberId());
		checkOldPassword(updateMemberPassword.getOldPassword(), member, updateMemberPassword);
		MemberEmail memberEmail = getMemberEmail(member);
		String message = updatePassword(updateMemberPassword.getNewPassword(), member, null, memberEmail);
		expireToken(member);
		if (memberEmail != null && !StringUtils.isBlank(memberEmail.getEmail())) {
			WelcomeEmailMemberRequest welcomeEmailMemberRequest = new WelcomeEmailMemberRequest();
			welcomeEmailMemberRequest.setEmail(memberEmail.getEmail());
			welcomeEmailMemberRequest.setEmailTitle(EmailTitles.PASSWORD_RESET);
			welcomeEmailMemberRequest.setFirstName(member.getFirstName());
			welcomeEmailMemberRequest.setOrgId(member.getOrganizationId().getId());
			emailService.sendEamilToMember(welcomeEmailMemberRequest);
		}
		PasswordResponse viewResponse = new PasswordResponse();
		viewResponse.setMemberId(member.getId());
		viewResponse.setMessage(message);
		LOGGER.debug("Generating jwttoken for member with id:: {}", member.getId());
		viewResponse.setProfileUpdated(member.isProfileUpdated());
		viewResponse.setStatusText(Constants.SUCCESS);
		LOGGER.info("updatePassword ended..");
		return viewResponse;
	}

	public void expireToken(Member member) {
		LOGGER.info("Save member token method started..!");
		LOGGER.info("Checking member is already exists in tokens table");
		Optional<AuthTokens> memberTokenOptional = authTokensRepository.findByMemberId(member);
		if (memberTokenOptional.isPresent()) {
			LOGGER.info("Updating member token info for member id:: {}", member.getId());
			memberTokenOptional.get().setExpiredAt(DateAndTimeUtil.now());
			memberTokenOptional.get().setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(memberTokenOptional.get());
		} else {
			LOGGER.info("Creating member token info for member id:: {}", member.getId());
			AuthTokens authTokens = new AuthTokens();
			authTokens.setCreatedAt(DateAndTimeUtil.now());
			authTokens.setExpiredAt(DateAndTimeUtil.now());
			authTokens.setMemberId(member);
			authTokens.setOrganizationId(member.getOrganizationId());
			authTokens.setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(authTokens);
			LOGGER.info("Created member token info with id:: {}", authTokens.getId());
		}
		LOGGER.info("Save member token method started..!");
	}

	private void checkOldPassword(String oldPassword, Member member, UpdateMemberPassword updateMemberPassword) {
		Optional<MemberEmail> memberEmailOptional = memberEmailRepository
				.findByMemberIdAndPrimaryAndDeletedAndVerified(member, true, false, true);
		if (!memberEmailOptional.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.MEMBER_PRIMARY_EMAIL_NOT_FOUND);
		}
		LOGGER.debug("encrypting requested password");
		String encryptedPassword = aesEncryption.passwordHashing(oldPassword);
		String encryptedNewPassword = aesEncryption.passwordHashing(updateMemberPassword.getNewPassword());
		LOGGER.debug("checking pasword matches or not..!");
		if (memberEmailOptional.get().getPassword() == null || (memberEmailOptional.get().getPassword() != null
				&& !encryptedPassword.equals(memberEmailOptional.get().getPassword()))) {
			throw new NoRecordFoundException(ExceptionalMessages.INCORRECT_OLD_PASSWORD);
		}

		if (encryptedNewPassword.equals(memberEmailOptional.get().getPassword())) {
			throw new InValidInputException(ExceptionalMessages.SAME_OLD_NEW_PASSWORD);
		}

	}

	public Member getMember(Long memberId) {

		Optional<Member> memberOptional = memberRepository.findById(memberId);
		if (!memberOptional.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		LOGGER.info("Member detils are fetched for id:: {}", memberId);
		return memberOptional.get();
	}

	private String savePassword(String password, Member member, MemberEmail memberEmail) {
		LOGGER.info("Saving password of Member with id:: {}", member.getId());
		String message = "";
		if (memberEmail != null) {
			String encryptedPassword = aesEncryption.passwordHashing(password);
			memberEmail.setUpdatedAt(DateAndTimeUtil.now());
			if (memberEmail.getPassword() == null) {
				LOGGER.debug("Creating member password");
				message = Constants.USER_PASSWORD_UPDATED;
			} else {
				LOGGER.debug("Updating member password");
				message = Constants.USER_PASSWORD_UPDATED;
			}
			memberEmail.setPassword(encryptedPassword);
			memberEmail.setVerified(true);
			memberEmailRepository.save(memberEmail);
		}
		return message;
	}

	private String updatePassword(String password, Member member, String deviceToken, MemberEmail memberEmail) {
		LOGGER.info("Saving password of Member with id:: {}", member.getId());
		String message = "";
		if (memberEmail != null) {
			String encryptedPassword = aesEncryption.passwordHashing(password);
			memberEmail.setUpdatedAt(DateAndTimeUtil.now());
			if (memberEmail.getPassword() == null) {
				LOGGER.debug("Creating member password");
				message = Constants.USER_PASSWORD_UPDATED;
			} else {
				LOGGER.debug("Updating member password");
				message = Constants.USER_PASSWORD_UPDATED;
			}
			memberEmail.setPassword(encryptedPassword);
			memberEmail.setVerified(true);
			memberEmailRepository.save(memberEmail);
		}
		return message;
	}

	public ResponseEntity<ViewResponse> saveMemberPersonalDetails(MemberPersonalDetails memberPersonalDetails) {
		LOGGER.info("Save member personal details method started..!");
		//
		verifyRequest(memberPersonalDetails);
		LOGGER.info("verifing request..!");
		// This jpa query checks whether the member is exits or not
		Member member = getMember(memberPersonalDetails.getMemberId());
		LOGGER.info("Updating member personal info for member id:: {}", member.getId());
		// if member is present updating member personal info
		String auditId = auditService.getAuditId();
		updateMemberDetails(memberPersonalDetails, member, auditId);
		LOGGER.info("Updated member personal info for member id:: {}", member.getId());
		// saving member address details
		MemberAddress memberAddress = new MemberAddress();
		LOGGER.info("Updating member address info for member id:: {}", member.getId());
		Optional<MemberAddress> memberAddressOptional = memberAddressRepository.findByMemberId(member);
		if (memberAddressOptional.isPresent()) {
			memberAddress = memberAddressOptional.get();
		}
		saveMemberAddress(memberPersonalDetails, member, memberAddress, auditId);
		LOGGER.info("Member address info created with id:: {}", memberAddress.getId());
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMemberId(member.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.MEMBER_PERSONAL_DETAILS_CREATED);
		viewResponse.setMessageTitle("Success!");
		LOGGER.info("Save member personal details method ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void updateMemberDetails(MemberPersonalDetails memberPersonalDetails, Member member, String auditId) {
		LOGGER.info("updateMemberDetails method started..");
		member.setUpdatedAt(DateAndTimeUtil.now());
		member.setFirstName(capitalize(memberPersonalDetails.getFirstName()));
		member.setLastName(capitalize(memberPersonalDetails.getLastName()));
		member.setMiddleName(capitalize(memberPersonalDetails.getMiddleName()));
		member.setPhoneNumber(memberPersonalDetails.getMobileNumber());
		member.setDateOfBirth(DateAndTimeUtil.stringDateToLocalDate(memberPersonalDetails.getDateOfBirth()));
		if ((memberPersonalDetails.getProductId() > 0 && member.getProductId() == null)
				|| (memberPersonalDetails.getProductId() > 0 && member.getProductId() != null
						&& memberPersonalDetails.getProductId() != member.getProductId().getId())) {
			Optional<MemberProduct> memberProduct = memberProductRepository
					.findById(memberPersonalDetails.getProductId());
			if (memberProduct.isPresent()) {
				// soft deleting family members if product type changed from Married/Family to
				// single

				if (member.getProductId() != null) {
					if (member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.FAMILY)
							&& memberProduct.get().getProductName().equalsIgnoreCase(StatusConstants.MARRIED)) {
						List<MemberFamily> memberFamilyList = new ArrayList<>();
						List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndIsDeleted(member,
								false);
						if (!memberFamily.isEmpty()) {
							memberFamily.forEach(family -> {
								if (family.getRelationShipMasterId().getRelationshipName()
										.equalsIgnoreCase(StatusConstants.CHILD)) {
									family.setDeleted(true);
									family.setStatus(StatusConstants.INACTIVE);
									family.setUpdatedAt(DateAndTimeUtil.now());
									memberFamilyList.add(family);
								}
							});
							memberFamilyRepository.saveAll(memberFamilyList);
						}
					}

					if ((member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.MARRIED)
							|| member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.FAMILY))
							&& memberProduct.get().getProductName().equalsIgnoreCase(StatusConstants.SINGLE)) {

						List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndIsDeleted(member,
								false);
						List<MemberFamily> memberFamilyList = new ArrayList<>();
						if (!memberFamily.isEmpty()) {
							memberFamily.forEach(family -> {
								family.setDeleted(true);
								family.setStatus(StatusConstants.INACTIVE);
								family.setUpdatedAt(DateAndTimeUtil.now());
								memberFamilyList.add(family);
							});
							memberFamilyRepository.saveAll(memberFamilyList);
						}
					}
					member.setProductId(memberProduct.get());
				} else {
					member.setProductId(memberProduct.get());
				}

			}
		}
		// This jpa query checks whether the name prefix master exits or not
		if (memberPersonalDetails.getMemberprefixId() != null && memberPersonalDetails.getMemberprefixId() != 0) {
			Optional<NamePrefixMaster> namePrefixMaster = namePrefixMasterRepository
					.findById(memberPersonalDetails.getMemberprefixId());
			if (namePrefixMaster.isPresent()) {
				member.setNamePrefixMasterId(namePrefixMaster.get());
			}
		}

		member.setStatus(StatusConstants.ACTIVATED);
		if (memberPersonalDetails.getMemberGenderId() != null) {
			Optional<GenderMaster> genderMaster = genderMasterRepository
					.findById(memberPersonalDetails.getMemberGenderId());
			if (genderMaster.isPresent()) {
				member.setGenderId(genderMaster.get());
			}
		}

		if (memberPersonalDetails.getCountryPhoneCodeId() != null) {
			Optional<CountryPhoneCodeMaster> countryCode = countryPhoneCodeMasterRepository
					.findById(memberPersonalDetails.getCountryPhoneCodeId());
			if (countryCode.isPresent()) {
				member.setCountryPhoneCodeMasterId(countryCode.get());
			}
		}
		member.setProfileUpdated(true);
		member.setUserId(null);
		member.setAuditId(auditId);
		memberRepository.save(member);
		LOGGER.debug("saving the member details..");
	}

	public ResponseEntity<ViewResponse> updateMemberPersonalDetails(MemberPersonalDetails memberPersonalDetails) {
		LOGGER.info("Update member personal details method started..!");
		//
		verifyRequest(memberPersonalDetails);
		LOGGER.info("verifing request..!");
		// This jpa query checks whether the member is exits or not
		Member member = getMember(memberPersonalDetails.getMemberId());
		LOGGER.info("Updating member personal info for member id:: {}", member.getId());
		// if member is present updating member personal info
		boolean memberUpdated = false;
		boolean addressUpdated = false;
		String auditId = auditService.getAuditId();
		memberUpdated = updateMemberDetailsForMobile(memberPersonalDetails, member, memberUpdated, auditId);
		LOGGER.info("Updated member personal info for member id:: {}", member.getId());
		// saving member address details
		LOGGER.info("Fecthing member address info for member id:: {}", member.getId());
		Optional<MemberAddress> memberAddressOptional = memberAddressRepository.findByMemberId(member);
		if (!memberAddressOptional.isPresent()) {
			MemberAddress address = new MemberAddress();
			LOGGER.info("Creating member address info for member id:: {}", member.getId());
			saveMemberAddress(memberPersonalDetails, member, address, auditId);
			// throw new
			// NoRecordFoundException(ExceptionalMessages.MEMBER_ADDRESS_NOT_FOUND);
		} else {
			LOGGER.info("Updating member address info for member id:: {}", member.getId());
			addressUpdated = updateMemberAddress(memberPersonalDetails, member, memberAddressOptional.get(),
					addressUpdated, auditId);
		}
		Optional<MemberEmail> email = memberEmailRepository.findByMemberIdAndPrimaryAndDeletedAndVerified(member, true,
				false, true);
		if (email.isPresent() && (memberUpdated || addressUpdated)) {
			sendEmailProfileUpdated(email.get(), EmailTitles.PROFILE_UPDATED, member);
		}
		getProfileDetails.updateMemberSfdcstatus(member);
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMemberId(member.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessageTitle("Success!");
		viewResponse.setMessage(Constants.MEMBER_PERSONAL_DETAILS_UPDATED);
		LOGGER.info("Update member personal details method started..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void verifyRequest(MemberPersonalDetails memberPersonalDetails) {
		if (StringUtils.isBlank(memberPersonalDetails.getFirstName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME);
		}
		if (StringUtils.isBlank(memberPersonalDetails.getLastName())) {
			throw new BadRequestException(ExceptionalMessages.LAST_NAME);
		}
		if (memberPersonalDetails.getMobileNumber() != null && !memberPersonalDetails.getMobileNumber().isEmpty()
				&& !StringUtils.isNumeric(memberPersonalDetails.getMobileNumber())) {
			throw new NoRecordFoundException(ExceptionalMessages.MOBILE_NUMBER_SHOULD_BE_NUMBERS);
		}
		if (memberPersonalDetails.getMobileNumber() != null && memberPersonalDetails.getMobileNumber().length() != 10
				&& !memberPersonalDetails.getMobileNumber().isEmpty()) {
			throw new NoRecordFoundException(ExceptionalMessages.MOBILE);
		}

		if (memberPersonalDetails.getZipCode() != null && !memberPersonalDetails.getZipCode().isEmpty()
				&& !StringUtils.isNumeric(memberPersonalDetails.getZipCode())) {
			throw new InValidInputException(ExceptionalMessages.ZIP_CODE_SHOULD_BE_NUMBERS);
		}
		if (memberPersonalDetails.getZipCode() != null && memberPersonalDetails.getZipCode().length() != 5
				&& !memberPersonalDetails.getZipCode().isEmpty()) {
			throw new InValidInputException(ExceptionalMessages.ZIP_CODE);
		}
	}

	public void checkPassword(String password) {
		if (!PASSWORD_PATTERN.matcher(password).matches()) {
			String message = ExceptionalMessages.INVALID_PASSWORD.replace("<Max>", "" + Constants.PASSWORD_MAX_LENGTH);
			message = message.replace("<Min>", "" + Constants.PASSWORD_MIN_LENGTH);
			throw new InValidInputException(message);
		}
	}

	private boolean updateMemberAddress(MemberPersonalDetails memberPersonalDetails, Member member,
			MemberAddress memberAddress, boolean updated, String auditId) {

		LOGGER.info("saveMemberAddress method started..");
		if (StringUtils.isBlank(memberAddress.getCityName()) || (!StringUtils.isBlank(memberAddress.getCityName())
				&& !memberAddress.getCityName().equalsIgnoreCase(memberPersonalDetails.getCity()))) {
			memberAddress.setCityName(memberPersonalDetails.getCity());
			updated = true;
		}
		if ((memberAddress.getCountryMasterId() == null && memberPersonalDetails.getCountryId() != null)
				|| (memberPersonalDetails.getCountryId() != null
						&& !memberPersonalDetails.getCountryId().equals(memberAddress.getCountryMasterId().getId()))) {
			Optional<CountryMaster> countryMaster = countryMasterRepository
					.findById(memberPersonalDetails.getCountryId());
			if (countryMaster.isPresent()) {
				memberAddress.setCountryMasterId(countryMaster.get());
				updated = true;
			}
		}

		if ((memberAddress.getStateMasterId() == null && memberPersonalDetails.getStateId() != null)
				|| (memberPersonalDetails.getStateId() != null
						&& !memberPersonalDetails.getStateId().equals(memberAddress.getStateMasterId().getId()))) {
			Optional<StateMaster> stateMaster = stateMasterRepository.findById(memberPersonalDetails.getStateId());
			if (stateMaster.isPresent()) {
				memberAddress.setStateMasterId(stateMaster.get());
				updated = true;
			}
		}

		LOGGER.debug("adding member address in memberAddress table..");
		if (StringUtils.isBlank(memberAddress.getZipCode()) || (!StringUtils.isBlank(memberAddress.getZipCode())
				&& !memberAddress.getZipCode().equalsIgnoreCase(memberPersonalDetails.getZipCode()))) {
			memberAddress.setZipCode(memberPersonalDetails.getZipCode());
			updated = true;
		}
		if (StringUtils.isBlank(memberAddress.getAddressLine1())
				|| (!StringUtils.isBlank(memberAddress.getAddressLine1()) && !memberPersonalDetails.getAddressLine1()
						.equalsIgnoreCase(memberAddress.getAddressLine1()))) {
			memberAddress.setAddressLine1(memberPersonalDetails.getAddressLine1());
			updated = true;
		}
		if (StringUtils.isBlank(memberAddress.getAddressLine2())
				|| (!StringUtils.isBlank(memberAddress.getAddressLine2()) && !memberPersonalDetails.getAddressLine2()
						.equalsIgnoreCase(memberAddress.getAddressLine2()))) {
			memberAddress.setAddressLine2(memberPersonalDetails.getAddressLine2());
			updated = true;
		}
		if (updated) {
			memberAddress.setMemberId(member);
			memberAddress.setUserId(null);
			memberAddress.setUpdatedAt(DateAndTimeUtil.now());
			memberAddress.setAuditId(auditId);
			memberAddressRepository.save(memberAddress);
		}
		LOGGER.info("saveMemberAddress method ended..");
		return updated;
	}

	private void saveMemberAddress(MemberPersonalDetails memberPersonalDetails, Member member,
			MemberAddress memberAddress, String auditId) {
		LOGGER.info("saveMemberAddress method started..");
		memberAddress.setCityName(memberPersonalDetails.getCity());
		if (memberPersonalDetails.getCountryId() != null) {
			Optional<CountryMaster> countryMaster = countryMasterRepository
					.findById(memberPersonalDetails.getCountryId());
			if (countryMaster.isPresent()) {
				memberAddress.setCountryMasterId(countryMaster.get());
			}
		}

		if (memberPersonalDetails.getStateId() != null) {
			Optional<StateMaster> stateMaster = stateMasterRepository.findById(memberPersonalDetails.getStateId());
			if (stateMaster.isPresent()) {
				memberAddress.setStateMasterId(stateMaster.get());
			}
		}

		LOGGER.debug("adding member address in memberAddress table..");
		memberAddress.setZipCode(memberPersonalDetails.getZipCode());
		memberAddress.setCreatedAt(DateAndTimeUtil.now());
		memberAddress.setUpdatedAt(DateAndTimeUtil.now());
		memberAddress.setAddressLine1(memberPersonalDetails.getAddressLine1());
		memberAddress.setAddressLine2(memberPersonalDetails.getAddressLine2());
		memberAddress.setMemberId(member);
		memberAddress.setUserId(null);
		memberAddress.setAuditId(auditId);
		memberAddressRepository.save(memberAddress);
		LOGGER.info("saveMemberAddress method ended..");
	}

	private boolean updateMemberDetailsForMobile(MemberPersonalDetails memberPersonalDetails, Member member,
			boolean updated, String auditId) {
		LOGGER.info("updateMemberDetails method started..");
		if (StringUtils.isBlank(member.getFirstName()) || (!StringUtils.isBlank(member.getFirstName())
				&& !member.getFirstName().equalsIgnoreCase(memberPersonalDetails.getFirstName()))) {
			member.setFirstName(capitalize(memberPersonalDetails.getFirstName()));
			updated = true;
		}
		if (StringUtils.isBlank(member.getLastName()) || (!StringUtils.isBlank(member.getLastName())
				&& !member.getLastName().equalsIgnoreCase(memberPersonalDetails.getLastName()))) {
			member.setLastName(capitalize(memberPersonalDetails.getLastName()));
			updated = true;
		}
		if (StringUtils.isBlank(member.getMiddleName()) || (!StringUtils.isBlank(member.getMiddleName())
				&& !member.getMiddleName().equalsIgnoreCase(memberPersonalDetails.getMiddleName()))) {
			member.setMiddleName(capitalize(memberPersonalDetails.getMiddleName()));
			updated = true;
		}
		if (!StringUtils.isBlank(member.getPhoneNumber())
				&& !member.getPhoneNumber().equalsIgnoreCase(memberPersonalDetails.getMobileNumber())) {
			member.setPhoneNumber(memberPersonalDetails.getMobileNumber());
			updated = true;
		}
		if (member.getDateOfBirth() == null || (member.getDateOfBirth() != null && !member.getDateOfBirth()
				.equals(DateAndTimeUtil.stringDateToLocalDate(memberPersonalDetails.getDateOfBirth())))) {
			member.setDateOfBirth(DateAndTimeUtil.stringDateToLocalDate(memberPersonalDetails.getDateOfBirth()));
			updated = true;
		}

		if ((memberPersonalDetails.getProductId() != null && member.getProductId() == null)
				|| (memberPersonalDetails.getProductId() != null && member.getProductId() != null
						&& memberPersonalDetails.getProductId() != member.getProductId().getId())) {
			Optional<MemberProduct> memberProduct = memberProductRepository
					.findById(memberPersonalDetails.getProductId());
			if (memberProduct.isPresent()) {
				// soft deleting family members if product type changed from Married/Family to
				// single

				if (member.getProductId() != null) {
					if (member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.FAMILY)
							&& memberProduct.get().getProductName().equalsIgnoreCase(StatusConstants.MARRIED)) {
						List<MemberFamily> memberFamilyList = new ArrayList<>();
						List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndIsDeleted(member,
								false);
						if (!memberFamily.isEmpty()) {
							memberFamily.forEach(family -> {
								if (family.getRelationShipMasterId().getRelationshipName()
										.equalsIgnoreCase(StatusConstants.CHILD)) {
									family.setDeleted(true);
									family.setStatus(StatusConstants.INACTIVE);
									family.setUpdatedAt(DateAndTimeUtil.now());
									memberFamilyList.add(family);
								}
							});
							memberFamilyRepository.saveAll(memberFamilyList);
						}
					}

					if ((member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.MARRIED)
							|| member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.FAMILY))
							&& memberProduct.get().getProductName().equalsIgnoreCase(StatusConstants.SINGLE)) {

						List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndIsDeleted(member,
								false);
						List<MemberFamily> memberFamilyList = new ArrayList<>();
						if (!memberFamily.isEmpty()) {
							memberFamily.forEach(family -> {
								family.setDeleted(true);
								family.setStatus(StatusConstants.INACTIVE);

								memberFamilyList.add(family);
							});
							memberFamilyRepository.saveAll(memberFamilyList);
						}
					}
					member.setProductId(memberProduct.get());
				} else {
					member.setProductId(memberProduct.get());
					updated = true;
				}

			}
		}

		// This jpa query checks whether the name prefix master exits or not
		if ((memberPersonalDetails.getMemberprefixId() != null && member.getNamePrefixMasterId()==null )||
				(memberPersonalDetails.getMemberprefixId() != null && member.getNamePrefixMasterId() != null
						&& memberPersonalDetails.getMemberprefixId() != 0
						&& !memberPersonalDetails.getMemberprefixId().equals(member.getNamePrefixMasterId().getId()))) {
			Optional<NamePrefixMaster> namePrefixMaster = namePrefixMasterRepository
					.findById(memberPersonalDetails.getMemberprefixId());
			if (namePrefixMaster.isPresent()) {
				member.setNamePrefixMasterId(namePrefixMaster.get());
				updated = true;
			}
		}

		if (member.getStatus() == null || member.getStatus().equalsIgnoreCase(StatusConstants.ENROLLED)
				|| member.getStatus().equalsIgnoreCase(StatusConstants.PENDING)) {
			member.setStatus(StatusConstants.ACTIVATED);
		}

		if ((memberPersonalDetails.getMemberGenderId() != null && member.getGenderId() == null)
				|| (memberPersonalDetails.getMemberGenderId() != null && member.getGenderId() != null
						&& !memberPersonalDetails.getMemberGenderId().equals(member.getGenderId().getId()))) {
			Optional<GenderMaster> genderMaster = genderMasterRepository
					.findById(memberPersonalDetails.getMemberGenderId());
			if (genderMaster.isPresent()) {
				member.setGenderId(genderMaster.get());
				updated = true;
			}
		}

		if (memberPersonalDetails.getCountryPhoneCodeId() != null && !memberPersonalDetails.getCountryPhoneCodeId()
				.equals(member.getCountryPhoneCodeMasterId().getId())) {
			Optional<CountryPhoneCodeMaster> countryCode = countryPhoneCodeMasterRepository
					.findById(memberPersonalDetails.getCountryPhoneCodeId());
			if (countryCode.isPresent()) {
				member.setCountryPhoneCodeMasterId(countryCode.get());
				updated = true;
			}
		}
		if (!member.isProfileUpdated()) {
			updated = true;
		}
		if (updated) {
			member.setProfileUpdated(true);
			member.setUserId(null);
			member.setUpdatedAt(DateAndTimeUtil.now());
			member.setAuditId(auditId);
			memberRepository.save(member);
		}
		LOGGER.debug("saving the member details..");
		return updated;
	}

	public String capitalize(String name) {
		return WordUtils.capitalizeFully(name);
	}

	public ResponseEntity<ViewMemberResponse> getAllStates(Long countryId) {

		LOGGER.info("getAllStates strated..");
		Optional<CountryMaster> country = countryMasterRepository.findById(countryId);
		if (!country.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.COUNTRY_NOT_FOUND);
		}
		// creating array list for ViewStates
		List<ViewStates> viewStatesList = new ArrayList<>();

		// fetching all states which are in active status
		List<StateMaster> stateMaster = stateMasterRepository.findByOrganizationIdAndCountryIdAndStatus(
				country.get().getOrganizationId(), country.get(), Constants.ACTIVE);

		LOGGER.debug("fetching list of states which are in active status..");

		if (!stateMaster.isEmpty()) {
			// looping through arrayList
			stateMaster.stream().forEach(state -> {
				ViewStates viewStates = new ViewStates();
				viewStates.setStateId(state.getId());
				viewStates.setStateName(state.getName());
				viewStatesList.add(viewStates);
			});
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.STATES_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewStatesList);
		LOGGER.info("getAllStates ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewMemberResponse> getAllCountries(Long userId, Long memberId) {
		LOGGER.info("getAllCountries strated..");
		Organization organization = getOrganization(userId, memberId);
		// creating array list for ViewCountries
		List<ViewCountries> viewCountriesList = new ArrayList<>();

		// fetching all countries which are in active status
		List<CountryMaster> countryMaster = countryMasterRepository.findByOrganizationIdAndStatus(organization,
				StatusConstants.ACTIVE);

		LOGGER.debug("fetching list of countries which are in active status..");

		if (!countryMaster.isEmpty()) {
			// looping through arrayList
			countryMaster.forEach(country -> {
				ViewCountries viewCountries = new ViewCountries();
				viewCountries.setCountryId(country.getId());
				viewCountries.setCountryName(country.getCountryName());
				viewCountriesList.add(viewCountries);
			});
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.COUNTRIES_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewCountriesList);
		LOGGER.info("getAllCountries ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewMemberResponse> getAllGender(Long userId, Long memberId) {
		LOGGER.info("getAllGender method strated..");
		Organization organization = getOrganization(userId, memberId);
		// creating array list for viewGenderList
		List<ViewGender> viewGenderList = new ArrayList<>();

		// fetching all gender which are in active status
		List<GenderMaster> genderMaster = genderMasterRepository.findByOrganizationIdAndStatus(organization,
				StatusConstants.ACTIVE);

		LOGGER.debug("fetching list of genders which are in active status..");
		if (!genderMaster.isEmpty()) {
			// looping through arrayList
			genderMaster.forEach(gender -> {
				ViewGender viewGender = new ViewGender();
				viewGender.setGenderId(gender.getId());
				viewGender.setGenderName(gender.getGender());
				viewGenderList.add(viewGender);
			});
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.GENDER_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewGenderList);
		LOGGER.info("getAllGender method ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public Organization getOrganization(Long userId, Long memberId) {
		Organization organization = new Organization();
		if (memberId != null) {
			Member member = getMember(memberId);
			organization = member.getOrganizationId();
		}
		if (userId != null) {
			SystemUsers user = loginService.getSystemUsers(userId);
			organization = user.getOrganizationId();
		}
		return organization;
	}

	private MemberEmail getMemberEmail(Member member) {
		Optional<MemberEmail> memberEmailOptional = memberEmailRepository.findByMemberIdAndDeletedAndPrimary(member,
				Boolean.FALSE, Boolean.TRUE);
		if (!memberEmailOptional.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.ACCOUNT_WITH_EMAIL_NOT_EXISTS);
		}
		LOGGER.info("Member email detils are fetched for id: {}", member.getId());
		return memberEmailOptional.get();
	}

	public ViewMemberResponse getMemberInfo(Long memberId) {
		LOGGER.info("getMemberInfo method started..");
		Member member = getMember(memberId);
		MemberEmail memberEmail = getMemberEmail(member);
		OrganizationAddress organizationAddress = organizationAddressRepository
				.findByOrganizationId(member.getOrganizationId());
		MemberInfo memberInfo = new MemberInfo();
		String name = "";
		if (member.getFirstName() != null) {
			name = member.getFirstName();
		}
		if (member.getLastName() != null) {
			name = name + " " + member.getLastName();
		}
		memberInfo.setName(name);
		if (memberEmail.getEmail() != null) {
			memberInfo.setEmail(memberEmail.getEmail());
		}
		memberInfo.setFirstName(member.getFirstName());
		memberInfo.setOrgCall(member.getOrganizationId().getPhoneNumber());
		memberInfo.setOrgFax(member.getOrganizationId().getFaxNumber());
		memberInfo.setDescriptionMaxValue(Constants.DESCRIPTION_MAX_LENGTH);
		memberInfo.setDescriptionMinValue(Constants.DESCRIPTION_MIN_LENGTH);
		memberInfo.setMessageSubMinSize(Constants.MESSAGE_SUB_MIN_LENGTH);
		memberInfo.setMessageSubMaxSize(Constants.MESSAGE_SUB_MAX_LENGTH);
		memberInfo.setMessageDescriptionMinSize(Constants.MESSAGE_DESCRIPTION_MIN_LENGTH);
		memberInfo.setMessageDescriptionMaxSize(Constants.MESSAGE_DESCRIPTION_MAX_LENGTH);
		memberInfo.setChatBoxMinSize(Constants.MESSAGE_DESCRIPTION_MIN_LENGTH);
		memberInfo.setChatBoxMaxSize(Constants.MESSAGE_DESCRIPTION_MAX_LENGTH);
		memberInfo.setMemberSince(DateAndTimeUtil.convertLocalDateToString(member.getCreatedAt().toLocalDate()));
		memberInfo.setAppVersion(member.getCurrentVersion());
		if (member.getEmployerId() != null) {
			GetEmployerInfo employerDetails = getEmployerDetails(member.getEmployerId());
			memberInfo.setEmployer(employerDetails.getEmployerName());
			memberInfo.setEmployerAvailable(true);
			if (employerDetails.getIndividualBrokerId() != null) {
				memberInfo.setBrokerName(employerDetails.getIndividualBrokerName());
				memberInfo.setBrokerContact(employerDetails.getBrokerContactNumber());
				memberInfo.setBrokerAvailable(true);
			} else {
				memberInfo.setBrokerAvailable(false);
			}

		}

		memberInfo.setMemberId(member.getMemberId());
		memberInfo.setCopyright(Constants.COPYRIGHT.replace("<Year>", "" + LocalDate.now().getYear()));
		if (organizationAddress != null) {
			memberInfo.setAddressLine1(organizationAddress.getAddressLine1());
			memberInfo.setAddressLine2(organizationAddress.getAddressLine2());
			memberInfo.setCityName(organizationAddress.getCityName());
			if (organizationAddress.getStateId() != null) {
				memberInfo.setStateCode(organizationAddress.getStateId().getCode());
				memberInfo.setStateName(organizationAddress.getStateId().getName());
			}
			if (organizationAddress.getCountryId() != null) {
				memberInfo.setContryCode(organizationAddress.getCountryId().getCountryCode());
				memberInfo.setContryName(organizationAddress.getCountryId().getCountryName());
			}
		}
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(memberInfo);
		viewResponse.setMemberId(memberId);
		LOGGER.info("getMemberInfo ended..");
		return viewResponse;
	}

	public ResponseEntity<ViewMemberResponse> getAllProduct(Long userId, Long memberId) {
		LOGGER.info("getAllProduct method strated..");
		Organization organization = getOrganization(userId, memberId);
		// creating array list for viewMemberProductrList
		List<ViewMemberProduct> viewMemberProductList = new ArrayList<>();

		// fetching all product which are in active status
		List<MemberProduct> memberProduct = memberProductRepository.findByOrganizationIdAndStatus(organization,
				StatusConstants.ACTIVE);

		LOGGER.debug("fetching list of product which are in active status..");

		if (!memberProduct.isEmpty()) {
			// looping through arrayList
			memberProduct.forEach(product -> {
				ViewMemberProduct viewMemberProduct = new ViewMemberProduct();
				viewMemberProduct.setProductId(product.getId());
				viewMemberProduct.setProductName(product.getProductName());
				viewMemberProductList.add(viewMemberProduct);
			});
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.PRODUCT_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewMemberProductList);
		LOGGER.info("getAllProduct method ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewMemberResponse> getAllOpportunity(Long userId, Long memberId) {
		LOGGER.info("getAllOpportunity method strated..");
		Organization organization = getOrganization(userId, memberId);
		// creating array list for viewOpportunitiesList
		List<ViewOpportunities> viewOpportunitiesList = new ArrayList<>();

		// fetching all opportunity which are in active status
		List<MemberTypeMaster> memberTypeMaster = memberTypeMasterRepository.findByOrganizationIdAndStatus(organization,
				StatusConstants.ACTIVE);

		LOGGER.debug("fetching list of product which are in active status..");

		if (!memberTypeMaster.isEmpty()) {
			// looping through arrayList
			memberTypeMaster.forEach(opportunity -> {
				ViewOpportunities viewOpportunities = new ViewOpportunities();
				viewOpportunities.setOpportunityId(opportunity.getId());
				viewOpportunities.setOpportunityName(opportunity.getTypeName());
				viewOpportunitiesList.add(viewOpportunities);
			});
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.OPPORTUNITY_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewOpportunitiesList);
		LOGGER.info("getAllOpportunity method ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewMemberResponse> getAllPhoneCodeMaster(Long userId, Long memberId) {
		LOGGER.info("getAllPhoneCodeMaster method strated..");
		Organization organization = getOrganization(userId, memberId);
		// creating array list for phoneCodeMasterViewList
		List<PhoneCodeMasterView> phoneCodeMasterViewList = new ArrayList<>();

		// fetching all country phone codes which are in active status
		List<CountryPhoneCodeMaster> countryPhoneCodeMaster = countryPhoneCodeMasterRepository
				.findByOrganizationIdAndStatus(organization, StatusConstants.ACTIVE);
		LOGGER.debug("fetching list of phone code which are in active status..");

		if (!countryPhoneCodeMaster.isEmpty()) {
			// looping through arrayList
			countryPhoneCodeMaster.forEach(phoneCode -> {
				PhoneCodeMasterView phoneCodeMasterView = new PhoneCodeMasterView();
				phoneCodeMasterView.setCountryPhoneCodeId(phoneCode.getId());
				phoneCodeMasterView.setCountryPhoneNumberCode(phoneCode.getPhoneNumberCode());
				phoneCodeMasterViewList.add(phoneCodeMasterView);
			});
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.PHONE_CODE_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(phoneCodeMasterViewList);
		LOGGER.info("getAllPhoneCodeMaster method ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public MemberInfoResponse getMemberDetails(String token, Long memberId) {
		LOGGER.info("Fetch member info from database started at: {}", DateAndTimeUtil.now());
		Member member = getMember(memberId);
		LOGGER.info("Fetched member info from database ended at: {}", DateAndTimeUtil.now());
		MemberInfoResponse memberInfo = new MemberInfoResponse();
		LOGGER.info("Fetch member token info from database started at: {}", DateAndTimeUtil.now());
		if (token != null) {
			Optional<AuthTokens> memberToken = authTokensRepository.findByTokenAndMemberId(token, member);
			if (memberToken.isPresent() && memberToken.get().getExpiredAt() != null) {
				memberInfo.setTokenExpiredAt(memberToken.get().getExpiredAt());
				if (memberToken.get().getExpiredAt().isBefore(DateAndTimeUtil.now())) {
					memberInfo.setTokenMessage(logoutService.getExceptionMessage(memberToken.get()));
				}
			} else {
				memberInfo.setTokenExpiredAt(DateAndTimeUtil.now());
			}
		}
		LOGGER.info("Fetch member token info from database ended at: {}", DateAndTimeUtil.now());

		LOGGER.info("Fetch member email info from database started at: {}", DateAndTimeUtil.now());
		Optional<MemberEmail> memberEmail = memberEmailRepository.findByMemberIdAndDeletedAndPrimary(member,
				Boolean.FALSE, Boolean.TRUE);
		LOGGER.info("Fetch member email info from database ended at: {}", DateAndTimeUtil.now());
		LOGGER.info("Response object creation started at: {}", DateAndTimeUtil.now());
		if (!memberEmail.isPresent()) {
			memberInfo.setStatus(Constants.FAILED);
			memberInfo.setMessage(Constants.MEMBER_TOKEN_VERIFIED);
			return memberInfo;
		}
		memberInfo.setMemberFirstName(member.getFirstName());
		memberInfo.setFcmToken(member.getFcmToken());
		memberInfo.setId(memberId);
		memberInfo.setMemberId(member.getMemberId());
		memberInfo.setMemberStatus(member.getStatus());
		memberInfo.setValid(Boolean.TRUE);
		memberInfo.setStatus(Constants.SUCCESS);
		memberInfo.setMessage(Constants.MEMBER_TOKEN_VERIFIED);
		memberInfo.setOrganizationId(member.getOrganizationId().getId());
		memberInfo.setFromEmail(member.getOrganizationId().getEmail());
		memberInfo.setMemberEmail(memberEmail.get().getEmail());
		memberInfo.setMemberName(member.getFirstName() + " " + member.getLastName());
		memberInfo.setOrganizationContact(member.getOrganizationId().getPhoneNumber());
		memberInfo.setFileSize(member.getOrganizationId().getFileSize());
		memberInfo.setOrganizationName(member.getOrganizationId().getName());
		memberInfo.setMemberShortName(getChar(member.getFirstName()) + getChar(member.getLastName()));
		memberInfo.setOrganizationShortName(getChar(member.getOrganizationId().getName()));
		LOGGER.info("Response object creation ended at: {}", DateAndTimeUtil.now());
		return memberInfo;
	}

	public MemberInfoResponse getMemberInfo(String token, Long memberId) {
		LOGGER.info("Fetch member info from database started at: {}", DateAndTimeUtil.now());
		List<Object[]> memberInfo2 = memberRepository.getMemberInfo(memberId, token);
		LOGGER.info("Fetched member info from database ended at: {}", DateAndTimeUtil.now());
		if (memberInfo2.isEmpty()) {
			throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
		}
		MemberInfoResponse memberInfo = new MemberInfoResponse();
		LOGGER.info("Response object creation started at: {}", DateAndTimeUtil.now());
		memberInfo2.forEach(member -> {
			if (member[1] != null) {
				memberInfo.setMemberFirstName((String) member[1]);
			}
			if (member[2] != null) {
				memberInfo.setMemberName((String) member[2]);
			}
			if (member[3] != null) {
				memberInfo.setMemberId((String) member[3]);
			}
			if (member[4] != null) {
				memberInfo.setMemberEmail((String) member[4]);
			}
			if (member[5] != null) {
				memberInfo.setFcmToken((String) member[5]);
			}
			if (member[6] != null) {
				memberInfo.setMemberStatus((String) member[6]);
			}
			if (member[7] != null) {
				memberInfo.setOrganizationName((String) member[7]);
			}
			if (member[8] != null) {
				memberInfo.setFromEmail((String) member[8]);
			}
			if (member[9] != null) {
				memberInfo.setOrganizationContact((String) member[9]);
			}
			if (member[10] != null) {
				memberInfo.setFileSize(((BigInteger) member[10]).longValue());
			}
			if (member[11] != null) {
				LocalDateTime date = ((Timestamp) member[11]).toLocalDateTime();
				memberInfo.setTokenExpiredAt(date);
				if (date.isBefore(DateAndTimeUtil.now())) {
					memberInfo.setTokenMessage(logoutService.getExceptionMessage((String) member[12],
							memberInfo.getFromEmail(), memberInfo.getMemberStatus()));
				}
			}
			if (member[13] != null) {
				memberInfo.setOrganizationId(((BigInteger) member[13]).longValue());
			}
		});
		memberInfo.setValid(Boolean.TRUE);
		memberInfo.setStatus(Constants.SUCCESS);
		memberInfo.setMessage(Constants.MEMBER_TOKEN_VERIFIED);
		memberInfo.setId(memberId);
		LOGGER.info("Response object creation ended at: {}", DateAndTimeUtil.now());
		return memberInfo;
	}

	public MemberInfoResponse verifyUserToken(String token, Long userId) {
		LOGGER.info("verifyUserToken method started at: {}" + DateAndTimeUtil.now());
		SystemUsers systemUsers = loginService.getSystemUsers(userId);
		Optional<AuthTokens> userToken = authTokensRepository.findByTokenAndUserId(token, systemUsers);
		MemberInfoResponse memberInfo = new MemberInfoResponse();
		memberInfo.setValid(Boolean.TRUE);
		memberInfo.setStatus(Constants.SUCCESS);
		memberInfo.setMessage(Constants.USER_TOKEN_VERIFIED);
		memberInfo.setId(userId);
		memberInfo.setUserId(userId);
		if (userToken.isPresent() && userToken.get().getExpiredAt() != null) {
			memberInfo.setTokenExpiredAt(userToken.get().getExpiredAt());
			if (userToken.get().getExpiredAt().isBefore(DateAndTimeUtil.now())) {
				String message = logoutService.getExceptionMessage(userToken.get());
				if (!StringUtils.isBlank(message) && message.equalsIgnoreCase(ExceptionalMessages.SESSION_EXPIRED)) {
					memberInfo.setTokenMessage(ExceptionalMessages.USER_SESSION_EXPIRED);
				} else {
					memberInfo.setTokenMessage(message);
				}
			}
		} else {
			memberInfo.setTokenExpiredAt(DateAndTimeUtil.now());
		}

		memberInfo.setOrganizationId(systemUsers.getOrganizationId().getId());
		LOGGER.info("verifyUserToken method ended at: {}" + DateAndTimeUtil.now());
		return memberInfo;
	}

	public ViewMembers getMembers(GetMembersRequest getMembersRequest) {
		LOGGER.info("getMembers method strated..");
		LOGGER.info("Fetching all members with list of ids");
		List<Member> membersList = memberRepository.findAllById(getMembersRequest.getMemberIds());
		LOGGER.info("Fetched all members with list of ids");
		ViewMembers members = new ViewMembers();
		members.setStatus(Constants.SUCCESS);
		members.setMessage(Constants.MEMBERS_LIST_FETCHED);
		members.setViewMembers(membersList.stream().map(member -> setMember(member)).collect(Collectors.toList()));
		LOGGER.info("getMembers method ended..");
		return members;
	}

	private ViewMember setMember(Member member) {
		ViewMember viewMember = new ViewMember();

		viewMember.setMeberId(member.getMemberId());
		viewMember.setId(member.getId());
		String shortname = "";
		String name = "";
		if (!StringUtils.isBlank(member.getFirstName())) {
			shortname = shortname + member.getFirstName().charAt(0);
			name = member.getFirstName();
		}
		if (!StringUtils.isBlank(member.getLastName())) {
			shortname = shortname + member.getLastName().charAt(0);
			name = name + " " + member.getFirstName();
		}

		viewMember.setName(member.getFirstName() + " " + member.getLastName());
		viewMember.setMemberShortName(shortname);
		return viewMember;
	}

	public ResponseEntity<GetCountryCodeInfo> getCountryCodeId(Long countryCodeId, Long organizationId) {
		LOGGER.info("getCarrier strated..");

		Optional<Organization> organization = organizationRepository.findById(organizationId);
		if (!organization.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		// fetching all carrier type which are in active status
		Optional<CountryPhoneCodeMaster> countryPhoneCodeMaster = countryPhoneCodeMasterRepository
				.findByIdAndOrganizationIdAndStatus(countryCodeId, organization.get(), StatusConstants.ACTIVE);
		if (!countryPhoneCodeMaster.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.COUNTRY_CODE);
		}
		LOGGER.debug("fetching list of carrier type which are in active status..");

		GetCountryCodeInfo getCarrierInfo = new GetCountryCodeInfo();

		getCarrierInfo.setCountryCodeId(countryPhoneCodeMaster.get().getId());
		getCarrierInfo.setCountryCode(countryPhoneCodeMaster.get().getPhoneNumberCode());

		getCarrierInfo.setStatusText(Constants.SUCCESS);
		LOGGER.info("getCarrier ended..");
		return ResponseEntity.status(HttpStatus.OK).body(getCarrierInfo);
	}

	public GetMemberChatInfo getMemberChatInfo(Long memberId) {
		Member member = getMember(memberId);
		GetMemberChatInfo memberChatInfo = new GetMemberChatInfo();
		memberChatInfo.setMemberName(member.getFirstName() + " " + member.getLastName());
		memberChatInfo.setOrganizationName(member.getOrganizationId().getName());
		memberChatInfo.setMemberShortName(getChar(member.getFirstName()) + getChar(member.getLastName()));
		memberChatInfo.setOrganizationShortName(getChar(member.getOrganizationId().getName()));
		return memberChatInfo;
	}

	private String getChar(String name) {
		if (name != null) {
			return name.substring(0, 1);
		}
		return "";
	}

	public ViewResponse sendEmailProfileUpdated(MemberEmail memberEmail, EmailTitles emailTitles, Member member) {
		LOGGER.info("Send welcome mail method started..!");

		WelcomeEmailMemberRequest welcomeEmailMemberRequest = new WelcomeEmailMemberRequest();
		welcomeEmailMemberRequest.setEmail(memberEmail.getEmail());
		welcomeEmailMemberRequest.setEmailTitle(emailTitles);
		welcomeEmailMemberRequest.setFirstName(member.getFirstName());
		welcomeEmailMemberRequest.setOrgId(member.getOrganizationId().getId());
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send welcome email");
			viewResponse = emailService.sendEamilToMember(welcomeEmailMemberRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: ", exception.getCause());
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send welcome email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.WELCOME_MEMBER);
		} else {
			LOGGER.debug("Exception occured while connecting email service");
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
		}

		return viewResponse;
	}

	public GetEmployerInfo getEmployerDetails(long employerId) {
		GetEmployerInfo getEmployerInfo = entityService.getEmployerDetails(employerId);
		if (getEmployerInfo == null || (!getEmployerInfo.getStatusText().equalsIgnoreCase(Constants.SUCCESS))) {
			throw new NoRecordFoundException(ExceptionalMessages.EMPLOYER_NOT_FOUND + employerId);
		}
		return getEmployerInfo;
	}

	public ViewResponse updateMemberStatus(Long memberId, Long userId) {
		Member member = getMember(memberId);
		userId = userId != null ? userId : 0;
		Optional<SystemUsers> systemUsers = systemUsersrepository.findById(userId);
		if (systemUsers.isPresent()) {
			member.setUserId(systemUsers.get());
		}
		Optional<MemberEmail> memberEmail = memberEmailRepository.findByMemberIdAndDeletedAndPrimary(member, false,
				true);
		if (memberEmail.isPresent() && !StringUtils.isBlank(memberEmail.get().getPassword())) {
			String auditId = auditService.getAuditId();
			member.setStatus(StatusConstants.ACTIVE);
			member.setAuditId(auditId);
			member.setUpdatedAt(DateAndTimeUtil.now());
			memberRepository.save(member);
		}
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.MEMBER_STATUS_UPDATED);
		viewResponse.setStatusText(Constants.SUCCESS);
		LOGGER.info("getAllPhoneCodeMaster method ended..");
		return viewResponse;
	}

	public ViewResponse getMemberCount(GetMemberCountRequest getMemberCountRequest) {
		LOGGER.info("getMemberCount method ended..");
		List<ViewMemberCountByEmployer> viewMemberCountByEmployerList = new ArrayList<>();
		if (getMemberCountRequest.getEmployerIds().isEmpty()) {
			getMemberCountRequest.getEmployerIds().add(0l);
		}
		Object[][] getMemberCount = memberRepository.getEmployerCount(getMemberCountRequest.getEmployerIds());
		for (Object[] objects : getMemberCount) {
			ViewMemberCountByEmployer viewMemberCountByEmployer = new ViewMemberCountByEmployer();
			viewMemberCountByEmployer.setCount(((BigInteger) objects[0]).longValue());
			viewMemberCountByEmployer.setEmployerId(((BigInteger) objects[1]).longValue());
			viewMemberCountByEmployerList.add(viewMemberCountByEmployer);
		}
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.MEMBER_STATUS_UPDATED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setViewMembersCountList(viewMemberCountByEmployerList);
		LOGGER.info("getMemberCount method ended..");
		return viewResponse;
	}

	public MemberTokenResponse getMemberToken(Long memberId, String refreshToken) {
		LOGGER.info("getMemberToken method started");
		Member member = getMember(memberId);
		LOGGER.info("Checking member with refresh token exists in tokens table");
		Optional<AuthTokens> memberTokenOptional = authTokensRepository.findByMemberIdAndRefreshToken(member,
				refreshToken);
		if (!memberTokenOptional.isPresent()) {
			throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
		}
		String token = jwtAuthentication.generateToken(member.getId(), Boolean.FALSE);
		String newRefreshToken = jwtAuthentication.generateRefreshToken(member.getId());
		LOGGER.info("Updating member token info for member id:: {}", member.getId());
		memberTokenOptional.get().setExpiredAt(DateAndTimeUtil.now().plusMinutes(memberTokenExpiryTime));
		memberTokenOptional.get().setToken(token);
		memberTokenOptional.get().setRefreshToken(newRefreshToken);
		memberTokenOptional.get().setUpdatedAt(DateAndTimeUtil.now());
		if (member.getDeviceToken() != null) {
			memberTokenOptional.get().setDeviceToken(member.getDeviceToken());
		}
		authTokensRepository.save(memberTokenOptional.get());
		MemberTokenResponse response = new MemberTokenResponse();
		response.setMessage(Constants.MEMBER_TOKEN);
		response.setStatusText(Constants.SUCCESS);
		response.setRefreshToken(newRefreshToken);
		response.setToken(token);
		response.setMemberId(memberId);
		LOGGER.info("getMemberToken method ended");
		return response;
	}

	public ViewResponse getOpportunities(String opportunityName) {
		LOGGER.info("getOpportunities method started");
		List<ViewOpportunityDetails> viewOpportunityDetailsList = new ArrayList<>();
		List<MemberTypeMaster> typeMasters = memberTypeMasterRepository.findAll();

		typeMasters.forEach(opportunity -> {
			ViewOpportunityDetails viewOpportunityDetails = new ViewOpportunityDetails();
			if (opportunityName.equalsIgnoreCase("Direct to Consumer")
					&& opportunity.getTypeName().equalsIgnoreCase("Direct to Consumer")) {
				viewOpportunityDetails.setOpportunityId(opportunity.getId());
				viewOpportunityDetails.setOpportunityName(opportunity.getTypeName());
				viewOpportunityDetailsList.add(viewOpportunityDetails);
			}
			if (opportunityName.equalsIgnoreCase("Block Opportunity")
					&& !opportunity.getTypeName().equalsIgnoreCase("Block Opportunity")) {
				viewOpportunityDetails.setOpportunityId(opportunity.getId());
				viewOpportunityDetails.setOpportunityName(opportunity.getTypeName());
				viewOpportunityDetailsList.add(viewOpportunityDetails);
			}
			if ((opportunityName.equalsIgnoreCase("Broker sponsored"))
					&& (opportunity.getTypeName().equalsIgnoreCase("Employer Direct")
							|| opportunity.getTypeName().equalsIgnoreCase("Direct to Consumer"))) {
				viewOpportunityDetails.setOpportunityId(opportunity.getId());
				viewOpportunityDetails.setOpportunityName(opportunity.getTypeName());
				viewOpportunityDetailsList.add(viewOpportunityDetails);
			}
			if (opportunityName.equalsIgnoreCase("Employer Direct")
					&& opportunity.getTypeName().equalsIgnoreCase("Direct to Consumer")) {
				viewOpportunityDetails.setOpportunityId(opportunity.getId());
				viewOpportunityDetails.setOpportunityName(opportunity.getTypeName());
				viewOpportunityDetailsList.add(viewOpportunityDetails);
			}
		});
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.OPPORTUNITY_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewOpportunityDetailsList);
		LOGGER.info("getOpportunities method ended");
		return viewResponse;
	}

	public ResponseEntity<ViewResponse> updateDirectMemberInfo(AddDirectMemberInfoRequest request) {
		LOGGER.info("updateDirectMemberInfo method started");
		Member member = getMember(request.getMemberId());
		if (StringUtils.isBlank(request.getFirstName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME);
		}
		if (StringUtils.isBlank(request.getLastName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME);
		}
		boolean updated = false;
		if (!StringUtils.isBlank(request.getFirstName())
				&& !request.getFirstName().equalsIgnoreCase(member.getFirstName())) {
			updated = true;
			member.setFirstName(request.getFirstName());
		}
		if (!StringUtils.isBlank(request.getLastName())
				&& !request.getLastName().equalsIgnoreCase(member.getLastName())) {
			updated = true;
			member.setLastName(request.getLastName());
		}
		if (!StringUtils.isBlank(request.getMobileNumber())
				&& !request.getMobileNumber().equalsIgnoreCase(member.getPhoneNumber())) {
			updated = true;
			member.setPhoneNumber(request.getMobileNumber());
		}

		Optional<MemberProduct> productId = memberProductRepository
				.findByProductNameAndOrganizationId(StatusConstants.SINGLE, member.getOrganizationId());
		if (productId.isPresent() && (member.getProductId() == null
				|| !productId.get().getProductName().equalsIgnoreCase(member.getProductId().getProductName()))) {
			updated = true;
			member.setProductId(productId.get());
		}

		if (request.getCountryPhoneCodeId() > 0) {
			Optional<CountryPhoneCodeMaster> countryCode = countryPhoneCodeMasterRepository
					.findById(request.getCountryPhoneCodeId());
			if (countryCode.isPresent()
					&& (member.getCountryPhoneCodeMasterId() == null || !countryCode.get().getPhoneNumberCode()
							.equalsIgnoreCase(member.getCountryPhoneCodeMasterId().getPhoneNumberCode()))) {
				updated = true;
				member.setCountryPhoneCodeMasterId(countryCode.get());
			}
		}
		if (updated) {
			String auditId = auditService.getAuditId();
			member.setStatus(StatusConstants.ACTIVATED);
			member.setProfileUpdated(true);
			member.setAuditId(auditId);
			member.setUpdatedAt(DateAndTimeUtil.now());
			memberRepository.save(member);
		}

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.MEMBER_PERSONAL_DETAILS_UPDATED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMemberId(member.getId());
		LOGGER.info("updateDirectMemberInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewResponse> getDirectMemberInfo(Long memberId) {
		LOGGER.info("getDirectMemberInfo method started");
		Member member = getMember(memberId);
		ViewDirectMemberInfo memberInfo = new ViewDirectMemberInfo();
		memberInfo.setFirstName(member.getFirstName());
		memberInfo.setLastName(member.getLastName());
		memberInfo.setMobileNumber(member.getPhoneNumber());
		if (member.getCountryPhoneCodeMasterId() != null) {
			memberInfo.setCountryPhoneCodeId(member.getCountryPhoneCodeMasterId().getId());
			memberInfo.setCountryCode(member.getCountryPhoneCodeMasterId().getPhoneNumberCode());
		}
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMessage(Constants.MEMBER_PERSONAL_INFO);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(memberInfo);
		viewResponse.setMemberId(member.getId());
		LOGGER.info("getDirectMemberInfo method ended");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

}
