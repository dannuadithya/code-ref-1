package com.billdog.user.common;

public enum DeductiblePaymentInfoEnum {

	PREF, EHN, STND

}
