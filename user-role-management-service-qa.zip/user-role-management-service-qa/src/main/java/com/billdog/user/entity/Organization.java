package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.Table;

@Entity(name = "ORGANIZATION")
@Table(name = "organization", indexes = { @Index(name = "id_index", columnList = "ID", unique = true) })
public class Organization extends BaseEntity {

	@Column(name = "NAME")
	private String name;

	@Column(name = "STATUS")
	private String status;

	@Column(name = "PHONE_NUMBER")
	private String phoneNumber;

	@Column(name = "FAX_NUMBER")
	private String faxNumber;

	@Column(name = "EMAIL")
	private String email;

	@Column(name = "TERMS_AND_CONDITIONS_URL")
	private String termsAndConditionsUrl;

	@Column(name = "privacy_url")
	private String privacyUrl;

	@Column(name = "about_us_url")
	private String aboutUsUrl;

	@Column(name = "faq_url")
	private String faqUrl;

	@Column(name = "file_size")
	private Long fileSize;

	public Long getFileSize() {
		return fileSize;
	}

	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}

	public String getAboutUsUrl() {
		return aboutUsUrl;
	}

	public void setAboutUsUrl(String aboutUsUrl) {
		this.aboutUsUrl = aboutUsUrl;
	}

	public String getFaqUrl() {
		return faqUrl;
	}

	public void setFaqUrl(String faqUrl) {
		this.faqUrl = faqUrl;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public String getFaxNumber() {
		return faxNumber;
	}

	public void setFaxNumber(String faxNumber) {
		this.faxNumber = faxNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public String getTermsAndConditionsUrl() {
		return termsAndConditionsUrl;
	}

	public void setTermsAndConditionsUrl(String termsAndConditionsUrl) {
		this.termsAndConditionsUrl = termsAndConditionsUrl;
	}

	public String getPrivacyUrl() {
		return privacyUrl;
	}

	public void setPrivacyUrl(String privacyUrl) {
		this.privacyUrl = privacyUrl;
	}

}
