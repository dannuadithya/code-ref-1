package com.billdog.user.common;

public enum AuditAction {

	ALL, Created, Modified

}
