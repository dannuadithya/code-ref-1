package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.billdog.user.entity.Organization;
import com.billdog.user.entity.Roles;

public interface RolesRepository extends JpaRepository<Roles, Long> {

	List<Roles> findByOrganizationId(Organization organization);

	Optional<Roles> findByRoleAndOrganizationId(String name, Organization organization);

	List<Roles> findByRoleNotAndOrganizationId(String superAdmin, Organization organizationId);

	List<Roles> findByRoleNotAndOrganizationIdOrderByRole(String superAdmin, Organization organizationId);

	List<Roles> findByRoleNotInAndOrganizationIdOrderByRole(List<String> rolesList, Organization organizationId);

	List<Roles> findByRoleAndOrganizationIdOrderByRole(String roleName, Organization organizationId);

	Optional<Roles> findByRoleAndOrganizationIdAndUserType(String name, Organization organizationId, String string);

	List<Roles> findByOrganizationIdAndUserType(Organization organizationId, String type);

	List<Roles> findByRoleNotInAndOrganizationIdAndUserTypeOrderByRole(List<String> rolesList,
			Organization organizationId, String string);

	@Query(value = "SELECT roa.id, roa.revType, roa.updated_at, roa.role, roa.status, roa.user_type, concat(su.first_name,' ', su.last_name), roa.audit_id, roa.rev  FROM roles_aud roa left join roles ro on ro.id=roa.id\n"
			+ "left join system_users su on su.id= roa.user_id\n"
			+ "where CASE WHEN COALESCE(?1,'') <> '' THEN roa.role ELSE '' END LIKE COALESCE(?2,'')\n"
			+ "and date(roa.updated_at) BETWEEN ?3 AND ?4 and roa.revtype in ?5 and ro.organization_id=?6 order by roa.rev desc, roa.updated_at desc", countQuery = "SELECT roa.id, roa.revType, roa.updated_at, roa.role, roa.status, roa.user_type, concat(su.first_name,' ', su.last_name), roa.audit_id, roa.rev  FROM roles_aud roa left join roles ro on ro.id=roa.id\n"
					+ "left join system_users su on su.id= roa.user_id\n"
					+ "where CASE WHEN COALESCE(?1,'') <> '' THEN roa.role ELSE '' END LIKE COALESCE(?2,'')\n"
					+ "and date(roa.updated_at) BETWEEN ?3 AND ?4 and roa.revtype in ?5 and ro.organization_id=?6 order by roa.rev desc, roa.updated_at desc", nativeQuery = true)
	Page<Object[]> getRoleAuditInfo(String name, String name2, String startDate, String endDate, List<Long> revtypes,
			long organizationId, Pageable pageRequest);


	@Query(value = "SELECT roa.id, roa.revType, roa.updated_at, roa.role, roa.status, roa.user_type, concat(su.first_name,' ', su.last_name), roa.audit_id, roa.rev   FROM roles_aud roa left join roles ro on ro.id=roa.id\n"
			+ "left join system_users su on su.id= roa.user_id\n"
			+ "where roa.id=?1 order by roa.rev desc", countQuery = "SELECT roa.id, roa.revType, roa.updated_at, roa.role, roa.status, roa.user_type, concat(su.first_name,' ', su.last_name), roa.audit_id, roa.rev   FROM roles_aud roa left join roles ro on ro.id=roa.id\n"
					+ "left join system_users su on su.id= roa.user_id\n"
					+ "where roa.id=?1 order by roa.rev desc", nativeQuery = true)
	Page<Object[]> getRoleAuditInfoById(Long id, PageRequest pageRequest);

	@Query(value = "SELECT roa.id, roa.revType, roa.updated_at, roa.role, roa.status, roa.user_type, concat(su.first_name,' ', su.last_name), roa.audit_id, roa.rev   FROM roles_aud roa left join roles ro on ro.id=roa.id\n"
			+ "left join system_users su on su.id= roa.user_id\n"
			+ "where roa.id=?1 and roa.rev<?2 order by roa.rev desc limit 1", countQuery = "SELECT roa.id, roa.revType, roa.updated_at, roa.role, roa.status, roa.user_type, concat(su.first_name,' ', su.last_name), roa.audit_id, roa.rev   FROM roles_aud roa left join roles ro on ro.id=roa.id\n"
					+ "left join system_users su on su.id= roa.user_id\n"
					+ "where roa.id=?1 and roa.rev<?2 order by roa.rev desc limit 1", nativeQuery = true)
	List<Object[]> getRoleAuditInfoByIdAndRev(long id, long rev);

	
	@Query(value = "select nsra.id,nsra.revType, nsra.updated_at, ns.name, nsra.read_access, nsra.write_access,nsra.custom,  nsra.rev   from navigation_screens_role_mapping_aud nsra\n"
			+ "left join navigation_screens ns on ns.id= nsra.navigation_screens_access_id\n"
			+ "where nsra.role_id=?1 and nsra.audit_id=?2 order by nsra.rev desc", countQuery = "select nsra.id,nsra.revType, nsra.updated_at, ns.name, nsra.read_access, nsra.write_access, nsra.custom,nsra.rev   from navigation_screens_role_mapping_aud nsra\n"
					+ "left join navigation_screens ns on ns.id= nsra.navigation_screens_access_id\n"
					+ "where nsra.role_id=?1 and nsra.audit_id=?2 order by nsra.rev desc", nativeQuery = true)
	List<Object[]> getRoleAccessByRoleId(long roleId, String auditId);

	@Query(value = "select nsra.id,nsra.revType, nsra.updated_at, ns.name,nsra.read_access, nsra.write_access, nsra.custom, nsra.rev   from navigation_screens_role_mapping_aud nsra\n"
			+ "left join navigation_screens ns on ns.id= nsra.navigation_screens_access_id\n"
			+ "where nsra.id=?1 and nsra.rev<?2 order by nsra.rev desc limit 1", countQuery = "select nsra.id,nsra.revType, nsra.updated_at, ns.name, nsra.read_access, nsra.write_access, nsra.custom,nsra.rev   from navigation_screens_role_mapping_aud nsra\n"
					+ "left join navigation_screens ns on ns.id= nsra.navigation_screens_access_id\n"
					+ "where nsra.id=?1 and nsra.rev<?2 order by nsra.rev desc limit 1", nativeQuery = true)
	List<Object[]> getRoleAccessById(long id, long rev);

}
