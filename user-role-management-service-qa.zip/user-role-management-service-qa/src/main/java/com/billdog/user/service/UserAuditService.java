package com.billdog.user.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.RecordsTime;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.AuditRequest;
import com.billdog.user.view.ViewAuditData;
import com.billdog.user.view.ViewResponse;

@Service
public class UserAuditService {

	@Autowired
	SystemUsersrepository systemUsersrepository;

	@Autowired
	MemberAuditService memberAuditService;

	private static final Logger LOGGER = LoggerFactory.getLogger(UserAuditService.class);

	public ResponseEntity<ViewResponse> getUserAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getUserAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = memberAuditService.getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.Custom.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}
		Page<Object[]> userObjects = systemUsersrepository.getUserAuditInfo(name, name, name, name, startDate, endDate,
				revtypes, auditRequest.getOrganizationId(), getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getData(userObjects.getContent());
		response.setTotalElements(userObjects.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getData(List<Object[]> userObjects) {
		List<ViewAuditData> viewAuditData = new ArrayList<>();

		userObjects.forEach(item -> {
			ViewAuditData auditResponse = new ViewAuditData();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> empObj = systemUsersrepository.getUserAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[11]).longValue());
				if (empObj != null && !empObj.isEmpty()) {
					for (Object[] item2 : empObj) {
						auditResponse = setUserValues(item, item2, auditResponse);
					}
				}
				if (auditResponse != null && (!StringUtils.isBlank(auditResponse.getOldValue())
						|| !StringUtils.isBlank(auditResponse.getNewValue()))) {
					viewAuditData.add(auditResponse);
				} else {
					auditResponse.setNewValue(Constants.NO_CHANGE);
					auditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditData.add(auditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				auditResponse = setCreatedUser(item, auditResponse);
				if (auditResponse != null && !StringUtils.isBlank(auditResponse.getNewValue())) {
					viewAuditData.add(auditResponse);
				}
			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(userObjects.size());
		response.setData(viewAuditData);
		response.setMessage(Constants.MEMBER_AUDIT_FETCHED);
		if (viewAuditData.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getUserAuditInfo method ended");
		return response;
	}

	private ViewAuditData setCreatedUser(Object[] item, ViewAuditData auditResponse) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];

		if (item[3] != null && !StringUtils.isBlank((String) item[3])) {
			newValue = newValue != null ? newValue + ", Email: " + item[3] : "Email: " + item[3];
		}
		if (item[4] != null && !StringUtils.isBlank((String) item[4])) {
			newValue = newValue != null ? newValue + ", first Name: " + item[4] : "first Name: " + item[4];
		}
		if (item[5] != null && !StringUtils.isBlank((String) item[5])) {
			newValue = newValue != null ? newValue + ", last Name: " + item[5] : "last Name: " + item[5];
		}

		if (item[6] != null && !StringUtils.isBlank((String) item[6])) {
			newValue = newValue != null ? newValue + ", Middle Name: " + item[6] : "Middle Name: " + item[6];
		}
		if (item[7] != null && !StringUtils.isBlank((String) item[7])) {
			newValue = newValue != null ? newValue + ", Mobile number: " + item[7] : "Mobile number: " + item[7];
		}

		if (item[8] != null && !StringUtils.isBlank((String) item[8])) {
			newValue = newValue != null ? newValue + ", status: " + item[8] : "status: " + item[8];
		}
		if (item[9] != null && !StringUtils.isBlank((String) item[9])) {
			newValue = newValue != null ? newValue + ", user type: " + item[9] : "user type: " + item[9];
		}
		if (item[14] != null && !StringUtils.isBlank((String) item[14])) {
			newValue = newValue != null ? newValue + ", name prefix master: " + item[14]
					: "name prefix master: " + item[14];
		}
		if (item[15] != null && !StringUtils.isBlank((String) item[15])) {
			newValue = newValue != null ? newValue + ", " + "role: " + item[15] : "role: " + item[15];
		}

		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		auditResponse.setUpdatedById(item[12] != null ? ((BigInteger) item[12]).longValue() : 0);
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		auditResponse.setNewValue(newValue);
		auditResponse.setModifiedBy(item[13] != null ? ((String) item[13]) : "");
		auditResponse.setMemberOrUser("User");
		return auditResponse;

	}

	private ViewAuditData setUserValues(Object[] item, Object[] item2, ViewAuditData viewAuditData) {
		boolean updated = false;
		String oldValue = null;
		String newValue = null;

		Timestamp updatedAt = (Timestamp) item[2];

		if (!StringUtils.isBlank((String) item[3]) && !StringUtils.isBlank((String) item2[3])
				&& !((String) item[3]).equalsIgnoreCase((String) item2[3])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "Email: " + item2[3] : "Email: " + item2[3];
			newValue = newValue != null ? newValue + ", " + "Email: " + item[3] : "Email: " + item[3];
		}
		if (!StringUtils.isBlank((String) item[3]) && StringUtils.isBlank((String) item2[3])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "Email: " + item[3] : "Email: " + item[3];
		}
		if (StringUtils.isBlank((String) item2[3]) && !StringUtils.isBlank((String) item2[3])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "Email: " + item2[3] : "Email: " + item2[3];
		}

		if (!StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])
				&& !((String) item[4]).equalsIgnoreCase((String) item2[4])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", first Name: " + item2[4] : "first Name: " + item2[4];
			newValue = newValue != null ? newValue + ", first Name: " + item[4] : "first Name: " + item[4];
		}
		if (!StringUtils.isBlank((String) item[4]) && StringUtils.isBlank((String) item2[4])) {
			updated = true;
			newValue = newValue != null ? newValue + ", first Name: " + item[4] : "first Name: " + item[4];
		}
		if (StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", first Name: " + item2[4] : "first Name: " + item2[4];
		}

		if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])
				&& !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", last Name: " + item2[5] : "last Name: " + item2[5];
			newValue = newValue != null ? newValue + ", last Name: " + item[5] : "last Name: " + item[5];
		}
		if (!StringUtils.isBlank((String) item[5]) && StringUtils.isBlank((String) item2[5])) {
			updated = true;
			newValue = newValue != null ? newValue + ", last Name: " + item[5] : "last Name: " + item[5];
		}
		if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", last Name: " + item2[5] : "last Name: " + item2[5];
		}

		if (!StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])
				&& !((String) item[6]).equalsIgnoreCase((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "middle name: " + item2[6] : "middle name: " + item2[6];
			newValue = newValue != null ? newValue + ", " + "middle name: " + item[6] : "middle name: " + item[6];
		}
		if (!StringUtils.isBlank((String) item[6]) && StringUtils.isBlank((String) item2[6])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "middle name: " + item[6] : "middle name: " + item[6];
		}
		if (StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "middle name: " + item2[6] : "middle name: " + item2[6];
		}

		if (item[7] != null && !((String) item[7]).equalsIgnoreCase((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "phone number: " + item2[7] : "phone number: " + item2[7];
			newValue = newValue != null ? newValue + ", " + "phone number: " + item[7] : "phone number: " + item[7];
		}
		if (!StringUtils.isBlank((String) item[7]) && StringUtils.isBlank((String) item2[7])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "phone number: " + item[7] : "phone number: " + item[7];
		}
		if (StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "phone number: " + item2[7] : "phone number: " + item2[7];
		}

		if (!StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])
				&& !((String) item[8]).equalsIgnoreCase((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "status: " + item2[8] : "status: " + item2[8];
			newValue = newValue != null ? newValue + ", " + "status: " + item[8] : "status: " + item[8];
		}
		if (!StringUtils.isBlank((String) item[8]) && StringUtils.isBlank((String) item2[8])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "status: " + item[8] : "status: " + item[8];
		}
		if (StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "status: " + item2[8] : "status: " + item2[8];
		}

		if (!StringUtils.isBlank((String) item[9]) && !StringUtils.isBlank((String) item2[9])
				&& !((String) item[9]).equalsIgnoreCase((String) item2[9])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "user type: " + item2[9] : "user type: " + item2[9];
			newValue = newValue != null ? newValue + ", " + "user type: " + item[9] : "user type: " + item[9];
		}
		if (!StringUtils.isBlank((String) item[9]) && StringUtils.isBlank((String) item2[9])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "user type: " + item[9] : "user type: " + item[9];
		}
		if (StringUtils.isBlank((String) item[9]) && !StringUtils.isBlank((String) item2[9])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "user type: " + item2[9] : "user type: " + item2[9];
		}

		if (!StringUtils.isBlank((String) item[14]) && !StringUtils.isBlank((String) item2[14])
				&& !((String) item[14]).equalsIgnoreCase((String) item2[14])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "name prefix: " + item2[14] : "name prefix: " + item2[14];
			newValue = newValue != null ? newValue + ", " + "name prefix: " + item[14] : "name prefix: " + item[14];
		}
		if (!StringUtils.isBlank((String) item[14]) && StringUtils.isBlank((String) item2[14])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "name prefix: " + item[14] : "name prefix: " + item[14];
		}
		if (StringUtils.isBlank((String) item[14]) && !StringUtils.isBlank((String) item2[14])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "name prefix: " + item2[14] : "name prefix: " + item2[14];
		}

		if (!StringUtils.isBlank((String) item[15]) && !StringUtils.isBlank((String) item2[15])
				&& !((String) item[15]).equalsIgnoreCase((String) item2[15])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "role: " + item2[15] : "role: " + item2[15];
			newValue = newValue != null ? newValue + ", " + "role: " + item[15] : "role: " + item[15];
		}
		if (!StringUtils.isBlank((String) item[15]) && StringUtils.isBlank((String) item2[15])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "role: " + item[15] : "role: " + item[15];
		}
		if (StringUtils.isBlank((String) item[15]) && !StringUtils.isBlank((String) item2[15])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "role: " + item2[15] : "role: " + item2[15];
		}

		if (updated) {
			viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
			viewAuditData.setMemberOrUser("User");
			viewAuditData.setUpdatedById(item[12] != null ? ((BigInteger) item[12]).longValue() : 0);
			viewAuditData.setAction(Constants.UPDATED);
			viewAuditData.setOldValue(oldValue);
			viewAuditData.setNewValue(newValue);
			viewAuditData.setModifiedBy(item[13] != null ? ((String) item[13]) : "");
			viewAuditData.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate())
									+ " "
									+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			return viewAuditData;
		}
		viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
		viewAuditData.setAction(getAction(item[1]));
		viewAuditData.setMemberOrUser("User");
		viewAuditData.setUpdatedById(item[12] != null ? ((BigInteger) item[12]).longValue() : 0);
		viewAuditData.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		viewAuditData.setModifiedBy(item[13] != null ? ((String) item[13]) : "");
		return viewAuditData;
	}

	private String getAction(Object item) {
		String action = null;
		int actionValue = ((Byte) item);
		if (actionValue == 0) {
			action = Constants.CREATED;
		}
		if (actionValue == 1) {
			action = Constants.UPDATED;
		}
		if (actionValue == 2) {
			action = Constants.DELETED;
		}
		return action;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	public ResponseEntity<ViewResponse> getUserAuditInfoById(Long id, Integer pageNumber, Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		Page<Object[]> userObj = systemUsersrepository.getUserAuditInfoById(id, getPageRequest(pageNumber, pageLimit));

		return ResponseEntity.status(HttpStatus.OK).body(getData(userObj.getContent()));
	}

}
