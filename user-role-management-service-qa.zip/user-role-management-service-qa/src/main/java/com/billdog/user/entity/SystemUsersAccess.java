package com.billdog.user.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "System_Users_Access")
@Table(name = "SYSTEM_USERS_ACCESS", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "user_index", columnList = "USER_ID", unique = false),
		@Index(name = "user_passcode_index", columnList = "USER_ID,PASSCODE", unique = false),
		@Index(name = "user_password_index", columnList = "USER_ID,PASSWORD", unique = false) })
public class SystemUsersAccess extends BaseEntity {

	@ManyToOne
	@JoinColumn(name = "USER_ID")
	private SystemUsers userId;

	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "PASSCODE")
	private String passcode;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Column(name = "email_count")
	private Long emailCount;

	@Column(name = "last_email_sent")
	private LocalDateTime mailSent;

	@Column(name = "PASSCODE_INCORRECT_COUNT")
	private Long passcodeIncorrectCount;

	@Column(name = "LAST_PASSCODE_VERIFIED")
	private LocalDateTime lasPasscodeVerified;

	@Column(name = "PASSWORD_INCORRECT_COUNT")
	private Long passwordIncorrectCount;

	@Column(name = "LAST_PASSWORD_VERIFIED")
	private LocalDateTime lasPasswordVerified;

	public Long getPasswordIncorrectCount() {
		return passwordIncorrectCount;
	}

	public void setPasswordIncorrectCount(Long passwordIncorrectCount) {
		this.passwordIncorrectCount = passwordIncorrectCount;
	}

	public LocalDateTime getLasPasswordVerified() {
		return lasPasswordVerified;
	}

	public void setLasPasswordVerified(LocalDateTime lasPasswordVerified) {
		this.lasPasswordVerified = lasPasswordVerified;
	}

	public Long getPasscodeIncorrectCount() {
		return passcodeIncorrectCount;
	}

	public void setPasscodeIncorrectCount(Long passcodeIncorrectCount) {
		this.passcodeIncorrectCount = passcodeIncorrectCount;
	}

	public LocalDateTime getLasPasscodeVerified() {
		return lasPasscodeVerified;
	}

	public void setLasPasscodeVerified(LocalDateTime lasPasscodeVerified) {
		this.lasPasscodeVerified = lasPasscodeVerified;
	}

	public SystemUsers getUserId() {
		return userId;
	}

	public void setUserId(SystemUsers userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPasscode() {
		return passcode;
	}

	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public Long getEmailCount() {
		return emailCount;
	}

	public void setEmailCount(Long emailCount) {
		this.emailCount = emailCount;
	}

	public LocalDateTime getMailSent() {
		return mailSent;
	}

	public void setMailSent(LocalDateTime mailSent) {
		this.mailSent = mailSent;
	}

}
