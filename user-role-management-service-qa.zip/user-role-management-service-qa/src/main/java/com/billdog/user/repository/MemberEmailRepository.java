package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.history.RevisionRepository;

import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.Organization;

public interface MemberEmailRepository
		extends JpaRepository<MemberEmail, Long>, RevisionRepository<MemberEmail, Long, Integer> {

	List<MemberEmail> findByMemberId(Member member);

	Optional<MemberEmail> findByEmailAndPrimaryAndOrganizationId(String primaryEmailId, boolean b,
			Organization organization);
	
	Optional<MemberEmail> findByMemberIdAndPrimaryAndDeletedAndVerified(Member member, boolean b, boolean c, boolean d);

	Optional<MemberEmail> findByMemberIdAndDeletedAndPrimaryAndSecondary(Member memberId, boolean b, boolean c,
			boolean d);

	Optional<MemberEmail> findByMemberIdAndDeletedAndPrimary(Member memberId, boolean b, boolean c);

	Optional<MemberEmail> findByEmailAndOrganizationIdAndDeletedAndPrimary(String email, Organization organization,
			boolean b, boolean c);

	Optional<MemberEmail> findByEmailAndOrganizationIdAndDeletedAndMemberId(String memberEmail,
			Organization organization, boolean b, Member member);

	Optional<MemberEmail> findByEmailAndOrganizationIdAndDeletedAndPrimaryAndVerified(String email,
			Organization organizationId, boolean b, boolean c, boolean d);

	Optional<MemberEmail> findByEmailAndOrganizationIdAndDeletedAndPrimaryAndVerifiedAndMemberId(String email,
			Organization organizationId, boolean b, boolean c, boolean d, Member member);

	Optional<MemberEmail> findByEmailAndOrganizationIdAndDeletedAndMemberIdAndSecondary(String memberEmail,
			Organization organization, boolean b, Member member, boolean c);

	Optional<MemberEmail> findByEmailAndPrimaryAndDeleted(String primaryEmailId, boolean b, boolean c);

	Optional<MemberEmail> findByMemberIdAndVerified(Member member, boolean b);

	Optional<MemberEmail> findByEmailAndMemberIdAndOrganizationId(String memberEmail, Member member,
			Organization organization);

	Optional<MemberEmail> findByEmailAndMemberIdAndSecondary(String primaryEmailId, Member member, boolean b);

	Optional<MemberEmail> findByMemberIdAndDeletedAndSecondary(Member member, boolean b, boolean c);

	Optional<MemberEmail> findByMemberIdAndEmail(Member member, String email);
	List<MemberEmail> findAllByMemberIdInAndPrimary(List<Member> membersList, boolean b);

	Optional<MemberEmail> findByEmailAndOrganizationIdAndPrimary(String memberEmail, Organization organization,
			boolean b);

}
