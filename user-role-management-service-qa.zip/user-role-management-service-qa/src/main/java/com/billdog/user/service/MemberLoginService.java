package com.billdog.user.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.authentication.AesEncryption;
import com.billdog.user.authentication.JWTAuthentication;
import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.Organization;
import com.billdog.user.exception.EmailLimitExceededException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.exception.PasscodeExpiredException;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.request.MemberPasscodeRequest;
import com.billdog.user.request.PasscodeEmailMemberRequest;
import com.billdog.user.request.ResendPasscodeRequest;
import com.billdog.user.request.SignInRequest;
import com.billdog.user.request.UpdateEmailRequest;
import com.billdog.user.request.UpdateMemberEmailRequest;
import com.billdog.user.request.VerifyMemberEmailRequest;
import com.billdog.user.request.VerifyMemberPasscodeRequest;
import com.billdog.user.view.VerifyEmailResponse;
import com.billdog.user.view.VerifyMemberPasscodeResponse;
import com.billdog.user.view.ViewMemberResponse;
import com.billdog.user.view.ViewResponse;

@Service
public class MemberLoginService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MemberLoginService.class);

	@Value("${passcode.expired.time.minutes}")
	private int passcodeExpiredTime;

	@Value("${passcode.email.times}")
	private int passcodeTimes;

	@Value("${passcode.length}")
	private int passcodeLength;


	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Autowired
	CreateMemberDetails createMemberDetails;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	AesEncryption aesEncryption;

	@Autowired
	MemberTypeMasterRepository memberTypeMasterRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	JWTAuthentication jwtAuthentication;

	@Autowired
	LoginService loginService;

	@Autowired
	EmailService emailService;

	@Autowired
	MemberService memberService;

	@Autowired
	CreateUserService createUserService;

	@Autowired
	AuditService auditService;

	public VerifyEmailResponse verifyMemberEmail(VerifyMemberEmailRequest verifyMemberEmailRequest) {
		LOGGER.info("Verify email method started..!");

		Organization organization = loginService.getOrganization(verifyMemberEmailRequest.getOrganizationId());

		Optional<MemberEmail> memberEmailEntity = memberEmailRepository
				.findByEmailAndOrganizationIdAndDeletedAndPrimary(verifyMemberEmailRequest.getEmail(), organization,
						false, true);
		if (memberEmailEntity.isPresent()) {
			Optional<Member> member = memberRepository
					.findByIdAndLockedAndLockedFromWeb(memberEmailEntity.get().getMemberId().getId(), true, true);
			if (member.isPresent()) {
				throw new NoRecordFoundException(getErrorMessage(organization));
			}
		}
		VerifyEmailResponse loginResponse = new VerifyEmailResponse();
		if (memberEmailEntity.isPresent()) {
			if (memberEmailEntity.get().getLasPasscodeVerified() != null
					&& memberEmailEntity.get().getPasscodeIncorrectCount() >= 3
					&& createUserService.checkDateTime(memberEmailEntity.get().getLasPasscodeVerified())) {
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}

			if (memberEmailEntity.get().getLasPasswordVerified() != null
					&& memberEmailEntity.get().getPasswordIncorrectCount() >= 3
					&& createUserService.checkDateTime(memberEmailEntity.get().getLasPasswordVerified())) {
				throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
			}
			if (memberEmailEntity.get().getMemberId()!=null && memberEmailEntity.get().getMemberId().isLocked()) {
				String auditId = auditService.getAuditId();
				memberEmailEntity.get().getMemberId().setLocked(false);
				memberEmailEntity.get().getMemberId().setAuditId(auditId);
				memberEmailEntity.get().getMemberId().setUpdatedAt(DateAndTimeUtil.now());
				memberRepository.save(memberEmailEntity.get().getMemberId());
			}

			if (!memberEmailEntity.get().isVerified()) {
				createMemberDetails.sendPasscode(verifyMemberEmailRequest, EmailTitles.MEMBER_PASSCODE,
						memberEmailEntity, organization);
				loginResponse.setStatusText(Constants.SUCCESS);
				loginResponse.setMessage(Constants.PASSCODE_SENT);
				loginResponse.setMemberId(memberEmailEntity.get().getMemberId().getId());
				return loginResponse;
			}
			loginResponse.setStatusText("There is a problem");
			loginResponse.setMessage(Constants.EMAIL_EXIST);
			loginResponse.setAsAMember(Boolean.TRUE);
			loginResponse.setMemberId(memberEmailEntity.get().getMemberId().getId());
			LOGGER.warn("Member Email already exits in the system..!");
			return loginResponse;
		}
		// sending passcode to to requested email
		ViewResponse sendPasscode = createMemberDetails.sendPasscode(verifyMemberEmailRequest,
				EmailTitles.MEMBER_PASSCODE, memberEmailEntity, organization);
		// providing successful response if user data is stores

		loginResponse.setStatusText(Constants.SUCCESS);
		loginResponse.setMessage(Constants.PASSCODE_SENT);
		loginResponse.setMemberId(sendPasscode.getMemberId());
		LOGGER.info("Verify email method ends..!");
		return loginResponse;

	}

	public ResponseEntity<ViewResponse> sendPasscodeByMember(ResendPasscodeRequest resendPasscodeRequest) {
		LOGGER.info("sending passcode to member method started");

		Organization organization = loginService.getOrganization(resendPasscodeRequest.getOrganizationId());
		LOGGER.debug("fetching organization based on input");

		Optional<Member> member = memberRepository.findById(resendPasscodeRequest.getMemberId());
		if (!member.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		Optional<MemberEmail> memberEmailEntity = memberEmailRepository
				.findByEmailAndOrganizationIdAndDeletedAndMemberId(resendPasscodeRequest.getEmail(), organization,
						false, member.get());
		if (!memberEmailEntity.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_NOT_FOUND_ORGANIZATION);
		}

		return ResponseEntity.status(HttpStatus.OK).body(createMemberDetails.resendPasscode(resendPasscodeRequest,
				EmailTitles.MEMBER_PASSCODE, memberEmailEntity, organization, member.get()));
	}

	public ResponseEntity<VerifyMemberPasscodeResponse> verifyMemberPasscode(
			VerifyMemberPasscodeRequest verifyMemberPasscodeRequest) {
		LOGGER.info("verify member passcode method started..!");
		Optional<Organization> organization = organizationRepository
				.findById(verifyMemberPasscodeRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<Member> member = memberRepository.findById(verifyMemberPasscodeRequest.getMemberId());
		if (!member.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		Optional<MemberEmail> memberEmail = memberEmailRepository.findByEmailAndOrganizationIdAndDeletedAndMemberId(
				verifyMemberPasscodeRequest.getMemberEmail(), organization.get(), false, member.get());
		if (!memberEmail.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_NOT_FOUND_ORGANIZATION);
		}
		// This jpa query checks whether the member type present or not
		if (!memberEmail.get().isPrimary()) {
			LOGGER.warn("Your email is not primary, please try to login with your primary email");
			throw new NoRecordFoundException(ExceptionalMessages.NOT_PRIMARY_EMAIL);
		}
		if (member.get().isLocked() && member.get().isLockedFromWeb()) {
			throw new NoRecordFoundException(getErrorMessage(organization.get()));
		}
		String auditId = auditService.getAuditId();
		if (memberEmail.get().getLasPasscodeVerified() != null && memberEmail.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(memberEmail.get().getLasPasscodeVerified())) {
			member.get().setLocked(true);
			member.get().setAuditId(auditId);
			member.get().setUpdatedAt(DateAndTimeUtil.now());
			memberRepository.save(member.get());
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}
		// This jpa query checks whether the passcode matched with email sent
		String decryptedPassCode = aesEncryption.decrypt(memberEmail.get().getPasscode());
		if (memberEmail.get().getPasscode() != null
				&& !decryptedPassCode.equals(verifyMemberPasscodeRequest.getPasscode())) {
			memberEmail.get().setPasscodeIncorrectCount(memberEmail.get().getPasscodeIncorrectCount() + 1);
			memberEmail.get().setLasPasscodeVerified(LocalDateTime.now());
			memberEmailRepository.save(memberEmail.get());
			throw new NoRecordFoundException(ExceptionalMessages.PLEASE_ENTER_VALID_PASSCODE);
		}
		memberEmail.get().setPasscodeIncorrectCount(0l);
		memberEmailRepository.save(memberEmail.get());
		// check time check whether member is eligible to resend passcode we can send
		// only 3times
		checkTime(memberEmail.get());
//		if (memberEmail.get().getMemberId() == null) {
//			// if passcode verified successfully then creating member with enrolled status
//
//		}
		memberEmail.get().setVerified(true);
		memberEmailRepository.save(memberEmail.get());
		String memberName = null;
		boolean indirectMamber = false;
		if (memberEmail.get().getMemberId() != null) {
			if (!StringUtils.isBlank(memberEmail.get().getMemberId().getFirstName())) {
				memberName = memberEmail.get().getMemberId().getFirstName();
			}
			if (!StringUtils.isBlank(memberEmail.get().getMemberId().getLastName())) {
				memberName = memberName + " " + memberEmail.get().getMemberId().getLastName();
			}
			if (memberEmail.get().getMemberId().getMemberTypeMasterId() != null
					&& !StringUtils.isBlank(memberEmail.get().getMemberId().getMemberTypeMasterId().getTypeName())
					&& !memberEmail.get().getMemberId().getMemberTypeMasterId().getTypeName()
							.equalsIgnoreCase(Constants.DIRECT_MEMBER)) {
				indirectMamber = true;
			}
		}

		VerifyMemberPasscodeResponse viewResponse = new VerifyMemberPasscodeResponse();
		viewResponse.setMemberId(memberEmail.get().getMemberId().getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.PASSCODE_VERIFIED_SUCCESSFULLY);

		viewResponse.setMemberName(memberName);

		viewResponse.setIndirectMamber(indirectMamber);
		LOGGER.info("verify member passcode method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	public String getMemberId(Long orgId) {
		LOGGER.info("Generating new member id under organization id:: {}", orgId);
		String latestMemberId = memberRepository.getMaxMemberId(orgId);
		String memberId = null;
		long number = 0;
		int count = 1;
		do {
			if (latestMemberId == null) {
				number = Long.parseLong(Constants.MEMBER_ID) + count;
				memberId = String.valueOf(number);
			} else {
				number = Long.parseLong(latestMemberId) + count;
				memberId = String.valueOf(number);
			}

			count++;
		} while (!memberRepository.findByMemberId(memberId).isEmpty());
		LOGGER.info("New member id:: {}", memberId);
		return memberId;
	}

	private void checkTime(MemberEmail memberEmail) {
		LOGGER.debug("checking time whether member is eligible to send passcode..!");
		if (DateAndTimeUtil.now().isAfter(memberEmail.getUpdatedAt().plusMinutes(passcodeExpiredTime))) {
			String message = ExceptionalMessages.PASSCODE_TIME_EXPIRED.replace("{time}", "" + passcodeExpiredTime);
			throw new PasscodeExpiredException(message);
		}
	}

	public ViewMemberResponse memberLogin(SignInRequest signInRequest) {
		LOGGER.info("member login method started");

		Optional<Organization> organization = organizationRepository.findById(signInRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}
		Optional<MemberEmail> memberEmail = memberEmailRepository
				.findByEmailAndOrganizationIdAndDeletedAndPrimaryAndVerified(signInRequest.getEmail(),
						organization.get(), false, true, true);
		if (!memberEmail.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_NOT_FOUND_ORGANIZATION);
		}

		if (memberEmail.get().getMemberId().isLocked() && memberEmail.get().getMemberId().isLockedFromWeb()) {
			throw new NoRecordFoundException(getErrorMessage(memberEmail.get().getOrganizationId()));
		}
		String auditId = auditService.getAuditId();
		if ((memberEmail.get().getLasPasscodeVerified() != null && memberEmail.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(memberEmail.get().getLasPasscodeVerified()))
				|| (memberEmail.get().getLasPasswordVerified() != null
						&& memberEmail.get().getPasswordIncorrectCount() >= 3
						&& createUserService.checkDateTime(memberEmail.get().getLasPasswordVerified()))) {
			memberEmail.get().getMemberId().setLocked(true);
			memberEmail.get().getMemberId().setAuditId(auditId);
			memberEmail.get().getMemberId().setUpdatedAt(DateAndTimeUtil.now());
			memberRepository.save(memberEmail.get().getMemberId());
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}

		if (memberEmail.get().getPassword() != null) {
			LOGGER.debug("encrypting requested password");
			String encryptedPassword = aesEncryption.passwordHashing(signInRequest.getPassword());
			checkStatus(memberEmail.get().getMemberId().getStatus());

			LOGGER.debug("checking pasword matches or not..!");
			if (memberEmail.get().getPassword() == null || (memberEmail.get().getPassword() != null
					&& !encryptedPassword.equals(memberEmail.get().getPassword()))) {
				memberEmail.get().setPasswordIncorrectCount(memberEmail.get().getPasswordIncorrectCount() + 1);
				memberEmail.get().setLasPasswordVerified(LocalDateTime.now());
				memberEmailRepository.save(memberEmail.get());
				throw new NoRecordFoundException(ExceptionalMessages.INCORRECT_USERNAME_PASSWORD);
			}
		} else {
			throw new NoRecordFoundException(ExceptionalMessages.INCORRECT_USERNAME_PASSWORD);
		}
		if (memberEmail.get().getMemberId() != null) {
			boolean update = false;
			if (memberEmail.get().getMemberId().isLocked()) {
				update = true;
				memberEmail.get().getMemberId().setLocked(false);
			}
			if (!StringUtils.isBlank(signInRequest.getFcmToken())
					&& !signInRequest.getFcmToken().equalsIgnoreCase(memberEmail.get().getMemberId().getFcmToken())) {
				update = true;
				memberEmail.get().getMemberId().setFcmToken(signInRequest.getFcmToken());
			}
			if (update) {
				memberEmail.get().getMemberId().setUpdatedAt(DateAndTimeUtil.now());
				memberEmail.get().getMemberId().setAuditId(auditId);
				if(!StringUtils.isBlank(signInRequest.getDeviceType())) {
					memberEmail.get().getMemberId().setDeviceType(signInRequest.getDeviceType());
				}
				memberRepository.save(memberEmail.get().getMemberId());
			}

		}
		memberEmail.get().setPasswordIncorrectCount(0l);
		memberEmailRepository.save(memberEmail.get());
		saveMemberAppInfo(signInRequest, memberEmail.get().getMemberId());
		String token = jwtAuthentication.generateToken(memberEmail.get().getMemberId().getId(), Boolean.FALSE);
		String refreshToken = jwtAuthentication.generateRefreshToken(memberEmail.get().getMemberId().getId());
		memberService.saveToken(token, refreshToken, memberEmail.get().getMemberId());
		ViewMemberResponse memberResponse = new ViewMemberResponse();
		memberResponse.setMemberId(memberEmail.get().getMemberId().getId());
		LOGGER.debug("providing JWT token in response for that member..!");
		memberResponse.setToken(token);
		memberResponse.setRefreshToken(refreshToken);
		memberResponse.setIndirectMember(memberEmail.get().getMemberId().getMemberTypeMasterId() != null && !memberEmail
				.get().getMemberId().getMemberTypeMasterId().getTypeName().equalsIgnoreCase(StatusConstants.DIRECT));
		memberResponse.setProfileUpdated(memberEmail.get().getMemberId().isProfileUpdated());
		memberResponse.setMessage("Member Login Success!");
		LOGGER.info("member login method ended");
		return memberResponse;
	}

	private void saveMemberAppInfo(SignInRequest signInRequest, Member member) {
		if (StringUtils.isNotBlank(signInRequest.getDeviceToken())) {
			member.setDeviceToken(signInRequest.getDeviceToken());
		}
		if (StringUtils.isNotBlank(member.getCurrentVersion())) {
			member.setOldVersion(member.getCurrentVersion());
		}
		if (StringUtils.isNotBlank(signInRequest.getAppVersion())) {
			member.setCurrentVersion(signInRequest.getAppVersion());
		}
	}

	public String getErrorMessage(Organization organization) {
		String message = ExceptionalMessages.WEB_LOCKED;
		if (organization != null && !StringUtils.isBlank(organization.getEmail())) {
			message = message.replace("<Email>", organization.getEmail());
		} else {
			message = message.replace("<Email>", "");
		}
		return message;
	}

	private void checkStatus(String status) {
		if (status == null || status.equalsIgnoreCase(StatusConstants.DISABLED)
				|| status.equalsIgnoreCase(StatusConstants.TERMINATED)) {
			throw new NoRecordFoundException(ExceptionalMessages.YOU_DONT_HAVE_ACCESS_PLEASE_CONTACT_SUPPORT_TEAM);
		}
	}

	public ViewResponse sendUpdatedEmail(EmailTitles emailTitles, Member member, MemberEmail memberEmail,
			String newEmail) {
		LOGGER.info("Send welcome mail method started..!");

		UpdateMemberEmailRequest updateEmailRequest = new UpdateMemberEmailRequest();
		updateEmailRequest.setEmailTitle(emailTitles);
		updateEmailRequest.setNewEmail(newEmail);
		updateEmailRequest.setOldEmail(memberEmail.getEmail());
		updateEmailRequest.setFirstName(member.getFirstName());
		updateEmailRequest.setOrgId(member.getOrganizationId().getId());
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send updated email");
			viewResponse = emailService.sendUpdatedEamilToMember(updateEmailRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: ", exception.getCause());
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send welcome email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.WELCOME_MEMBER);
		} else {
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
		}

		return viewResponse;
	}

	public ViewResponse sendUpdatedEmailToMember(VerifyMemberPasscodeRequest verifyMemberPasscodeRequest,
			EmailTitles emailTitles, Member member) {
		LOGGER.info("Send welcome mail method started..!");

		UpdateEmailRequest updateEmailRequest = new UpdateEmailRequest();
		updateEmailRequest.setEmailTitle(emailTitles);
		updateEmailRequest.setFirstName(member.getFirstName());
		updateEmailRequest.setLastName(member.getLastName());
		updateEmailRequest.setUserName(verifyMemberPasscodeRequest.getMemberEmail());
		updateEmailRequest.setOrgId(member.getOrganizationId().getId());
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send welcome email");
			viewResponse = emailService.sendUpdatedEamil(updateEmailRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: ", exception.getCause());
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send welcome email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.WELCOME_MEMBER);
		} else {
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
		}

		return viewResponse;
	}

	private void deletingSecoundaryEmail(MemberEmail memberEmail) {

		Optional<MemberEmail> memberEmailEntity = memberEmailRepository
				.findByMemberIdAndDeletedAndPrimaryAndSecondary(memberEmail.getMemberId(), false, false, true);
		if (memberEmailEntity.isPresent()) {
			memberEmailEntity.get().setUpdatedAt(DateAndTimeUtil.now());
			memberEmailEntity.get().setDeleted(true);
			memberEmailEntity.get().setSecondary(false);
			memberEmail.setUserId(null);
			memberEmailRepository.save(memberEmailEntity.get());
		}
	}

	private void newEmailToPrimary(MemberEmail memberEmail, MemberEmail memberEmailentity) {
		memberEmail.setUpdatedAt(DateAndTimeUtil.now());
		memberEmail.setPrimary(true);
		memberEmail.setVerified(true);
		memberEmail.setPassword(memberEmailentity.getPassword());
		memberEmail.setUserId(null);
		memberEmailRepository.save(memberEmail);
	}

	public ResponseEntity<ViewResponse> verifyUpdatedEmailPasscode(
			VerifyMemberPasscodeRequest verifyMemberPasscodeRequest) {
		LOGGER.info("verify member passcode method started..!");
		Optional<Organization> organization = organizationRepository
				.findById(verifyMemberPasscodeRequest.getOrganizationId());
		if (!organization.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ORGANIZATION_NOT_FOUND);
		}

		Optional<Member> member = memberRepository.findById(verifyMemberPasscodeRequest.getMemberId());
		if (!member.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		// check whether primary email present or not also used to send email for old
		// email
		Optional<MemberEmail> memberEmail = memberEmailRepository.findByMemberIdAndVerified(member.get(), true);
		if (!memberEmail.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_NOT_FOUND_ORGANIZATION);
		}

		Optional<MemberEmail> memberPrimaryEmail = memberEmailRepository.findByEmailAndOrganizationIdAndPrimary(
				verifyMemberPasscodeRequest.getMemberEmail(), organization.get(), true);
		if (memberPrimaryEmail.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS);
		}

		Optional<MemberEmail> memberEmailEntity = memberEmailRepository.findByEmailAndMemberIdAndOrganizationId(
				verifyMemberPasscodeRequest.getMemberEmail(), member.get(), organization.get());
		if (memberEmailEntity.isPresent()) {
			String decryption = aesEncryption.decrypt(memberEmailEntity.get().getPasscode());
			if (!verifyMemberPasscodeRequest.getPasscode().equalsIgnoreCase(decryption)) {
				throw new NoRecordFoundException(ExceptionalMessages.PLEASE_ENTER_VALID_PASSCODE);
			}
			checkTime(memberEmailEntity.get());
		}

		checkEmailExitsAsSecondary(verifyMemberPasscodeRequest, organization.get(), member.get());

		// sending email to old email
		sendUpdatedEmail(EmailTitles.OLD_EMAIL, member.get(), memberEmail.get(),
				verifyMemberPasscodeRequest.getMemberEmail());
		// sending email to new email
		sendUpdatedEmailToMember(verifyMemberPasscodeRequest, EmailTitles.NEW_EMAIL, member.get());
		memberService.expireToken(member.get());
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMemberId(verifyMemberPasscodeRequest.getMemberId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.EMAIL_ADDED_SUCCESSFULLY);
		LOGGER.info("verify member passcode method has ended..!");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	private void checkEmailExitsAsSecondary(VerifyMemberPasscodeRequest verifyMemberPasscodeRequest,
			Organization organization, Member member) {

		Optional<MemberEmail> memberEmail1 = memberEmailRepository
				.findByEmailAndOrganizationIdAndDeletedAndPrimaryAndVerified(
						verifyMemberPasscodeRequest.getMemberEmail(), organization, false, true, true);
		if (memberEmail1.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.EMAIL_EXITS);
		}

		Optional<MemberEmail> memberEmailSecoundary = memberEmailRepository
				.findByEmailAndOrganizationIdAndDeletedAndMemberIdAndSecondary(
						verifyMemberPasscodeRequest.getMemberEmail(), organization, false, member, true);
		if (memberEmailSecoundary.isPresent()) {
			if (memberEmailSecoundary.get().getEmail().equalsIgnoreCase(verifyMemberPasscodeRequest.getMemberEmail())) {
				Optional<MemberEmail> memberPrimaryEmail = memberEmailRepository
						.findByMemberIdAndPrimaryAndDeletedAndVerified(member, true, false, true);
				if (memberPrimaryEmail.isPresent()) {
					memberPrimaryEmail.get().setUpdatedAt(DateAndTimeUtil.now());
					memberPrimaryEmail.get().setPrimary(false);
					memberPrimaryEmail.get().setSecondary(true);
					// memberPrimaryEmail.get().setPassword(null);
					memberPrimaryEmail.get().setVerified(false);
					memberPrimaryEmail.get().setDeleted(false);
					memberPrimaryEmail.get().setUserId(null);
					memberEmailRepository.save(memberPrimaryEmail.get());
				}
				memberEmailSecoundary.get().setPrimary(true);
				memberEmailSecoundary.get().setUpdatedAt(DateAndTimeUtil.now());
				if (memberPrimaryEmail.isPresent() && memberPrimaryEmail.get().getPassword() != null) {
					memberEmailSecoundary.get().setPassword(memberPrimaryEmail.get().getPassword());
				}
				memberEmailSecoundary.get().setDeleted(false);
				memberEmailSecoundary.get().setVerified(true);
				memberEmailSecoundary.get().setSecondary(false);
				memberEmailSecoundary.get().setUserId(null);
				memberEmailRepository.save(memberEmailSecoundary.get());

			}
		} else {
			Optional<MemberEmail> memberEmail = memberEmailRepository.findByEmailAndOrganizationIdAndDeletedAndMemberId(
					verifyMemberPasscodeRequest.getMemberEmail(), organization, false, member);
			if (!memberEmail.isPresent()) {
				throw new NoRecordFoundException(ExceptionalMessages.EMAIL_NOT_FOUND_ORGANIZATION);
			}
			// deleting secondary email if exits for member
			deletingSecoundaryEmail(memberEmail.get());

			// old primary email to secondary
			Optional<MemberEmail> memberEmailOptional = memberEmailRepository
					.findByMemberIdAndDeletedAndPrimary(memberEmail.get().getMemberId(), false, true);
			if (memberEmailOptional.isPresent()) {
				MemberEmail email = memberEmailOptional.get();
				email.setUpdatedAt(DateAndTimeUtil.now());
				email.setPrimary(false);
				email.setSecondary(true);
				email.setVerified(false);
				email.setUserId(null);
				// email.setPassword(null);
				memberEmailRepository.save(email);
			}

			// setting new email to primary
			if (memberEmailOptional.isPresent()) {
				newEmailToPrimary(memberEmail.get(), memberEmailOptional.get());
			}
		}
	}

	public ResponseEntity<ViewResponse> sendPasscodeForForgotPassword(MemberPasscodeRequest memberPasscodeRequest) {
		LOGGER.info("sending passcode to member method started");

		Organization organization = loginService.getOrganization(memberPasscodeRequest.getOrganizationId());
		LOGGER.debug("fetching organization based on input");

		Optional<MemberEmail> memberEmailEntity = memberEmailRepository
				.findByEmailAndPrimaryAndOrganizationId(memberPasscodeRequest.getEmail(), true, organization);
		if (!memberEmailEntity.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ACCOUNT_WITH_EMAIL_NOT_EXISTS);
		}

		checkStatus(memberEmailEntity.get().getMemberId().getStatus());
//		if (memberEmailEntity.get().getLasPasscodeVerified() != null
//				&& memberEmailEntity.get().getPasscodeIncorrectCount() >= 3
//				&& createUserService.checkDateTime(memberEmailEntity.get().getLasPasscodeVerified())) {
//			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
//		}
		Optional<Member> member = memberRepository.findById(memberEmailEntity.get().getMemberId().getId());
		if (member.isPresent() && member.get().isLocked() && member.get().isLockedFromWeb()) {
			throw new NoRecordFoundException(getErrorMessage(organization));
		}

		if (memberEmailEntity.get().getLasPasscodeVerified() != null
				&& memberEmailEntity.get().getPasscodeIncorrectCount() >= 3
				&& createUserService.checkDateTime(memberEmailEntity.get().getLasPasscodeVerified())) {
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}

		if (memberEmailEntity.get().getLasPasswordVerified() != null
				&& memberEmailEntity.get().getPasswordIncorrectCount() >= 3
				&& createUserService.checkDateTime(memberEmailEntity.get().getLasPasswordVerified())) {
			throw new NoRecordFoundException(ExceptionalMessages.LOCKED);
		}
		if(member.isPresent()) {
			member.get().setLocked(false);
			memberRepository.save(member.get());
		}
		

		return ResponseEntity.status(HttpStatus.OK).body(resendPasscode(memberPasscodeRequest,
				EmailTitles.MEMBER_PASSCODE, memberEmailEntity, organization, member));
	}

	public ViewResponse resendPasscode(MemberPasscodeRequest memberPasscodeRequest, EmailTitles emailTitle,
			Optional<MemberEmail> memberEmail, Organization organization, Optional<Member> member) {
		LOGGER.info("Send passcode method started..!");
		LOGGER.info("Checking email passcode limit to email new passcode to member");
		if (memberEmail.isPresent() && memberEmail.get().getEmailCount() != null
				&& memberEmail.get().getEmailCount() >= passcodeTimes
				&& createMemberDetails.createUserService.checkDate(memberEmail.get().getMailSent().toLocalDate())) {
			String message = ExceptionalMessages.PASSCODE_EMAIL_LIMIT_EXCEEDED.replace("{times}", "" + passcodeTimes);
			throw new EmailLimitExceededException(message);
		}
		String passcode = createMemberDetails.createUserService.generatePasscode(passcodeLength);
		LOGGER.debug("Generated new passcode for login purpose");
		if (!memberEmail.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.ACCOUNT_WITH_EMAIL_NOT_EXISTS);
		}
		savePasscode(memberPasscodeRequest, memberEmail, passcode, organization);
		LOGGER.info("Creting passcode email member request object for calling email service");
		PasscodeEmailMemberRequest passcodeEmailMemberRequest = new PasscodeEmailMemberRequest();
		passcodeEmailMemberRequest.setEmail(memberPasscodeRequest.getEmail());
		passcodeEmailMemberRequest.setPasscode(passcode);
		passcodeEmailMemberRequest.setEmailTitle(emailTitle);

		if (member.isPresent()) {
			passcodeEmailMemberRequest.setFirstName(member.get().getFirstName());
			passcodeEmailMemberRequest.setOrgId(member.get().getOrganizationId().getId());
		}
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send passcode email");
			viewResponse = emailService.sendEamilToMember(passcodeEmailMemberRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: ", exception.getCause());
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send passcode email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.SENT_PASSCODE);
			viewResponse.setMemberId(memberEmail.get().getMemberId().getId());
		} else {
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}
		return viewResponse;
	}

	private MemberEmail savePasscode(MemberPasscodeRequest memberPasscodeRequest, Optional<MemberEmail> optional,
			String passcode, Organization orOptional) {
		LOGGER.info("savePasscode method started");
		MemberEmail memberEmail = new MemberEmail();
		if (optional.isPresent()) {
			LOGGER.info("Updating member recent passcode for login verification");
			memberEmail = optional.get();
			LOGGER.info("Checking last passcode email date for updating passcode email limit count");
			if (memberEmail.getMailSent() != null
					&& memberEmail.getMailSent().toLocalDate().isEqual(DateAndTimeUtil.now().toLocalDate())) {
				memberEmail.setEmailCount(memberEmail.getEmailCount() + 1);
			} else {
				memberEmail.setEmailCount(1l);
			}
			memberEmail.setUpdatedAt(DateAndTimeUtil.now());
			memberEmail.setMailSent(DateAndTimeUtil.now());
			memberEmail.setUserId(null);
			String encryptedPassword = aesEncryption.encrypt(passcode);
			memberEmail.setPasscode(encryptedPassword);
			LOGGER.info("savePasscode method ended");

		}
		return memberEmailRepository.save(memberEmail);
	}

}
