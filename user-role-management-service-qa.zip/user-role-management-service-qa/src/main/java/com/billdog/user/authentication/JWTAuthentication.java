package com.billdog.user.authentication;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.exception.InvalidAuthTokenException;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;

@Service
public class JWTAuthentication {

	@Value("${user.jwt.token.minutes}")
	private Integer userTokenExpiryTime;

	@Value("${member.jwt.token.minutes}")
	private Integer memberTokenExpiryTime;

	@Value("${member.refresh.token.minutes}")
	private Integer memberRefreshTokenExpiryTime;

	/*
	 * @Value("${user.refresh.token.minutes}") private Integer
	 * userRefreshTokenExpiryTime;
	 */

	private static final String SECRET_KEY = "70c349b2-9b18-4dc3-b5f6-57b10cc74f56";

	public String generateToken(Long id, boolean isUser) {
		Integer expiryTime = isUser ? userTokenExpiryTime : memberTokenExpiryTime;
		String subject = isUser ? "USER-" + id : "MEMBER-" + id;
		return Jwts.builder().setSubject(subject).setIssuedAt(Date.from(Instant.now()))
				.setExpiration(Date.from(Instant.now().plus(expiryTime, ChronoUnit.MINUTES)))
				.signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
	}

	public Claims verifyToken(String token) {
		try {
			return Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
		} catch (Exception e) {
			return null;
		}
	}
	
	public void verifyTokenTime(String token) {
		try {
			final Claims claims = Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token).getBody();
			if (claims == null) {
				throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
			}
			Date currentDate = new Date();
			if (claims.getExpiration().compareTo(currentDate) <= 0) {
				throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
			}
		} catch (Exception e) {
			throw new InvalidAuthTokenException(ExceptionalMessages.SESSION_EXPIRED);
		}
	}

	public String generateRefreshToken(Long id) {
		Integer expiryTime = memberRefreshTokenExpiryTime;
		String subject = "" + id;
		return Jwts.builder().setSubject(subject).setIssuedAt(Date.from(Instant.now()))
				.setExpiration(Date.from(Instant.now().plus(expiryTime, ChronoUnit.MINUTES)))
				.signWith(SignatureAlgorithm.HS256, SECRET_KEY).compact();
	}
}