package com.billdog.user.request;

import java.util.List;

public class MemberCaseCountRequest {

	private List<Long> memberIds;
	private long organizationId;

	public List<Long> getMemberIds() {
		return memberIds;
	}

	public void setMemberIds(List<Long> memberIds) {
		this.memberIds = memberIds;
	}

	public long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(long organizationId) {
		this.organizationId = organizationId;
	}

}
