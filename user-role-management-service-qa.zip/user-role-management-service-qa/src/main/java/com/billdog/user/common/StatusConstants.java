package com.billdog.user.common;

public class StatusConstants {

	public static final String ACTIVE = "Active";
	public static final String ENROLLED = "Enrolled";
	public static final String INACTIVE = "Inactive";

	// member types

	public static final String DIRECT = "Direct to Consumer";
	public static final String INDIRECT = "Indirect member";
	public static final String ACTIVATED = "Activated";
	public static final String TRANSITION = "Transition";
	public static final String DISABLED = "Disabled";
	public static final String TERMINATED = "Terminated";

	// Role name constants
	public static final String SUPER_ADMIN = "Super Admin";
	public static final String SYSTEM_ADMIN = "System Admin";
	public static final String DELETED = "Deleted";
	public static final String PENDING = "Pending";
	public static final String SINGLE = "Single";
	public static final String MARRIED = "Married";
	public static final String FAMILY = "Family";

	public static final String ROLE_ACCESS_UPDATED = "Role Access Updated";
	public static final String ROLE_UPDATED = "Role Updated";
	public static final String BLOCK_OPPORTUNITY = "Block Opportunity";
	public static final String CHILD = "Child";

}
