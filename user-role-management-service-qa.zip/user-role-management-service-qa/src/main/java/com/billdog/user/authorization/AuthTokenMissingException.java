package com.billdog.user.authorization;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.billdog.user.exception.UnauthorizedException;

@SuppressWarnings("serial")
@ResponseStatus(HttpStatus.BAD_GATEWAY)
public class AuthTokenMissingException extends UnauthorizedException {

	public AuthTokenMissingException(String errMsg) {
		super(errMsg);
	}
	
	public AuthTokenMissingException(String message, Throwable cause) {
        super(message, cause);
    }
}

