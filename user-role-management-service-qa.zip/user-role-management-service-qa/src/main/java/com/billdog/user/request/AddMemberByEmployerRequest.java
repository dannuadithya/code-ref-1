package com.billdog.user.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class AddMemberByEmployerRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter first name")
	@Size(min = 2, message = "First name should contains minimum 2 characters")
	@Size(max = 30, message = "First name should not exceed 30 characters")
	private String firstName;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter last name")
	@Size(min = 2, message = "Last name should contains minimum 2 characters")
	@Size(max = 30, message = "Last name should not exceed 30 characters")
	private String lastName;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@Size(min = 10, max = 10, message = "Contact Number must be 10 digits")
	@Pattern(regexp = "^(0|[1-9][0-9]*)$", message = "Invalid contact number")
	private String contactNumber;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotBlank(message = "Please enter Email")
	@Email(message = "Invalid email format")
	private String email;

	@NotNull(message = "Product id must not be null")
	private Long productId;

	@NotNull(message = "User id must not be null")
	private Long userId;

	@NotNull(message = "Please provide Employer id must not be null")
	private Long employerId;

	private long countryCodeId;

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotNull(message = "Please provide opportunity type")
	private String opportunityType;
	
	@JsonIgnore
	private long memberId;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public Long getCountryCodeId() {
		return countryCodeId;
	}

	public void setCountryCodeId(Long countryCodeId) {
		this.countryCodeId = countryCodeId;
	}

}


