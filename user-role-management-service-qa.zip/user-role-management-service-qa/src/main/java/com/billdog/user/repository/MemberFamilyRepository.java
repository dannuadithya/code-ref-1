package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberFamily;

@Repository
public interface MemberFamilyRepository extends JpaRepository<MemberFamily, Long> {

	List<MemberFamily> findByMemberId(Member member);

	List<MemberFamily> findByMemberIdAndStatus(Member member, String active);

	Optional<MemberFamily> findByIdAndMemberId(Long familyMemberId, Member member);

	List<MemberFamily> findByMemberIdAndStatusAndIsDeleted(Member member, String active, boolean b);

	List<MemberFamily> findByMemberIdAndIsDeleted(Member member, boolean b);

	@Query(value = "select id, revtype,updated_at, user_id, date_of_birth, first_name,is_deleted,last_name,middle_name,status,relationship_master_id from billdog_user.member_family_aud order by updated_at desc", countQuery = "select id, revtype,updated_at, user_id, date_of_birth, first_name,is_deleted,last_name,middle_name,status,relationship_master_id from billdog_user.member_family_aud order by updated_at desc", nativeQuery = true)
	Page<Object[]> getMemberFamilyInfo(PageRequest pageRequest);

	@Query(value = "select id, revtype,updated_at, user_id, date_of_birth, first_name,is_deleted,last_name,middle_name,status,relationship_master_id from billdog_user.member_family_aud where id =?1 and updated_at<?2 limit 1 ", countQuery = "select id, revtype,updated_at, user_id, date_of_birth, first_name,is_deleted,last_name,middle_name,status,relationship_master_id from billdog_user.member_family_aud where id =?1 and updated_at<?2 limit 1 ", nativeQuery = true)
	List<Object[]> getMemberFamilyInfoById(long longValue, String string);

	@Query(value = "select mf.id,mf.revtype,mf.updated_at,mf.user_id,mf.date_of_birth,mf.first_name,mf.is_deleted,mf.last_name,\n"
			+ "mf.middle_name,mf.status,mf.relationship_master_id,mf.rev,concat(su.first_name ,' ',su.last_name) as userName,rm.relationship_name,concat(m.first_name ,' ',m.last_name) as memberName, npm.prefix\n"
			+ "from billdog_user.member_family_aud mf\n" + "left join system_users su on su.id = mf.user_id\n"
			+ "left join relationship_master rm on rm.id = mf.relationship_master_id\n"
			+ "left join member_family mff on mff.id = mf.id\n"
			+ "left join member m on m.id = mff.member_id left join name_prefix_master npm on npm.id = mf.name_prefix_master\n"
			+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN mf.first_name ELSE '' END LIKE COALESCE(?2,'') or\n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN mf.last_name ELSE '' END LIKE COALESCE(?4,'')) \n"
			+ "and date(mf.updated_at) BETWEEN ?5 AND ?6 and mf.revtype in ?7 and m.organization_id = ?8\n"
			+ "order by mf.rev desc,mf.updated_at desc", countQuery = "select mf.id,mf.revtype,mf.updated_at,mf.user_id,mf.date_of_birth,mf.first_name,mf.is_deleted,mf.last_name,\n"
					+ "mf.middle_name,mf.status,mf.relationship_master_id,mf.rev,concat(su.first_name ,' ',su.last_name) as userName,rm.relationship_name,concat(m.first_name ,' ',m.last_name) as memberName, npm.prefix\n"
					+ "from billdog_user.member_family_aud mf\n" + "left join system_users su on su.id = mf.user_id\n"
					+ "left join relationship_master rm on rm.id = mf.relationship_master_id\n"
					+ "left join member_family mff on mff.id = mf.id\n"
					+ "left join member m on m.id = mff.member_id left join name_prefix_master npm on npm.id = mf.name_prefix_master\n"
					+ "where (CASE WHEN COALESCE(?1,'') <> '' THEN mf.first_name ELSE '' END LIKE COALESCE(?2,'') or\n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN mf.last_name ELSE '' END LIKE COALESCE(?4,'')) \n"
					+ "and date(mf.updated_at) BETWEEN ?5 AND ?6 and mf.revtype in ?7 and m.organization_id = ?8\n"
					+ "order by mf.rev desc,mf.updated_at desc", nativeQuery = true)
	Page<Object[]> getMemberFamilyAuditInfo(String name, String name2, String name3, String name4, String startDate,
			String endDate, List<Long> revtypes, long organizationId, PageRequest pageRequest);

	@Query(value = "select mf.id,mf.revtype,mf.updated_at,mf.user_id,mf.date_of_birth,mf.first_name,mf.is_deleted,mf.last_name,\n"
			+ "mf.middle_name,mf.status,mf.relationship_master_id,mf.rev,concat(su.first_name ,' ',su.last_name) as userName,rm.relationship_name,concat(m.first_name ,' ',m.last_name) as memberName, npm.prefix\n"
			+ "from billdog_user.member_family_aud mf\n" + "left join system_users su on su.id = mf.user_id\n"
			+ "left join relationship_master rm on rm.id = mf.relationship_master_id left join member m on m.id = mf.member_id left join name_prefix_master npm on npm.id = mf.name_prefix_master\n"
			+ "where mf.id =?1 and mf.rev<?2 order by mf.rev desc limit 1", countQuery = "select mf.id,mf.revtype,mf.updated_at,mf.user_id,mf.date_of_birth,mf.first_name,mf.is_deleted,mf.last_name,\n"
					+ "mf.middle_name,mf.status,mf.relationship_master_id,mf.rev,concat(su.first_name ,' ',su.last_name) as userName,rm.relationship_name,concat(m.first_name ,' ',m.last_name) as memberName, npm.prefix\n"
					+ "from billdog_user.member_family_aud mf\n" + "left join system_users su on su.id = mf.user_id\n"
					+ "left join relationship_master rm on rm.id = mf.relationship_master_id left join member m on m.id = mf.member_id left join name_prefix_master npm on npm.id = mf.name_prefix_master\n"
					+ "where mf.id =?1 and mf.rev<?2 order by mf.rev desc limit 1", nativeQuery = true)
	List<Object[]> getMemberAuditInfoByIdAndRev(long longValue, long longValue2);

	@Query(value = "select mf.id,mf.revtype,mf.updated_at,mf.user_id,mf.date_of_birth,mf.first_name,mf.is_deleted,mf.last_name,\n"
			+ "mf.middle_name,mf.status,mf.relationship_master_id,mf.rev,concat(su.first_name ,' ',su.last_name) as userName,rm.relationship_name,concat(m.first_name ,' ',m.last_name) as memberName, npm.prefix\n"
			+ "from billdog_user.member_family_aud mf\n" + "left join system_users su on su.id = mf.user_id\n"
			+ "left join relationship_master rm on rm.id = mf.relationship_master_id left join member m on m.id = mf.member_id left join name_prefix_master npm on npm.id = mf.name_prefix_master\n"
			+ "where mf.id=?1 order by mf.rev desc", countQuery = "select mf.id,mf.revtype,mf.updated_at,mf.user_id,mf.date_of_birth,mf.first_name,mf.is_deleted,mf.last_name,\n"
					+ "mf.middle_name,mf.status,mf.relationship_master_id,mf.rev,concat(su.first_name ,' ',su.last_name) as userName,rm.relationship_name,concat(m.first_name ,' ',m.last_name) as memberName, npm.prefix\n"
					+ "from billdog_user.member_family_aud mf\n" + "left join system_users su on su.id = mf.user_id\n"
					+ "left join relationship_master rm on rm.id = mf.relationship_master_id left join member m on m.id = mf.member_id left join name_prefix_master npm on npm.id = mf.name_prefix_master\n"
					+ "where mf.id=?1 order by mf.rev desc", nativeQuery = true)
	Page<Object[]> getMemberFamilyAuditInfoById(Long id, PageRequest pageRequest);
}
