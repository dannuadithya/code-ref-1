package com.billdog.user.common;

public class ExceptionalMessages {

	public static final String USER_NOT_FOUND = "User not found";
	public static final String USER_NOT_FOUND_WITH_EMAIL = "User not found";
	public static final String ROLE_NOT_FOUND = "Role not found";

	public static final String THIS_USER_DOES_NOT_BELONG_TO_SAME_ORGANIZATION = "This user does not belong to same organization";

	public static final String PLEASE_ENTER_VALID_EMAIL = "Please enter valid email";
	public static final String VALID_EMAIL = "Please provide valid email";

	public static final String PLEASE_ENTER_VALID_PASSCODE = "The passcode you entered is invalid. Please try again.";

	public static final String EMAIL_NOT_FOUND = "Email not found";

	public static final String ENTER_VALID_MOBILE_NUMBER = "Please enter valid mobile number";

	public static final String EMAIL_ALREADY_EXITS_IN_ORGANIZATION = "Email already exits in this organization";
	public static final String EMAIL_ALREADY_EXITS = "Email already exits";

	public static final String USERS_NOT_FOUND = "User not found";

	public static final String EMAIL_DOES_NOT_EXITS = "Email does not exits";

	public static final String ROLE_SCREEN_MAPPING = "Role screen mapping not found";

	public static final String INCORRECT_PASSWORD = "Incorrect password. please try again or you can reset your password.";

	public static final String INCORRECT_USERNAME_PASSWORD = "The Username and Password don’t match our records, please check them and try logging in again.";

	public static final String USER_NOT_FOUND_IN_ORGANISATION = "User not found in this organization";

	public static final String PASSCODE_EMAIL_LIMIT_EXCEEDED = "You have exceeded the maximum allowed Resend Passcode. Please try again tomorrow";
	public static final String PASSCODE_TIME_EXPIRED = "Passcode Entered is Expired. Please click on Resend Passcode and try Again.";
	public static final String INCORRECT_PASSCODE = "<Times> incorrect passcode entries. Resend Passcode will be disabled after <Limit> incorrect Entries";

	public static final String ROLE_ALREADY_EXISTS = "Role already exists";

	public static final String CREATE_ROLE_PERMISSIONS = "You don't have permissions create new role";

	// update role previleges exceptions
	public static final String OWN_PREVILEGES = "You don't have permissions to update <ROLE> role privileges";
	public static final String SUPER_ADMIN_CAN_NOT_UPDATE_EXCEPT_SYSTEM_ADMIN = "Super Admin can't update <ROLE> role previleges except System Admin privileges";
	public static final String SYSTEM_ADMIN_CAN_NOT_UPDATE_PRIVILEGES = "Syetem Admin can't update <ROLE> role privileges";
	public static final String YOU_CAN_NOT_UPDATE_PRIVILEGES = "<ROLE> user don't have permissions to update privileges";

	public static final String OWN_PREVILEGES_ACCESS = "You can not access <ROLE> role privileges";
	public static final String UNABLE_SEND_WELCOME_MAIL = "Unable send welcome mail";

	public static final String DON_NOT_HAVE_PREVILEGES_ACCESS = "You don't have permissions, please contact your Administrator";
	public static final String DON_NOT_HAVE_ACCESS = "You don't have access, please contact your Administrator";
	public static final String MEMBER_NOT_FOUND = "Member not found";
	public static final String ORGANIZATION_NOT_FOUND_BY_URL = "Something went wrong. Please try again";

	public static final String SOMETHING_WENT_WRONG = "Something went wrong. Please try again";
	public static final String MEMBER_NOT_FOUND_WITH_EMAIL = "Member already present in this organization";
	public static final String INVALID_PASSWORD = "Password must be <Min>-<Max> characters and contain an uppercase, lowercase, number and special character";

	// member exceptional messages
	public static final String MEMBER_NOT_FORUND_WITH_ID = "Member not found";
	public static final String ACCOUNT_WITH_EMAIL_NOT_EXISTS = "Account with this email not exists. Please sign-up.";
	public static final String MEMBER_PRIMARY_EMAIL_NOT_FOUND = "Your primary email not found";
	public static final String NOT_PRIMARY_EMAIL = "Your email is not primary, please try to login with your primary email";
	public static final String ORGANIZATION_NOT_FOUND = "Something went wrong. Please try again";
	public static final String MEMBER_PREFIX_MASTER_NOT_FOUND = "Member prefix master not found";
	public static final String COUNTRY_CODE_NOT_FOUND = "Country code not found";
	public static final String ZIP_CODE = "zipcode should be 5 digits";
	public static final String MOBILE = "Mobile number should be 10 digits";
	public static final String MOBILE_NUMBER_SHOULD_BE_NUMBERS = "Mobile numbers should not contain alphabets";
	public static final String ZIP_CODE_SHOULD_BE_NUMBERS = "ZipCode should not contains alphabets";
	public static final String EMAIL_NOT_FOUND_ORGANIZATION = "Email not found in this organization";
	public static final String VERIFY_EMAIL = "Please verify your email";
	public static final String COUNTRY_NOT_FOUND = "No country found";
	public static final String STATE_NOT_FOUND = "No state found";
	public static final String NO_DIRECT_MEMBER = "No Direct member type is not found in master table";
	public static final String RELATIONSHIP_NOT_FORUND_WITH_ID = "Relationship not found";
	public static final String FAMILY_MEMBER_NOT_FORUND_WITH_ID = "Family Member details not found";
	public static final String EMAIL_EXITS = "This email already exists. Please try logging in";
	public static final String MIDDLE_NAME = "Middle name should be 2 Characters Minimum, 20 Characters maximum";
	public static final String MIDDLE_NAME_CHARACTERS = "Middle name should contains only characters";
	public static final String ADDRESS_CHARACTERS = "Address can be maximum 125 characters";
	public static final String STREET_CHARACTERS = "Street can be maximum 125 characters";
	public static final String CITY_CHARACTERS = "City can be maximum 125 characters";
	public static final String FIRST_NAME = "Your first name must contains 2-30 characters";
	public static final String LAST_NAME = "Your last name must contains 2-30 characters";
	public static final String FIRST_NAME_LIMIT = "First name must contains 2-30 characters";
	public static final String LAST_NAME_LIMIT = "Last name must contains 2-30 characters";
	public static final String PLEASE_PROVIDE_COUNTRY_CODE = "Please provide valid country phone code";
	public static final String FAMILY_MEMBER_FIRST_NAME = "Your last name must contains 2-20 characters";
	public static final String FAMILY_MEMBER_LAST_NAME = "Your first name must contains 2-20 characters";
	public static final String FIRST_NAME_NOT_NULL = "First Name should not be null";
	public static final String LAST_NAME_NOT_NULL = "Last Name should not be null";
	public static final String RELATIONSHIP = "Please update the relationship for your family member.";
	public static final String PREFIX = "Prefix should not be null";
	public static final String DOB = "Date of birth should not be null";
	public static final String INSURANCE_TYPE_NOT_FOUND = "Insurance type not found";
	public static final String INSURANCE_SUB_TYPE_NOT_FOUND = "Insurance sub type not found";
	public static final String MEMBER_CARRIER_NOT_FOUND = "Member carrier not found";
	public static final String GROUP_ID_NOT_NULL = "Group Id should not be not";
	public static final String PRODUCTNAME_NOT_NULL = "Product name should not be null";
	public static final String PROVIDER_NOT_NULL = "Provider contact number should not be null";
	public static final String CUSTOMER_SERVICE_ID_NOT_NULL = "Customer service contact number should not be null";
	public static final String PROVIDER_CONTACT_NUMBER = "Provider Contact number must contain 10 digits";
	public static final String PROVIDER_CONTACT_NUMBER_DIGITS = "Provider contact number should contains only digits";
	public static final String PROVIDER_CONTACT_NUMER_MESSAGE = "Please enter valid mobile number for provider contact number";
	public static final String CUSTOMER_SERVICE_CONTACT_NUMBER = "Contact number must contain 10 digits";
	public static final String CUSTOMER_SERVICE_CONTACT_DIGITS = "Customer service number should contain only digits";
	public static final String INSURANCE_DETAILS = "You can add maximun of two insurance details";
	public static final String FAMILY_DETAILS = "You can add maximun of seven family details";
	// email service exceptions
	public static final String EMAIL_SERVICE_BAD_REQUEST = "Please provide valid inputs to send email";
	public static final String EMAIL_SERVICE_NOT_FOUND = "Send email url not found";
	public static final String UNABLE_SEND_PASSCODE = "We are unable to send passcode to mail !!";
	public static final String EMAIL_SERVICE_GATEWAY_TIMEOUT = "Email service gateway timeout, please try after sometime !!";
	public static final String EMAIL_SERVICE_UNAVAILABLE = "Email service unavailable, please try after sometime !!";
	public static final String MOBILE_SHOULD_BE_NUMBERS = "Invalid mobile number";
	public static final String MOBILE_NUMER = "Mobile number should contains 10 digits";
	public static final String UNABLE_SEND_WELCOME_EMAIL = "Unable to send welcome email to member";
	public static final String LAST_NAME_CHARACTERS = "Last name should be characters";

	public static final String FIRST_NAME_WEB = "Last name must contains 2-20 characters";
	public static final String LAST_NAME_WEB = "First name must contains 2-20 characters";
	public static final String FIRST_NAME_CHARACTERS = "First name should be characters";
	public static final String PRODUCT_NAME = "Please change product type to Married / Family for adding family members";
	public static final String PRODUCT_TYPE = "Please change product type to adding family members";
	public static final String UNABLE_SEND_UPDATED_EMAIL = "Unable to send updated email to member";
	public static final String PRMARY_EMAIL_ALREADY_EXITS = "Primary email already exits in this organization";
	public static final String SECOUNDARY_EMAIL_ALREADY_EXITS = "Secoundary email already exits in this organization";

	public static final String INVALID_TOKEN = "INVALID TOKEN";
	public static final String TOKEN_EXPIRED = "TOKEN EXPIRED";
	// public static final String SESSION_EXPIRED = "Session Expired. Please Login";

	public static final String AUTH_TOKEN_MISSING = "AUTH TOKEN MISSING";
	public static final String USER_EMAIL_ALREADY_EXITS = "Email already exits in this organization";

	public static final String CASE_SERVICE_UNAVAILABLE = "Case service unavailable, please try after sometime!!";
	public static final String CASE_SERVICE_ISSUE = "Facing issue with Case service, please try after sometime!!";
	public static final String CASE_SERVICE_BAD_REQUEST = "Please provide valid inputs to case service!!";
	public static final String CASE_SERVICE_NOT_FOUND = "Case service url not found!!";
	public static final String EMAIL_ALREADY_EXITS_PRIMARY = "Email already exits as primary email in this organization";
	public static final String EMAIL_ALREADY_EXITS_SECONDARY = "Email already exits as secondary email in this organization";
	public static final String MEMBER_ADDRESS_NOT_FOUND = "Address info not found";
	public static final String INSURANCE_DETAILS_NOT_FOUND = "Insurance Details not found";
	public static final String GROUP_ID = "Group Id should not exceed 20 characters";
	public static final String PRODUCT_NAME_LIMIT = "Product Name should not exceed 30 characters";

	public static final String YOU_DONT_HAVE_ACCESS_PLEASE_CONTACT_SUPPORT_TEAM = "You dont have access. Please contact support team.";
	public static final String ENTITY_SERVICE_UNAVAILABLE = "Entity service unavailable, please try after sometime!!";
	public static final String ENTITY_SERVICE_ISSUE = "Facing issue with Entity service, please try after sometime!!";
	public static final String ENTITY_SERVICE_BAD_REQUEST = "Please provide valid inputs to entity service!!";
	public static final String ENTITY_SERVICE_NOT_FOUND = "Entity service url not found!!";
	public static final String INVALID_PASSCODE = "Please enter valid passcode";
	public static final String COUNTRY_CODE = "Country code not found";
	public static final String MEMBER_CONFIRM_PASSWORD = "Create & Confirm password’s do not match";
	public static final String SAME_OLD_NEW_PASSWORD = "Old Password and new password cannot be same";
	public static final String INCORRECT_OLD_PASSWORD = "Old password is incorrect";
	public static final String DATE_FORMAT = "Please provide date in MM-DD-YYYY format.";
	public static final String LOCKED = "Your account is locked.Please try again after 24hrs.";
	public static final String UPGRADE_YOUR_PRODUCT_TYPE_TO_FAMILY = "Your current product type is Married. Please upgrade your product type to Family to add Child";
	public static final String SPOUSE = "You are not allowed to add more than 1 spouse";
	public static final String PRODUCT_NOT_FOUND = "Please select a product to complete your profile";
	public static final String USER_CONFIRM_PASSWORD = "Create & Confirm password’s do not match";
	public static final String WEB_LOCKED = "You account has been locked. Please contact <Email>";
	public static final String PRODUCT_NAME_VALIDATION = "Product name should not contain special characters";
	public static final String GROUP_ID_VALIDATION = "Group Id should not contain special characters";
	public static final String MEMBER_INSURANCE_VALIDATION = "Member insurance Id should not contain special characters";
	public static final String YOU_DONT_HAVE_ACCESS = "you don't have access";
	public static final String ENTER_VALID_DOMAINS = "Please enter email from any one of these domains only <domain names>";
	public static final String PRODUCT_INVALID = "Please provide valid product type";
	public static final String MEMBER_ACCOUNT_DISABLED = "Your account has <Status>. Please contact <Organisation mail>";
	public static final String USER_ACCOUNT_DISABLED = "Your account is <Status>. Please contact <Organisation email>";
	public static final String USER_ROLE_UPDATED = "Your role has updated. Please login";
	public static final String ROLE_PRIVILEGE_UPDATED = "Your privilege's has been updated. Please login";
	public static final String INTERNAL_USER_ACCESS = "You are an internal user, please check your domain url";
	public static final String EMPLOYER_NOT_FOUND = "Employer not found";

	public static final String CONTACT_NUMBER = "Contact number should be numbers";
	public static final String CONTACT_NUMBER_RESTRICTION = "Invalid contact number";

	public static final String UNABLE_TO_CLOSE_FILE = "Unable to close file";
	public static final String FILE_CANNOT_BE_NULL = "File can not be null";
	public static final String UNABLE_TO_READ = "Unable to read file";
	public static final String FILE_CANNOT_BE_EMPTY = "File can not be empty!!";

	public static final String SESSION_EXPIRED = "Please log in again.";
	public static final String OPPORTUNITY_TYPE_NOT_FOUND = "Member opportunity type not found";

	public static final String FILE_COLUMNS = "Column Names should be case sensitive, Please use First Name, Last Name, Email,Contact Number and Product Type as column names and retry again";
	public static final String PLEASE_PROVIDE_MODULE = "Please provide module";
	public static final String MODULE_NOT_FOUND = "Module not found";
	public static final String SUB_MODULE = "Please provide sub module name";
	public static final String USER_SESSION_EXPIRED = "Session Expired, please login again.";
	public static final String PASSWORD_MATCHED = "This is your Old Password. Please enter a New Password";
	public static final String EMAIL_NOT_FOUND_INDIVIDUAL = "No Individual broker found with the given email ID";
	public static final String USER_INVALID_PASSWORD = "Password between <Min> to <Max> characters contains a combination of 1 uppercase, 1 lowercase, 1 Special Character and 1 number";


}
