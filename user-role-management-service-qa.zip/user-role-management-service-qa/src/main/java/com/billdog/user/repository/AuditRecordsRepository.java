package com.billdog.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.AuditRecords;

@Repository
public interface AuditRecordsRepository extends JpaRepository<AuditRecords, Long> {

	@Query(value = "SELECT coalesce(id,0) FROM audit_records order by id desc limit 1", nativeQuery = true)
	Long getAuditId();

	AuditRecords findByAuditId(String auditId);

}