package com.billdog.user.service;

import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.authentication.AesEncryption;
import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.Organization;
import com.billdog.user.exception.EmailLimitExceededException;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.request.PasscodeEmailMemberRequest;
import com.billdog.user.request.UpdatePrimaryEmailRequest;
import com.billdog.user.view.VerifyEmailResponse;
import com.billdog.user.view.ViewResponse;

@Service
public class UpdatePrimaryEmailService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(LoginService.class);

	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Autowired
	CreateMemberDetails createMemberDetails;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	MemberTypeMasterRepository memberTypeMasterRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Value("${passcode.email.times}")
	private int passcodeTimes;

	@Value("${passcode.length}")
	private int passcodeLength;

	@Autowired
	CreateUserService createUserService;

	@Autowired
	EmailService emailService;

	@Autowired
	GetProfileDetails getProfileDetails;

	@Autowired
	AesEncryption aesEncryption;

	public ResponseEntity<VerifyEmailResponse> updateMemberEmail(UpdatePrimaryEmailRequest updatePrimaryEmailRequest) {
		LOGGER.info("updateMemberEmail method started..!");

		Optional<Member> member = memberRepository.findById(updatePrimaryEmailRequest.getMemberId());
		if (!member.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}

		Optional<MemberEmail> memberEmailentityOptional = memberEmailRepository
				.findByMemberIdAndPrimaryAndDeletedAndVerified(member.get(), true, false, true);
		if (!memberEmailentityOptional.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}

		Optional<MemberEmail> memberEmailentity = memberEmailRepository
				.findByEmailAndOrganizationIdAndDeletedAndPrimaryAndVerified(updatePrimaryEmailRequest.getEmail(),
						memberEmailentityOptional.get().getOrganizationId(), false, true, true);
		if (memberEmailentity.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS_PRIMARY);
		}

//		Optional<MemberEmail> memberEmailentity1 = memberEmailRepository
//				.findByEmailAndOrganizationIdAndDeletedAndSecondary(updatePrimaryEmailRequest.getEmail(),
//						memberEmailentityOptional.get().getOrganizationId(), false, true);
//		if (memberEmailentity1.isPresent()) {
//			throw new MemberNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS_SECONDARY);
//		}

		Optional<MemberEmail> memberEmailEntity = memberEmailRepository
				.findByEmailAndOrganizationIdAndDeletedAndPrimaryAndVerifiedAndMemberId(
						updatePrimaryEmailRequest.getEmail(), member.get().getOrganizationId(), false, false, false,
						member.get());
		if (memberEmailEntity.isPresent()) {
			sendPasscode(updatePrimaryEmailRequest, EmailTitles.MEMBER_PASSCODE, memberEmailentityOptional,
					memberEmailentityOptional.get().getOrganizationId(), member.get(), memberEmailEntity);
		}
		if (!memberEmailEntity.isPresent()) {
			sendPasscode(updatePrimaryEmailRequest, EmailTitles.MEMBER_PASSCODE, memberEmailentityOptional,
					memberEmailentityOptional.get().getOrganizationId(), member.get(), memberEmailEntity);
		}

		// providing successful responseverifyEmailResponse if user data is stores
		VerifyEmailResponse verifyEmailResponse = new VerifyEmailResponse();
		verifyEmailResponse.setStatusText(Constants.SUCCESS);
		verifyEmailResponse.setMessage(Constants.PASSCODE_SENT);
		verifyEmailResponse.setMemberId(updatePrimaryEmailRequest.getMemberId());
		LOGGER.info("updateMemberEmail method ends..!");
		return ResponseEntity.status(HttpStatus.OK).body(verifyEmailResponse);

	}

	public ViewResponse sendPasscode(UpdatePrimaryEmailRequest updatePrimaryEmailRequest, EmailTitles emailTitle,
			Optional<MemberEmail> memberEmail, Organization organization, Member member,
			Optional<MemberEmail> memberEmailEntity) {
		LOGGER.info("Send passcode method started..!");
		LOGGER.info("Checking email passcode limit to email new passcode to member");
		if (memberEmail.isPresent() && memberEmail.get().getEmailCount() != null
				&& memberEmail.get().getEmailCount() >= passcodeTimes
				&& createUserService.checkDate(memberEmail.get().getMailSent().toLocalDate())) {
			String message = ExceptionalMessages.PASSCODE_EMAIL_LIMIT_EXCEEDED.replace("{times}", "" + passcodeTimes);
			throw new EmailLimitExceededException(message);
		}
		String passcode = createUserService.generatePasscode(passcodeLength);
		LOGGER.debug("Generated new passcode for login purpose");
		savePasscode(updatePrimaryEmailRequest, passcode, organization, member, memberEmailEntity);
		LOGGER.info("Creting passcode email member request object for calling email service");
		PasscodeEmailMemberRequest passcodeEmailMemberRequest = new PasscodeEmailMemberRequest();
		passcodeEmailMemberRequest.setEmail(updatePrimaryEmailRequest.getEmail());
		passcodeEmailMemberRequest.setPasscode(passcode);
		passcodeEmailMemberRequest.setEmailTitle(emailTitle);
		passcodeEmailMemberRequest.setFirstName(member.getFirstName());
		passcodeEmailMemberRequest.setOrgId(member.getOrganizationId().getId());
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send passcode email");
			viewResponse = emailService.sendEamilToMember(passcodeEmailMemberRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: ", exception.getCause());
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send passcode email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.SENT_PASSCODE);
		} else {
			throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
		}

		return viewResponse;
	}

	/*
	 * this method used to save member new passcode
	 */
	private void savePasscode(UpdatePrimaryEmailRequest updatePrimaryEmailRequest, String passcode,
			Organization orOptional, Member member, Optional<MemberEmail> memberEmailEntity) {
		String encryptedPassword = aesEncryption.encrypt(passcode);
		LOGGER.info("savePasscode method started");
		LOGGER.info("Saving new email");
		if (memberEmailEntity.isPresent()) {
			memberEmailEntity.get().setUpdatedAt(DateAndTimeUtil.now());
			memberEmailEntity.get().setPasscode(encryptedPassword);
			memberEmailRepository.save(memberEmailEntity.get());
		} else {
			MemberEmail memberEmail = new MemberEmail();
			memberEmail.setCreatedAt(DateAndTimeUtil.now());
			memberEmail.setUpdatedAt(DateAndTimeUtil.now());
			memberEmail.setEmail(updatePrimaryEmailRequest.getEmail());
			memberEmail.setEmailCount((long) 0);
			memberEmail.setPasscode(encryptedPassword);
			memberEmail.setPrimary(false);
			memberEmail.setMemberId(member);
			memberEmail.setOrganizationId(member.getOrganizationId());
			memberEmail.setDeleted(false);
			memberEmail.setVerified(false);
			memberEmailRepository.save(memberEmail);
		}

		LOGGER.info("savePasscode method ended");
	}

}
