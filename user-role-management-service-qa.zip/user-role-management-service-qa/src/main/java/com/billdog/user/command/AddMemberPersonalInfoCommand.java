package com.billdog.user.command;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.request.AddMemberPersonalInfoRequest;
import com.billdog.user.service.AddMember;
import com.billdog.user.view.ViewResponse;

@Service
public class AddMemberPersonalInfoCommand
		implements Command<AddMemberPersonalInfoRequest, ResponseEntity<ViewResponse>> {

	@Autowired
	AddMember addMember;

	@Override
	public ResponseEntity<ViewResponse> excute(AddMemberPersonalInfoRequest addMemberRequest) {

		if (StringUtils.isNumeric(addMemberRequest.getMiddleName())) {
			throw new InValidInputException(ExceptionalMessages.MIDDLE_NAME_CHARACTERS);
		}
		if (addMemberRequest.getMiddleName() != null && !addMemberRequest.getMiddleName().isEmpty()) {
			if (addMemberRequest.getMiddleName().length() < 2 || addMemberRequest.getMiddleName().length() > 20) {
				throw new InValidInputException(ExceptionalMessages.MIDDLE_NAME);
			}

		}

		if (addMemberRequest.getStreet() != null && !addMemberRequest.getStreet().isEmpty()
				&& addMemberRequest.getStreet().length() > 125) {
			throw new InValidInputException(ExceptionalMessages.STREET_CHARACTERS);
		}

		if (addMemberRequest.getCityName() != null && !addMemberRequest.getCityName().isEmpty()
				&& addMemberRequest.getCityName().length() > 125) {
			throw new InValidInputException(ExceptionalMessages.CITY_CHARACTERS);
		}

		if (addMemberRequest.getZipCode() != null && !addMemberRequest.getZipCode().isEmpty()
				&& !StringUtils.isNumeric(addMemberRequest.getZipCode())) {
			throw new InValidInputException(ExceptionalMessages.ZIP_CODE_SHOULD_BE_NUMBERS);
		}
		if (addMemberRequest.getZipCode() != null && addMemberRequest.getZipCode().length() != 5
				&& !addMemberRequest.getZipCode().isEmpty()) {
			throw new InValidInputException(ExceptionalMessages.ZIP_CODE);
		}

		if (addMemberRequest.getAddressLine1() != null && !addMemberRequest.getAddressLine1().isEmpty()
				&& addMemberRequest.getAddressLine1().length() > 125) {
			throw new InValidInputException(ExceptionalMessages.ADDRESS_CHARACTERS);
		}
		if (addMemberRequest.getAddressLine2() != null && !addMemberRequest.getAddressLine2().isEmpty()
				&& addMemberRequest.getAddressLine2().length() > 125) {
			throw new InValidInputException(ExceptionalMessages.ADDRESS_CHARACTERS);
		}

		return ResponseEntity.status(HttpStatus.OK).body(addMember.addNewMemberPersonalInfo(addMemberRequest));

	}
}