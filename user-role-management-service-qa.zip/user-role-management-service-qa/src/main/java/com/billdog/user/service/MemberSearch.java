package com.billdog.user.service;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.request.MemberCaseCountRequest;
import com.billdog.user.request.MemberSearchRequest;
import com.billdog.user.view.GetMemberCaseCount;
import com.billdog.user.view.MemberCaseCount;
import com.billdog.user.view.ViewMemberDetails;
import com.billdog.user.view.ViewResponse;

@Service
public class MemberSearch {

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	CaseService caseService;

	@Autowired
	LoginService loginService;

	private static final Logger LOGGER = LoggerFactory.getLogger(MemberSearch.class);

	public ResponseEntity<ViewResponse> searchMembers(MemberSearchRequest memberSearchRequest) {
		LOGGER.info("search member details method started..!");

		String memberFirstName = null;
		String memberLastName = null;
		String mobileNumber = null;
		String email = null;
		String sfdcId = null;
		String status = memberSearchRequest.getStatus();
		String memberId = memberSearchRequest.getMemberId();
		if (memberSearchRequest.getName() != null && !memberSearchRequest.getName().equals("")) {
			memberFirstName = "%" + memberSearchRequest.getName() + "%";
		} else {
			memberFirstName = memberSearchRequest.getName();
		}

		if (memberSearchRequest.getName() != null && !memberSearchRequest.getName().equals("")) {
			memberLastName = "%" + memberSearchRequest.getName() + "%";
		} else {
			memberLastName = memberSearchRequest.getName();
		}

		if (memberSearchRequest.getEmailId() != null && !memberSearchRequest.getEmailId().equals("")) {
			email = "%" + memberSearchRequest.getEmailId() + "%";
		} else {
			email = memberSearchRequest.getEmailId();
		}

		if (memberSearchRequest.getMobileNumber() != null && !memberSearchRequest.getMobileNumber().equals("")) {
			mobileNumber = "%" + memberSearchRequest.getMobileNumber() + "%";
		} else {
			mobileNumber = memberSearchRequest.getMobileNumber();
		}

		if (memberSearchRequest.getSfdcId() != null && !memberSearchRequest.getSfdcId().equals("")) {
			sfdcId = "%" + memberSearchRequest.getSfdcId() + "%";
		} else {
			sfdcId = memberSearchRequest.getSfdcId();
		}

		Long opportunity = memberSearchRequest.getOpportunity();
		if (opportunity == 0) {
			opportunity = -999l;
		}
		SystemUsers systemUsers = loginService.getSystemUsers(memberSearchRequest.getUserId());
		Integer pageNumber = memberSearchRequest.getPageNumber() > 0 ? memberSearchRequest.getPageNumber() : 0;
		Integer pageLimit = memberSearchRequest.getPageLimit() > 0 ? memberSearchRequest.getPageLimit() : 10;
		// native query for searching users and assigning parameters respectively
		Page<Object[][]> memberDetails = memberRepository.getMemberDetails(memberFirstName, memberFirstName,
				memberLastName, memberLastName, mobileNumber, mobileNumber, email, email, status, status, sfdcId,
				sfdcId, memberId, memberId, opportunity, opportunity, getPageRequest(pageNumber, pageLimit));

		// for loop for users searched with native query and assigning values
		// respectively
		List<ViewMemberDetails> viewMemberDetailsList = getMemberList(memberDetails,
				getMemberCaseCount(systemUsers.getOrganizationId().getId(), memberDetails));
		LOGGER.debug("Setting member details for new member object");

		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.USER_DETAILS_FETCHED);
		if (viewMemberDetailsList.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(viewMemberDetailsList);
		response.setTotal(memberDetails.getTotalElements());

		LOGGER.info("search member details method end..!");
		return ResponseEntity.status(HttpStatus.OK).body(response);

	}

	private List<ViewMemberDetails> getMemberList(Page<Object[][]> memberDetails,
			List<MemberCaseCount> memberCaseCount) {
		List<ViewMemberDetails> viewMemberDetailsList = new ArrayList<>();
		for (Object[] objects : memberDetails) {
			ViewMemberDetails viewMemberDetails = new ViewMemberDetails();
			viewMemberDetails.setFirstName(((String) objects[0]));
			viewMemberDetails.setLastName(((String) objects[1]));
			viewMemberDetails.setSfdcId((String) objects[2]);
			viewMemberDetails.setMobileNumber((String) objects[3]);
			viewMemberDetails.setStatus((String) objects[4]);
			viewMemberDetails.setEmail((String) objects[5]);
			viewMemberDetails.setId(((BigInteger) objects[6]).longValue());
			viewMemberDetails.setMemberId((String) objects[7]);
			viewMemberDetails.setMemberOpportunityType((String) objects[13]);
			viewMemberDetails.setMemberOpportunityTypeId(((BigInteger) objects[14]).longValue());
			viewMemberDetails.setProduct((String) objects[8]);
			if ((BigInteger) objects[6] != null) {
				MemberCaseCount caseCount = getCaseCount(((BigInteger) objects[6]).longValue(), memberCaseCount);
				if (caseCount != null) {
					viewMemberDetails.setOpenCases(caseCount.getCaseCount());
				}
			}
			Timestamp passcodeVerifiedDate = (Timestamp) objects[10];
			Timestamp passwordVerifiedDate = (Timestamp) objects[11];

			if ((Boolean) objects[12] == true) {
				viewMemberDetails.setLockStatus((Boolean) objects[9]);
			} else {
				if ((Boolean) objects[9] == true) {
					if (passcodeVerifiedDate != null) {
						if (LocalDateTime.now().minusHours(24).isAfter(passcodeVerifiedDate.toLocalDateTime())) {
							viewMemberDetails.setLockStatus(false);
						} else {
							viewMemberDetails.setLockStatus(true);
						}
					}
					if (passwordVerifiedDate != null) {
						if (LocalDateTime.now().minusHours(24).isAfter(passwordVerifiedDate.toLocalDateTime())) {
							viewMemberDetails.setLockStatus(false);
						} else {
							viewMemberDetails.setLockStatus(true);
						}
					}

				} else {
					viewMemberDetails.setLockStatus(false);
				}
			}

			viewMemberDetailsList.add(viewMemberDetails);
		}
		return viewMemberDetailsList;

	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

	private List<MemberCaseCount> getMemberCaseCount(long organizationId, Page<Object[][]> memberDetails) {
		List<Long> memberIds = new ArrayList<>();
		for (Object[] objects : memberDetails) {
			memberIds.add(((BigInteger) objects[6]).longValue());
		}

		MemberCaseCountRequest caseCountRequest = new MemberCaseCountRequest();
		caseCountRequest.setOrganizationId(organizationId);
		caseCountRequest.setMemberIds(memberIds);

		GetMemberCaseCount memberCaseCount = caseService.getMemberCaseCount(caseCountRequest);
		if (memberCaseCount != null) {
			return memberCaseCount.getMemberCaseCount();
		}
		return new ArrayList<>();
	}

	private MemberCaseCount getCaseCount(Long memberId, List<MemberCaseCount> memberCaseCount) {
		return memberCaseCount.stream().filter(member -> member.getMemberId() == memberId).findFirst().orElse(null);
	}
}
