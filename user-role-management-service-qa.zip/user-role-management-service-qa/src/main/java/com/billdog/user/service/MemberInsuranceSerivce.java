package com.billdog.user.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.DeductiblePaymentInfoEnum;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.InsuranceDetails;
import com.billdog.user.entity.InsuranceSubTypeMaster;
import com.billdog.user.entity.InsuranceTypes;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberInsuranceDetails;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.repository.InsuranceDetailsRepository;
import com.billdog.user.repository.InsuranceSubTypeRepository;
import com.billdog.user.repository.InsuranceTypeRepository;
import com.billdog.user.repository.MemberInsuranceDetailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.AddInsuranceDetailsListRequest;
import com.billdog.user.request.DeductiablePayInfoRequest;
import com.billdog.user.request.EditInsuranceRequest;
import com.billdog.user.view.GetCarrierInfo;
import com.billdog.user.view.InsuranceSubTypeDetails;
import com.billdog.user.view.ViewDeductibleCoPayList;
import com.billdog.user.view.ViewDeductibleCoPayListInfo;
import com.billdog.user.view.ViewInsuranceDetails;
import com.billdog.user.view.ViewInsuranceDetailsInfo;
import com.billdog.user.view.ViewInsuranceTypeDetails;
import com.billdog.user.view.ViewMemberResponse;
import com.billdog.user.view.ViewResponse;

@Service
public class MemberInsuranceSerivce {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MemberInsuranceSerivce.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	InsuranceTypeRepository insuranceTypeRepository;

	@Autowired
	InsuranceSubTypeRepository insuranceSubTypeRepository;

	@Autowired
	EntityService entityService;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	InsuranceDetailsRepository insuranceDetailsRepository;

	@Autowired
	MemberInsuranceDetailRepository memberInsuranceDetailRepository;

	@Autowired
	MemberService memberService;

	@Autowired
	SystemUsersrepository systemUserepository;

	@Autowired
	AuditService auditService;

	@Value("${insurance.size}")
	private long insuranceSize;

	/**
	 * @param createOrganization
	 * @return
	 */
	public ResponseEntity<ViewResponse> createMemberInsurance(
			AddInsuranceDetailsListRequest addInsuranceDetailsListRequest) {
		LOGGER.info("createMemberInsurance method started..!");

		Optional<SystemUsers> user = systemUserepository.findById(addInsuranceDetailsListRequest.getUserId());

		Member member = memberService.getMember(addInsuranceDetailsListRequest.getMemberId());

		LOGGER.debug("checking whether how many insurance details added to member");
		List<InsuranceDetails> insuranceDetailsEntity = insuranceDetailsRepository.findByMemberId(member);
		if (!insuranceDetailsEntity.isEmpty() && insuranceDetailsEntity.size() >= 2) {
			throw new InValidInputException(ExceptionalMessages.INSURANCE_DETAILS);
		}

		List<MemberInsuranceDetails> memberInsuranceDetailsList = new ArrayList<>();
		addInsuranceDetailsListRequest.getAddInsuranceDetailsRequestsList().forEach(addInsurance -> {
			LOGGER.debug("looping through the request object");
			String regex = "^[ a-zA-Z0-9]+$";
			if (!addInsurance.getProductName().matches(regex)) {
				throw new InValidInputException(ExceptionalMessages.PRODUCT_NAME_VALIDATION);
			}
			if (!addInsurance.getGroupId().matches(regex)) {
				throw new InValidInputException(ExceptionalMessages.GROUP_ID_VALIDATION);
			}
			if (!addInsurance.getMemberInsuranceId().matches(regex)) {
				throw new InValidInputException(ExceptionalMessages.MEMBER_INSURANCE_VALIDATION);
			}
			InsuranceDetails insuranceDetails = new InsuranceDetails();
			if (addInsurance.getGroupId() == null) {
				throw new InValidInputException(ExceptionalMessages.GROUP_ID_NOT_NULL);
			}
			if (addInsurance.getProductName() == null) {
				throw new InValidInputException(ExceptionalMessages.PRODUCTNAME_NOT_NULL);
			}
			if (addInsurance.getProviderContactNumber() == null) {
				throw new InValidInputException(ExceptionalMessages.PROVIDER_NOT_NULL);
			}
			if (addInsurance.getCustomerServiceContactNumber() == null) {
				throw new InValidInputException(ExceptionalMessages.CUSTOMER_SERVICE_ID_NOT_NULL);
			}
			if (!StringUtils.isNumeric(addInsurance.getProviderContactNumber())) {
				throw new InValidInputException(ExceptionalMessages.PROVIDER_CONTACT_NUMBER_DIGITS);
			}
			if (addInsurance.getProviderContactNumber().length() < 10
					|| addInsurance.getProviderContactNumber().length() > 10) {
				throw new InValidInputException(ExceptionalMessages.PROVIDER_CONTACT_NUMBER);
			}
			if (!StringUtils.isNumeric(addInsurance.getCustomerServiceContactNumber())) {
				throw new InValidInputException(ExceptionalMessages.CUSTOMER_SERVICE_CONTACT_DIGITS);
			}
			if (addInsurance.getCustomerServiceContactNumber().length() < 10
					|| addInsurance.getCustomerServiceContactNumber().length() > 10) {
				throw new InValidInputException(ExceptionalMessages.CUSTOMER_SERVICE_CONTACT_NUMBER);
			}
			Optional<InsuranceTypes> insuranceType = insuranceTypeRepository.findById(addInsurance.getInsuranceType());
			if (!insuranceType.isPresent()) {
				throw new MemberNotFoundException(ExceptionalMessages.INSURANCE_TYPE_NOT_FOUND);
			}
			insuranceDetails.setInsuranceTypeId(insuranceType.get());
			Optional<InsuranceSubTypeMaster> insuranceSubType = insuranceSubTypeRepository
					.findById(addInsurance.getSubType());
			if (!insuranceSubType.isPresent()) {
				throw new MemberNotFoundException(ExceptionalMessages.INSURANCE_SUB_TYPE_NOT_FOUND);
			}
			String auditId = auditService.getAuditId();
			insuranceDetails.setMemberInsuranceId(addInsurance.getMemberInsuranceId());
			insuranceDetails.setInsuranceSubTypeId(insuranceSubType.get());
			checkCarrierType(addInsurance.getCarrier(), member.getOrganizationId().getId());
			insuranceDetails.setCarrierId(addInsurance.getCarrier());
			if (user.isPresent()) {
				insuranceDetails.setUserId(user.get());
			} else {
				insuranceDetails.setUserId(null);
			}
			insuranceDetails.setGroupId(addInsurance.getGroupId());
			insuranceDetails.setMemberId(member);
			insuranceDetails.setProductName(addInsurance.getProductName());
			insuranceDetails.setProviderContactNumber(addInsurance.getProviderContactNumber());
			insuranceDetails.setCustomerServiceContactNumber(addInsurance.getCustomerServiceContactNumber());
			insuranceDetails.setCreatedAt(DateAndTimeUtil.now());
			insuranceDetails.setUpdatedAt(DateAndTimeUtil.now());
			insuranceDetails.setAuditId(auditId);
			insuranceDetailsRepository.save(insuranceDetails);
			if (!addInsurance.getDeductiblePayInfoList().isEmpty()) {
				addInsurance.getDeductiblePayInfoList().forEach(memberInsurancePayInfo -> {
					LOGGER.debug("looping through DeductiblePay request object");
					MemberInsuranceDetails memberInsuranceDetails = new MemberInsuranceDetails();
					memberInsuranceDetails.setCreatedAt(DateAndTimeUtil.now());
					memberInsuranceDetails.setUpdatedAt(DateAndTimeUtil.now());
					memberInsuranceDetails.setMemberId(member);
					memberInsuranceDetails.setPcp(memberInsurancePayInfo.getPcp());
					memberInsuranceDetails.setSpec(memberInsurancePayInfo.getSpec());
					memberInsuranceDetails.setEr(memberInsurancePayInfo.getEr());
					memberInsuranceDetails.setDed(memberInsurancePayInfo.getDed());
					memberInsuranceDetails
							.setTypeName(memberInsurancePayInfo.getDeductiblePaymentInfoEnum().toString());
					memberInsuranceDetails.setInsuranceDetails(insuranceDetails);
					if (user.isPresent()) {
						memberInsuranceDetails.setUserId(user.get());
					} else {
						memberInsuranceDetails.setUserId(null);
					}
					memberInsuranceDetails.setAuditId(auditId);
					memberInsuranceDetailsList.add(memberInsuranceDetails);
				});
				memberInsuranceDetailRepository.saveAll(memberInsuranceDetailsList);
			}

		});
		
		LOGGER.info("createMemberInsurance method ends..!");
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setMemberId(addInsuranceDetailsListRequest.getMemberId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.MEMBER_INSURANCE);
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);

	}

	public GetCarrierInfo checkCarrierType(long carrierId, long orgId) {
		GetCarrierInfo carrierInfo = entityService.getCarrierInfo(carrierId, orgId);
		if (carrierInfo == null || (!carrierInfo.getStatusText().equalsIgnoreCase(Constants.SUCCESS))) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_CARRIER_NOT_FOUND);
		}
		return carrierInfo;
	}

	public ResponseEntity<ViewMemberResponse> getAllInsuranceType(Long userId, Long memberId) {
		LOGGER.info("getAllInsuranceType strated..");
		Organization organization = memberService.getOrganization(userId, memberId);
		// creating array list for ViewInsuranceTypeDetails
		List<ViewInsuranceTypeDetails> viewInsuranceTypeDetailsList = new ArrayList<>();

		// fetching all countries which are in active status
		List<InsuranceTypes> insurance = insuranceTypeRepository.findByOrganizationIdAndStatus(organization,
				StatusConstants.ACTIVE);
		LOGGER.debug("fetching list of insurance which are in active status..");
		if (!insurance.isEmpty()) {
			// looping through arrayList
			insurance.forEach(insurancetype -> {
				ViewInsuranceTypeDetails viewInsuranceTypeDetails = new ViewInsuranceTypeDetails();
				viewInsuranceTypeDetails.setInsuranceTypeId(insurancetype.getId());
				viewInsuranceTypeDetails.setInsuranceTypeName(insurancetype.getName());
				viewInsuranceTypeDetailsList.add(viewInsuranceTypeDetails);
			});
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.INSURANCE_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewInsuranceTypeDetailsList);
		LOGGER.info("getAllInsuranceType ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewMemberResponse> getAllInsuranceSubType(Long userId, Long memberId) {
		LOGGER.info("getAllInsuranceSubType strated..");
		Organization organization = memberService.getOrganization(userId, memberId);
		// creating array list for viewInsuranceSubTypeDetailsList
		List<InsuranceSubTypeDetails> viewInsuranceSubTypeDetailsList = new ArrayList<>();

		// fetching all insurance sub type which are in active status
		List<InsuranceSubTypeMaster> insurance = insuranceSubTypeRepository.findByOrganizationIdAndStatus(organization,
				StatusConstants.ACTIVE);
		LOGGER.debug("fetching list of insurance sub type which are in active status..");
		if (!insurance.isEmpty()) {
			// looping through arrayList
			insurance.forEach(insuranceSubtype -> {
				InsuranceSubTypeDetails insuranceSubTypeDetails = new InsuranceSubTypeDetails();
				insuranceSubTypeDetails.setInsuraceSubTypeId(insuranceSubtype.getId());
				insuranceSubTypeDetails.setInsuranceSubTypeName(insuranceSubtype.getName());
				viewInsuranceSubTypeDetailsList.add(insuranceSubTypeDetails);
			});
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.INSURANCES_SUB_TYPE_FETCHED);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewInsuranceSubTypeDetailsList);
		LOGGER.info("getAllInsuranceSubType ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewMemberResponse> getInsuranceDetails(Long memberId) {
		LOGGER.info("getInsuranceDetails strated..");
		Optional<Member> member = memberRepository.findById(memberId);
		if (!member.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		List<ViewInsuranceDetails> viewInsuranceDetailsList = new ArrayList<>();

		List<InsuranceDetails> insuranceDetails = insuranceDetailsRepository.findByMemberId(member.get());
		if (!insuranceDetails.isEmpty()) {
			insuranceDetails.forEach(insurance -> {
				ViewInsuranceDetails viewInsuranceDetails = new ViewInsuranceDetails();
				Optional<InsuranceTypes> insuranceType = insuranceTypeRepository
						.findById(insurance.getInsuranceTypeId().getId());
				viewInsuranceDetails.setInsuranceType(insuranceType.get().getName());
				viewInsuranceDetails.setInsuranceTypeId(insuranceType.get().getId());
				Optional<InsuranceSubTypeMaster> insuranceSubTypeMaster = insuranceSubTypeRepository
						.findById(insurance.getInsuranceSubTypeId().getId());
				viewInsuranceDetails.setInsuranceSubType(insuranceSubTypeMaster.get().getName());
				viewInsuranceDetails.setInsuranceSubTypeId(insuranceSubTypeMaster.get().getId());
				GetCarrierInfo checkCarrierType = checkCarrierType(insurance.getCarrierId(),
						member.get().getOrganizationId().getId());
				viewInsuranceDetails.setCarrier(checkCarrierType.getCarrierName());
				viewInsuranceDetails.setCarrierId(checkCarrierType.getCarrierId());
				viewInsuranceDetails.setGroupId(insurance.getGroupId());
				viewInsuranceDetails.setMemberInsuranceId(insurance.getMemberInsuranceId());
				viewInsuranceDetails.setMemberId(insurance.getMemberId().getId());
				viewInsuranceDetails.setProductName(insurance.getProductName());
				viewInsuranceDetails.setProviderContactNumber(insurance.getProviderContactNumber());
				viewInsuranceDetails.setCustomerServiceContactNumber(insurance.getCustomerServiceContactNumber());
				viewInsuranceDetails.setInsuranceId(insurance.getId());
				List<MemberInsuranceDetails> memberInsuranceDetails = memberInsuranceDetailRepository
						.findByMemberIdAndInsuranceDetails(member.get(), insurance);
				List<ViewDeductibleCoPayList> viewDeductibleCoPay = new ArrayList<>();
				memberInsuranceDetails.forEach(memberInsurance -> {
					ViewDeductibleCoPayList coPayList = new ViewDeductibleCoPayList();
					coPayList.setPcp(memberInsurance.getPcp());
					coPayList.setSpec(memberInsurance.getSpec());
					coPayList.setEr(memberInsurance.getEr());
					coPayList.setDed(memberInsurance.getDed());
					coPayList.setTier(memberInsurance.getTypeName());
					long displayOrderIncrement = 1;
					coPayList.setDisplayOrder(DeductiblePaymentInfoEnum.valueOf(memberInsurance.getTypeName()).ordinal()
							+ displayOrderIncrement);
					viewDeductibleCoPay.add(coPayList);
				});
				List<ViewDeductibleCoPayList> viewDeductibleCoPayList = viewDeductibleCoPay.stream()
						.sorted(Comparator.comparing(ViewDeductibleCoPayList::getDisplayOrder))
						.collect(Collectors.toList());
				viewInsuranceDetails.setViewDeductibleCoPayList(viewDeductibleCoPayList);
				viewInsuranceDetailsList.add(viewInsuranceDetails);
			});
		}
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.INSURANCE_DETAILS);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(viewInsuranceDetailsList);
		LOGGER.info("getInsuranceDetails ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	public ResponseEntity<ViewMemberResponse> getInsuranceDetailsByMember(Long memberId) {
		LOGGER.info("getInsuranceDetails strated..");
		LOGGER.info("Get member info from database strated at {}",DateAndTimeUtil.now());
		Optional<Member> member = memberRepository.findById(memberId);
		LOGGER.info("Get member info from database ended at {}",DateAndTimeUtil.now());
		if (!member.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		List<ViewInsuranceDetailsInfo> viewInsuranceDetailsList = new ArrayList<>();	
		LOGGER.info("Get member insurance info from database strated at {}",DateAndTimeUtil.now());
		List<InsuranceDetails> insuranceDetails = insuranceDetailsRepository.findByMemberId(member.get());
		LOGGER.info("Get member insurance info from database ended at {}",DateAndTimeUtil.now());
		LOGGER.info("Get member insurance co-pay info from database strated at {}",DateAndTimeUtil.now());
		List<MemberInsuranceDetails> memberInsuranceDetailsList = memberInsuranceDetailRepository
				.findAllByMemberIdAndInsuranceDetailsIn(member.get(), insuranceDetails);
		LOGGER.info("Get member insurance co-pay info from database ended at {}",DateAndTimeUtil.now());
		
		LOGGER.info("Response object creation started at {}",DateAndTimeUtil.now());
		if (!insuranceDetails.isEmpty()) {
			insuranceDetails.forEach(insurance -> {
				ViewInsuranceDetailsInfo viewInsuranceDetails = new ViewInsuranceDetailsInfo();
				viewInsuranceDetails.setInsuranceType(insurance.getInsuranceTypeId().getName());
				viewInsuranceDetails.setInsuranceTypeId(insurance.getInsuranceTypeId().getId());
				viewInsuranceDetails.setInsuranceSubType(insurance.getInsuranceSubTypeId().getName());
				viewInsuranceDetails.setInsuranceSubTypeId(insurance.getInsuranceSubTypeId().getId());
				GetCarrierInfo checkCarrierType = checkCarrierType(insurance.getCarrierId(),
						member.get().getOrganizationId().getId());
				viewInsuranceDetails.setCarrier(checkCarrierType.getCarrierName());
				viewInsuranceDetails.setCarrierId(checkCarrierType.getCarrierId());
				viewInsuranceDetails.setGroupId(insurance.getGroupId());
				viewInsuranceDetails.setMemberId(insurance.getMemberId().getId());
				viewInsuranceDetails.setProductName(insurance.getProductName());
				viewInsuranceDetails.setProviderContactNumber(insurance.getProviderContactNumber());
				viewInsuranceDetails.setCustomerServiceContactNumber(insurance.getCustomerServiceContactNumber());
				viewInsuranceDetails.setMemberInsuranceId(insurance.getMemberInsuranceId());
				viewInsuranceDetails.setInsuranceId(insurance.getId());				
				List<MemberInsuranceDetails> memberInsuranceDetails = memberInsuranceDetailsList.stream()
					      .filter(ins -> ins.getInsuranceDetails().getId()==insurance.getId())
					    	        .collect(Collectors.toList());				
				viewInsuranceDetails.setViewDeductibleCoPayList(getCopayList(memberInsuranceDetails));
				viewInsuranceDetailsList.add(viewInsuranceDetails);
			});
		}
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.INSURANCE_DETAILS);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMaxSize(insuranceSize);
		viewResponse.setInsuranceMessage(Constants.INSURANCE_EXCEPTION_MESSAGE);
		viewResponse.setData(viewInsuranceDetailsList);
		LOGGER.info("Response object creation ended at {}",DateAndTimeUtil.now());
		LOGGER.info("getInsuranceDetails ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	private List<ViewDeductibleCoPayListInfo> getCopayList(List<MemberInsuranceDetails> memberInsuranceDetails) {
		List<ViewDeductibleCoPayListInfo> viewDeductibleCoPay = new ArrayList<>();
		ViewDeductibleCoPayListInfo coPayList = new ViewDeductibleCoPayListInfo();
		long displayOrderIncrement = 1;
		coPayList.setPcp("PCP");
		coPayList.setSpec("SPEC");
		coPayList.setEr("ER");
		coPayList.setDed("DED");
		coPayList.setTier("TIER");
		viewDeductibleCoPay.add(coPayList);
		if (memberInsuranceDetails.isEmpty()) {
			for (DeductiblePaymentInfoEnum deductiblePaymentInfo : DeductiblePaymentInfoEnum.values()) {
				ViewDeductibleCoPayListInfo coPayList2 = new ViewDeductibleCoPayListInfo();
				coPayList2.setPcp(String.valueOf(0));
				coPayList2.setSpec(String.valueOf(0));
				coPayList2.setEr(String.valueOf(0));
				coPayList2.setDed(String.valueOf(0));
				coPayList2.setTier(deductiblePaymentInfo.toString());
				coPayList2.setDisplayOrder(DeductiblePaymentInfoEnum.valueOf(deductiblePaymentInfo.toString()).ordinal()
						+ displayOrderIncrement);
				viewDeductibleCoPay.add(coPayList2);
			}
		} else {
			memberInsuranceDetails.forEach(memberInsurance -> {
				ViewDeductibleCoPayListInfo coPayList2 = new ViewDeductibleCoPayListInfo();
				coPayList2.setPcp(String.valueOf(memberInsurance.getPcp()));
				coPayList2.setSpec(String.valueOf(memberInsurance.getSpec()));
				coPayList2.setEr(String.valueOf(memberInsurance.getEr()));
				coPayList2.setDed(String.valueOf(memberInsurance.getDed()));
				coPayList2.setTier(String.valueOf(memberInsurance.getTypeName()));
				coPayList2.setDisplayOrder(DeductiblePaymentInfoEnum.valueOf(memberInsurance.getTypeName()).ordinal()
						+ displayOrderIncrement);
				viewDeductibleCoPay.add(coPayList2);
			});
		}
		List<ViewDeductibleCoPayListInfo> viewDeductibleCoPayListInfo = viewDeductibleCoPay.stream()
				.sorted(Comparator.comparing(ViewDeductibleCoPayListInfo::getDisplayOrder))
				.collect(Collectors.toList());

		return viewDeductibleCoPayListInfo;
	}

	public ResponseEntity<ViewResponse> editMemberInsurance(EditInsuranceRequest editInsuranceRequest) {
		LOGGER.info("Edit Member Insurance method started..!");
		Optional<SystemUsers> user = systemUserepository.findById(editInsuranceRequest.getUserId());
		Member member = memberService.getMember(editInsuranceRequest.getMemberId());
		validateInsuranceRequest(editInsuranceRequest);
		boolean updated = false;
		LOGGER.debug("checking whether insurance present for member or not");
		Optional<InsuranceDetails> insuranceDetailsEntity = insuranceDetailsRepository
				.findById(editInsuranceRequest.getInsuranceId());
		if (!insuranceDetailsEntity.isPresent()) {
			throw new InValidInputException(ExceptionalMessages.INSURANCE_DETAILS_NOT_FOUND);
		}
		String auditId = auditService.getAuditId();
		InsuranceDetails insuranceDetails = insuranceDetailsEntity.get();
		if (editInsuranceRequest.getInsuranceType() != 0
				&& editInsuranceRequest.getInsuranceType() != insuranceDetails.getInsuranceTypeId().getId()) {
			Optional<InsuranceTypes> insuranceType = insuranceTypeRepository
					.findById(editInsuranceRequest.getInsuranceType());
			if (!insuranceType.isPresent()) {
				throw new MemberNotFoundException(ExceptionalMessages.INSURANCE_TYPE_NOT_FOUND);
			}
			updated = true;
			insuranceDetails.setInsuranceTypeId(insuranceType.get());
		}
		if (editInsuranceRequest.getSubType() != 0
				&& editInsuranceRequest.getSubType() != insuranceDetails.getInsuranceSubTypeId().getId()) {
			Optional<InsuranceSubTypeMaster> insuranceSubType = insuranceSubTypeRepository
					.findById(editInsuranceRequest.getSubType());
			if (!insuranceSubType.isPresent()) {
				throw new MemberNotFoundException(ExceptionalMessages.INSURANCE_SUB_TYPE_NOT_FOUND);
			}
			updated = true;
			insuranceDetails.setInsuranceSubTypeId(insuranceSubType.get());
		}
		if (editInsuranceRequest.getCarrier() != 0
				&& editInsuranceRequest.getCarrier() != insuranceDetails.getCarrierId()) {
			checkCarrierType(editInsuranceRequest.getCarrier(), member.getOrganizationId().getId());
			updated = true;
			insuranceDetails.setCarrierId(editInsuranceRequest.getCarrier());
		}

		if (!StringUtils.isBlank(editInsuranceRequest.getMemberInsuranceId()) && !editInsuranceRequest
				.getMemberInsuranceId().equalsIgnoreCase(insuranceDetails.getMemberInsuranceId())) {
			updated = true;
			insuranceDetails.setMemberInsuranceId(editInsuranceRequest.getMemberInsuranceId());
		}
		if (!StringUtils.isBlank(editInsuranceRequest.getGroupId())
				&& !editInsuranceRequest.getGroupId().equalsIgnoreCase(insuranceDetails.getGroupId())) {
			updated = true;
			insuranceDetails.setGroupId(editInsuranceRequest.getGroupId());
		}
		if (!StringUtils.isBlank(editInsuranceRequest.getProductName())
				&& !editInsuranceRequest.getProductName().equalsIgnoreCase(insuranceDetails.getProductName())) {
			updated = true;
			insuranceDetails.setProductName(editInsuranceRequest.getProductName());
		}
		if (!StringUtils.isBlank(editInsuranceRequest.getProviderContactNumber()) && !editInsuranceRequest
				.getProviderContactNumber().equalsIgnoreCase(insuranceDetails.getProviderContactNumber())) {
			updated = true;
			insuranceDetails.setProviderContactNumber(editInsuranceRequest.getProviderContactNumber());
		}
		if (!StringUtils.isBlank(editInsuranceRequest.getCustomerServiceContactNumber())
				&& !editInsuranceRequest.getCustomerServiceContactNumber()
						.equalsIgnoreCase(insuranceDetails.getCustomerServiceContactNumber())) {
			updated = true;
			insuranceDetails.setCustomerServiceContactNumber(editInsuranceRequest.getCustomerServiceContactNumber());
		}
		
		List<MemberInsuranceDetails> memberInsuranceDetailsList = new ArrayList<>();
		if (editInsuranceRequest.getDeductiblePayInfoList() != null
				&& !editInsuranceRequest.getDeductiblePayInfoList().isEmpty()) {
			for (DeductiablePayInfoRequest coPayList : editInsuranceRequest.getDeductiblePayInfoList()) {
				Optional<MemberInsuranceDetails> memberInsuranceDetails = memberInsuranceDetailRepository
						.findAllByInsuranceDetailsAndTypeName(insuranceDetailsEntity.get(),
								coPayList.getDeductiblePaymentInfoEnum().toString());
				if (memberInsuranceDetails.isPresent()) {
					boolean update = false;
					if (coPayList.getPcp() != memberInsuranceDetails.get().getPcp()) {
						update = true;
						memberInsuranceDetails.get().setPcp((coPayList.getPcp()));
					}

					if (coPayList.getSpec() != memberInsuranceDetails.get().getSpec()) {
						update = true;
						memberInsuranceDetails.get().setSpec(coPayList.getSpec());
					}
					if (coPayList.getEr() != memberInsuranceDetails.get().getEr()) {
						update = true;
						memberInsuranceDetails.get().setEr(coPayList.getEr());
					}

					if (coPayList.getDed() != memberInsuranceDetails.get().getDed()) {
						update = true;
						memberInsuranceDetails.get().setDed(coPayList.getDed());
					}

					if (update) {
						updated = true;
						if (user.isPresent()) {
							memberInsuranceDetails.get().setUserId(user.get());
						} else {
							memberInsuranceDetails.get().setUserId(null);
						}
						memberInsuranceDetails.get().setAuditId(auditId);
						memberInsuranceDetails.get().setTypeName(coPayList.getDeductiblePaymentInfoEnum().toString());
						memberInsuranceDetails.get().setUpdatedAt(DateAndTimeUtil.now());
						memberInsuranceDetailsList.add(memberInsuranceDetails.get());
					}
				}
			}

		}
		if (updated) {
			if (user.isPresent()) {
				insuranceDetails.setUserId(user.get());
			} else {
				insuranceDetails.setUserId(null);
			}
			insuranceDetails.setAuditId(auditId);
			insuranceDetails.setUpdatedAt(DateAndTimeUtil.now());
			insuranceDetailsRepository.save(insuranceDetails);
			memberInsuranceDetailRepository.saveAll(memberInsuranceDetailsList);
		}

		LOGGER.info("Edit Member Insurance method ends..!");
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.MEMBER_INSURANCE_UPDATED);
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

	private void validateInsuranceRequest(EditInsuranceRequest editInsuranceRequest) {

		if (editInsuranceRequest.getGroupId() != null && !editInsuranceRequest.getGroupId().isEmpty()
				&& editInsuranceRequest.getGroupId().length() > 20) {
			throw new InValidInputException(ExceptionalMessages.GROUP_ID);
		}

		if (editInsuranceRequest.getProductName() != null && !editInsuranceRequest.getProductName().isEmpty()
				&& editInsuranceRequest.getProductName().length() > 30) {
			throw new InValidInputException(ExceptionalMessages.PRODUCT_NAME_LIMIT);
		}

		if (!StringUtils.isNumeric(editInsuranceRequest.getProviderContactNumber())) {
			throw new InValidInputException(ExceptionalMessages.PROVIDER_CONTACT_NUMBER_DIGITS);
		}
		if (editInsuranceRequest.getProviderContactNumber().length() < 10
				|| editInsuranceRequest.getProviderContactNumber().length() > 10) {
			throw new InValidInputException(ExceptionalMessages.PROVIDER_CONTACT_NUMBER);
		}
		if (!StringUtils.isNumeric(editInsuranceRequest.getCustomerServiceContactNumber())) {
			throw new InValidInputException(ExceptionalMessages.CUSTOMER_SERVICE_CONTACT_DIGITS);
		}
		if (editInsuranceRequest.getCustomerServiceContactNumber().length() < 10
				|| editInsuranceRequest.getCustomerServiceContactNumber().length() > 10) {
			throw new InValidInputException(ExceptionalMessages.CUSTOMER_SERVICE_CONTACT_NUMBER);
		}
	}
}
