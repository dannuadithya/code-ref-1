package com.billdog.user.request;

import java.util.List;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class AddInsuranceDetailsRequest {

	private long insuranceType;
	private long subType;
	private long carrier;
	private String groupId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String productName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String providerContactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String customerServiceContactNumber;
	private String memberInsuranceId;
	private List<DeductiablePayInfoRequest> deductiblePayInfoList;

	public String getMemberInsuranceId() {
		return memberInsuranceId;
	}

	public void setMemberInsuranceId(String memberInsuranceId) {
		this.memberInsuranceId = memberInsuranceId;
	}

	public long getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(long insuranceType) {
		this.insuranceType = insuranceType;
	}

	public long getSubType() {
		return subType;
	}

	public void setSubType(long subType) {
		this.subType = subType;
	}

	public long getCarrier() {
		return carrier;
	}

	public void setCarrier(long carrier) {
		this.carrier = carrier;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProviderContactNumber() {
		return providerContactNumber;
	}

	public void setProviderContactNumber(String providerContactNumber) {
		this.providerContactNumber = providerContactNumber;
	}

	public String getCustomerServiceContactNumber() {
		return customerServiceContactNumber;
	}

	public void setCustomerServiceContactNumber(String customerServiceContactNumber) {
		this.customerServiceContactNumber = customerServiceContactNumber;
	}

	public List<DeductiablePayInfoRequest> getDeductiblePayInfoList() {
		return deductiblePayInfoList;
	}

	public void setDeductiblePayInfoList(List<DeductiablePayInfoRequest> deductiblePayInfoList) {
		this.deductiblePayInfoList = deductiblePayInfoList;
	}

}
