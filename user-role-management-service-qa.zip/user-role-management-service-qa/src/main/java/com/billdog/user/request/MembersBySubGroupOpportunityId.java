package com.billdog.user.request;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class MembersBySubGroupOpportunityId {

	private Long userId;
	private Long subGroupOpportunityId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String opportunityType;

	public String getOpportunityType() {
		return opportunityType;
	}

	public void setOpportunityType(String opportunityType) {
		this.opportunityType = opportunityType;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Long getSubGroupOpportunityId() {
		return subGroupOpportunityId;
	}

	public void setSubGroupOpportunityId(Long subGroupOpportunityId) {
		this.subGroupOpportunityId = subGroupOpportunityId;
	}

}
