package com.billdog.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.InsuranceSubTypeMaster;
import com.billdog.user.entity.Organization;

public interface InsuranceSubTypeRepository extends JpaRepository<InsuranceSubTypeMaster, Long> {

	List<InsuranceSubTypeMaster> findAllByStatus(String active);

	List<InsuranceSubTypeMaster> findByOrganizationIdAndStatus(Organization organization, String active);

}
