package com.billdog.user.request;

import javax.validation.constraints.NotNull;

public class ResendPasscodeMemberEmailRequest {

	@NotNull(message = "email must not be null")
	private String email;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
