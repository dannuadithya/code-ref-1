package com.billdog.user.request;

public class MemberCountByEmployer {

	private Long employerId;

	public Long getEmployerId() {
		return employerId;
	}

	public void setEmployerId(Long employerId) {
		this.employerId = employerId;
	}

}
