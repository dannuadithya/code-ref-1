package com.billdog.user.common;

public enum StatusType {
	USER, MEMBER,LOCKSTATUS,EMPLOYER_DIRECT
}
