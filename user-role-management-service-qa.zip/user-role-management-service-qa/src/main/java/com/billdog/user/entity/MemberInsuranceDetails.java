package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "MEMBER_INSURANCE_DETAILS")
@Table(name = "member_insurance_details", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "org_member_index", columnList = "MEMBER_ID,ORGANIZATION_ID", unique = false),
		@Index(name = "member_index", columnList = "MEMBER_ID", unique = false) })
public class MemberInsuranceDetails extends BaseEntity {

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "MEMBER_ID")
	private Member memberId;

	@Audited
	@Column(name = "INSURANCE_TYPE_NAME")
	private String typeName;

	@Audited
	@Column(name = "PCP", columnDefinition = "integer default 0")
	private int pcp;

	@Audited
	@Column(name = "SPEC", columnDefinition = "integer default 0")
	private int spec;

	@Audited
	@Column(name = "ER", columnDefinition = "integer default 0")
	private int er;

	@Audited
	@Column(name = "DED", columnDefinition = "integer default 0")
	private int ded;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "INSURANCE_DETAILS_ID")
	private InsuranceDetails insuranceDetails;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "USER_ID")
	private SystemUsers userId;

	@Audited
	@Column(name = "audit_id")
	private String auditId;

	public InsuranceDetails getInsuranceDetails() {
		return insuranceDetails;
	}

	public void setInsuranceDetails(InsuranceDetails insuranceDetails) {
		this.insuranceDetails = insuranceDetails;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public Member getMemberId() {
		return memberId;
	}

	public void setMemberId(Member memberId) {
		this.memberId = memberId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public int getPcp() {
		return pcp;
	}

	public void setPcp(int pcp) {
		this.pcp = pcp;
	}

	public int getSpec() {
		return spec;
	}

	public void setSpec(int spec) {
		this.spec = spec;
	}

	public int getEr() {
		return er;
	}

	public void setEr(int er) {
		this.er = er;
	}

	public int getDed() {
		return ded;
	}

	public void setDed(int ded) {
		this.ded = ded;
	}

	public SystemUsers getUserId() {
		return userId;
	}

	public void setUserId(SystemUsers userId) {
		this.userId = userId;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

}