package com.billdog.user.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.EmailTitles;
import com.billdog.user.request.VerifyEmailRequest;
import com.billdog.user.service.CreateUserService;
import com.billdog.user.view.ViewResponse;

@Service
public class SendPasscodeCommand implements Command<VerifyEmailRequest, ResponseEntity<ViewResponse>> {

	@Autowired
	CreateUserService createUserService;

	@Override
	public ResponseEntity<ViewResponse> excute(VerifyEmailRequest email) {
		return ResponseEntity.status(HttpStatus.OK)
				.body(createUserService.sendPasscodeByUserId(email, EmailTitles.UPDATE_PASSWORD));

	}
}