package com.billdog.user.exception;

public class FamilyMemberNotFoundException extends NoRecordFoundException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FamilyMemberNotFoundException(String exception) {
		super(exception);
	}
}
