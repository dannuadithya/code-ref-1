package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberSfdcStatus;
import com.billdog.user.entity.Organization;

@Repository
public interface MemberSfdcStatusRespository extends JpaRepository<MemberSfdcStatus, Long> {

	List<MemberSfdcStatus> findAllByProfileUpdated(boolean b);

	List<MemberSfdcStatus> findAllByProfileUpdatedAndMemberIdNotIn(boolean profileUpdated, List<Member> memberList);

	Optional<MemberSfdcStatus> findByMemberId(Member member);

	List<MemberSfdcStatus> findAllByIntegrationStatus(String failed);

	List<MemberSfdcStatus> findAllByIntegrationStatusAndOrganizationId(String failed, Organization organizationId);

	long countByIntegrationStatusAndOrganizationId(String failed, Organization organizationId);

	List<MemberSfdcStatus> findAllByMemberIdIn(List<Member> memberList);

	List<MemberSfdcStatus> findAllByIntegrationStatusAndOrganizationIdOrderByCreatedAtDesc(String failed,
			Organization organizationId);

}
