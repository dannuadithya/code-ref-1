package com.billdog.user.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.exception.InternalServerException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.exception.ServiceUnavailableException;
import com.billdog.user.repository.CaseRepository;
import com.billdog.user.request.AuditRequest;
import com.billdog.user.request.MemberCaseCountRequest;
import com.billdog.user.view.CasesSummaryView;
import com.billdog.user.view.GetMemberCaseCount;
import com.billdog.user.view.ViewResponse;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Component
public class CaseService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CaseService.class);

	@Value("${caseservice.baseurl}")
	private String caseBaseUrl;

	private CaseRepository getCaseRepository(String token) {
		OkHttpClient.Builder userHttpClient;
		if (StringUtils.isNotBlank(token)) {
			userHttpClient = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
				@Override
				public Response intercept(Chain chain) throws IOException {
					Request request = chain.request().newBuilder().addHeader("authorization", token).build();
					return chain.proceed(request);
				}
			});
		} else {
			userHttpClient = new OkHttpClient.Builder();
		}
		Retrofit retrofit = new Retrofit.Builder().baseUrl(caseBaseUrl)
				.addConverterFactory(GsonConverterFactory.create())
				.client(userHttpClient.connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build())
				.build();
		return retrofit.create(CaseRepository.class);
	}

	public GetMemberCaseCount getMemberCaseCount(MemberCaseCountRequest caseCountRequest) {
		LOGGER.info("verifyUserToken method started..!");
		CaseRepository userRepository = getCaseRepository(null);

		Call<GetMemberCaseCount> callSync = userRepository.getMemberCaseCount(caseCountRequest);

		try {
			retrofit2.Response<GetMemberCaseCount> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.CASE_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.CASE_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.CASE_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.CASE_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.CASE_SERVICE_ISSUE);
				}

			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling case service, message:: {}", exception.getMessage());
			// throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
		return null;
	}

	public CasesSummaryView getCaseInfo() {
		LOGGER.info("getMemberInfo method started..!");
		CaseRepository userRepository = getCaseRepository(null);
		Call<CasesSummaryView> callSync = userRepository.getCaseInfo();

		try {
			retrofit2.Response<CasesSummaryView> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from case service");
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.CASE_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.CASE_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.CASE_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.CASE_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.CASE_SERVICE_ISSUE);
				}

			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling case service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse getAuditInfo(AuditRequest auditRequest) {

		LOGGER.info("getAuditInfo method started..!");
		CaseRepository caseRepository = getCaseRepository(null);

		Call<ViewResponse> callSync = caseRepository.getAuditInfo(auditRequest);

		try {
			retrofit2.Response<ViewResponse> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling case service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse getAuditInfoById(Long recordId, String moduleName, Integer pageNumber, Integer pageLimit) {

		LOGGER.info("getAuditInfoById method started..!");
		CaseRepository caseRepository = getCaseRepository(null);

		Call<ViewResponse> callSync = caseRepository.getAuditInfoById(recordId, moduleName, pageNumber, pageLimit);

		try {
			retrofit2.Response<ViewResponse> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling case service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}
}
