package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.CountryPhoneCodeMaster;
import com.billdog.user.entity.Organization;

public interface CountryPhoneCodeMasterRepository extends JpaRepository<CountryPhoneCodeMaster, Long>{

	Optional<CountryPhoneCodeMaster> findByIdAndStatus(long countryPhoneCodeId, String active);

	List<CountryPhoneCodeMaster> findAllByStatus(String active);

	List<CountryPhoneCodeMaster> findByOrganizationIdAndStatus(Organization organization, String active);

	Optional<CountryPhoneCodeMaster> findByIdAndOrganizationIdAndStatus(Long countryCodeId, Organization organization,
			String active);

	Optional<CountryPhoneCodeMaster> findByPhoneNumberCodeAndOrganizationId(String countryPhoneCode,
			Organization organizationId);

}
