package com.billdog.user.exception;

public class InvalidAuthTokenException extends UnauthorizedException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidAuthTokenException(String errMsg) {
		super(errMsg);
	}
	
	public InvalidAuthTokenException(String message, Throwable cause) {
        super(message, cause);
    }
}
