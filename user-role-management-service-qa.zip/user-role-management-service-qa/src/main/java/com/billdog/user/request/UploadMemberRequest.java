package com.billdog.user.request;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.billdog.user.view.ErrorRecord;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UploadMemberRequest {
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String firstName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String lastName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String contactNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String countryPhoneCode;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String email;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String productType;
	private ErrorRecord errorRecord;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getProductType() {
		return productType;
	}

	public void setProductType(String productType) {
		this.productType = productType;
	}

	public ErrorRecord getErrorRecord() {
		return errorRecord;
	}

	public void setErrorRecord(ErrorRecord errorRecord) {
		this.errorRecord = errorRecord;
	}

	public String getCountryPhoneCode() {
		return countryPhoneCode;
	}

	public void setCountryPhoneCode(String countryPhoneCode) {
		this.countryPhoneCode = countryPhoneCode;
	}


}
