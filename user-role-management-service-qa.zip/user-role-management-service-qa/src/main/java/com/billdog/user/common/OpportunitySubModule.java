package com.billdog.user.common;

public enum OpportunitySubModule {

	Block_Opportunity,Sub_Group_Opportunity,Broker_Sponsored,Employer_Direct
}
