package com.billdog.user.request;

import java.util.List;

public class AddInsuranceDetailsListRequest {

	private List<AddInsuranceDetailsRequest> addInsuranceDetailsRequestsList;
	private long memberId;
	private long userId;

	public List<AddInsuranceDetailsRequest> getAddInsuranceDetailsRequestsList() {
		return addInsuranceDetailsRequestsList;
	}

	public void setAddInsuranceDetailsRequestsList(List<AddInsuranceDetailsRequest> addInsuranceDetailsRequestsList) {
		this.addInsuranceDetailsRequestsList = addInsuranceDetailsRequestsList;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

}
