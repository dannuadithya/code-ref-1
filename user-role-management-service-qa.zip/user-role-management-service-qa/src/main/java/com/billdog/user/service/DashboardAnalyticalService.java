package com.billdog.user.service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberProduct;
import com.billdog.user.repository.MemberProductRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.view.CasesSummaryView;
import com.billdog.user.view.DashboardAnalyticalView;
import com.billdog.user.view.DashboardResponseView;
import com.billdog.user.view.MemberProductSummaryView;
import com.billdog.user.view.MemberSummaryView;

@Service
public class DashboardAnalyticalService {

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	MemberProductRepository memberProductRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	CaseService caseService;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(DashboardAnalyticalService.class);

	public DashboardResponseView dashboardAnalyticalData() {

		List<MemberSummaryView> MemberSummaryList = new ArrayList<>();

		MemberSummaryView memberSummaryView = new MemberSummaryView();
		List<Member> member = memberRepository.findAll();
		long pendingMembers = member.stream()
				.filter(members -> members.getStatus().equalsIgnoreCase(StatusConstants.PENDING)).count();
		memberSummaryView.setPending(pendingMembers);
		long enrolledMembers = member.stream()
				.filter(members -> members.getStatus().equalsIgnoreCase(StatusConstants.ENROLLED)).count();
		memberSummaryView.setEnrolled(enrolledMembers);
		long activeMembers = member.stream()
				.filter(members -> members.getStatus().equalsIgnoreCase(StatusConstants.ACTIVE)).count();
		memberSummaryView.setActive(activeMembers);
		long activatedMembers = member.stream()
				.filter(members -> members.getStatus().equalsIgnoreCase(StatusConstants.ACTIVATED)).count();
		memberSummaryView.setActivated(activatedMembers);
		long terminatedMembers = member.stream()
				.filter(members -> members.getStatus().equalsIgnoreCase(StatusConstants.TERMINATED)).count();
		memberSummaryView.setTerminated(terminatedMembers);
		long disabledMembers = member.stream()
				.filter(members -> members.getStatus().equalsIgnoreCase(StatusConstants.DISABLED)).count();
		memberSummaryView.setDisabled(disabledMembers);
		memberSummaryView.setTotal((double) member.size());

		LocalDate currentMonthFirstDate = LocalDate.now().withDayOfMonth(1);
		LocalDate lastMonthFirstDate = YearMonth.now().minusMonths(1).atDay(1);
		LocalDate lastMonthTodayDate = LocalDate.now().minusMonths(1);

		LocalDate localDate = LocalDate.now();

		Long familyMemberCount = memberRepository.getSumOfMembers(currentMonthFirstDate, localDate);

		Long familyMemberCountPreMonth = memberRepository.getSumOfMembers(lastMonthFirstDate, lastMonthTodayDate);

		if (familyMemberCount != 0) {
			Long difference = familyMemberCount - familyMemberCountPreMonth;
			Double MemberPercentage = (Double) ((difference.doubleValue() / familyMemberCount.doubleValue())
					* Constants.HUNDRED);

			memberSummaryView.setMemberGrowth(MemberPercentage);
		} else {
			memberSummaryView.setMemberGrowth(null);
		}

		MemberSummaryList.add(memberSummaryView);

		// List<MemberProduct> memberProductEntity = memberProductRepository.findAll();

		List<MemberProductSummaryView> memberProductSummaryList = new ArrayList<>();
		MemberProductSummaryView MemberProductSummaryView = new MemberProductSummaryView();

		Long singleMember = memberRepository.getSingleMembers();
		MemberProductSummaryView.setSingle(singleMember);
		Long marriedMember = memberRepository.getMarriedMembers();
		MemberProductSummaryView.setMarried(marriedMember);
		Long familyMember = memberRepository.getFamilyMembers();
		MemberProductSummaryView.setFamily(familyMember);

		MemberProductSummaryView.setTotal(singleMember + marriedMember + familyMember);
		memberProductSummaryList.add(MemberProductSummaryView);

		CasesSummaryView infoResponse = caseService.getCaseInfo();
		List<CasesSummaryView> casesSummaryList = new ArrayList<>();
		CasesSummaryView casesSummaryView = new CasesSummaryView();
		casesSummaryView.setClosedCases(infoResponse.getClosedCases());
		casesSummaryView.setOpenCases(infoResponse.getOpenCases());
		casesSummaryView.setTotalCases(infoResponse.getClosedCases() + infoResponse.getOpenCases());
		casesSummaryView.setCaseGrowth(infoResponse.getCaseGrowth());
		casesSummaryList.add(casesSummaryView);

		DashboardAnalyticalView dashboardAnalyticalView = new DashboardAnalyticalView();
		dashboardAnalyticalView.setMemberSummaryList(MemberSummaryList);
		dashboardAnalyticalView.setMemberProductSummaryList(memberProductSummaryList);
		dashboardAnalyticalView.setCasesSummaryList(casesSummaryList);

		DashboardResponseView viewResponse = new DashboardResponseView();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.DASHBOARD_ANALYTICS);
		viewResponse.setData(dashboardAnalyticalView);
		return viewResponse;

	}

}
