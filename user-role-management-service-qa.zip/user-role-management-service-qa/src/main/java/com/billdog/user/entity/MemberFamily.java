package com.billdog.user.entity;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.apache.commons.text.WordUtils;
import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.request.FamilyMemberRequest;

@Entity(name = "MEMBER_FAMILY")
@Table(name = "member_family", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "org_member_index", columnList = "MEMBER_ID,ORGANIZATION_ID", unique = false),
		@Index(name = "member_index", columnList = "MEMBER_ID", unique = false) })
public class MemberFamily extends BaseEntity {

	@Audited
	@Column(name = "first_name")
	private String firstName;
	@Audited
	@Column(name = "last_name")
	private String lastName;
	@Audited
	@Column(name = "middle_name")
	private String middleName;
	@Audited
	@Column(name = "status")
	private String status;
	@Audited
	@Column(name = "date_of_birth")
	private LocalDate dateOfBirth;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "name_prefix_master")
	private NamePrefixMaster namePrefixMaster;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "RELATIONSHIP_MASTER_ID")
	private RelationshipMaster relationShipMasterId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "MEMBER_ID")
	private Member memberId;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Audited
	@Column(name = "is_deleted")
	private boolean isDeleted;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "USER_ID")
	private SystemUsers userId;

	public MemberFamily(Member member, NamePrefixMaster namePrefixMaster2, RelationshipMaster relationshipMaster,
			FamilyMemberRequest familyMemberRequest) {
		this.dateOfBirth = DateAndTimeUtil.stringDateToLocalDate(familyMemberRequest.getDateOfBirth());
		this.firstName = WordUtils.capitalizeFully(familyMemberRequest.getFirstName());
		this.lastName = WordUtils.capitalizeFully(familyMemberRequest.getLastName());
		this.middleName = WordUtils.capitalizeFully(familyMemberRequest.getMiddleName());
		if (namePrefixMaster2 != null) {
			this.namePrefixMaster = namePrefixMaster2;
		}
		if (relationshipMaster != null) {
			this.relationShipMasterId = relationshipMaster;
		}
		this.memberId = member;
		this.status = StatusConstants.ACTIVE;
		this.organizationId = member.getOrganizationId();
		setCreatedAt(DateAndTimeUtil.now());
		setUpdatedAt(DateAndTimeUtil.now());
	}

	public MemberFamily() {

	}

	public boolean isDeleted() {
		return isDeleted;
	}

	public void setDeleted(boolean isDeleted) {
		this.isDeleted = isDeleted;
	}

	public RelationshipMaster getRelationShipMasterId() {
		return relationShipMasterId;
	}

	public void setRelationShipMasterId(RelationshipMaster relationShipMasterId) {
		this.relationShipMasterId = relationShipMasterId;
	}

	public Member getMemberId() {
		return memberId;
	}

	public void setMemberId(Member memberId) {
		this.memberId = memberId;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public NamePrefixMaster getNamePrefixMaster() {
		return namePrefixMaster;
	}

	public void setNamePrefixMaster(NamePrefixMaster namePrefixMaster) {
		this.namePrefixMaster = namePrefixMaster;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getMiddleName() {
		return middleName;
	}

	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public SystemUsers getUserId() {
		return userId;
	}

	public void setUserId(SystemUsers userId) {
		this.userId = userId;
	}

}
