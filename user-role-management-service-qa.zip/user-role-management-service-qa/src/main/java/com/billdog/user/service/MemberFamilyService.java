package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.transaction.Transactional;

import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberFamily;
import com.billdog.user.entity.NamePrefixMaster;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.RelationshipMaster;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.FamilyMemberNotFoundException;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.repository.MemberFamilyRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.NamePrefixMasterRepository;
import com.billdog.user.repository.RelationshipMasterRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.AddFamilyDetailsListRequest;
import com.billdog.user.request.AddFamilyMemberRequest;
import com.billdog.user.request.FamilyMemberRequest;
import com.billdog.user.request.UpdateFamilyMemberRequest;
import com.billdog.user.view.FamilyMemberInfo;
import com.billdog.user.view.NamePrefix;
import com.billdog.user.view.RelationshipInfo;
import com.billdog.user.view.ViewMemberResponse;
import com.billdog.user.view.ViewResponse;

@Service
public class MemberFamilyService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MemberFamilyService.class);

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	NamePrefixMasterRepository namePrefixMasterRepository;

	@Autowired
	RelationshipMasterRepository relationshipMasterRepository;

	@Autowired
	MemberFamilyRepository memberFamilyRepository;

	@Autowired
	MemberService memberService;

	@Autowired
	SystemUsersrepository systemUserepository;

	@Autowired
	LoginService loginService;

	@Transactional
	public ViewMemberResponse addFamilyMemberInfo(AddFamilyDetailsListRequest addFamilyDetailsListRequest) {
		LOGGER.info("addFamilyMemberInfo strated..");

		Optional<SystemUsers> user = systemUserepository.findById(addFamilyDetailsListRequest.getUserId());

		Optional<Member> member = memberRepository.findById(addFamilyDetailsListRequest.getMemberId());
		if (!member.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FOUND);
		}
		if (member.get().getProductId() == null) {
			throw new MemberNotFoundException(ExceptionalMessages.PRODUCT_TYPE);
		}
		LOGGER.debug("checking whether member product type is single or not");
		if (member.get().getProductId().getProductName().equalsIgnoreCase("Single")) {
			throw new MemberNotFoundException(ExceptionalMessages.PRODUCT_NAME);
		}
		MemberFamily memberFamily = new MemberFamily();
		List<MemberFamily> memberFamilyList = new ArrayList<>();
		addFamilyDetailsListRequest.getFamilyDetailsList().forEach(addFamily -> {

			Optional<RelationshipMaster> relationshipMaster = relationshipMasterRepository
					.findById(addFamily.getRelationshipId());
			if (!relationshipMaster.isPresent()) {
				throw new MemberNotFoundException(ExceptionalMessages.RELATIONSHIP_NOT_FORUND_WITH_ID);
			}

			if (member.get().getProductId().getProductName().equalsIgnoreCase("Married")
					&& relationshipMaster.get().getRelationshipName().equalsIgnoreCase("Child")) {
				throw new InValidInputException(ExceptionalMessages.UPGRADE_YOUR_PRODUCT_TYPE_TO_FAMILY);
			}
			LOGGER.debug("checking whether how many family members are added till now");
			List<MemberFamily> memberFamilyEntity = memberFamilyRepository.findByMemberIdAndIsDeleted(member.get(),
					false);
			if (!memberFamilyEntity.isEmpty()) {
				if (memberFamilyEntity.size() >= 7) {
					throw new InValidInputException(ExceptionalMessages.FAMILY_DETAILS);
				}
				memberFamilyEntity.forEach(familyMember -> {
					if (member.get().getProductId().getProductName().equalsIgnoreCase("Married")) {
						if (familyMember.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Spouse")
								&& relationshipMaster.get().getRelationshipName().equalsIgnoreCase("Spouse")) {
							throw new MemberNotFoundException(ExceptionalMessages.SPOUSE);
						}
					}
					if (member.get().getProductId().getProductName().equalsIgnoreCase("Family")) {
						if (familyMember.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Spouse")
								&& relationshipMaster.get().getRelationshipName().equalsIgnoreCase("Spouse")) {
							throw new MemberNotFoundException(ExceptionalMessages.SPOUSE);
						}
					}
				});

			}
			if (addFamily.getFirstName() == null && !addFamily.getFirstName().isEmpty()) {
				throw new InValidInputException(ExceptionalMessages.FIRST_NAME_NOT_NULL);

			} else if (addFamily.getFirstName().length() < 2 || addFamily.getFirstName().length() > 20) {
				throw new InValidInputException(ExceptionalMessages.FIRST_NAME);
			}

			if (addFamily.getLastName() == null && !addFamily.getLastName().isEmpty()) {
				throw new InValidInputException(ExceptionalMessages.LAST_NAME_NOT_NULL);

			} else if (addFamily.getLastName().length() < 2 || addFamily.getLastName().length() > 20) {
				throw new InValidInputException(ExceptionalMessages.LAST_NAME);
			}
			if (addFamily.getRelationshipId() == null) {
				throw new InValidInputException(ExceptionalMessages.RELATIONSHIP);
			}
			if (addFamily.getDateOfBirth() == null) {
				throw new InValidInputException(ExceptionalMessages.DOB);
			}
			LOGGER.debug("adding member family in memberfamily table..");
			memberFamily.setCreatedAt(DateAndTimeUtil.now());
			memberFamily.setUpdatedAt(DateAndTimeUtil.now());
			memberFamily.setFirstName(WordUtils.capitalizeFully(addFamily.getFirstName()));
			memberFamily.setLastName(WordUtils.capitalizeFully(addFamily.getLastName()));
			memberFamily.setMiddleName(WordUtils.capitalizeFully(addFamily.getMiddleName()));
			memberFamily.setRelationShipMasterId(relationshipMaster.get());
			Optional<NamePrefixMaster> namePrefixMaster = namePrefixMasterRepository.findById(addFamily.getPrefixId());
			if (namePrefixMaster.isPresent()) {
				memberFamily.setNamePrefixMaster(namePrefixMaster.get());
			}
			memberFamily.setMemberId(member.get());
			memberFamily.setDateOfBirth(DateAndTimeUtil.stringDateToLocalDate(addFamily.getDateOfBirth()));
			memberFamily.setStatus(StatusConstants.ACTIVE);
			if (user.isPresent()) {

				memberFamily.setUserId(user.get());
			} else {

				memberFamily.setUserId(null);
			}
			memberFamilyList.add(memberFamily);
		});
		memberFamilyRepository.saveAll(memberFamilyList);
		LOGGER.info("Family member deatils saved");
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMemberId(addFamilyDetailsListRequest.getMemberId());
		viewResponse.setId(memberFamily.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessageTitle("Success!");
		viewResponse.setMessage(Constants.MEMBER_FAMILY_DETAILS);
		LOGGER.info("addFamilyMemberInfo ended..");
		return viewResponse;
	}

	public MemberFamily updateFamilyMember(MemberFamily memberFamily, FamilyMemberRequest familyMemberRequest,
			SystemUsers user) {
		if (familyMemberRequest.getPrefixId() != null) {
			Optional<NamePrefixMaster> namePrefix = namePrefixMasterRepository
					.findById(familyMemberRequest.getPrefixId());
			if (namePrefix.isPresent()) {
				memberFamily.setNamePrefixMaster(namePrefix.get());
			}
		}

		if (familyMemberRequest.getRelationshipId() != null
				&& !familyMemberRequest.getRelationshipId().equals(memberFamily.getRelationShipMasterId().getId())) {
			Optional<RelationshipMaster> relationship = relationshipMasterRepository
					.findById(familyMemberRequest.getRelationshipId());
			if (!relationship.isPresent()) {
				throw new MemberNotFoundException(ExceptionalMessages.RELATIONSHIP_NOT_FORUND_WITH_ID);
			}
			memberFamily.setRelationShipMasterId(relationship.get());
		}
		memberFamily.setDateOfBirth(DateAndTimeUtil.stringDateToLocalDate(familyMemberRequest.getDateOfBirth()));
		memberFamily.setFirstName(WordUtils.capitalizeFully(familyMemberRequest.getFirstName()));
		memberFamily.setLastName(WordUtils.capitalizeFully(familyMemberRequest.getLastName()));
		memberFamily.setMiddleName(WordUtils.capitalizeFully(familyMemberRequest.getMiddleName()));
		memberFamily.setUpdatedAt(DateAndTimeUtil.now());
		memberFamily.setUserId(user);
		return memberFamilyRepository.save(memberFamily);
	}

	public ViewMemberResponse updateFamilyMember(FamilyMemberRequest familyMemberRequest, Long familyMemberId) {
		LOGGER.info("updateFamilyMember method started..");
		Optional<MemberFamily> familyMember = memberFamilyRepository.findById(familyMemberId);
		if (!familyMember.isPresent()) {
			throw new FamilyMemberNotFoundException(ExceptionalMessages.FAMILY_MEMBER_NOT_FORUND_WITH_ID);
		}
		if (familyMemberRequest.getRelationshipId() != null) {
			Optional<RelationshipMaster> relationship = relationshipMasterRepository
					.findById(familyMemberRequest.getRelationshipId());
			if (relationship.isPresent()) {
				// familyMember.get().setRelationShipMasterId(relationship.get());
			}

			List<MemberFamily> memberFamilyEntity = memberFamilyRepository
					.findByMemberIdAndIsDeleted(familyMember.get().getMemberId(), false);
			if (!memberFamilyEntity.isEmpty()) {
				memberFamilyEntity.forEach(family -> {
					if (relationship.get().getRelationshipName() != null
							&& !relationship.get().getRelationshipName().isEmpty()
							&& family.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Spouse")
							&& relationship.get().getRelationshipName().equalsIgnoreCase("Spouse")
							&& family.getId() != familyMemberId) {
						throw new InValidInputException(ExceptionalMessages.SPOUSE);
					}
				});
			}
		}
		updateFamilyMember(familyMember.get(), familyMemberRequest, null);
		ViewMemberResponse response = new ViewMemberResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessageTitle("Success!");
		response.setMessage(Constants.FAMILY_MEMBER_INFO_UPDATED);
		LOGGER.info("updateFamilyMember method ended..");
		return response;
	}

	public ViewMemberResponse updateFamilyMemberByUser(FamilyMemberRequest familyMemberRequest, Long familyMemberId,
			Long userId) {
		LOGGER.info("updateFamilyMember method started..");
		Optional<MemberFamily> familyMember = memberFamilyRepository.findById(familyMemberId);
		SystemUsers user = loginService.getSystemUsers(userId);
		if (!familyMember.isPresent()) {
			throw new FamilyMemberNotFoundException(ExceptionalMessages.FAMILY_MEMBER_NOT_FORUND_WITH_ID);
		}
		if (familyMemberRequest.getRelationshipId() != null) {
			Optional<RelationshipMaster> relationship = relationshipMasterRepository
					.findById(familyMemberRequest.getRelationshipId());
			if (relationship.isPresent()) {
				// familyMember.get().setRelationShipMasterId(relationship.get());
			}

			List<MemberFamily> memberFamilyEntity = memberFamilyRepository
					.findByMemberIdAndIsDeleted(familyMember.get().getMemberId(), false);
			if (!memberFamilyEntity.isEmpty()) {
				memberFamilyEntity.forEach(family -> {
					if (relationship.get().getRelationshipName() != null
							&& !relationship.get().getRelationshipName().isEmpty()
							&& family.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Spouse")
							&& relationship.get().getRelationshipName().equalsIgnoreCase("Spouse")
							&& family.getId() != familyMemberId) {
						throw new InValidInputException(ExceptionalMessages.SPOUSE);
					}
				});
			}
		}
		updateFamilyMember(familyMember.get(), familyMemberRequest, user);
		ViewMemberResponse response = new ViewMemberResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.FAMILY_MEMBER_INFO_UPDATED);
		LOGGER.info("updateFamilyMember method ended..");
		return response;
	}

	public ViewMemberResponse getFamilyMembers(Long memberId) {
		LOGGER.info("getFamilyMembers method started..");
		Member member = memberService.getMember(memberId);
		List<MemberFamily> familymeMembers = memberFamilyRepository.findByMemberIdAndIsDeleted(member, false);
		ViewMemberResponse response = new ViewMemberResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMemberId(memberId);
		response.setData(familymeMembers.stream().map(familyMember -> setFamilyMemberInfo(familyMember))
				.collect(Collectors.toList()));
		LOGGER.info("getFamilyMembers method ended..");
		return response;
	}

	private FamilyMemberInfo setFamilyMemberInfo(MemberFamily familyMember) {
		FamilyMemberInfo familyMemberInfo = new FamilyMemberInfo();
		familyMemberInfo.setDateOfBirth(DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMember.getDateOfBirth()));
		familyMemberInfo.setFirstName(familyMember.getFirstName());
		familyMemberInfo.setLastName(familyMember.getLastName());
		familyMemberInfo.setRelationship(familyMember.getRelationShipMasterId().getRelationshipName());
		familyMemberInfo.setMiddleName(familyMember.getMiddleName());
		familyMemberInfo.setFamilyMemberId(familyMember.getId());
		if (familyMember.getNamePrefixMaster() != null) {
			familyMemberInfo.setPrefixId(familyMember.getNamePrefixMaster().getId());
			familyMemberInfo.setPrefixName(familyMember.getNamePrefixMaster().getPrefix());
		}
		familyMemberInfo.setRelationshipId(familyMember.getRelationShipMasterId().getId());
		familyMemberInfo.setStatus(familyMember.getStatus());
		return familyMemberInfo;
	}

	public ViewMemberResponse getNamePrefix(Long memberId, Long userId) {
		LOGGER.info("getNamePrefix method started..");
		Organization organization = memberService.getOrganization(userId, memberId);
		List<NamePrefixMaster> namePrefixList = namePrefixMasterRepository.findByOrganizationIdAndStatus(organization,
				StatusConstants.ACTIVE);
		LOGGER.info("Fetched name prefix  list from system for organizationId:: {}", organization.getId());
		ViewMemberResponse response = new ViewMemberResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMemberId(memberId);
		response.setData(
				namePrefixList.stream().map(namePrefix -> setNamePrefixInfo(namePrefix)).collect(Collectors.toList()));
		LOGGER.info("getNamePrefix method ended..");
		return response;
	}

	public ViewResponse getNamePrefixByUser(Long userId) {
		LOGGER.info("getNamePrefix method started..");
		SystemUsers user = loginService.getSystemUsers(userId);
		List<NamePrefixMaster> namePrefixList = namePrefixMasterRepository
				.findByOrganizationIdAndStatus(user.getOrganizationId(), StatusConstants.ACTIVE);
		LOGGER.info("Fetched name prefix  list from system for organizationId:: {}", user.getOrganizationId());
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setUserId(userId);
		response.setData(
				namePrefixList.stream().map(namePrefix -> setNamePrefixInfo(namePrefix)).collect(Collectors.toList()));
		LOGGER.info("getNamePrefix method ended..");
		return response;
	}

	private NamePrefix setNamePrefixInfo(NamePrefixMaster prefixMaster) {
		NamePrefix namePrefix = new NamePrefix();
		namePrefix.setPrefixId(prefixMaster.getId());
		namePrefix.setPrefixName(prefixMaster.getPrefix());
		return namePrefix;
	}

	private RelationshipInfo setRelationshipInfo(RelationshipMaster relationship) {
		RelationshipInfo relationshipInfo = new RelationshipInfo();
		relationshipInfo.setRelationshipId(relationship.getId());
		relationshipInfo.setRelationshipName(relationship.getRelationshipName());
		return relationshipInfo;
	}

	public ViewMemberResponse getRelationshipInfo(Long userId, Long memberId) {
		LOGGER.info("getRelationshipInfo method started..");
		Organization organization = memberService.getOrganization(userId, memberId);
		List<RelationshipMaster> relationshipList = relationshipMasterRepository
				.findByOrganizationIdAndStatus(organization, StatusConstants.ACTIVE);
		LOGGER.info("Fetched relationship list from system for organizationId:: {}", organization.getId());
		ViewMemberResponse response = new ViewMemberResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMemberId(memberId);
		response.setData(relationshipList.stream().map(relationship -> setRelationshipInfo(relationship))
				.collect(Collectors.toList()));
		LOGGER.info("getRelationshipInfo method ended..");
		return response;
	}

	public ViewMemberResponse updateFamilyMemberStatus(Long memberId, Long familyMemberId) {
		LOGGER.info("updateFamilyMemberStatus method started..");
		Member member = memberService.getMember(memberId);
		Optional<MemberFamily> familyMember = memberFamilyRepository.findByIdAndMemberId(familyMemberId, member);
		if (!familyMember.isPresent()) {
			throw new FamilyMemberNotFoundException(ExceptionalMessages.FAMILY_MEMBER_NOT_FORUND_WITH_ID);
		}
		familyMember.get().setStatus(StatusConstants.INACTIVE);
		memberFamilyRepository.save(familyMember.get());
		ViewMemberResponse response = new ViewMemberResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.FAMILY_MEMBER_REMOVED);
		LOGGER.info("updateFamilyMemberStatus method ended..");
		return response;
	}

	@Transactional
	public ViewMemberResponse addFamilyMemberInfoForMobile(AddFamilyMemberRequest addFamilyDetailsListRequest) {
		LOGGER.info("addFamilyMemberInfo strated..");

		Optional<Member> member = memberRepository.findById(addFamilyDetailsListRequest.getMemberId());
		if (!member.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FOUND);
		}
		LOGGER.debug("checking whether member product type is single or not");
		if (member.get().getProductId().getProductName().equalsIgnoreCase("Single")) {
			throw new MemberNotFoundException(ExceptionalMessages.PRODUCT_NAME);
		}
		Optional<RelationshipMaster> relationshipMaster = relationshipMasterRepository
				.findById(addFamilyDetailsListRequest.getRelationshipId());
		if (!relationshipMaster.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.RELATIONSHIP_NOT_FORUND_WITH_ID);
		}
		if (member.get().getProductId().getProductName().equalsIgnoreCase("Married")
				&& relationshipMaster.get().getRelationshipName().equalsIgnoreCase("Child")) {
			throw new InValidInputException(ExceptionalMessages.UPGRADE_YOUR_PRODUCT_TYPE_TO_FAMILY);
		}
		LOGGER.debug("checking whether how many family members are added till now");
		List<MemberFamily> memberFamilyEntity = memberFamilyRepository.findByMemberIdAndIsDeleted(member.get(), false);
		if (!memberFamilyEntity.isEmpty()) {
			if (memberFamilyEntity.size() >= 7) {
				throw new InValidInputException(ExceptionalMessages.FAMILY_DETAILS);
			}
			memberFamilyEntity.forEach(familyMember -> {
				if (member.get().getProductId().getProductName().equalsIgnoreCase("Married")) {
					if (familyMember.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Spouse")
							&& relationshipMaster.get().getRelationshipName().equalsIgnoreCase("Spouse")) {
						throw new InValidInputException(ExceptionalMessages.SPOUSE);
					}
				}
				if (member.get().getProductId().getProductName().equalsIgnoreCase("Family")) {
					if (familyMember.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Spouse")
							&& relationshipMaster.get().getRelationshipName().equalsIgnoreCase("Spouse")) {
						throw new InValidInputException(ExceptionalMessages.SPOUSE);
					}
				}
			});
		}
		MemberFamily memberFamily = new MemberFamily();
		LOGGER.debug("adding member family in memberfamily table..");
		memberFamily.setCreatedAt(DateAndTimeUtil.now());
		memberFamily.setUpdatedAt(DateAndTimeUtil.now());
		memberFamily.setFirstName(WordUtils.capitalizeFully(addFamilyDetailsListRequest.getFirstName()));
		memberFamily.setLastName(WordUtils.capitalizeFully(addFamilyDetailsListRequest.getLastName()));
		memberFamily.setMiddleName(WordUtils.capitalizeFully(addFamilyDetailsListRequest.getMiddleName()));
		memberFamily.setRelationShipMasterId(relationshipMaster.get());
		Optional<NamePrefixMaster> namePrefixMaster = namePrefixMasterRepository
				.findById(addFamilyDetailsListRequest.getPrefixId());
		if (namePrefixMaster.isPresent()) {
			memberFamily.setNamePrefixMaster(namePrefixMaster.get());
		}
		memberFamily.setMemberId(member.get());
		memberFamily
				.setDateOfBirth(DateAndTimeUtil.stringDateToLocalDate(addFamilyDetailsListRequest.getDateOfBirth()));
		memberFamily.setStatus(StatusConstants.ACTIVE);
		memberFamilyRepository.save(memberFamily);
		LOGGER.info("Family member deatils saved");

		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMemberId(addFamilyDetailsListRequest.getMemberId());
		viewResponse.setId(memberFamily.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.MEMBER_FAMILY_ADDED);
		LOGGER.info("addFamilyMemberInfo ended..");
		return viewResponse;
	}

	public MemberFamily updateFamilyMemberForMobile(MemberFamily memberFamily,
			UpdateFamilyMemberRequest familyMemberRequest) {
		boolean updated = false;
		if (familyMemberRequest.getRelationshipId() != null
				&& !familyMemberRequest.getRelationshipId().equals(memberFamily.getRelationShipMasterId().getId())) {
			Optional<RelationshipMaster> relationship = relationshipMasterRepository
					.findById(familyMemberRequest.getRelationshipId());
			if (relationship.isPresent()) {
				if (familyMemberRequest.getRelationshipId() != null && !familyMemberRequest.getRelationshipId()
						.equals(memberFamily.getRelationShipMasterId().getId())) {
					memberFamily.setRelationShipMasterId(relationship.get());
					updated = true;
				}
			}
		}
		if ((memberFamily.getNamePrefixMaster() == null && familyMemberRequest.getPrefixId() != null)
				|| (familyMemberRequest.getPrefixId() != null
						&& memberFamily.getNamePrefixMaster() != null
						&& !familyMemberRequest.getPrefixId().equals(memberFamily.getNamePrefixMaster().getId()))) {
			Optional<NamePrefixMaster> namePrefix = namePrefixMasterRepository
					.findById(familyMemberRequest.getPrefixId());
			if (namePrefix.isPresent()) {
				memberFamily.setNamePrefixMaster(namePrefix.get());
				updated = true;
			}
		}
		LOGGER.info("member date of birth" + memberFamily.getDateOfBirth());
		LOGGER.info("member request date of birth" + familyMemberRequest.getDateOfBirth());
		if (!memberFamily.getDateOfBirth()
				.equals(DateAndTimeUtil.stringDateToLocalDate(familyMemberRequest.getDateOfBirth()))) {
			memberFamily.setDateOfBirth(DateAndTimeUtil.stringDateToLocalDate(familyMemberRequest.getDateOfBirth()));
			updated = true;
		}
		if (!memberFamily.getFirstName().equalsIgnoreCase(familyMemberRequest.getFirstName())) {
			memberFamily.setFirstName(WordUtils.capitalizeFully(familyMemberRequest.getFirstName()));
			updated = true;
		}
		if (!memberFamily.getLastName().equalsIgnoreCase(familyMemberRequest.getLastName())) {
			memberFamily.setLastName(WordUtils.capitalizeFully(familyMemberRequest.getLastName()));
			updated = true;
		}
		if (!memberFamily.getMiddleName().equalsIgnoreCase(familyMemberRequest.getMiddleName())) {
			memberFamily.setMiddleName(WordUtils.capitalizeFully(familyMemberRequest.getMiddleName()));
			updated = true;
		}
		if (updated) {
			memberFamily.setUpdatedAt(DateAndTimeUtil.now());
			memberFamilyRepository.save(memberFamily);
		}
		return memberFamily;

	}

	public ViewMemberResponse updateFamilyMemberForMobile(UpdateFamilyMemberRequest familyMemberRequest,
			Long familyMemberId) {
		LOGGER.info("updateFamilyMember method started..");
		Optional<MemberFamily> familyMember = memberFamilyRepository.findById(familyMemberId);
		if (!familyMember.isPresent()) {
			throw new FamilyMemberNotFoundException(ExceptionalMessages.FAMILY_MEMBER_NOT_FORUND_WITH_ID);
		}
		if (familyMemberRequest.getRelationshipId() != null) {
			Optional<RelationshipMaster> relationship = relationshipMasterRepository
					.findById(familyMemberRequest.getRelationshipId());
			if (relationship.isPresent()) {
				// familyMember.get().setRelationShipMasterId(relationship.get());

				Optional<Member> member = memberRepository.findById(familyMemberRequest.getMemberId());
				if (member.isPresent()) {
					if (member.get().getProductId().getProductName().equalsIgnoreCase("Married")
							&& relationship.get().getRelationshipName().equalsIgnoreCase("Child")) {
						throw new InValidInputException(ExceptionalMessages.UPGRADE_YOUR_PRODUCT_TYPE_TO_FAMILY);
					}
					List<MemberFamily> memberFamilyEntity = memberFamilyRepository
							.findByMemberIdAndIsDeleted(familyMember.get().getMemberId(), false);
					if (!memberFamilyEntity.isEmpty()) {
						memberFamilyEntity.forEach(family -> {
							if (relationship.get().getRelationshipName() != null
									&& !relationship.get().getRelationshipName().isEmpty()
									&& family.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Spouse")
									&& relationship.get().getRelationshipName().equalsIgnoreCase("Spouse")) {
								throw new InValidInputException(ExceptionalMessages.SPOUSE);
							}
						});
					}
				}
			}
		}
		updateFamilyMemberForMobile(familyMember.get(), familyMemberRequest);

		ViewMemberResponse response = new ViewMemberResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.FAMILY_MEMBER_INFO_UPDATED);
		LOGGER.info("updateFamilyMember method ended..");
		return response;
	}

}
