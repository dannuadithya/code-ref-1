package com.billdog.user.request;

import java.util.List;

public class GetMembersRequest {

	private Long userId;
	private List<Long> memberIds;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public List<Long> getMemberIds() {
		return memberIds;
	}

	public void setMemberIds(List<Long> memberIds) {
		this.memberIds = memberIds;
	}

}
