package com.billdog.user.service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.request.SearchDirectMember;
import com.billdog.user.view.SerachMemberDetails;
import com.billdog.user.view.ViewResponse;

@Service
public class GetMemberService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GetMemberService.class);

	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Value("${passcode.email.times}")
	private int passcodeTimes;

	@Value("${passcode.length}")
	private int passcodeLength;

	@Autowired
	EmailService emailService;

	@Autowired
	LoginService loginService;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	MemberRepository memberRepository;

	/*
	 * This method will take userid and provides list of direct members.
	 */
	public ViewResponse getDirectMembers(SearchDirectMember searchDirectMember) {
		LOGGER.info("Get direct members method started");

		int pageNumber = searchDirectMember.getPageNumber() != null ? searchDirectMember.getPageNumber() : 0;
		int pageLimit = (searchDirectMember.getPageLimit() != null && searchDirectMember.getPageLimit() > 0)
				? searchDirectMember.getPageLimit()
				: 10;
		String firstName = "";
		String lastName = "";
		String email = "";
		String sfdcId = "";
		String mobileNumber = "";
		String status = "";
		SystemUsers systemUsers = loginService.getSystemUsers(searchDirectMember.getUserId());
		if (searchDirectMember.getName() != null && !searchDirectMember.getName().equals("")) {
			firstName = "%" + searchDirectMember.getName() + "%";
			lastName = "%" + searchDirectMember.getName() + "%";
		}
		if (searchDirectMember.getEmail() != null && !searchDirectMember.getEmail().equals("")) {
			email = "%" + searchDirectMember.getEmail() + "%";
		}
		if (searchDirectMember.getSfdcId() != null && !searchDirectMember.getSfdcId().equals("")) {
			sfdcId = "%" + searchDirectMember.getSfdcId() + "%";
		}
		if (searchDirectMember.getMobileNumber() != null && !searchDirectMember.getMobileNumber().equals("")) {
			mobileNumber = "%" + searchDirectMember.getMobileNumber() + "%";
		}
		if (searchDirectMember.getStatus() != null && !searchDirectMember.getStatus().equals("")) {
			status = "%" + searchDirectMember.getStatus() + "%";
		}
		String memberId = searchDirectMember.getMemberId();

		LOGGER.info("Fetching all direct members from the system by applying filters");
		Page<Object[][]> members = memberRepository.getAllDirectMembers(firstName, firstName, lastName, lastName,
				mobileNumber, mobileNumber, email, email, sfdcId, sfdcId, status, status, memberId, memberId,
				systemUsers.getOrganizationId().getId(),
				StatusConstants.DIRECT, getPageRequest(pageNumber, pageLimit));

		List<SerachMemberDetails> memberDetails = getMembers(members);
		ViewResponse response = new ViewResponse();
		response.setUserId(searchDirectMember.getUserId());
		response.setTotal(members.getTotalElements());
		if (memberDetails.isEmpty()) {
			LOGGER.info("Setting a message when no results found in database for given input");
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		response.setData(memberDetails);
		response.setStatusText(Constants.SUCCESS);
		LOGGER.info("Get direct members method ended");
		return response;
	}

	private List<SerachMemberDetails> getMembers(Page<Object[][]> members) {
		LOGGER.info("Rendering all direct members to response data");
		List<SerachMemberDetails> memberDetails = new ArrayList<>();
		for (Object[] member : members) {
			SerachMemberDetails newMember = new SerachMemberDetails();
			newMember.setId(((BigInteger) member[0]).longValue());
			newMember.setFirstName(((String) member[1]));
			newMember.setLastName(((String) member[2]));
			newMember.setEmail((String) member[3]);
			newMember.setMobileNumber((String) member[4]);
			newMember.setSfdcId((String) member[5]);
			newMember.setStatus((String) member[6]);
			newMember.setMemberId((String) member[8]);
			memberDetails.add(newMember);
		}
		LOGGER.info("Rendered all direct members to response data");
		return memberDetails;
	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}
}
