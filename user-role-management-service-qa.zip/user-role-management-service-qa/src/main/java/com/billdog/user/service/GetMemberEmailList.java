package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.view.EmailListForMember;
import com.billdog.user.view.ViewMemberResponse;

@Service
public class GetMemberEmailList {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MemberService.class);

	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Autowired
	MemberRepository memberRepository;

	public ResponseEntity<ViewMemberResponse> getMemberEmailList(Long memberId) {
		LOGGER.info("getMemberEmailList method started..");
		// creating array list for EmailListForMember

		List<EmailListForMember> EmailListForMemberList = new ArrayList<>();

		Optional<Member> member = memberRepository.findById(memberId);
		if (!member.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		List<MemberEmail> memberEmail = memberEmailRepository.findByMemberId(member.get());
		if (memberEmail.isEmpty()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		memberEmail.forEach(email -> {
			EmailListForMember emailListForMember = new EmailListForMember();
			LOGGER.debug("looping through member email repository");
			emailListForMember.setEmail(email.getEmail());
			emailListForMember.setPrimary(email.isPrimary());
			EmailListForMemberList.add(emailListForMember);
		});

		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.EMAIL_SCREEN_MESSAGE);
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setData(EmailListForMemberList);
		LOGGER.info("getMemberEmailList method end..");
		return ResponseEntity.status(HttpStatus.OK).body(viewResponse);
	}

}
