package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "NAVIGATION_SCREENS_ROLE_MAPPING")
@Table(name = "navigation_screens_role_mapping", indexes = {
		@Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "role_org_index", columnList = "ORGANIZATION_ID,ROLE_ID", unique = false),
		@Index(name = "id_role_index", columnList = "ID,ROLE_ID", unique = false) })
public class RoleNavigationScreens extends BaseEntity {

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "ROLE_ID")
	private Roles roleId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "NAVIGATION_SCREENS_ACCESS_ID")
	private NavigationScreen navigationScreensId;

	@Audited
	@Column(name = "READ_ACCESS")
	private boolean readAccess;

	@Audited
	@Column(name = "WRITE_ACCESS")
	private boolean writeAccess;

	@Audited
	@Column(name = "CUSTOM")
	private boolean custom;

	@Audited
	@Column(name = "userId")
	private Long userId;

	@Audited
	@Column(name = "AUDIT_ID")
	private String auditId;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public Roles getRoleId() {
		return roleId;
	}

	public void setRoleId(Roles roleId) {
		this.roleId = roleId;
	}

	public NavigationScreen getNavigationScreensId() {
		return navigationScreensId;
	}

	public void setNavigationScreensId(NavigationScreen navigationScreensId) {
		this.navigationScreensId = navigationScreensId;
	}

	public boolean isReadAccess() {
		return readAccess;
	}

	public void setReadAccess(boolean readAccess) {
		this.readAccess = readAccess;
	}

	public boolean isWriteAccess() {
		return writeAccess;
	}

	public void setWriteAccess(boolean writeAccess) {
		this.writeAccess = writeAccess;
	}

	public boolean isCustom() {
		return custom;
	}

	public void setCustom(boolean custom) {
		this.custom = custom;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

}
