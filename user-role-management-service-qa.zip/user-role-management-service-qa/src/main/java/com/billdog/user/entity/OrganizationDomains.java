package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "ORGANIZATION_domains")
@Table(name = "organization_domains", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "org_index", columnList = "ORGANIZATION_ID", unique = false) })
public class OrganizationDomains extends BaseEntity {

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Column(name = "DOMAIN_URL")
	private String domainUrl;

	@Column(name = "TYPE")
	private String type;

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public String getDomainUrl() {
		return domainUrl;
	}

	public void setDomainUrl(String domainUrl) {
		this.domainUrl = domainUrl;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
