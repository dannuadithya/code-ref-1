package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.Organization;
import com.billdog.user.entity.Roles;
import com.billdog.user.entity.SystemUsers;

@Repository
public interface SystemUsersrepository extends JpaRepository<SystemUsers, Long> {

	@Query(value = "SELECT su.id,su.first_name,su.last_name,su.email,su.mobile_number,su.role_id,su.status,su.id as organizationId,r.role,su.locked,suc.last_passcode_verified,suc.last_password_verified,su.locked_from_web, su.user_type\n"
			+ "			FROM system_users su \n"
			+ "join roles r on r.id = su.role_id left join system_users_access suc on suc.user_id = su.id\n"
			+ "			where ((CASE WHEN COALESCE(?1,'') <> '' THEN su.first_name ELSE '' END LIKE COALESCE(?2,'') OR \n"
			+ "			CASE WHEN COALESCE(?3,'') <> '' THEN su.last_name ELSE '' END LIKE COALESCE(?4,'')) AND \n"
			+ "			CASE WHEN COALESCE(?5,'') <> '' THEN su.mobile_number ELSE '' END LIKE COALESCE(?6,'') AND\n"
			+ "			CASE WHEN COALESCE(?7,'') <> '' THEN su.email ELSE '' END LIKE COALESCE(?8,'') AND\n"
			+ "           CASE WHEN COALESCE(?9,-999) <> -999 THEN su.role_id ELSE -999 END = COALESCE(?10,-999)) AND CASE WHEN COALESCE(?11,'') <> '' THEN su.user_type ELSE '' END LIKE COALESCE(?12,'') and su.organization_id = ?13 and r.role not in ('Super Admin') order by su.created_at desc", countQuery = "SELECT su.id,su.first_name,su.last_name,su.email,su.mobile_number,su.role_id,su.status,su.id as organizationId,r.role,su.locked,suc.last_passcode_verified,suc.last_password_verified,su.locked_from_web, su.user_type \n"
					+ "			FROM system_users su\n"
					+ "			join roles r on r.id = su.role_id left join system_users_access suc on suc.user_id = su.id\n"
					+ "			where ((CASE WHEN COALESCE(?1,'') <> '' THEN su.first_name ELSE '' END LIKE COALESCE(?2,'') OR \n"
					+ "			CASE WHEN COALESCE(?3,'') <> '' THEN su.last_name ELSE '' END LIKE COALESCE(?4,'')) AND \n"
					+ "			CASE WHEN COALESCE(?5,'') <> '' THEN su.mobile_number ELSE '' END LIKE COALESCE(?6,'') AND\n"
					+ "			CASE WHEN COALESCE(?7,'') <> '' THEN su.email ELSE '' END LIKE COALESCE(?8,'') AND\n"
					+ "			CASE WHEN COALESCE(?9,-999) <> -999 THEN su.role_id ELSE -999 END = COALESCE(?10,-999)) AND CASE WHEN COALESCE(?11,'') <> '' THEN su.user_type ELSE '' END LIKE COALESCE(?12,'') and su.organization_id = ?13 and r.role not in ('Super Admin') order by su.created_at desc", nativeQuery = true)

	Page<Object[][]> getUserDetails(String userFirstName, String userFirstName2, String userLastName,
			String userLastName2, String mobileNumber, String mobileNumber2, String email, String email2, Long roleId,
			Long roleId2, String userType, String userType2, Long organizationId, PageRequest pageRequest);

	Optional<SystemUsers> findByRoleId(Roles role);

	Optional<SystemUsers> findByOrganizationId(Organization organization);

	Optional<SystemUsers> findByEmailAndOrganizationId(String email, Organization organization);

	Optional<SystemUsers> findByEmail(String email);

	Optional<SystemUsers> findByIdAndOrganizationId(long userId, Organization organizationId);

	/*
	 * Page<Object[][]> getAllUserDetails(String userFirstName, String
	 * userFirstName2, String userLastName, String userLastName2, String
	 * mobileNumber, String mobileNumber2, String email, String email2, Long roleId,
	 * Long roleId2, Long organizationId, PageRequest pageRequest);
	 */

	Optional<SystemUsers> findByEmailAndOrganizationIdAndStatusNot(String email, Organization organization,
			String status);

	Optional<SystemUsers> findByEmailAndStatusNot(String email, String status);

	List<SystemUsers> findAllByRoleId(Roles role);

	Optional<SystemUsers> findByEmailAndOrganizationIdAndUserType(String email, Organization organization,
			String userType);

	Optional<SystemUsers> findByEmailAndOrganizationIdAndStatusNotAndUserType(String email, Organization organizationId,
			String deleted, String string);

	@Query(value = "select sua.id,sua.revtype,sua.updated_at,sua.email,sua.first_name,sua.last_name,sua.middle_name,sua.mobile_number,\n"
			+ "       sua.status,sua.user_type,sua.name_prefix_master_id,sua.rev,sua.user_id,concat(su.first_name ,' ',su.last_name) as userName,npm.prefix , ro.role\n"
			+ "from system_users_aud sua left join system_users su on su.id = sua.user_id\n"
			+ "    left join name_prefix_master npm on npm.id = sua.name_prefix_master_id left join system_users suu on suu.id = sua.id\n"
			+ "left join roles ro on ro.id= sua.role_id\n"
			+ " where (CASE WHEN COALESCE(?1,'') <> '' THEN sua.first_name ELSE '' END LIKE COALESCE(?2,'') or \n"
			+ "CASE WHEN COALESCE(?3,'') <> '' THEN sua.last_name ELSE '' END LIKE COALESCE(?4,''))\n"
			+ "and date(sua.updated_at) BETWEEN ?5 AND ?6 and sua.revtype in ?7  and suu.organization_id =?8\n"
			+ "order by sua.updated_at desc, sua.rev desc", countQuery = "select sua.id,sua.revtype,sua.updated_at,sua.email,sua.first_name,sua.last_name,sua.middle_name,sua.mobile_number,\n"
					+ "       sua.status,sua.user_type,sua.name_prefix_master_id,sua.rev,sua.user_id,concat(su.first_name ,' ',su.last_name) as userName,npm.prefix , ro.role\n"
					+ "from system_users_aud sua left join system_users su on su.id = sua.user_id\n"
					+ "    left join name_prefix_master npm on npm.id = sua.name_prefix_master_id left join system_users suu on suu.id = sua.id\n"
					+ "left join roles ro on ro.id= sua.role_id\n "
					+ " where (CASE WHEN COALESCE(?1,'') <> '' THEN sua.first_name ELSE '' END LIKE COALESCE(?2,'') or \n"
					+ "CASE WHEN COALESCE(?3,'') <> '' THEN sua.last_name ELSE '' END LIKE COALESCE(?4,''))\n"
					+ "and date(sua.updated_at) BETWEEN ?5 AND ?6 and sua.revtype in ?7  and suu.organization_id =?8\n"
					+ "order by sua.updated_at desc, sua.rev desc", nativeQuery = true)
	Page<Object[]> getUserAuditInfo(String name, String name2, String name3, String name4, String string,
			String endDate, List<Long> revtypes, long organizationId, PageRequest pageRequest);

	@Query(value = "select sua.id,sua.revtype,sua.updated_at,sua.email,sua.first_name,sua.last_name,sua.middle_name,sua.mobile_number,\n"
			+ "       sua.status,sua.user_type,sua.name_prefix_master_id,sua.rev,sua.user_id,concat(su.first_name ,' ',su.last_name) as userName,npm.prefix , ro.role\n"
			+ "from system_users_aud sua left join system_users su on su.id = sua.user_id\n"
			+ "    left join name_prefix_master npm on npm.id = sua.name_prefix_master_id left join system_users suu on suu.id = sua.id\n"
			+ "left join roles ro on ro.id= sua.role_id"
			+ " where sua.id =?1 and sua.rev<?2 order by sua.rev desc limit 1", countQuery = "select sua.id,sua.revtype,sua.updated_at,sua.email,sua.first_name,sua.last_name,sua.middle_name,sua.mobile_number,\n"
					+ "       sua.status,sua.user_type,sua.name_prefix_master_id,sua.rev,sua.user_id,concat(su.first_name ,' ',su.last_name) as userName,npm.prefix , ro.role\n"
					+ "from system_users_aud sua left join system_users su on su.id = sua.user_id\n"
					+ "    left join name_prefix_master npm on npm.id = sua.name_prefix_master_id left join system_users suu on suu.id = sua.id\n"
					+ "left join roles ro on ro.id= sua.role_id"
					+ " where sua.id =?1 and sua.rev<?2 order by sua.rev desc limit 1", nativeQuery = true)
	List<Object[]> getUserAuditInfoByIdAndRev(long longValue, long longValue2);

	@Query(value = "select sua.id,sua.revtype,sua.updated_at,sua.email,sua.first_name,sua.last_name,sua.middle_name,sua.mobile_number,\n"
			+ "       sua.status,sua.user_type,sua.name_prefix_master_id,sua.rev,sua.user_id,concat(su.first_name ,' ',su.last_name) as userName,npm.prefix , ro.role\n"
			+ "from system_users_aud sua left join system_users su on su.id = sua.user_id\n"
			+ "    left join name_prefix_master npm on npm.id = sua.name_prefix_master_id left join system_users suu on suu.id = sua.id\n"
			+ "left join roles ro on ro.id= sua.role_id\n"
			+ " where sua.id=?1 order by sua.rev desc", countQuery = "select sua.id,sua.revtype,sua.updated_at,sua.email,sua.first_name,sua.last_name,sua.middle_name,sua.mobile_number,\n"
					+ "       sua.status,sua.user_type,sua.name_prefix_master_id,sua.rev,sua.user_id,concat(su.first_name ,' ',su.last_name) as userName,npm.prefix , ro.role\n"
					+ "from system_users_aud sua left join system_users su on su.id = sua.user_id\n"
					+ "    left join name_prefix_master npm on npm.id = sua.name_prefix_master_id left join system_users suu on suu.id = sua.id\n"
					+ "left join roles ro on ro.id= sua.role_id\n"
					+ " where sua.id=?1 order by sua.rev desc", nativeQuery = true)
	Page<Object[]> getUserAuditInfoById(Long id, PageRequest pageRequest);

	Optional<SystemUsers> findByEmailAndOrganizationIdAndUserTypeAndStatusNot(String email, Organization organizationId,
			String string, String deleted);

	Optional<SystemUsers> findByEmailAndStatusNotAndUserType(String email, String deleted, String string);

}
