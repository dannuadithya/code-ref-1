package com.billdog.user.service;

import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.entity.FailedEmailTrigger;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.repository.EmailRepository;
import com.billdog.user.repository.FailedEmailTriggerRepository;
import com.billdog.user.request.PasscodeEmailMemberRequest;
import com.billdog.user.request.PasscodeEmailRequest;
import com.billdog.user.request.UpdateEmailRequest;
import com.billdog.user.request.UpdateMemberEmailRequest;
import com.billdog.user.request.WelcomeEmailMemberRequest;
import com.billdog.user.view.ViewResponse;

import retrofit2.Call;
import retrofit2.Response;

@Component
public class EmailService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(EmailService.class);
	@Autowired
	EmailRepository emailRepository;

	@Autowired
	FailedEmailTriggerRepository failedEmailTriggerRepository;

	public ViewResponse sendEamil(PasscodeEmailRequest passcodeEmailRequest) {
		LOGGER.info("sendEamil method started..!");

		Call<ViewResponse> callSync = emailRepository.sendPasscodeEmail(passcodeEmailRequest);

		try {
			Response<ViewResponse> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info(Constants.SUCCESS_RESPONSE_FROM_EMAIL_SERVICE);
				return response.body();
			} else {
				Optional<FailedEmailTrigger> failedEmailTriggerOptional = failedEmailTriggerRepository
						.findByEmailAndEmailTitle(passcodeEmailRequest.getEmail(),
								passcodeEmailRequest.getEmailTitle().toString());
				if (!failedEmailTriggerOptional.isPresent()) {
					saveSendEamil(passcodeEmailRequest);
				}
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.EMAIL_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.EMAIL_SERVICE_BAD_REQUEST);
				} else {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling email service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse sendEamilToMember(PasscodeEmailMemberRequest passcodeEmailMemberRequest) {
		LOGGER.info("sendEamilToMember method started..!");
		Call<ViewResponse> callSync = emailRepository.sendPasscodeEmailToMember(passcodeEmailMemberRequest);

		try {
			Response<ViewResponse> response = callSync.execute();
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info(Constants.SUCCESS_RESPONSE_FROM_EMAIL_SERVICE);
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
				} else {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_PASSCODE);
				}
			}
		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling email service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse sendWelcomeEamilToMember(WelcomeEmailMemberRequest welcomeEmailMemberRequest) {
		LOGGER.info("sendWelcomeEamilToMember method started..!");
		Call<ViewResponse> callSync = emailRepository.welcomeEmailMember(welcomeEmailMemberRequest);

		try {
			Response<ViewResponse> response = callSync.execute();

			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info(Constants.SUCCESS_RESPONSE_FROM_EMAIL_SERVICE);
				return response.body();
			} else {
				Optional<FailedEmailTrigger> failedEmailTriggerOptional = failedEmailTriggerRepository
						.findByEmailAndEmailTitle(welcomeEmailMemberRequest.getEmail(),
								welcomeEmailMemberRequest.getEmailTitle().toString());
				if (!failedEmailTriggerOptional.isPresent()) {
					saveSendWelcomeEamilToMember(welcomeEmailMemberRequest);
				}
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
				} else {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling email service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse sendEamilToMember(WelcomeEmailMemberRequest welcomeEmailMemberRequest) {
		LOGGER.info("sendWelcomeEamilToMember method started..!");
		Call<ViewResponse> callSync = emailRepository.welcomeEmailMember(welcomeEmailMemberRequest);

		try {
			Response<ViewResponse> response = callSync.execute();

			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info(Constants.SUCCESS_RESPONSE_FROM_EMAIL_SERVICE);
				return response.body();
			} else {
				Optional<FailedEmailTrigger> failedEmailTriggerOptional = failedEmailTriggerRepository
						.findByEmailAndEmailTitle(welcomeEmailMemberRequest.getEmail(),
								welcomeEmailMemberRequest.getEmailTitle().toString());
				if (!failedEmailTriggerOptional.isPresent()) {
					saveSendEamilToMember(welcomeEmailMemberRequest);
				}

				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
				} else {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling email service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse sendUpdatedEamilToMember(UpdateMemberEmailRequest updateMemberEmailRequest) {
		LOGGER.info("sendUpdatedEamilToMember method started..!");
		Call<ViewResponse> callSync = emailRepository.updatedEmail(updateMemberEmailRequest);
		try {
			Response<ViewResponse> response = callSync.execute();

			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info(Constants.SUCCESS_RESPONSE_FROM_EMAIL_SERVICE);
				return response.body();
			} else {
				Optional<FailedEmailTrigger> failedEmailTriggerOptional = failedEmailTriggerRepository
						.findByEmailAndEmailTitle(updateMemberEmailRequest.getOldEmail(),
								updateMemberEmailRequest.getEmailTitle().toString());
				if (!failedEmailTriggerOptional.isPresent()) {
					saveSendUpdatedEamilToMember(updateMemberEmailRequest);
				}

				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
				} else {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling email service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse sendUpdatedEamil(UpdateEmailRequest updateEmailRequest) {
		LOGGER.info("sendUpdatedEamil method started..!");
		Call<ViewResponse> callSync = emailRepository.updatedEmailToMember(updateEmailRequest);
		try {
			Response<ViewResponse> response = callSync.execute();

			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info(Constants.SUCCESS_RESPONSE_FROM_EMAIL_SERVICE);
				return response.body();
			} else {
				Optional<FailedEmailTrigger> failedEmailTriggerOptional = failedEmailTriggerRepository
						.findByEmailAndEmailTitle(updateEmailRequest.getUserName(),
								updateEmailRequest.getEmailTitle().toString());
				if (!failedEmailTriggerOptional.isPresent()) {
					saveSendUpdatedEamil(updateEmailRequest);
				}

				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
				} else {
					throw new BadRequestException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling email service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	private void saveSendEamil(PasscodeEmailRequest passcodeEmailRequest) {

		try {
			if (!passcodeEmailRequest.getEmailTitle().toString().contains(EmailTitles.MEMBER_PASSCODE.toString())
					|| !passcodeEmailRequest.getEmailTitle().toString().contains(EmailTitles.PASSWORD_RESET.toString())
					|| !passcodeEmailRequest.getEmailTitle().toString().contains(EmailTitles.SEND_PASSCODE.toString())
					|| !passcodeEmailRequest.getEmailTitle().toString()
							.contains(EmailTitles.UPDATE_PASSWORD.toString())) {
				FailedEmailTrigger failedEmailTrigger = new FailedEmailTrigger();
				failedEmailTrigger.setCreatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setUpdatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setEmail(passcodeEmailRequest.getEmail());
				failedEmailTrigger.setEmailTitle(passcodeEmailRequest.getEmailTitle().toString());
				failedEmailTrigger.setFirstName(passcodeEmailRequest.getUsername());
				failedEmailTrigger.setOrganizationId(passcodeEmailRequest.getOrganizationId());
				failedEmailTriggerRepository.save(failedEmailTrigger);

			}

		} catch (Exception e) {
			LOGGER.info("Exception occured while connecting email service, cause:: ", e.getCause());
		}

	}

	private void saveSendWelcomeEamilToMember(WelcomeEmailMemberRequest welcomeEmailMemberRequest) {

		try {
			if (!welcomeEmailMemberRequest.getEmailTitle().toString().contains(EmailTitles.MEMBER_PASSCODE.toString())
					|| !welcomeEmailMemberRequest.getEmailTitle().toString()
							.contains(EmailTitles.PASSWORD_RESET.toString())
					|| !welcomeEmailMemberRequest.getEmailTitle().toString()
							.contains(EmailTitles.SEND_PASSCODE.toString())
					|| !welcomeEmailMemberRequest.getEmailTitle().toString()
							.contains(EmailTitles.UPDATE_PASSWORD.toString())) {

				FailedEmailTrigger failedEmailTrigger = new FailedEmailTrigger();
				failedEmailTrigger.setCreatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setUpdatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setEmail(welcomeEmailMemberRequest.getEmail());
				failedEmailTrigger.setEmailTitle(welcomeEmailMemberRequest.getEmailTitle().toString());
				failedEmailTrigger.setFirstName(welcomeEmailMemberRequest.getFirstName());
				failedEmailTrigger.setOrganizationId(welcomeEmailMemberRequest.getOrgId());
				failedEmailTriggerRepository.save(failedEmailTrigger);
			}

		} catch (Exception e) {
			LOGGER.info("Exception occured while connecting email service, cause:: ", e.getCause());
		}

	}

	private void saveSendEamilToMember(WelcomeEmailMemberRequest welcomeEmailMemberRequest) {

		try {

			if (!welcomeEmailMemberRequest.getEmailTitle().toString().contains(EmailTitles.MEMBER_PASSCODE.toString())
					|| !welcomeEmailMemberRequest.getEmailTitle().toString()
							.contains(EmailTitles.PASSWORD_RESET.toString())
					|| !welcomeEmailMemberRequest.getEmailTitle().toString()
							.contains(EmailTitles.SEND_PASSCODE.toString())
					|| !welcomeEmailMemberRequest.getEmailTitle().toString()
							.contains(EmailTitles.UPDATE_PASSWORD.toString())) {

				FailedEmailTrigger failedEmailTrigger = new FailedEmailTrigger();
				failedEmailTrigger.setCreatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setUpdatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setEmail(welcomeEmailMemberRequest.getEmail());
				failedEmailTrigger.setEmailTitle(welcomeEmailMemberRequest.getEmailTitle().toString());
				failedEmailTrigger.setFirstName(welcomeEmailMemberRequest.getFirstName());
				failedEmailTrigger.setOrganizationId(welcomeEmailMemberRequest.getOrgId());
				failedEmailTriggerRepository.save(failedEmailTrigger);
			}

		} catch (Exception e) {
			LOGGER.info("Exception occured while connecting email service, cause:: ", e.getCause());
		}

	}

	private void saveSendUpdatedEamilToMember(UpdateMemberEmailRequest updateMemberEmailRequest) {
		try {

			if (!updateMemberEmailRequest.getEmailTitle().toString().contains(EmailTitles.MEMBER_PASSCODE.toString())
					|| !updateMemberEmailRequest.getEmailTitle().toString()
							.contains(EmailTitles.PASSWORD_RESET.toString())
					|| !updateMemberEmailRequest.getEmailTitle().toString()
							.contains(EmailTitles.SEND_PASSCODE.toString())
					|| !updateMemberEmailRequest.getEmailTitle().toString()
							.contains(EmailTitles.UPDATE_PASSWORD.toString())) {

				FailedEmailTrigger failedEmailTrigger = new FailedEmailTrigger();
				failedEmailTrigger.setCreatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setUpdatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setOldEmail(updateMemberEmailRequest.getOldEmail());
				failedEmailTrigger.setNewEmail(updateMemberEmailRequest.getNewEmail());
				failedEmailTrigger.setFirstName(updateMemberEmailRequest.getFirstName());
				failedEmailTrigger.setEmailTitle(updateMemberEmailRequest.getEmailTitle().toString());
				failedEmailTrigger.setOrganizationId(updateMemberEmailRequest.getOrgId());
				failedEmailTriggerRepository.save(failedEmailTrigger);
			}

		} catch (Exception e) {
			LOGGER.info("Exception occured while connecting email service, cause:: ", e.getCause());
		}
	}

	private void saveSendUpdatedEamil(UpdateEmailRequest updateEmailRequest) {

		try {

			if (!updateEmailRequest.getEmailTitle().toString().contains(EmailTitles.MEMBER_PASSCODE.toString())
					|| !updateEmailRequest.getEmailTitle().toString().contains(EmailTitles.PASSWORD_RESET.toString())
					|| !updateEmailRequest.getEmailTitle().toString().contains(EmailTitles.SEND_PASSCODE.toString())
					|| !updateEmailRequest.getEmailTitle().toString()
							.contains(EmailTitles.UPDATE_PASSWORD.toString())) {

				FailedEmailTrigger failedEmailTrigger = new FailedEmailTrigger();
				failedEmailTrigger.setCreatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setUpdatedAt(DateAndTimeUtil.now());
				failedEmailTrigger.setLastName(updateEmailRequest.getLastName());
				failedEmailTrigger.setEmail(updateEmailRequest.getUserName());
				failedEmailTrigger.setFirstName(updateEmailRequest.getFirstName());
				failedEmailTrigger.setEmailTitle(updateEmailRequest.getEmailTitle().toString());
				failedEmailTrigger.setOrganizationId(updateEmailRequest.getOrgId());
				failedEmailTriggerRepository.save(failedEmailTrigger);
			}

		} catch (Exception e) {
			LOGGER.info("Exception occured while connecting email service, cause:: ", e.getCause());
		}

	}

}
