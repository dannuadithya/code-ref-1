package com.billdog.user.command;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.request.UpdatePersonalDetailsRequest;
import com.billdog.user.service.GetProfileDetails;
import com.billdog.user.view.ViewMemberResponse;

@Service
public class UpdateMemberPersonalInfoCommand
		implements Command<UpdatePersonalDetailsRequest, ResponseEntity<ViewMemberResponse>> {

	@Autowired
	GetProfileDetails getProfileDetails;

	@Override
	public ResponseEntity<ViewMemberResponse> excute(UpdatePersonalDetailsRequest updatePersonalDetails) {
		if (StringUtils.isBlank(updatePersonalDetails.getFirstName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME_LIMIT);
		}
		if (StringUtils.isBlank(updatePersonalDetails.getLastName())) {
			throw new BadRequestException(ExceptionalMessages.LAST_NAME_LIMIT);
		}
		if (StringUtils.isNumeric(updatePersonalDetails.getMiddleName())) {
			throw new InValidInputException(ExceptionalMessages.MIDDLE_NAME_CHARACTERS);
		}
		if (updatePersonalDetails.getMiddleName() != null && !updatePersonalDetails.getMiddleName().isEmpty()) {
			if (updatePersonalDetails.getMiddleName().length() < 2
					|| updatePersonalDetails.getMiddleName().length() > 20) {
				throw new InValidInputException(ExceptionalMessages.MIDDLE_NAME);
			}

		}

		if (StringUtils.isNumeric(updatePersonalDetails.getFirstName())) {
			throw new InValidInputException(ExceptionalMessages.FIRST_NAME_CHARACTERS);
		}
		if (updatePersonalDetails.getFirstName() != null && !updatePersonalDetails.getFirstName().isEmpty()) {
			if (updatePersonalDetails.getFirstName().length() < 2
					|| updatePersonalDetails.getFirstName().length() > 20) {
				throw new InValidInputException(ExceptionalMessages.FIRST_NAME_WEB);
			}

		}

		if (StringUtils.isNumeric(updatePersonalDetails.getLastName())) {
			throw new InValidInputException(ExceptionalMessages.LAST_NAME_CHARACTERS);
		}
		if (updatePersonalDetails.getLastName() != null && !updatePersonalDetails.getLastName().isEmpty()) {
			if (updatePersonalDetails.getLastName().length() < 2 || updatePersonalDetails.getLastName().length() > 20) {
				throw new InValidInputException(ExceptionalMessages.LAST_NAME_WEB);
			}

		}

		if (updatePersonalDetails.getStreet() != null && !updatePersonalDetails.getStreet().isEmpty()
				&& updatePersonalDetails.getStreet().length() > 125) {
			throw new InValidInputException(ExceptionalMessages.STREET_CHARACTERS);
		}

		if (updatePersonalDetails.getCityName() != null && !updatePersonalDetails.getCityName().isEmpty()
				&& updatePersonalDetails.getCityName().length() > 125) {
			throw new InValidInputException(ExceptionalMessages.CITY_CHARACTERS);
		}

		if (!StringUtils.isBlank(updatePersonalDetails.getZipcode())
				&& !StringUtils.isNumeric(updatePersonalDetails.getZipcode())) {
			throw new InValidInputException(ExceptionalMessages.ZIP_CODE_SHOULD_BE_NUMBERS);
		}
		if (!StringUtils.isBlank(updatePersonalDetails.getZipcode())
				&& updatePersonalDetails.getZipcode().length() != 5
				&& !updatePersonalDetails.getZipcode().isEmpty()) {
			throw new InValidInputException(ExceptionalMessages.ZIP_CODE);
		}

		if (updatePersonalDetails.getAddressLine1() != null && !updatePersonalDetails.getAddressLine1().isEmpty()
				&& updatePersonalDetails.getAddressLine1().length() > 125) {
			throw new InValidInputException(ExceptionalMessages.ADDRESS_CHARACTERS);
		}
		if (updatePersonalDetails.getAddressLine2() != null && !updatePersonalDetails.getAddressLine2().isEmpty()
				&& updatePersonalDetails.getAddressLine2().length() > 125) {
			throw new InValidInputException(ExceptionalMessages.ADDRESS_CHARACTERS);
		}

		if (updatePersonalDetails.getMobileNumber()!=null && !updatePersonalDetails.getMobileNumber().isEmpty()
				&& !StringUtils.isNumeric(updatePersonalDetails.getMobileNumber())) {
			throw new InValidInputException(ExceptionalMessages.MOBILE_SHOULD_BE_NUMBERS);
		}
		if (updatePersonalDetails.getMobileNumber() != null && updatePersonalDetails.getMobileNumber().length() <= 9
				&& !updatePersonalDetails.getMobileNumber().isEmpty()) {
			throw new InValidInputException(ExceptionalMessages.MOBILE_NUMER);
		}

		return ResponseEntity.status(HttpStatus.OK)
				.body(getProfileDetails.updatePersonalDetails(updatePersonalDetails));

	}
}