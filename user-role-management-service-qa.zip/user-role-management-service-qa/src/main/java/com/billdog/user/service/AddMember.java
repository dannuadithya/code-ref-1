package com.billdog.user.service;

import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.CountryMaster;
import com.billdog.user.entity.CountryPhoneCodeMaster;
import com.billdog.user.entity.GenderMaster;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberAddress;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.MemberProduct;
import com.billdog.user.entity.MemberTypeMaster;
import com.billdog.user.entity.NamePrefixMaster;
import com.billdog.user.entity.Organization;
import com.billdog.user.entity.StateMaster;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.repository.CountryMasterRepository;
import com.billdog.user.repository.CountryPhoneCodeMasterRepository;
import com.billdog.user.repository.GenderMasterRepository;
import com.billdog.user.repository.MemberAddressRepository;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberProductRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.repository.NamePrefixMasterRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.StateMasterRepository;
import com.billdog.user.request.AddMemberPersonalInfoRequest;
import com.billdog.user.request.WelcomeEmailMemberRequest;
import com.billdog.user.view.ViewResponse;

@Service
public class AddMember {

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	NamePrefixMasterRepository namePrefixMasterRepository;

	@Autowired
	GenderMasterRepository genderMasterRepository;

	@Autowired
	CountryPhoneCodeMasterRepository countryPhoneCodeMasterRepository;

	@Autowired
	MemberProductRepository memberProductRepository;

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Autowired
	CountryMasterRepository countryMasterRepository;

	@Autowired
	StateMasterRepository stateMasterRepository;

	@Autowired
	MemberAddressRepository addressRepository;

	@Autowired
	MemberTypeMasterRepository memberTypeMasterRepository;

	@Autowired
	MemberLoginService memberLoginService;

	@Autowired
	EmailService emailService;

	@Autowired
	LoginService loginService;

	@Autowired
	AuditService auditService;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(AddMember.class);

	public ViewResponse addNewMemberPersonalInfo(AddMemberPersonalInfoRequest addMemberRequest) {
		LOGGER.info("add new member personal details method started..!");
		if (StringUtils.isBlank(addMemberRequest.getFirstName())) {
			throw new BadRequestException(ExceptionalMessages.FIRST_NAME_LIMIT);
		}
		if (StringUtils.isBlank(addMemberRequest.getLastName())) {
			throw new BadRequestException(ExceptionalMessages.LAST_NAME_LIMIT);
		}
		SystemUsers user = loginService.getSystemUsers(addMemberRequest.getUserId());

		Organization organization = user.getOrganizationId();

		Optional<MemberEmail> memberEmailOptional = memberEmailRepository
				.findByEmailAndPrimaryAndOrganizationId(addMemberRequest.getPrimaryEmailId(), true, organization);
		if (memberEmailOptional.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS_IN_ORGANIZATION);
		}
		String auditId = auditService.getAuditId();
		Member member = saveMember(addMemberRequest, organization, user, auditId);

		saveMemberEmailDetails(addMemberRequest, member, user, auditId);

		sendWelcomeEmail(addMemberRequest.getFirstName(), addMemberRequest.getPrimaryEmailId(),
				EmailTitles.MEMBER_WELCOME);

		if (addMemberRequest.getAddressLine1() != null || addMemberRequest.getAddressLine2() != null
				|| addMemberRequest.getCityName() != null || addMemberRequest.getStreet() != null
				|| addMemberRequest.getCountryId() > 0 || addMemberRequest.getStateId() > 0
				|| addMemberRequest.getZipCode() != null) {
			memberAddressDetails(addMemberRequest, member, user, auditId);
		}
		// providing successful response
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MEMBER_PERSONAL_INFO);
		response.setMemberId(member.getId());

		return response;

	}

	private Member saveMember(AddMemberPersonalInfoRequest addMemberRequest, Organization organization,
			SystemUsers user, String auditId) {

		Member member = new Member();
		member.setCreatedAt(DateAndTimeUtil.now());
		member.setUpdatedAt(DateAndTimeUtil.now());
		member.setOrganizationId(organization);
		member.setStatus(StatusConstants.ENROLLED);
		member.setMemberId(memberLoginService.getMemberId(organization.getId()));
		Optional<NamePrefixMaster> namePrefixMaster = namePrefixMasterRepository
				.findByIdAndStatus(addMemberRequest.getPrefixId(), Constants.ACTIVE);
		if (namePrefixMaster.isPresent()) {
			member.setNamePrefixMasterId(namePrefixMaster.get());
		}
		member.setFirstName(WordUtils.capitalizeFully(addMemberRequest.getFirstName()));
		member.setLastName(WordUtils.capitalizeFully(addMemberRequest.getLastName()));
		member.setMiddleName(WordUtils.capitalizeFully(addMemberRequest.getMiddleName()));

		Optional<GenderMaster> genderMaster = genderMasterRepository.findByIdAndStatus(addMemberRequest.getGenderId(),
				Constants.ACTIVE);
		if (genderMaster.isPresent()) {
			member.setGenderId(genderMaster.get());
		}
		Optional<CountryPhoneCodeMaster> countryPhoneCode = countryPhoneCodeMasterRepository
				.findByIdAndStatus(addMemberRequest.getCountryPhoneCodeId(), Constants.ACTIVE);
		if (countryPhoneCode.isPresent()) {
			member.setCountryPhoneCodeMasterId(countryPhoneCode.get());
		}
		member.setPhoneNumber(addMemberRequest.getMobileNumber());
		if (!StringUtils.isBlank(addMemberRequest.getDateOfBirth())) {
			member.setDateOfBirth(DateAndTimeUtil.stringDateToLocalDate(addMemberRequest.getDateOfBirth()));
		}
		Optional<MemberProduct> memberProduct = memberProductRepository
				.findByIdAndStatus(addMemberRequest.getProductId(), Constants.ACTIVE);
		if (memberProduct.isPresent()) {
			member.setProductId(memberProduct.get());
		}
		Optional<MemberTypeMaster> memberTypeMaster = memberTypeMasterRepository
				.findByIdAndStatus(addMemberRequest.getOpportunityTypeId(), Constants.ACTIVE);
		if (memberTypeMaster.isPresent()) {
			if (!memberTypeMaster.get().getTypeName().equalsIgnoreCase(Constants.DIRECT_MEMBER)) {
				member.setEmployerId(addMemberRequest.getEmployerId());
			}
			member.setMemberTypeMasterId(memberTypeMaster.get());
		}
		member.setProfileUpdated(true);
		member.setUserId(user);
		member.setAuditId(auditId);
		return memberRepository.save(member);

	}

	private void saveMemberEmailDetails(AddMemberPersonalInfoRequest addMemberRequest, Member member,
			SystemUsers user, String auditId) {

		if (!addMemberRequest.getPrimaryEmailId().isEmpty()) {
			MemberEmail memberEmail = new MemberEmail();
			memberEmail.setCreatedAt(DateAndTimeUtil.now());
			memberEmail.setUpdatedAt(DateAndTimeUtil.now());
			memberEmail.setMemberId(member);
			memberEmail.setEmail(addMemberRequest.getPrimaryEmailId());
			memberEmail.setPrimary(true);
			if (member.getOrganizationId() != null) {
				memberEmail.setOrganizationId(member.getOrganizationId());
			}
			memberEmail.setUserId(user);
			memberEmail.setAuditId(auditId);
			memberEmailRepository.save(memberEmail);
		}
		if (addMemberRequest.getSecoundaryEmailId() != null && !addMemberRequest.getSecoundaryEmailId().isEmpty()) {
			MemberEmail memberEmail1 = new MemberEmail();
			memberEmail1.setCreatedAt(DateAndTimeUtil.now());
			memberEmail1.setUpdatedAt(DateAndTimeUtil.now());
			memberEmail1.setMemberId(member);
			memberEmail1.setEmail(addMemberRequest.getSecoundaryEmailId());
			memberEmail1.setPrimary(false);
			memberEmail1.setSecondary(true);
			if (member.getOrganizationId() != null) {
				memberEmail1.setOrganizationId(member.getOrganizationId());
			}
			memberEmail1.setUserId(user);
			memberEmail1.setAuditId(auditId);
			memberEmailRepository.save(memberEmail1);
		}

	}

	private void memberAddressDetails(AddMemberPersonalInfoRequest addMemberRequest, Member member, SystemUsers user,
			String auditId) {

		MemberAddress memberAddress = new MemberAddress();
		LOGGER.info("Fecthing member address info for member id:: {}", member.getId());
		Optional<MemberAddress> memberAddressOptional = addressRepository.findByMemberId(member);
		if (memberAddressOptional.isPresent()) {
			memberAddress = memberAddressOptional.get();
		}
		memberAddress.setCreatedAt(DateAndTimeUtil.now());
		memberAddress.setUpdatedAt(DateAndTimeUtil.now());
		memberAddress.setStreet(addMemberRequest.getStreet());
		memberAddress.setCityName(addMemberRequest.getCityName());
		Optional<CountryMaster> countryMaster = countryMasterRepository
				.findByIdAndStatus(addMemberRequest.getCountryId(), Constants.ACTIVE);
		if (countryMaster.isPresent()) {
			memberAddress.setCountryMasterId(countryMaster.get());
		}
		Optional<StateMaster> stateMaster = stateMasterRepository.findByIdAndStatus(addMemberRequest.getStateId(),
				Constants.ACTIVE);
		if (stateMaster.isPresent()) {
			memberAddress.setStateMasterId(stateMaster.get());
		}
		memberAddress.setZipCode(addMemberRequest.getZipCode());
		memberAddress.setAddressLine1(addMemberRequest.getAddressLine1());
		memberAddress.setAddressLine2(addMemberRequest.getAddressLine2());
		memberAddress.setMemberId(member);
		memberAddress.setUserId(user);
		memberAddress.setAuditId(auditId);
		addressRepository.save(memberAddress);

	}

	public ViewResponse sendWelcomeEmail(String firstName, String email, EmailTitles emailTitles) {
		LOGGER.info("Send welcome mail method started..!");

		WelcomeEmailMemberRequest welcomeEmailMemberRequest = new WelcomeEmailMemberRequest();
		welcomeEmailMemberRequest.setEmail(email);
		welcomeEmailMemberRequest.setEmailTitle(emailTitles);
		welcomeEmailMemberRequest.setFirstName(capitalize(firstName));
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send welcome email");
			viewResponse = emailService.sendWelcomeEamilToMember(welcomeEmailMemberRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: {}", exception.getMessage());
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send welcome email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.WELCOME_MEMBER);
		} else {
			LOGGER.info(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_WELCOME_EMAIL);
		}

		return viewResponse;
	}

	public String capitalize(String name) {
		return WordUtils.capitalizeFully(name);
	}

}
