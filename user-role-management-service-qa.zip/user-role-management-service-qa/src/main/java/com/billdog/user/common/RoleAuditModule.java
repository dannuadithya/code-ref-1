package com.billdog.user.common;

public enum RoleAuditModule {
	
	Role

}
