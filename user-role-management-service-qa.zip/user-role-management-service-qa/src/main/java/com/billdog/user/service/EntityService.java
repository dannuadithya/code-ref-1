package com.billdog.user.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.exception.BadRequestException;
import com.billdog.user.exception.InternalServerException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.exception.ServiceUnavailableException;
import com.billdog.user.repository.EntityRepository;
import com.billdog.user.request.AuditRequest;
import com.billdog.user.request.ExternalUserRequest;
import com.billdog.user.request.UpdateExternalUserRequest;
import com.billdog.user.response.UpdateUserDetailsResponse;
import com.billdog.user.view.GetCarrierInfo;
import com.billdog.user.view.GetEmployerInfo;
import com.billdog.user.view.ViewExternalUser;
import com.billdog.user.view.ViewResponse;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Component
public class EntityService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(EntityService.class);

	@Value("${entityservice.baseurl}")
	private String entityBaseUrl;

	private EntityRepository getEntityRepository(String token) {
		OkHttpClient.Builder userHttpClient;
		if (StringUtils.isNotBlank(token)) {
			userHttpClient = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
				@Override
				public Response intercept(Chain chain) throws IOException {
					Request request = chain.request().newBuilder().addHeader("authorization", token).build();
					return chain.proceed(request);
				}
			});
		} else {
			userHttpClient = new OkHttpClient.Builder();
		}
		Retrofit retrofit = new Retrofit.Builder().baseUrl(entityBaseUrl)
				.addConverterFactory(GsonConverterFactory.create())
				.client(userHttpClient.connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build())
				.build();
		return retrofit.create(EntityRepository.class);
	}

	public GetCarrierInfo getCarrierInfo(long carrierTypeId, long organizationId) {
		LOGGER.info("verifyUserToken method started..!");
		EntityRepository entityRepository = getEntityRepository(null);

		Call<GetCarrierInfo> callSync = entityRepository.getCarrierInfo(carrierTypeId, organizationId);

		try {
			retrofit2.Response<GetCarrierInfo> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.ENTITY_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}

			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling entity service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public GetEmployerInfo getEmployerInfo(Long employerId) {
		LOGGER.info("verifyUserToken method started..!");
		EntityRepository entityRepository = getEntityRepository(null);

		Call<GetEmployerInfo> callSync = entityRepository.getEmployerInfo(employerId);

		try {
			retrofit2.Response<GetEmployerInfo> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				LOGGER.info("Response from api calling {} {}", response.code(),
						response.message() != null ? response.message() : "");
				throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling entity service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public GetEmployerInfo getEmployerDetails(long employerId) {
		LOGGER.info("getEmployerDetails method started..!");
		EntityRepository entityRepository = getEntityRepository(null);

		Call<GetEmployerInfo> callSync = entityRepository.getEmployerInfo(employerId);

		try {
			retrofit2.Response<GetEmployerInfo> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.ENTITY_SERVICE_NOT_FOUND);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}

			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling case service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewExternalUser getExternalUserInfo(ExternalUserRequest externalUserRequest) {
		LOGGER.info("getExternalUserInfo method started..!");
		EntityRepository entityRepository = getEntityRepository(null);

		Call<ViewExternalUser> callSync = entityRepository.getExternalUserInfo(externalUserRequest);

		try {
			retrofit2.Response<ViewExternalUser> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.EMAIL_NOT_FOUND);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}
			}

		} catch (Exception exception) {
			// throw new NoRecordFoundException(exception.getMessage());
			LOGGER.info(exception.getMessage());

		}
		return null;

	}

	public ViewExternalUser getUserInfo(ExternalUserRequest externalUserRequest) {
		LOGGER.info("getExternalUserInfo method started..!");
		EntityRepository entityRepository = getEntityRepository(null);

		Call<ViewExternalUser> callSync = entityRepository.getExternalUserInfo(externalUserRequest);

		try {
			retrofit2.Response<ViewExternalUser> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.EMAIL_NOT_FOUND_INDIVIDUAL);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}
			}

		} catch (Exception exception) {
			throw new NoRecordFoundException(exception.getMessage());

		}

	}

	public UpdateUserDetailsResponse updateExternalUser(UpdateExternalUserRequest updateExternalUserRequest) {
		LOGGER.info("updateExternalUser method started..!");
		EntityRepository entityRepository = getEntityRepository(null);

		Call<UpdateUserDetailsResponse> callSync = entityRepository.updateExternalUser(updateExternalUserRequest);

		try {
			retrofit2.Response<UpdateUserDetailsResponse> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling case service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse getAuditInfo(AuditRequest auditRequest) {

		LOGGER.info("getAuditInfo method started..!");
		EntityRepository entityRepository = getEntityRepository(null);

		Call<ViewResponse> callSync = entityRepository.getAuditInfo(auditRequest);

		try {
			retrofit2.Response<ViewResponse> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling case service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

	public ViewResponse getAuditInfoById(Long recordId, String moduleName, Integer pageNumber, Integer pageLimit) {

		LOGGER.info("getAuditInfoById method started..!");
		EntityRepository entityRepository = getEntityRepository(null);

		Call<ViewResponse> callSync = entityRepository.getAuditInfoById(recordId, moduleName, pageNumber, pageLimit);

		try {
			retrofit2.Response<ViewResponse> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from entity service with code:: {}", response.code());
				return response.body();
			} else {
				if (response.code() == 404) {
					throw new NoRecordFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS);
				} else if (response.code() == 400) {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_BAD_REQUEST);
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else if (response.code() == 500) {
					throw new InternalServerException(ExceptionalMessages.ENTITY_SERVICE_UNAVAILABLE);
				} else {
					throw new BadRequestException(ExceptionalMessages.ENTITY_SERVICE_ISSUE);
				}
			}

		} catch (Exception exception) {
			LOGGER.info("Exception occurred while calling case service, message:: {}", exception.getMessage());
			throw new NoRecordFoundException(ExceptionalMessages.SOMETHING_WENT_WRONG);
		}
	}

}
