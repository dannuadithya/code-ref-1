package com.billdog.user.request;

import com.billdog.user.common.DeductiblePaymentInfoEnum;

public class DeductiablePayInfoRequest {

	private int pcp;
	private int spec;
	private int er;
	private int ded;
	private DeductiblePaymentInfoEnum deductiblePaymentInfoEnum;

	public int getPcp() {
		return pcp;
	}

	public void setPcp(int pcp) {
		this.pcp = pcp;
	}

	public int getSpec() {
		return spec;
	}

	public void setSpec(int spec) {
		this.spec = spec;
	}

	public int getEr() {
		return er;
	}

	public void setEr(int er) {
		this.er = er;
	}

	public int getDed() {
		return ded;
	}

	public void setDed(int ded) {
		this.ded = ded;
	}

	public DeductiblePaymentInfoEnum getDeductiblePaymentInfoEnum() {
		return deductiblePaymentInfoEnum;
	}

	public void setDeductiblePaymentInfoEnum(DeductiblePaymentInfoEnum deductiblePaymentInfoEnum) {
		this.deductiblePaymentInfoEnum = deductiblePaymentInfoEnum;
	}

}
