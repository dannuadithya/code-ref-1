package com.billdog.user.request;

import javax.validation.constraints.NotNull;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class SearchDirectMember {

	@NotNull(message = "User id must not be null")
	private Long userId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	@NotNull(message = "Member id must not be null")
	private String memberId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String name;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String email;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String sfdcId;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String mobileNumber;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String status;
	private Integer pageNumber;
	private Integer pageLimit;

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSfdcId() {
		return sfdcId;
	}

	public void setSfdcId(String sfdcId) {
		this.sfdcId = sfdcId;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public Integer getPageNumber() {
		return pageNumber;
	}

	public void setPageNumber(Integer pageNumber) {
		this.pageNumber = pageNumber;
	}

	public Integer getPageLimit() {
		return pageLimit;
	}

	public void setPageLimit(Integer pageLimit) {
		this.pageLimit = pageLimit;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
