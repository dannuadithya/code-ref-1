package com.billdog.user.config;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.exception.InternalServerException;
import com.billdog.user.exception.ServiceUnavailableException;
import com.billdog.user.repository.EmailRepository;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Configuration
public class RetrofitConfig {

	@Value("${emailservice.baseurl}")
	private String emailBaseUrl;

	OkHttpClient.Builder httpClient = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
		@Override
		public Response intercept(Chain chain) throws IOException {
			Response response = chain.proceed(chain.request().newBuilder().build());
			if (response.code() == 503) {
				throw new ServiceUnavailableException(ExceptionalMessages.EMAIL_SERVICE_UNAVAILABLE);
			} else if (response.code() == 500) {
				throw new InternalServerException(ExceptionalMessages.EMAIL_SERVICE_UNAVAILABLE);
			}
			return response;
		}
	});

	@Bean
	public EmailRepository getEmailRepository() {
		Retrofit retrofit = new Retrofit.Builder().baseUrl(emailBaseUrl)
				.addConverterFactory(GsonConverterFactory.create())
				.client(httpClient.connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build())
				.build();

		return retrofit.create(EmailRepository.class);

	}

}
