package com.billdog.user.request;

public class UpdateMemberPersonalInfoRequest {

	private long userId;
	private long memberId;

	public long getUserId() {
		return userId;
	}

	public void setUserId(long userId) {
		this.userId = userId;
	}

	public long getMemberId() {
		return memberId;
	}

	public void setMemberId(long memberId) {
		this.memberId = memberId;
	}

}
