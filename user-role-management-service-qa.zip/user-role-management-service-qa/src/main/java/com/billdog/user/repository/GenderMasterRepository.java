package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.GenderMaster;
import com.billdog.user.entity.Organization;

public interface GenderMasterRepository extends JpaRepository<GenderMaster, Long> {

	List<GenderMaster> findAllByStatus(String active);

	Optional<GenderMaster> findByIdAndStatus(long genderId, String active);

	List<GenderMaster> findByOrganizationIdAndStatus(Organization organization, String active);

}
