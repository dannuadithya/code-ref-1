package com.billdog.user.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.user.exception.ErrorResponse;
import com.billdog.user.response.LoginResponse;
import com.billdog.user.service.OrganizationService;
import com.billdog.user.view.ViewOrganizationResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class OrganizationController {

	@Autowired
	OrganizationService organizationService;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = LoginResponse.class, message = "user signed in successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@GetMapping(value = "/organization", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewOrganizationResponse> getOrganization(@RequestParam String url) {
		return ResponseEntity.status(HttpStatus.OK).body(organizationService.getOrganiation(url));
	}

}
