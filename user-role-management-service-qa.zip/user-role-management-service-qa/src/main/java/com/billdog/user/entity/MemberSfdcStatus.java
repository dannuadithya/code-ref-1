package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "MEMBER_SFDC_STATUS")
@Table(name = "member_sfdc_status")
public class MemberSfdcStatus extends BaseEntity {

	@ManyToOne
	@JoinColumn(name = "MEMBER_ID")
	private Member memberId;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Column(name = "ERROR_MESSAGE")
	private String errorMessage;

	@Column(name = "INTEGRATION_STATUS")
	private String integrationStatus;

	@Column(name = "PROFILE_UPDATED")
	private boolean profileUpdated;

	public Member getMemberId() {
		return memberId;
	}

	public void setMemberId(Member memberId) {
		this.memberId = memberId;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}

	public String getIntegrationStatus() {
		return integrationStatus;
	}

	public void setIntegrationStatus(String integrationStatus) {
		this.integrationStatus = integrationStatus;
	}

	public boolean isProfileUpdated() {
		return profileUpdated;
	}

	public void setProfileUpdated(boolean profileUpdated) {
		this.profileUpdated = profileUpdated;
	}

}
