package com.billdog.user.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity(name = "NAVIGATION_SCREENS")
@Table(name = "navigation_screens", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "status_org_index", columnList = "ORGANIZATION_ID,STATUS", unique = false) })
public class NavigationScreen extends BaseEntity {

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Audited
	@Column(name = "NAME")
	private String name;

	@Audited
	@Column(name = "URL")
	private String url;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JsonManagedReference
	@JoinColumn(name = "PARENT_ID", columnDefinition = "bigint(20)")
	private NavigationScreen parentId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@OneToMany(mappedBy = "parentId", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JsonBackReference
	private List<NavigationScreen> navigationScreens;

	@Audited
	@Column(name = "DISPLAY_ORDER", columnDefinition = "bigint(20) default 0")
	private long displayOrder;

	@Audited
	@Column(name = "STATUS")
	private String status;

	@Audited
	@Column(name = "type")
	private String type;

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public NavigationScreen getParentId() {
		return parentId;
	}

	public void setParentId(NavigationScreen parentId) {
		this.parentId = parentId;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public long getDisplayOrder() {
		return displayOrder;
	}

	public void setDisplayOrder(long displayOrder) {
		this.displayOrder = displayOrder;
	}

	public List<NavigationScreen> getNavigationScreens() {
		return navigationScreens;
	}

	public void setNavigationScreens(List<NavigationScreen> navigationScreens) {
		this.navigationScreens = navigationScreens;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

}
