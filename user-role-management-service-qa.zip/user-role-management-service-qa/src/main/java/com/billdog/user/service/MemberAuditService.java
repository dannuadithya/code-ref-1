package com.billdog.user.service;

import java.math.BigInteger;
import java.sql.Date;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.RecordsTime;
import com.billdog.user.repository.MemberFamilyRepository;
import com.billdog.user.repository.MemberInsuranceDetailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.request.AuditRequest;
import com.billdog.user.view.GetCarrierInfo;
import com.billdog.user.view.ViewAuditData;
import com.billdog.user.view.ViewResponse;

@Service
public class MemberAuditService {

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	MemberFamilyRepository memberFamilyRepository;

	@Autowired
	MemberInsuranceDetailRepository memberInsuranceDetailRepository;

	@Autowired
	MemberInsuranceSerivce memberInsuranceSerivce;

	private static final Logger LOGGER = LoggerFactory.getLogger(MemberAuditService.class);

	public ResponseEntity<ViewResponse> getMemberAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getMemberAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.Custom.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}
		Page<Object[]> empObjects = memberRepository.getMemberAuditInfo(name, name, name, name, startDate, endDate,
				revtypes, auditRequest.getOrganizationId(), getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getData(empObjects.getContent());
		response.setTotalElements(empObjects.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getMemberFamilyData(List<Object[]> memberObjects) {
		List<ViewAuditData> viewAuditData = new ArrayList<>();

		memberObjects.forEach(item -> {
			ViewAuditData auditResponse = new ViewAuditData();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> familyObj = memberFamilyRepository.getMemberAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[11]).longValue());
				if (familyObj != null && !familyObj.isEmpty()) {
					for (Object[] item2 : familyObj) {
						auditResponse = setFamilyValues(item, item2, auditResponse);
					}
				}
				if (auditResponse != null && (!StringUtils.isBlank(auditResponse.getOldValue())
						|| !StringUtils.isBlank(auditResponse.getNewValue()))) {
					viewAuditData.add(auditResponse);
				} else {
					auditResponse.setNewValue(Constants.NO_CHANGE);
					auditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditData.add(auditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				auditResponse = setCreatedMemberFamily(item, auditResponse);
				if (auditResponse != null && !StringUtils.isBlank(auditResponse.getNewValue())) {
					viewAuditData.add(auditResponse);
				}
			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(memberObjects.size());
		response.setData(viewAuditData);
		response.setMessage(Constants.MEMBER_AUDIT_FETCHED);
		if (viewAuditData.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getMemberAuditInfo method ended");
		return response;
	}

	private ViewAuditData setCreatedMemberFamily(Object[] item, ViewAuditData auditResponse) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];
		if (item[5] != null) {
			newValue = newValue != null ? newValue + ", first name: " + item[5] : "first name: " + item[5];
		}

		if (item[7] != null) {
			newValue = newValue != null ? newValue + ", last name: " + item[7] : "last name: " + item[7];
		}
		if (item[4] != null) {
			newValue = newValue != null ? newValue + ", date of birth: " + item[4] : "date of birth: " + item[4];
		}

		if (item[8] != null && !StringUtils.isBlank((String) item[8])) {
			newValue = newValue != null ? newValue + ", middle name: " + item[8] : "middle name: " + item[8];
		}
		if (item[9] != null && !StringUtils.isBlank((String) item[9])) {
			newValue = newValue != null ? newValue + ", status: " + item[9] : "status: " + item[9];
		}

		if (item[13] != null && !StringUtils.isBlank((String) item[13])) {
			newValue = newValue != null ? newValue + ", relationship type: " + item[13]
					: "relationship type: " + item[13];
		}
		if (item[15] != null && !StringUtils.isBlank((String) item[15])) {
			newValue = newValue != null ? newValue + ", " + "name prefix: " + item[15] : "name prefix: " + item[15];
		}

		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		auditResponse.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		auditResponse.setNewValue(newValue);
		if (item[12] != null) {
			auditResponse.setModifiedBy(((String) item[12]));
			auditResponse.setMemberOrUser("User");
		} else {
			auditResponse.setModifiedBy(((String) item[14]));
			auditResponse
					.setModifiedBy(auditResponse.getModifiedBy().contains("null") ? "" : auditResponse.getModifiedBy());
			auditResponse.setMemberOrUser("Member");
		}
		return auditResponse;

	}

	private ViewAuditData setFamilyValues(Object[] item, Object[] item2, ViewAuditData viewAuditData) {
		boolean updated = false;
		String oldValue = null;
		String newValue = null;

		Timestamp updatedAt = (Timestamp) item[2];

		if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])
				&& !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", first name: " + item2[5] : "first name: " + item2[5];
			newValue = newValue != null ? newValue + ", first name: " + item[5] : "first name: " + item[5];
		}
		if (!StringUtils.isBlank((String) item[5]) && StringUtils.isBlank((String) item2[5])) {
			updated = true;
			newValue = newValue != null ? newValue + ", first name: " + item[5] : "first name: " + item[5];
		}
		if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", first name: " + item2[5] : "first name: " + item2[5];
		}

		if (!StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])
				&& !((String) item[7]).equalsIgnoreCase((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", last name: " + item2[7] : "last name: " + item2[7];
			newValue = newValue != null ? newValue + ", last name: " + item[7] : "last name: " + item[7];
		}
		if (!StringUtils.isBlank((String) item[7]) && StringUtils.isBlank((String) item2[7])) {
			updated = true;
			newValue = newValue != null ? newValue + ", last name: " + item[7] : "last name: " + item[7];
		}
		if (StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", last name: " + item2[7] : "last name: " + item2[7];
		}

		if (!StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])
				&& !((String) item[8]).equalsIgnoreCase((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "middle name: " + item2[8] : "middle name: " + item2[8];
			newValue = newValue != null ? newValue + ", " + "middle name: " + item[8] : "middle name: " + item[8];
		}
		if (!StringUtils.isBlank((String) item[8]) && StringUtils.isBlank((String) item2[8])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "middle name: " + item[8] : "middle name: " + item[8];
		}
		if (StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "middle name: " + item2[8] : "middle name: " + item2[8];
		}

		if (item[4] != null && item2[4] != null) {
			Date familyMemberDob = (Date) item[4];
			Date familyMemberDob2 = (Date) item2[4];
			if (!familyMemberDob.equals(familyMemberDob2)) {
				updated = true;
				oldValue = oldValue != null
						? oldValue + ", date of birth: "
								+ DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMemberDob2.toLocalDate())
						: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMemberDob2.toLocalDate());
				newValue = newValue != null
						? newValue + ", date of birth: "
								+ DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMemberDob.toLocalDate())
						: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMemberDob.toLocalDate());

			}
		}
		if (item[4] != null && item2[4] == null) {
			Date familyMemberDob = (Date) item[4];
			updated = true;
			newValue = newValue != null
					? newValue + ", date of birth: "
							+ DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMemberDob.toLocalDate())
					: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMemberDob.toLocalDate());

		}
		if (item[4] == null && item2[4] != null) {
			Date familyMemberDob2 = (Date) item2[4];
			updated = true;
			oldValue = oldValue != null
					? oldValue + ", date of birth: "
							+ DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMemberDob2.toLocalDate())
					: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(familyMemberDob2.toLocalDate());
		}

		if (!StringUtils.isBlank((String) item[9]) && !StringUtils.isBlank((String) item2[9])
				&& !((String) item[9]).equalsIgnoreCase((String) item2[9])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "status: " + item2[9] : "status: " + item2[9];
			newValue = newValue != null ? newValue + ", " + "status: " + item[9] : "status: " + item[9];
		}
		if (!StringUtils.isBlank((String) item[9]) && StringUtils.isBlank((String) item2[9])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "status: " + item[9] : "status: " + item[9];
		}
		if (StringUtils.isBlank((String) item[9]) && !StringUtils.isBlank((String) item2[9])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "status: " + item2[9] : "status: " + item2[9];
		}

		if (!StringUtils.isBlank((String) item[13]) && !StringUtils.isBlank((String) item2[13])
				&& !((String) item[13]).equalsIgnoreCase((String) item2[13])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "relationship type: " + item2[13]
					: "relationship type: " + item2[13];
			newValue = newValue != null ? newValue + ", " + "relationship type: " + item[13]
					: "relationship type: " + item[13];
		}
		if (!StringUtils.isBlank((String) item[13]) && StringUtils.isBlank((String) item2[13])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "relationship type: " + item[13]
					: "relationship type: " + item[13];
		}
		if (StringUtils.isBlank((String) item[13]) && !StringUtils.isBlank((String) item2[13])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "relationship type: " + item2[13]
					: "relationship type: " + item2[13];
		}
		if (!StringUtils.isBlank((String) item[15]) && !StringUtils.isBlank((String) item2[15])
				&& !((String) item[15]).equalsIgnoreCase((String) item2[15])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", name prefix: " + item2[15] : "name prefix: " + item2[15];
			newValue = newValue != null ? newValue + ", name prefix: " + item[15] : "name prefix: " + item[15];
		}
		if (!StringUtils.isBlank((String) item[15]) && StringUtils.isBlank((String) item2[15])) {
			updated = true;
			newValue = newValue != null ? newValue + ", name prefix: " + item[15] : "name prefix: " + item[15];
		}
		if (StringUtils.isBlank((String) item[15]) && !StringUtils.isBlank((String) item2[15])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", name prefix: " + item2[15] : "name prefix: " + item2[15];
		}

		if (updated) {
			viewAuditData.setRecordId(((BigInteger) item[0]).longValue());

			viewAuditData.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
			viewAuditData.setAction(Constants.UPDATED);
			viewAuditData.setOldValue(oldValue);
			viewAuditData.setNewValue(newValue);
			viewAuditData.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate())
									+ " " + DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			if (item[12] != null) {
				viewAuditData.setModifiedBy(((String) item[12]));
				viewAuditData.setMemberOrUser("User");
			} else {
				viewAuditData.setModifiedBy(((String) item[14]));
				viewAuditData.setModifiedBy(
						viewAuditData.getModifiedBy().contains("null") ? "" : viewAuditData.getModifiedBy());
				viewAuditData.setMemberOrUser("Member");
			}

			return viewAuditData;
		}
		viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
		viewAuditData.setAction(getAction(item[1]));
		viewAuditData.setUpdatedById(item[3] != null ? ((BigInteger) item[3]).longValue() : 0);
		viewAuditData.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		if (item[12] != null) {
			viewAuditData.setModifiedBy(((String) item[12]));
			viewAuditData.setMemberOrUser("User");
		} else {
			viewAuditData.setModifiedBy(((String) item[14]));
			viewAuditData
					.setModifiedBy(viewAuditData.getModifiedBy().contains("null") ? "" : viewAuditData.getModifiedBy());
			viewAuditData.setMemberOrUser("Member");
		}
		return viewAuditData;
	}

	private ViewResponse getData(List<Object[]> memObjects) {
		List<ViewAuditData> viewAuditData = new ArrayList<>();

		memObjects.forEach(item -> {
			ViewAuditData auditResponse = new ViewAuditData();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> empObj = memberRepository.getMemberAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[13]).longValue());
				if (empObj != null && !empObj.isEmpty()) {
					for (Object[] item2 : empObj) {
						auditResponse = setValues(item, item2, auditResponse);
					}
				}
				if (auditResponse != null && (!StringUtils.isBlank(auditResponse.getOldValue())
						|| !StringUtils.isBlank(auditResponse.getNewValue()))) {
					viewAuditData.add(auditResponse);
				} else {
					auditResponse.setNewValue(Constants.NO_CHANGE);
					auditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditData.add(auditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				auditResponse = setCreatedMember(item, auditResponse);
				if (auditResponse != null && !StringUtils.isBlank(auditResponse.getNewValue())) {
					viewAuditData.add(auditResponse);
				}
			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(memObjects.size());
		response.setData(viewAuditData);
		response.setMessage(Constants.MEMBER_AUDIT_FETCHED);
		if (viewAuditData.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getMemberAuditInfo method ended");
		return response;
	}

	public List<Long> getRevtypes(AuditRequest auditRequest) {
		List<Long> revtypes = new ArrayList<>();
		if (StringUtils.isBlank(auditRequest.getType()) || auditRequest.getType().equalsIgnoreCase("All")) {
			revtypes.add(0l);
			revtypes.add(1l);
			revtypes.add(2l);
		}
		if (auditRequest.getType().equalsIgnoreCase(Constants.CREATED)) {
			revtypes.add(0l);
		}
		if (auditRequest.getType().equalsIgnoreCase(Constants.UPDATED)
				|| auditRequest.getType().equalsIgnoreCase(Constants.MODIFIED)) {
			revtypes.add(1l);
		}
		return revtypes;
	}

	public LocalDateTime getDate(String time) {
		LocalDate date = LocalDate.now();
		if (time.equalsIgnoreCase(RecordsTime.Last_Week.toString().replace("_", " "))) {
			date = LocalDate.now().minusDays(7);
		} else if (time.equalsIgnoreCase(RecordsTime.Last_Month.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(1);
		} else if (time.equalsIgnoreCase(RecordsTime.Last_3_Months.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(3);
		} else if (time.equalsIgnoreCase(RecordsTime.Last_6_Months.toString().replace("_", " "))) {
			date = LocalDate.now().minusMonths(6);
		} else if (time.equalsIgnoreCase(RecordsTime.Last_Year.toString().replace("_", " "))) {
			date = LocalDate.now().minusYears(1);
		} else {
			date = LocalDate.of(2020, 01, 01);
		}
		return date.atTime(00, 00);
	}

	public ResponseEntity<ViewResponse> getMemberFamilyAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getMemberFamilyAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.Custom.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}
		Page<Object[]> familyObj = memberFamilyRepository.getMemberFamilyAuditInfo(name, name, name, name, startDate,
				endDate, revtypes, auditRequest.getOrganizationId(),
				getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getMemberFamilyData(familyObj.getContent());
		response.setTotalElements(familyObj.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	public ResponseEntity<ViewResponse> getMemberInsuranceAuditInfo(AuditRequest auditRequest, List<Long> revtypes) {

		LOGGER.info("getMemberInsuranceAuditInfo method started");
		int pageLimit = auditRequest.getPageLimit() > 0 ? auditRequest.getPageLimit() : 20;

		String name = null;
		if (auditRequest.getName() != null && !auditRequest.getName().equals("")) {
			name = "%" + auditRequest.getName() + "%";
		} else {
			name = auditRequest.getName();
		}

		String startDate = getDate(auditRequest.getTimePeriod()).toString();
		String endDate = LocalDate.now().toString();
		if (auditRequest.getTimePeriod().equalsIgnoreCase(RecordsTime.Custom.toString())) {
			startDate = auditRequest.getStartDate();
			endDate = auditRequest.getEndDate();
		}
		Page<Object[]> insuranceObj = memberInsuranceDetailRepository.getMemberInsuranceAuditInfo(name, name, name,
				name, startDate, endDate, revtypes, auditRequest.getOrganizationId(),
				getPageRequest(auditRequest.getPageNumber(), pageLimit));

		ViewResponse response = getMemberInsuranceData(insuranceObj.getContent());
		response.setTotalElements(insuranceObj.getTotalElements());
		return ResponseEntity.status(HttpStatus.OK).body(response);
	}

	private ViewResponse getMemberInsuranceData(List<Object[]> memberObjects) {
		List<ViewAuditData> viewAuditData = new ArrayList<>();

		memberObjects.forEach(item -> {
			ViewAuditData auditResponse = new ViewAuditData();
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> familyObj = memberInsuranceDetailRepository.getMemberAuditInfoByIdAndRev(
						((BigInteger) item[0]).longValue(), ((Integer) item[11]).longValue());
				if (familyObj != null && !familyObj.isEmpty()) {
					for (Object[] item2 : familyObj) {
						auditResponse = setInsuranceValues(item, item2, auditResponse);
					}
				}
				if (auditResponse != null && (!StringUtils.isBlank(auditResponse.getOldValue())
						|| !StringUtils.isBlank(auditResponse.getNewValue()))) {
					viewAuditData.add(auditResponse);
				} else {
					auditResponse.setNewValue(Constants.NO_CHANGE);
					auditResponse.setOldValue(Constants.NO_CHANGE);
					viewAuditData.add(auditResponse);
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				auditResponse = setCreatedMemberInsurance(item, auditResponse);
				if (auditResponse != null && !StringUtils.isBlank(auditResponse.getNewValue())) {
					viewAuditData.add(auditResponse);
				}
			}
		});

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setTotalElements(memberObjects.size());
		response.setData(viewAuditData);
		response.setMessage(Constants.MEMBER_AUDIT_FETCHED);
		if (viewAuditData.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getMemberAuditInfo method ended");
		return response;
	}

	private ViewAuditData setCreatedMemberInsurance(Object[] item, ViewAuditData auditResponse) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];

		
		if (item[4] != null) {
			newValue = newValue != null ? newValue + ", customer service contact number: " + item[4]
					: "customer service contact number: " + item[4];
		}

		if (item[5] != null) {
			newValue = newValue != null ? newValue + ", group id: " + item[5] : "group id: " + item[5];
		}
		if (item[6] != null) {
			newValue = newValue != null ? newValue + ", member insurance id: " + item[6]
					: "member insurance id: " + item[6];
		}

		if (item[7] != null && !StringUtils.isBlank((String) item[7])) {
			newValue = newValue != null ? newValue + ", product name: " + item[7] : "product name: " + item[7];
		}
		if (item[8] != null && !StringUtils.isBlank((String) item[8])) {
			newValue = newValue != null ? newValue + ", provider contact number: " + item[8]
					: "provider contact number: " + item[8];
		}

		if (item[14] != null && !StringUtils.isBlank((String) item[14])) {
			newValue = newValue != null ? newValue + ", insurance sub type: " + item[14]
					: "insurance sub type: " + item[14];
		}

		if (item[15] != null && !StringUtils.isBlank((String) item[15])) {
			newValue = newValue != null ? newValue + ", insurance type: " + item[15] : "insurance type: " + item[15];
		}
		if(item[3]!=null) {
			try {
				GetCarrierInfo checkCarrierType = null;
				checkCarrierType = memberInsuranceSerivce.checkCarrierType(((BigInteger) item[3]).longValue(),
						((BigInteger) item[18]).longValue());
				if (checkCarrierType != null && !StringUtils.isBlank(checkCarrierType.getCarrierName())) {
					newValue = newValue != null ? newValue + ", " + "carrier name: " + checkCarrierType.getCarrierName()
							: "carrier name: " + checkCarrierType.getCarrierName();
				}
			} catch (Exception e) {
				LOGGER.info("error occured while calling entity service");
			}
		}
		
		ViewAuditData viewAuditData2 = getInsuranceInfo(((BigInteger) item[0]).longValue(), (String) item[17]);
		if (viewAuditData2 != null && !StringUtils.isBlank(viewAuditData2.getNewValue())) {
			newValue = newValue != null ? newValue + ", " + viewAuditData2.getNewValue() : viewAuditData2.getNewValue();

		}
		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		auditResponse.setUpdatedById(item[12] != null ? ((BigInteger) item[12]).longValue() : 0);
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		auditResponse.setNewValue(newValue);
		if (item[12] != null) {
			auditResponse.setModifiedBy(((String) item[16]));
			auditResponse.setMemberOrUser("User");
		} else {
			auditResponse.setModifiedBy(((String) item[13]));
			auditResponse.setMemberOrUser("Member");
		}
		return auditResponse;

	}

	private boolean getValue(Object item) {
		if (item != null) {
			int actionValue = ((Integer) item);
			return actionValue == 1;
		}
		return false;
	}

	private ViewAuditData setInsuranceValues(Object[] item, Object[] item2, ViewAuditData viewAuditData) {
		boolean updated = false;
		String oldValue = null;
		String newValue = null;

		Timestamp updatedAt = (Timestamp) item[2];

		
		if (item[4] != null && !((String) item[4]).equalsIgnoreCase((String) item2[4])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "customer service contact number: " + item2[4]
					: "customer service contact number: " + item2[4];
			newValue = newValue != null ? newValue + ", " + "customer service contact number: " + item[4]
					: "customer service contact number: " + item[4];
		}
		if (!StringUtils.isBlank((String) item[4]) && StringUtils.isBlank((String) item2[4])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "customer service contact number: " + item[4]
					: "customer service contact number: " + item[4];
		}
		if (StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "customer service contact number: " + item2[4]
					: "customer service contact number: " + item2[4];
		}

		if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])
				&& !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", group id: " + item2[5] : "group id: " + item2[5];
			newValue = newValue != null ? newValue + ", group id: " + item[5] : "group id: " + item[5];
		}
		if (!StringUtils.isBlank((String) item[6]) && StringUtils.isBlank((String) item2[6])) {
			updated = true;
			newValue = newValue != null ? newValue + ", group id: " + item[5] : "group id: " + item[5];
		}
		if (StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", group id: " + item2[5] : "group id: " + item2[5];
		}

		if (!StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])
				&& !((String) item[6]).equalsIgnoreCase((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", member insurance id: " + item2[6]
					: "member insurance id: " + item2[6];
			newValue = newValue != null ? newValue + ", member insurance id: " + item[6]
					: "member insurance id: " + item[6];
		}
		if (!StringUtils.isBlank((String) item[6]) && StringUtils.isBlank((String) item2[6])) {
			updated = true;
			newValue = newValue != null ? newValue + ", member insurance id: " + item[6]
					: "member insurance id: " + item[6];
		}
		if (StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", member insurance id: " + item2[6]
					: "member insurance id: " + item2[6];
		}

		if (!StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])
				&& !((String) item[7]).equalsIgnoreCase((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "product name: " + item2[7] : "product name: " + item2[7];
			newValue = newValue != null ? newValue + ", " + "product name: " + item[7] : "product name: " + item[7];
		}
		if (!StringUtils.isBlank((String) item[7]) && StringUtils.isBlank((String) item2[7])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "product name: " + item[7] : "product name: " + item[7];
		}
		if (StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "product name: " + item2[7] : "product name: " + item2[7];
		}

		if (!StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])
				&& !((String) item[8]).equalsIgnoreCase((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "provider contact number: " + item2[8]
					: "provider contact number: " + item2[8];
			newValue = newValue != null ? newValue + ", " + "provider contact number: " + item[8]
					: "provider contact number: " + item[8];
		}
		if (!StringUtils.isBlank((String) item[8]) && StringUtils.isBlank((String) item2[8])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "provider contact number: " + item[8]
					: "provider contact number: " + item[8];
		}
		if (StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "provider contact number: " + item2[8]
					: "provider contact number: " + item2[8];
		}

		if (!StringUtils.isBlank((String) item[14]) && !StringUtils.isBlank((String) item2[14])
				&& !((String) item[14]).equalsIgnoreCase((String) item2[14])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "insurance sub type: " + item2[14]
					: "insurance sub type: " + item2[14];
			newValue = newValue != null ? newValue + ", " + "insurance sub type: " + item[14]
					: "insurance sub type: " + item[14];
		}
		if (!StringUtils.isBlank((String) item[14]) && StringUtils.isBlank((String) item2[14])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "insurance sub type: " + item[14]
					: "insurance sub type: " + item[14];
		}
		if (StringUtils.isBlank((String) item[14]) && !StringUtils.isBlank((String) item2[14])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "insurance sub type: " + item2[14]
					: "insurance sub type: " + item2[14];
		}

		if (!StringUtils.isBlank((String) item[15]) && !StringUtils.isBlank((String) item2[15])
				&& !((String) item[15]).equalsIgnoreCase((String) item2[15])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "insurance type: " + item2[15]
					: "insurance type: " + item2[15];
			newValue = newValue != null ? newValue + ", " + "insurance type: " + item[15]
					: "insurance type: " + item[15];
		}
		if (!StringUtils.isBlank((String) item[15]) && StringUtils.isBlank((String) item2[15])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "insurance type: " + item[15]
					: "insurance type: " + item[15];
		}
		if (StringUtils.isBlank((String) item[15]) && !StringUtils.isBlank((String) item2[15])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "insurance type: " + item2[15]
					: "insurance type: " + item2[15];
		}

		if (item[3] != null && item2[3] != null
				&& ((BigInteger) item[3]).longValue() != ((BigInteger) item2[3]).longValue()) {
			updated = true;

			try {
				GetCarrierInfo checkCarrierType = null;
				checkCarrierType = memberInsuranceSerivce.checkCarrierType(((BigInteger) item2[3]).longValue(),
						((BigInteger) item[18]).longValue());
				if (checkCarrierType != null && !StringUtils.isBlank(checkCarrierType.getCarrierName())) {
					updated = true;
					oldValue = oldValue != null ? oldValue + ", " + "carrier name: " + checkCarrierType.getCarrierName()
							: "carrier name: " + checkCarrierType.getCarrierName();
				}
			} catch (Exception e) {
				LOGGER.info("error occured while calling entity service");
			}

			try {
				GetCarrierInfo checkCarrierType = null;
				checkCarrierType = memberInsuranceSerivce.checkCarrierType(((BigInteger) item[3]).longValue(),
						((BigInteger) item[18]).longValue());
				if (checkCarrierType != null && !StringUtils.isBlank(checkCarrierType.getCarrierName())) {
					updated = true;
					newValue = newValue != null ? newValue + ", " + "carrier name: " + checkCarrierType.getCarrierName()
							: "carrier name: " + checkCarrierType.getCarrierName();
				}
			} catch (Exception e) {
				LOGGER.info("error occured while calling entity service");
			}

		}
		if (item[3] != null && item2[3] == null) {
			updated = true;
			try {
				GetCarrierInfo checkCarrierType = null;
				checkCarrierType = memberInsuranceSerivce.checkCarrierType(((BigInteger) item[3]).longValue(),
						((BigInteger) item[18]).longValue());
				if (checkCarrierType != null && !StringUtils.isBlank(checkCarrierType.getCarrierName())) {
					updated = true;
					newValue = newValue != null ? newValue + ", " + "carrier name: " + checkCarrierType.getCarrierName()
							: "carrier name: " + checkCarrierType.getCarrierName();
				}
			} catch (Exception e) {
				LOGGER.info("error occured while calling entity service");
			}
		}
		if (item[3] == null && item2[3] != null) {
			try {
				GetCarrierInfo checkCarrierType = null;
				checkCarrierType = memberInsuranceSerivce.checkCarrierType(((BigInteger) item2[3]).longValue(),
						((BigInteger) item[18]).longValue());
				if (checkCarrierType != null && !StringUtils.isBlank(checkCarrierType.getCarrierName())) {
					updated = true;
					oldValue = oldValue != null ? oldValue + ", " + "carrier name: " + checkCarrierType.getCarrierName()
							: "carrier name: " + checkCarrierType.getCarrierName();
				}
			} catch (Exception e) {
				LOGGER.info("error occured while calling entity service");
			}
		}

		ViewAuditData viewAuditData2 = getInsuranceInfo(((BigInteger) item[0]).longValue(), (String) item[17]);
		if (viewAuditData2 != null) {
			if (!StringUtils.isBlank(viewAuditData2.getOldValue())) {
				updated = true;
				oldValue = oldValue != null ? oldValue + ", " + viewAuditData2.getOldValue()
						: viewAuditData2.getOldValue();
			}
			if (!StringUtils.isBlank(viewAuditData2.getNewValue())) {
				updated = true;
				newValue = newValue != null ? newValue + ", " + viewAuditData2.getNewValue()
						: viewAuditData2.getNewValue();
			}
		}

		if (updated) {
			viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
			viewAuditData.setUpdatedById(item[12] != null ? ((BigInteger) item[12]).longValue() : 0);
			viewAuditData.setAction(Constants.UPDATED);
			viewAuditData.setOldValue(oldValue);
			viewAuditData.setNewValue(newValue);
			viewAuditData.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate())
									+ " " + DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			if (item[12] != null) {
				viewAuditData.setModifiedBy(((String) item[16]));
				viewAuditData.setMemberOrUser("User");
			} else {
				viewAuditData.setModifiedBy(((String) item[13]));
				viewAuditData.setMemberOrUser("Member");
			}

			return viewAuditData;
		}
		viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
		viewAuditData.setAction(getAction(item[1]));
		viewAuditData.setUpdatedById(item[12] != null ? ((BigInteger) item[12]).longValue() : 0);
		viewAuditData.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		if (item[12] != null) {
			viewAuditData.setModifiedBy(((String) item[16]));
			viewAuditData.setMemberOrUser("User");
		} else {
			viewAuditData.setModifiedBy(((String) item[13]));
			viewAuditData.setMemberOrUser("Member");
		}
		return viewAuditData;
	}

	private ViewAuditData getInsuranceInfo(long id, String auditId) {
		String oldInsuranceValue = null;
		String newInsuranceValue = null;
		ViewAuditData auditResponse = new ViewAuditData();

		List<Object[]> memberInsuranceDetails = memberInsuranceDetailRepository.getMemberInsuranceInfoByInsuranceId(id,
				auditId);

		for (Object[] insurance : memberInsuranceDetails) {
			if (getAction(insurance[7]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> memberInsuranceDetails2 = memberInsuranceDetailRepository.getMemberInsuranceDetailsById(
						((BigInteger) insurance[0]).longValue(), ((Integer) insurance[6]).longValue());
				if (memberInsuranceDetails2 != null && !memberInsuranceDetails2.isEmpty()) {
					for (Object[] insurance2 : memberInsuranceDetails2) {
						String oldValue = null;
						String newValue = null;
						if (((Integer) insurance[2]).intValue() > 0 && ((Integer) insurance2[2]).intValue() > 0
								&& (((Integer) insurance[2]).intValue() != ((Integer) insurance2[2]).intValue())) {
							oldValue = oldValue != null ? oldValue + ", spec: " + insurance2[2]
									: "spec: " + insurance2[2];
							newValue = newValue != null ? newValue + ",  spec: " + insurance[2]
									: "spec: " + insurance[2];
						}
						if (((Integer) insurance[2]).intValue() > 0 && ((Integer) insurance2[2]).intValue() == 0) {
							newValue = newValue != null ? newValue + ",  spec: " + insurance[2]
									: "spec: " + insurance[2];
						}
						if (((Integer) insurance[2]).intValue() == 0 && ((Integer) insurance2[2]).intValue() > 0) {
							oldValue = oldValue != null ? oldValue + ", spec: " + insurance2[2]
									: "spec: " + insurance2[2];
						}

						if (((Integer) insurance[3]).intValue() > 0 && ((Integer) insurance2[3]).intValue() > 0
								&& (((Integer) insurance[3]).intValue() != ((Integer) insurance2[3]).intValue())) {
							oldValue = oldValue != null ? oldValue + ", pcp: " + insurance2[3]
									: "pcp: " + insurance2[3];
							newValue = newValue != null ? newValue + ",  pcp: " + insurance[3] : "pcp: " + insurance[3];
						}
						if (((Integer) insurance[3]).intValue() > 0 && ((Integer) insurance2[3]).intValue() == 0) {
							newValue = newValue != null ? newValue + ",  pcp: " + insurance[3] : "pcp: " + insurance[3];
						}
						if (((Integer) insurance[3]).intValue() == 0 && ((Integer) insurance2[3]).intValue() > 0) {
							oldValue = oldValue != null ? oldValue + ", pcp: " + insurance2[3]
									: "pcp: " + insurance2[3];
						}
						if (((Integer) insurance[4]).intValue() > 0 && ((Integer) insurance2[4]).intValue() > 0
								&& (((Integer) insurance[4]).intValue() != ((Integer) insurance2[4]).intValue())) {
							oldValue = oldValue != null ? oldValue + ", er: " + insurance2[4] : "er: " + insurance2[4];
							newValue = newValue != null ? newValue + ",  er: " + insurance[4] : "er: " + insurance[4];
						}
						if (((Integer) insurance[4]).intValue() > 0 && ((Integer) insurance2[4]).intValue() == 0) {
							newValue = newValue != null ? newValue + ",  er: " + insurance[4] : "er: " + insurance[4];
						}
						if (((Integer) insurance[4]).intValue() == 0 && ((Integer) insurance2[4]).intValue() > 0) {
							oldValue = oldValue != null ? oldValue + ", er: " + insurance2[4] : "er: " + insurance2[4];
						}
						if (((Integer) insurance[5]).intValue() > 0 && ((Integer) insurance2[5]).intValue() > 0
								&& (((Integer) insurance[5]).intValue() != ((Integer) insurance2[5]).intValue())) {
							oldValue = oldValue != null ? oldValue + ", ded: " + insurance2[5]
									: "ded: " + insurance2[5];
							newValue = newValue != null ? newValue + ",  ded: " + insurance[5] : "ded: " + insurance[5];
						}
						if (((Integer) insurance[5]).intValue() > 0 && ((Integer) insurance2[5]).intValue() == 0) {
							newValue = newValue != null ? newValue + ",  ded: " + insurance[5] : "ded: " + insurance[5];
						}
						if (((Integer) insurance[5]).intValue() == 0 && ((Integer) insurance2[5]).intValue() > 0) {
							oldValue = oldValue != null ? oldValue + ", ded: " + insurance2[5]
									: "ded: " + insurance2[5];
						}

						if (oldValue != null) {
							oldInsuranceValue = oldInsuranceValue != null
									? oldInsuranceValue + ", insurance type name: " + (String) insurance2[1] + ", "
											+ oldValue
									: "insurance type name: " + (String) insurance2[1] + ", " + oldValue;
						}
						if (newValue != null) {
							newInsuranceValue = newInsuranceValue != null
									? newInsuranceValue + ", insurance type name: " + (String) insurance[1] + ", "
											+ newValue
									: "insurance type name: " + (String) insurance[1] + ", " + newValue;
						}
					}
				}
			}
			if (getAction(insurance[7]).equalsIgnoreCase(Constants.CREATED)) {
				String newValue = null;
				if (((Integer) insurance[2]).intValue() > 0) {
					newValue = newValue != null ? newValue + ",  spec: " + insurance[2] : "spec: " + insurance[2];
				}
				if (((Integer) insurance[3]).intValue() > 0) {
					newValue = newValue != null ? newValue + ",  pcp: " + insurance[3] : "pcp: " + insurance[3];
				}
				if (((Integer) insurance[4]).intValue() > 0) {
					newValue = newValue != null ? newValue + ",  er: " + insurance[4] : "er: " + insurance[4];
				}
				if (((Integer) insurance[5]).intValue() > 0) {
					newValue = newValue != null ? newValue + ",  ded: " + insurance[5] : "ded: " + insurance[5];
				}
				if (newValue != null) {
					newInsuranceValue = newInsuranceValue != null
							? newInsuranceValue + ", insurance type name: " + (String) insurance[1] + ", " + newValue
							: "insurance type name: " + (String) insurance[1] + ", " + newValue;
				}
			}
		}
		auditResponse.setOldValue(oldInsuranceValue);
		auditResponse.setNewValue(newInsuranceValue);
		return auditResponse;
	}




	private ViewAuditData setValues(Object[] item, Object[] item2, ViewAuditData viewAuditData) {
		boolean updated = false;
		String oldValue = null;
		String newValue = null;

		Timestamp updatedAt = (Timestamp) item[2];

		if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])
				&& !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", first name: " + item2[5] : "first name: " + item2[5];
			newValue = newValue != null ? newValue + ", first name: " + item[5] : "first name: " + item[5];
		}
		if (!StringUtils.isBlank((String) item[5]) && StringUtils.isBlank((String) item2[5])) {
			updated = true;
			newValue = newValue != null ? newValue + ", first name: " + item[5] : "first name: " + item[5];
		}
		if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", first name: " + item2[5] : "first name: " + item2[5];
		}

		if (!StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])
				&& !((String) item[4]).equalsIgnoreCase((String) item2[4])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", last name: " + item2[4] : "last name: " + item2[4];
			newValue = newValue != null ? newValue + ", last name: " + item[4] : "last name: " + item[4];
		}
		if (!StringUtils.isBlank((String) item[4]) && StringUtils.isBlank((String) item2[4])) {
			updated = true;
			newValue = newValue != null ? newValue + ", last name: " + item[4] : "last name: " + item[4];
		}
		if (StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", last name: " + item2[4] : "last name: " + item2[4];
		}

		if (item[6] != null && item2[6] != null) {
			Date memberDob = (Date) item[6];
			Date memberDob2 = (Date) item2[6];
			if (!memberDob.equals(memberDob2)) {
				updated = true;
				oldValue = oldValue != null
						? oldValue + ", date of birth: "
								+ DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob2.toLocalDate())
						: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob2.toLocalDate());
				newValue = newValue != null
						? newValue + ", date of birth: "
								+ DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob.toLocalDate())
						: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob.toLocalDate());

			}
		}
		if (item[6] != null && item2[6] == null) {
			Date memberDob = (Date) item[6];
			updated = true;
			newValue = newValue != null
					? newValue + ", date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob.toLocalDate())
					: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob.toLocalDate());

		}
		if (item[6] == null && item2[6] != null) {
			Date memberDob2 = (Date) item2[6];
			updated = true;
			oldValue = oldValue != null
					? oldValue + ", date of birth: "
							+ DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob2.toLocalDate())
					: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob2.toLocalDate());
		}

		if (!StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])
				&& !((String) item[7]).equalsIgnoreCase((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "phone number: " + item2[7] : "phone number: " + item2[7];
			newValue = newValue != null ? newValue + ", " + "phone number: " + item[7] : "phone number: " + item[7];
		}
		if (!StringUtils.isBlank((String) item[7]) && StringUtils.isBlank((String) item2[7])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "phone number: " + item[7] : "phone number: " + item[7];
		}
		if (StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "phone number: " + item2[7] : "phone number: " + item2[7];
		}

		if (!StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])
				&& !((String) item[8]).equalsIgnoreCase((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "status: " + item2[8] : "status: " + item2[8];
			newValue = newValue != null ? newValue + ", " + "status: " + item[8] : "status: " + item[8];
		}
		if (!StringUtils.isBlank((String) item[8]) && StringUtils.isBlank((String) item2[8])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "status: " + item[8] : "status: " + item[8];
		}
		if (StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "status: " + item2[8] : "status: " + item2[8];
		}

		if (!StringUtils.isBlank((String) item[16]) && !StringUtils.isBlank((String) item2[16])
				&& !((String) item[16]).equalsIgnoreCase((String) item2[16])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "gender: " + item2[16] : "gender: " + item2[16];
			newValue = newValue != null ? newValue + ", " + "gender: " + item[16] : "gender: " + item[16];
		}
		if (!StringUtils.isBlank((String) item[16]) && StringUtils.isBlank((String) item2[16])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "gender: " + item[16] : "gender: " + item[16];
		}
		if (StringUtils.isBlank((String) item[16]) && !StringUtils.isBlank((String) item2[16])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "gender: " + item2[16] : "gender: " + item2[16];
		}

		if (!StringUtils.isBlank((String) item[17]) && !StringUtils.isBlank((String) item2[17])
				&& !((String) item[17]).equalsIgnoreCase((String) item2[17])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "name prefix: " + item2[17] : "name prefix: " + item2[17];
			newValue = newValue != null ? newValue + ", " + "name prefix: " + item[17] : "name prefix: " + item[17];
		}
		if (!StringUtils.isBlank((String) item[17]) && StringUtils.isBlank((String) item2[17])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "name prefix: " + item[17] : "name prefix: " + item[17];
		}
		if (StringUtils.isBlank((String) item[17]) && !StringUtils.isBlank((String) item2[17])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "name prefix: " + item2[17] : "name prefix: " + item2[17];
		}

		if (!StringUtils.isBlank((String) item[18]) && !StringUtils.isBlank((String) item2[18])
				&& !((String) item[18]).equalsIgnoreCase((String) item2[18])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "product: " + item2[18] : "product: " + item2[18];
			newValue = newValue != null ? newValue + ", " + "product: " + item[18] : "product: " + item[18];
		}
		if (!StringUtils.isBlank((String) item[18]) && StringUtils.isBlank((String) item2[18])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "product: " + item[18] : "product: " + item[18];
		}
		if (StringUtils.isBlank((String) item[18]) && !StringUtils.isBlank((String) item2[18])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "product: " + item2[18] : "product: " + item2[18];
		}

		if (!StringUtils.isBlank((String) item[12]) && !StringUtils.isBlank((String) item2[12])
				&& !((String) item[12]).equalsIgnoreCase((String) item2[12])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "middle name: " + item2[12] : "middle name: " + item2[12];
			newValue = newValue != null ? newValue + ", " + "middle name: " + item[12] : "middle name: " + item[12];
		}
		if (!StringUtils.isBlank((String) item[12]) && StringUtils.isBlank((String) item2[12])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "middle name: " + item[12] : "middle name: " + item[12];
		}
		if (StringUtils.isBlank((String) item[12]) && !StringUtils.isBlank((String) item2[12])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "middle name: " + item2[12] : "middle name: " + item2[12];
		}

		if (!StringUtils.isBlank((String) item[20]) && !StringUtils.isBlank((String) item2[20])
				&& !((String) item[20]).equalsIgnoreCase((String) item2[20])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "sfdc id: " + item2[20] : "sfdc id: " + item2[20];
			newValue = newValue != null ? newValue + ", " + "sfdc id: " + item[20] : "sfdc id: " + item[20];
		}
		if (!StringUtils.isBlank((String) item[20]) && StringUtils.isBlank((String) item2[20])) {
			updated = true;
			newValue = newValue != null ? newValue + ", " + "sfdc id: " + item[20] : "sfdc id: " + item[20];
		}
		if (StringUtils.isBlank((String) item[20]) && !StringUtils.isBlank((String) item2[20])) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", " + "sfdc id: " + item2[20] : "sfdc id: " + item2[20];
		}

		if ((getValue(item[21]) && !getValue(item2[21])) || (!getValue(item[21]) && getValue(item2[21]))) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", locked: " + getValue(item2[21])
					: "locked: " + getValue(item2[21]);
			newValue = newValue != null ? newValue + ", locked: " + getValue(item[21])
					: "locked: " + getValue(item[21]);
		}

		if ((getValue(item[22]) && !getValue(item2[22])) || (!getValue(item[22]) && getValue(item2[22]))) {
			updated = true;
			oldValue = oldValue != null ? oldValue + ", locked from web: " + getValue(item2[22])
					: "locked from web: " + getValue(item2[22]);
			newValue = newValue != null ? newValue + ", locked from web: " + getValue(item[22])
					: "locked from web: " + getValue(item[22]);
		}

		ViewAuditData viewAuditData2 = getEmailInfo(((BigInteger) item[0]).longValue(), (String) item[19]);
		if (viewAuditData2 != null) {
			if (!StringUtils.isBlank(viewAuditData2.getOldValue())) {
				updated = true;
				oldValue = oldValue != null ? oldValue + ", " + viewAuditData2.getOldValue()
						: viewAuditData2.getOldValue();
			}
			if (!StringUtils.isBlank(viewAuditData2.getNewValue())) {
				newValue = newValue != null ? newValue + ", " + viewAuditData2.getNewValue()
						: viewAuditData2.getNewValue();
			}
		}

		ViewAuditData addressAudit = getAddressInfo(((BigInteger) item[0]).longValue(), (String) item[19]);
		if (addressAudit != null) {
			if (!StringUtils.isBlank(addressAudit.getOldValue())) {
				updated = true;
				oldValue = oldValue != null ? oldValue + ", " + addressAudit.getOldValue()
						: addressAudit.getOldValue();
			}
			if (!StringUtils.isBlank(addressAudit.getNewValue())) {
				updated = true;
				newValue = newValue != null ? newValue + ", " + addressAudit.getNewValue()
						: addressAudit.getNewValue();
			}
		}

		if (updated) {
			viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
			viewAuditData.setUpdatedById(item[14] != null ? ((BigInteger) item[14]).longValue() : 0);
			viewAuditData.setAction(Constants.UPDATED);
			viewAuditData.setOldValue(oldValue);
			viewAuditData.setNewValue(newValue);
			viewAuditData.setUpdatedAt(
					updatedAt != null
							? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate())
									+ " " + DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
							: null);
			if (item[15] != null) {
				viewAuditData.setModifiedBy(((String) item[15]));
				viewAuditData.setMemberOrUser("User");
			} else {
				viewAuditData.setModifiedBy(((String) item[5]) + " " + (String) item[4]);
				viewAuditData.setModifiedBy(
						viewAuditData.getModifiedBy().contains("null") ? "" : viewAuditData.getModifiedBy());
				viewAuditData.setMemberOrUser("Member");
			}

			return viewAuditData;
		}
		viewAuditData.setRecordId(((BigInteger) item[0]).longValue());
		viewAuditData.setAction(getAction(item[1]));
		viewAuditData.setUpdatedById(item[14] != null ? ((BigInteger) item[14]).longValue() : 0);
		viewAuditData.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		if (item[15] != null) {
			viewAuditData.setModifiedBy(((String) item[15]));
			viewAuditData.setMemberOrUser("User");
		} else {
			viewAuditData.setModifiedBy(((String) item[5]) + " " + (String) item[4]);
			viewAuditData
					.setModifiedBy(viewAuditData.getModifiedBy().contains("null") ? "" : viewAuditData.getModifiedBy());
			viewAuditData.setMemberOrUser("Member");
		}
		return viewAuditData;
	}

	private ViewAuditData getEmailInfo(long memberId, String auditId) {
		String oldEmailValue = null;
		String newEmailValue = null;
		ViewAuditData auditResponse = new ViewAuditData();

		List<Object[]> memberEmails = memberRepository.getMemberEmailAuditInfo(memberId, auditId);

		for (Object[] memberEmail : memberEmails) {
			if (getAction(memberEmail[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> memberEmails2 = memberRepository.getMemberEmailAuditById(
						((BigInteger) memberEmail[0]).longValue(), ((Integer) memberEmail[5]).longValue());
				if (memberEmails2 != null && !memberEmails2.isEmpty()) {
					for (Object[] memberEmail2 : memberEmails2) {
						String oldValue = null;
						String newValue = null;
						if (!StringUtils.isBlank((String) memberEmail[3])
								&& !StringUtils.isBlank((String) memberEmail2[3])
								&& !((String) memberEmail[3]).equalsIgnoreCase((String) memberEmail2[3])) {
							oldValue = oldValue != null ? oldValue + ", email: " + memberEmail2[3]
									: "email: " + memberEmail2[3];
							newValue = newValue != null ? newValue + ", email: " + memberEmail[3]
									: "email: " + memberEmail[3];
						}
						if (!StringUtils.isBlank((String) memberEmail[3])
								&& StringUtils.isBlank((String) memberEmail2[3])) {
							newValue = newValue != null ? newValue + ", email: " + memberEmail[3]
									: "email: " + memberEmail[3];
						}
						if (StringUtils.isBlank((String) memberEmail[3])
								&& !StringUtils.isBlank((String) memberEmail2[3])) {
							oldValue = oldValue != null ? oldValue + ", email: " + memberEmail2[3]
									: "email: " + memberEmail2[3];
						}

						if (memberEmail[4] != null && memberEmail2[4] != null && Boolean.TRUE.equals(memberEmail[4])
								&& !Boolean.TRUE.equals(memberEmail2[4])) {

							oldValue = oldValue != null ? oldValue + ", primary: " + memberEmail2[4]
									: "primary: " + memberEmail2[4];
							newValue = newValue != null ? newValue + ", primary: " + memberEmail[4]
									: "primary: " + memberEmail[4];
						}

						if (memberEmail[2] != null && memberEmail2[2] != null && Boolean.TRUE.equals(memberEmail[2])
								&& !Boolean.TRUE.equals(memberEmail2[2])) {

							oldValue = oldValue != null ? oldValue + ", deleted: " + memberEmail2[2]
									: "deleted: " + memberEmail2[2];
							newValue = newValue != null ? newValue + ", deleted: " + memberEmail[2]
									: "deleted: " + memberEmail[2];
						}

						if (oldValue != null) {
							oldEmailValue = oldEmailValue != null ? oldEmailValue + ", " + oldValue : oldValue;

						}
						if (newValue != null) {
							newEmailValue = newEmailValue != null ? newEmailValue + ", " + newValue : newValue;
						}
					}
				}
			}
			if (getAction(memberEmail[1]).equalsIgnoreCase(Constants.CREATED)) {
				String newValue = null;
				if (memberEmail[3] != null && !StringUtils.isBlank((String) memberEmail[3])) {
					newValue = newValue != null ? newValue + ", email: " + memberEmail[3] : "email: " + memberEmail[3];
				}
				newValue = newValue != null ? newValue + ", primary: " + memberEmail[4] : "primary: " + memberEmail[4];

				newValue = newValue != null ? newValue + ", deleted: " + memberEmail[2] : "deleted: " + memberEmail[2];

				if (newValue != null) {
					newEmailValue = newEmailValue != null ? newEmailValue + ", " + newValue : newValue;
				}
			}
		}
		auditResponse.setOldValue(oldEmailValue);
		auditResponse.setNewValue(newEmailValue);
		return auditResponse;
	}
	
	
	private ViewAuditData getAddressInfo(long memberId, String auditId) {
		String oldEmailValue = null;
		String newEmailValue = null;
		ViewAuditData auditResponse = new ViewAuditData();

		List<Object[]> memberAddress = memberRepository.getMemberAddressInfo(auditId);

		for (Object[] item : memberAddress) {
			if (getAction(item[1]).equalsIgnoreCase(Constants.UPDATED)) {
				List<Object[]> memberAddress2 = memberRepository.getMemberAddressInfoById(
						((BigInteger) item[0]).longValue(), ((Integer) item[2]).longValue());
				if (memberAddress2 != null && !memberAddress2.isEmpty()) {
					for (Object[] item2 : memberAddress2) {
						String oldValue = null;
						String newValue = null;
						if (!StringUtils.isBlank((String) item[3]) && !StringUtils.isBlank((String) item2[3])
								&& !((String) item[3]).equalsIgnoreCase((String) item2[3])) {
							oldValue = oldValue != null ? oldValue + ", address line 1: " + item2[3] : "address line 1: " + item2[3];
							newValue = newValue != null ? newValue + ", address line 1: " + item[3] : "address line 1: " + item[3];
						}
						if (!StringUtils.isBlank((String) item[3]) && StringUtils.isBlank((String) item2[3])) {
							newValue = newValue != null ? newValue + ", address line 1: " + item[3] : "address line 1: " + item[3];
						}
						if (StringUtils.isBlank((String) item[3]) && !StringUtils.isBlank((String) item2[3])) {
							oldValue = oldValue != null ? oldValue + ", address line 1: " + item2[3] : "address line 1: " + item2[3];
						}

						if (!StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])
								&& !((String) item[4]).equalsIgnoreCase((String) item2[4])) {
							oldValue = oldValue != null ? oldValue + ", address line 2: " + item2[4] : "address line 2: " + item2[4];
							newValue = newValue != null ? newValue + ", address line 2: " + item[4] : "address line 2: " + item[4];
						}
						if (!StringUtils.isBlank((String) item[4]) && StringUtils.isBlank((String) item2[4])) {
							newValue = newValue != null ? newValue + ", address line 2: " + item[4] : "address line 2: " + item[4];
						}
						if (StringUtils.isBlank((String) item[4]) && !StringUtils.isBlank((String) item2[4])) {
							oldValue = oldValue != null ? oldValue + ", address line 2: " + item2[4] : "address line 2: " + item2[4];
						}

						if (!StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])
								&& !((String) item[5]).equalsIgnoreCase((String) item2[5])) {
							oldValue = oldValue != null ? oldValue + ", city name: " + item2[5] : "city name: " + item2[5];
							newValue = newValue != null ? newValue + ", city name: " + item[5] : "city name: " + item[5];
						}
						if (!StringUtils.isBlank((String) item[5]) && StringUtils.isBlank((String) item2[5])) {
							newValue = newValue != null ? newValue + ", city name: " + item[5] : "city name: " + item[5];
						}
						if (StringUtils.isBlank((String) item[5]) && !StringUtils.isBlank((String) item2[5])) {
							oldValue = oldValue != null ? oldValue + ", city name: " + item2[5] : "city name: " + item2[5];
						}

						if (!StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])
								&& !((String) item[6]).equalsIgnoreCase((String) item2[6])) {
							oldValue = oldValue != null ? oldValue + ", street: " + item2[6] : "street: " + item2[6];
							newValue = newValue != null ? newValue + ", street: " + item[6] : "street: " + item[6];
						}
						if (!StringUtils.isBlank((String) item[6]) && StringUtils.isBlank((String) item2[6])) {
							newValue = newValue != null ? newValue + ", street: " + item[6] : "street: " + item[6];
						}
						if (StringUtils.isBlank((String) item[6]) && !StringUtils.isBlank((String) item2[6])) {
							oldValue = oldValue != null ? oldValue + ", street: " + item2[6] : "street: " + item2[6];
						}

						if (!StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])
								&& !((String) item[7]).equalsIgnoreCase((String) item2[7])) {
							oldValue = oldValue != null ? oldValue + ", zip code: " + item2[7] : "zip code: " + item2[7];
							newValue = newValue != null ? newValue + ", zip code: " + item[7] : "zip code: " + item[7];
						}
						if (!StringUtils.isBlank((String) item[7]) && StringUtils.isBlank((String) item2[7])) {
							newValue = newValue != null ? newValue + ", zip code: " + item[7] : "zip code: " + item[7];
						}
						if (StringUtils.isBlank((String) item[7]) && !StringUtils.isBlank((String) item2[7])) {
							oldValue = oldValue != null ? oldValue + ", zip code: " + item2[7] : "zip code: " + item2[7];
						}

						if (!StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])
								&& !((String) item[8]).equalsIgnoreCase((String) item2[8])) {
							oldValue = oldValue != null ? oldValue + ", country name: " + item2[8] : "country name: " + item2[8];
							newValue = newValue != null ? newValue + ", country name: " + item[8] : "country name: " + item[8];
						}
						if (!StringUtils.isBlank((String) item[8]) && StringUtils.isBlank((String) item2[8])) {
							newValue = newValue != null ? newValue + ", country name: " + item[8] : "country name: " + item[8];
						}
						if (StringUtils.isBlank((String) item[8]) && !StringUtils.isBlank((String) item2[8])) {
							oldValue = oldValue != null ? oldValue + ", country name: " + item2[8] : "country name: " + item2[8];
						}

						if (!StringUtils.isBlank((String) item[9]) && !StringUtils.isBlank((String) item2[9])
								&& !((String) item[9]).equalsIgnoreCase((String) item2[9])) {
							oldValue = oldValue != null ? oldValue + ", state name: " + item2[9] : "state name: " + item2[9];
							newValue = newValue != null ? newValue + ", state name: " + item[9] : "state name: " + item[9];
						}
						if (!StringUtils.isBlank((String) item[9]) && StringUtils.isBlank((String) item2[9])) {
							newValue = newValue != null ? newValue + ", state name: " + item[9] : "state name: " + item[9];
						}
						if (StringUtils.isBlank((String) item[9]) && !StringUtils.isBlank((String) item2[9])) {
							oldValue = oldValue != null ? oldValue + ", state name: " + item2[9] : "state name: " + item2[9];
						}

						if (oldValue != null) {
							oldEmailValue = oldEmailValue != null ? oldEmailValue + ", " + oldValue : oldValue;

						}
						if (newValue != null) {
							newEmailValue = newEmailValue != null ? newEmailValue + ", " + newValue : newValue;
						}
					}
				}
			}
			if (getAction(item[1]).equalsIgnoreCase(Constants.CREATED)) {
				String newValue = null;
				if (!StringUtils.isBlank((String) item[3])) {
					newValue = newValue != null ? newValue + ", address line 1: " + item[3] : "address line 1: " + item[3];
				}

				if (!StringUtils.isBlank((String) item[4])) {
					newValue = newValue != null ? newValue + ", address line 2: " + item[4] : "address line 2: " + item[4];
				}
				if (!StringUtils.isBlank((String) item[5])) {
					newValue = newValue != null ? newValue + ", city name: " + item[5] : "city name: " + item[5];
				}
				if (!StringUtils.isBlank((String) item[6])) {
					newValue = newValue != null ? newValue + ", street: " + item[6] : "street: " + item[6];
				}

				if (!StringUtils.isBlank((String) item[7])) {
					newValue = newValue != null ? newValue + ", zip code: " + item[7] : "zip code: " + item[7];
				}
				if (!StringUtils.isBlank((String) item[8])) {
					newValue = newValue != null ? newValue + ", country name: " + item[8] : "country name: " + item[8];
				}
				if (!StringUtils.isBlank((String) item[9])) {
					newValue = newValue != null ? newValue + ", state name: " + item[9] : "state name: " + item[9];
				}
				if (newValue != null) {
					newEmailValue = newEmailValue != null ? newEmailValue + ", " + newValue : newValue;
				}
			}
		}
		auditResponse.setOldValue(oldEmailValue);
		auditResponse.setNewValue(newEmailValue);
		return auditResponse;
	}



	private String getAction(Object item) {
		String action = "";
		int actionValue = ((Byte) item);
		if (actionValue == 0) {
			action = Constants.CREATED;
		}
		if (actionValue == 1) {
			action = Constants.UPDATED;
		}
		if (actionValue == 2) {
			action = Constants.DELETED;
		}
		return action;
	}

	private ViewAuditData setCreatedMember(Object[] item, ViewAuditData auditResponse) {
		String newValue = null;
		Timestamp updatedAt = (Timestamp) item[2];

		if (item[5] != null && !StringUtils.isBlank((String) item[5])) {
			newValue = newValue != null ? newValue + ", first name: " + item[5] : "first name: " + item[5];
		}
		if (item[4] != null && !StringUtils.isBlank((String) item[4])) {
			newValue = newValue != null ? newValue + ", last name: " + item[4] : "last name: " + item[4];
		}

		if (item[6] != null) {
			Date memberDob = (Date) item[6];
			newValue = newValue != null
					? newValue + ", date of birth: "
							+ DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob.toLocalDate())
					: "date of birth: " + DateAndTimeUtil.convertLocalDateToMMDDYYYY(memberDob.toLocalDate());
		}
		if (item[7] != null && !StringUtils.isBlank((String) item[7])) {
			newValue = newValue != null ? newValue + ", phone number: " + item[7] : "phone number: " + item[7];
		}
		if (item[8] != null && !StringUtils.isBlank((String) item[8])) {
			newValue = newValue != null ? newValue + ", status: " + item[8] : "status: " + item[8];
		}
		if (item[16] != null) {
			newValue = newValue != null ? newValue + ", gender: " + item[16] : "gender: " + item[16];
		}
		if (item[17] != null) {
			newValue = newValue != null ? newValue + ", name prefix: " + item[17] : "name prefix: " + item[17];
		}
		if (item[18] != null) {
			newValue = newValue != null ? newValue + ", product: " + item[18] : "product: " + item[18];
		}
		if (item[20] != null) {
			newValue = newValue != null ? newValue + ", " + "sfdc id: " + item[20] : "sfdc id: " + item[20];
		}
		newValue = newValue != null ? newValue + ", locked: " + getValue(item[21]) : "locked: " + getValue(item[21]);
		newValue = newValue != null ? newValue + ", locked from web: " + getValue(item[22])
				: "locked from web: " + getValue(item[22]);

		ViewAuditData viewAuditData2 = getEmailInfo(((BigInteger) item[0]).longValue(), (String) item[19]);
		if (viewAuditData2 != null) {
			if (!StringUtils.isBlank(viewAuditData2.getNewValue())) {
				newValue = newValue != null ? newValue + ", " + viewAuditData2.getNewValue()
						: viewAuditData2.getNewValue();
			}
		}
		ViewAuditData addressAudit = getAddressInfo(((BigInteger) item[0]).longValue(), (String) item[19]);
		if (addressAudit != null) {
			if (!StringUtils.isBlank(addressAudit.getNewValue())) {
				newValue = newValue != null ? newValue + ", " + addressAudit.getNewValue()
						: addressAudit.getNewValue();
			}
		}

		auditResponse.setRecordId(((BigInteger) item[0]).longValue());
		auditResponse.setAction(getAction(item[1]));
		auditResponse.setUpdatedById(item[14] != null ? ((BigInteger) item[14]).longValue() : 0);
		auditResponse.setUpdatedAt(
				updatedAt != null
						? DateAndTimeUtil.convertLocalDateToMMDDYYYY(updatedAt.toLocalDateTime().toLocalDate()) + " "
								+ DateAndTimeUtil.getTime(updatedAt.toLocalDateTime().toLocalTime())
						: null);
		auditResponse.setNewValue(newValue);
		if (item[15] != null) {
			auditResponse.setModifiedBy(((String) item[15]));
			auditResponse.setMemberOrUser("User");
		} else {
			auditResponse.setModifiedBy(((String) item[5]) + " " + (String) item[4]);
			auditResponse
					.setModifiedBy(auditResponse.getModifiedBy().contains("null") ? "" : auditResponse.getModifiedBy());
			auditResponse.setMemberOrUser("Member");
		}
		return auditResponse;

	}

	private PageRequest getPageRequest(int pageNo, int pageSize) {
		return PageRequest.of(pageNo, pageSize);
	}

//	public ResponseEntity<ViewResponse> getMemberAuditInfoById(Long recordId, String moduleName) {
//
//		if (moduleName.equalsIgnoreCase(MemberAuditModules.Member_info.toString())) {
//			return getMemberAuditInfoById(recordId);
//		}
//
//		if (moduleName.equalsIgnoreCase(MemberAuditModules.Member_family.toString())) {
//			return getMemberFamilyAuditInfoById(recordId);
//		}
//
//		if (moduleName.equalsIgnoreCase(MemberAuditModules.Member_insurance.toString())) {
//			return getMemberInsuranceAuditInfoById(recordId);
//		}
//
//		ViewResponse response = new ViewResponse();
//		response.setStatusText(Constants.SUCCESS);
//		response.setMessage(Constants.NO_RESULTS_FOUND);
//		LOGGER.info("getMemberAudit method ended");
//		return ResponseEntity.status(HttpStatus.OK).body(response);
//	}

	public ResponseEntity<ViewResponse> getMemberAuditInfoById(Long id, Integer pageNumber, Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		Page<Object[]> memberObjects = memberRepository.getMemberAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));

		return ResponseEntity.status(HttpStatus.OK).body(getData(memberObjects.getContent()));
	}

	public ResponseEntity<ViewResponse> getMemberFamilyAuditInfoById(Long id, Integer pageNumber, Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		Page<Object[]> memberFamilyObj = memberFamilyRepository.getMemberFamilyAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));

		return ResponseEntity.status(HttpStatus.OK).body(getMemberFamilyData(memberFamilyObj.getContent()));
	}

	public ResponseEntity<ViewResponse> getMemberInsuranceAuditInfoById(Long id, Integer pageNumber,
			Integer pageLimit) {
		pageNumber = pageNumber != null ? pageNumber : 0;
		pageLimit = pageLimit != null ? pageLimit : 20;
		Page<Object[]> memberFamilyObj = memberInsuranceDetailRepository.getMemberInsuranceAuditInfoById(id,
				getPageRequest(pageNumber, pageLimit));
		return ResponseEntity.status(HttpStatus.OK).body(getMemberInsuranceData(memberFamilyObj.getContent()));
	}

}
