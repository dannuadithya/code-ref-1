package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.AuthTokens;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.SystemUsers;

@Repository
public interface AuthTokensRepository extends JpaRepository<AuthTokens, Long> {

	Optional<AuthTokens> findByTokenAndMemberId(String token, Member member);

	Optional<AuthTokens> findByMemberId(Member member);

	Optional<AuthTokens> findByTokenAndUserId(String token, SystemUsers systemUsers);

	Optional<AuthTokens> findByUserId(SystemUsers systemUser);

	List<AuthTokens> findAllByUserId(List<SystemUsers> usersList);

	Optional<AuthTokens> findByTokenAndMemberIdAndDeviceToken(String header, Member member, String deviceToken);

	List<AuthTokens> findAllByUserIdIn(List<SystemUsers> usersList);

	Optional<AuthTokens> findByMemberIdAndRefreshToken(Member member, String refreshToken);

}
