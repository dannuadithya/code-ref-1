package com.billdog.user.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.billdog.user.authentication.AesEncryption;
import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.common.UserType;
import com.billdog.user.entity.AuthTokens;
import com.billdog.user.entity.NavigationScreen;
import com.billdog.user.entity.RoleNavigationScreens;
import com.billdog.user.entity.Roles;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.entity.SystemUsersAccess;
import com.billdog.user.exception.InValidInputException;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.exception.RecordExistsException;
import com.billdog.user.repository.AuthTokensRepository;
import com.billdog.user.repository.NamePrefixMasterRepository;
import com.billdog.user.repository.NavigationScreenRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.RoleNavigationScreensRepository;
import com.billdog.user.repository.RolesRepository;
import com.billdog.user.repository.SystemUsersAccessRepository;
import com.billdog.user.repository.SystemUsersrepository;
import com.billdog.user.request.CreateRoleRequest;
import com.billdog.user.request.UpdateUserPasswordRequest;
import com.billdog.user.request.WelcomeEmailMemberRequest;
import com.billdog.user.view.MemberInfoResponse;
import com.billdog.user.view.UserPasswordResponse;
import com.billdog.user.view.ViewResponse;

@Service
public class CreateRoleService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(CreateRoleService.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	NamePrefixMasterRepository namePrefixMasterRepository;

	@Autowired
	SystemUsersrepository systemUsersrepository;

	@Autowired
	RoleNavigationScreensRepository roleNavigationScreensRepository;

	@Autowired
	RolesRepository rolesRepository;

	@Autowired
	NavigationScreenRepository navigationScreenRepository;

	@Autowired
	LoginService loginService;

	@Autowired
	SystemUsersAccessRepository systemUsersAccessRepository;

	@Autowired
	AesEncryption aesEncryption;

	@Autowired
	AuthTokensRepository authTokensRepository;

	@Autowired
	EmailService emailService;

	@Autowired
	AuditService auditService;

	/*
	 * create role method takes userid, role name and created a new record and
	 * provides response.
	 */
	public ViewResponse createRole(CreateRoleRequest createRoleRequest) {
		LOGGER.info("create role method started..!");
		SystemUsers appUser = loginService.getSystemUsers(createRoleRequest.getUserId());
		String roleName = appUser.getRoleId().getRole();
		if (roleName != null && !roleName.equalsIgnoreCase(StatusConstants.SYSTEM_ADMIN)
				&& !roleName.equalsIgnoreCase(StatusConstants.SUPER_ADMIN)) {
			throw new RecordExistsException(ExceptionalMessages.CREATE_ROLE_PERMISSIONS);
		}

		Optional<Roles> roleOpt = rolesRepository.findByRoleAndOrganizationIdAndUserType(createRoleRequest.getName(),
				appUser.getOrganizationId(), createRoleRequest.getRoleType());
		LOGGER.debug("Checking role is already present in system with name:: {}", createRoleRequest.getName());
		if (roleOpt.isPresent()) {
			throw new RecordExistsException(ExceptionalMessages.ROLE_ALREADY_EXISTS);
		}
		LOGGER.debug("Creating new role if role doesn't exists in the system already");
		String auditId = auditService.getAuditId();
		Roles role = new Roles();
		role.setCreatedAt(DateAndTimeUtil.now());
		role.setUpdatedAt(DateAndTimeUtil.now());
		role.setOrganizationId(appUser.getOrganizationId());
		role.setRole(createRoleRequest.getName());
		role.setUserType(createRoleRequest.getRoleType());
		role.setStatus(StatusConstants.ACTIVE);
		role.setUserId(createRoleRequest.getUserId());
		role.setAuditId(auditId);
		rolesRepository.save(role);
		LOGGER.debug("New role created with id:: {}  and name:: {}", role.getId(), role.getRole());
		mapScreenswithRole(role, role.getUserType(), createRoleRequest.getUserId(), auditId);
		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setRoleId(role.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		if (createRoleRequest.getRoleType().equalsIgnoreCase(UserType.External.toString())) {
			viewResponse.setMessage(Constants.EXTERNAL_ROLE_CREATED);
		} else {
			viewResponse.setMessage(Constants.INTERNAL_ROLE_CREATED);
		}
		LOGGER.info("create role method ended..!");
		return viewResponse;

	}

	private void mapScreenswithRole(Roles role, String type, long userId, String auditId) {
		LOGGER.info("Mapping role with navigation screens");
		List<NavigationScreen> screens = navigationScreenRepository
				.findByOrganizationIdAndType(role.getOrganizationId(), type);
		LOGGER.debug("Fetched all navigation screens to map with role:: {}", role.getRole());
		List<RoleNavigationScreens> roleNavigationScreens = new ArrayList<>();
		screens.forEach(screen -> {
			RoleNavigationScreens roleNavigationScreen = new RoleNavigationScreens();
			roleNavigationScreen.setCreatedAt(DateAndTimeUtil.now());
			roleNavigationScreen.setUpdatedAt(DateAndTimeUtil.now());
			roleNavigationScreen.setNavigationScreensId(screen);
			roleNavigationScreen.setRoleId(role);
			roleNavigationScreen.setReadAccess(false);
			if (screen.getName().equalsIgnoreCase(Constants.DASHBOARD) || (screen.getParentId() != null
					&& (screen.getParentId().getName()).equalsIgnoreCase(Constants.DASHBOARD))) {
				roleNavigationScreen.setReadAccess(true);
			}
			roleNavigationScreen.setWriteAccess(false);
			roleNavigationScreen.setOrganizationId(role.getOrganizationId());
			roleNavigationScreen.setUserId(userId);
			roleNavigationScreen.setAuditId(auditId);
			roleNavigationScreens.add(roleNavigationScreen);
		});
		roleNavigationScreensRepository.saveAll(roleNavigationScreens);
		LOGGER.debug("All navigation screens are mapped with role:: {}", role.getRole());
	}

	public UserPasswordResponse updatePassword(UpdateUserPasswordRequest updateUserPasswordRequest) {
		LOGGER.info("updatePassword strated..");
		if (!updateUserPasswordRequest.getNewPassword().equals(updateUserPasswordRequest.getConfirmNewPassword())) {
			throw new InValidInputException(ExceptionalMessages.USER_CONFIRM_PASSWORD);
		}
		loginService.checkPassword(updateUserPasswordRequest.getNewPassword());
		SystemUsers user = getUser(updateUserPasswordRequest.getUserId());
		SystemUsersAccess systemUser = checkOldPassword(updateUserPasswordRequest.getOldPassword(), user,
				updateUserPasswordRequest);
		String encryptedPassword = aesEncryption.passwordHashing(updateUserPasswordRequest.getNewPassword());
		systemUser.setUpdatedAt(DateAndTimeUtil.now());
		systemUser.setPassword(encryptedPassword);
		systemUsersAccessRepository.save(systemUser);

		expireToken(user);

		WelcomeEmailMemberRequest welcomeEmailMemberRequest = new WelcomeEmailMemberRequest();
		welcomeEmailMemberRequest.setEmail(user.getEmail());
		welcomeEmailMemberRequest.setFirstName(user.getFirstName());
		welcomeEmailMemberRequest.setEmailTitle(EmailTitles.PASSWORD_RESET);
		welcomeEmailMemberRequest.setOrgId(user.getOrganizationId().getId());
		emailService.sendEamilToMember(welcomeEmailMemberRequest);

		UserPasswordResponse viewResponse = new UserPasswordResponse();
		viewResponse.setUserId(user.getId());
		viewResponse.setMessage(Constants.USER_PASSWORD_UPDATED);
		LOGGER.debug("Generating jwttoken for member with id:: {}", user.getId());
		viewResponse.setStatusText(Constants.SUCCESS);
		LOGGER.info("updatePassword ended..");
		return viewResponse;
	}

	public SystemUsers getUser(Long userId) {

		Optional<SystemUsers> user = systemUsersrepository.findById(userId);
		if (!user.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.USER_NOT_FOUND);
		}
		LOGGER.info("user detils are fetched for id:: {}", userId);
		return user.get();
	}

	private SystemUsersAccess checkOldPassword(String oldPassword, SystemUsers user,
			UpdateUserPasswordRequest updateUserPasswordRequest) {
		Optional<SystemUsersAccess> systemUser = systemUsersAccessRepository.findByUserId(user);
		if (!systemUser.isPresent()) {
			throw new NoRecordFoundException(ExceptionalMessages.USER_NOT_FOUND_IN_ORGANISATION);
		}
		LOGGER.debug("encrypting requested password");
		String encryptedPassword = aesEncryption.passwordHashing(oldPassword);
		String encryptedNewPassword = aesEncryption.passwordHashing(updateUserPasswordRequest.getNewPassword());
		LOGGER.debug("checking pasword matches or not..!");
		if (systemUser.get().getPassword() == null || (systemUser.get().getPassword() != null
				&& !encryptedPassword.equals(systemUser.get().getPassword()))) {
			throw new NoRecordFoundException(ExceptionalMessages.INCORRECT_OLD_PASSWORD);
		}
		if (encryptedNewPassword.equals(systemUser.get().getPassword())) {
			throw new InValidInputException(ExceptionalMessages.SAME_OLD_NEW_PASSWORD);
		}
		return systemUser.get();

	}

	public void expireToken(SystemUsers user) {
		LOGGER.info("Save user token method started..!");
		LOGGER.info("Checking user is already exists in tokens table");
		Optional<AuthTokens> userTokenOptional = authTokensRepository.findByUserId(user);
		if (userTokenOptional.isPresent()) {
			LOGGER.info("Updating user token info for user id:: {}", user.getId());
			userTokenOptional.get().setExpiredAt(DateAndTimeUtil.now());
			userTokenOptional.get().setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(userTokenOptional.get());
		} else {
			LOGGER.info("Creating user token info for user id:: {}", user.getId());
			AuthTokens authTokens = new AuthTokens();
			authTokens.setCreatedAt(DateAndTimeUtil.now());
			authTokens.setExpiredAt(DateAndTimeUtil.now());
			authTokens.setUserId(user);
			authTokens.setOrganizationId(user.getOrganizationId());
			authTokens.setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(authTokens);
			LOGGER.info("Created user token info with id:: {}", authTokens.getId());
		}
		LOGGER.info("Save user token method started..!");
	}

	public MemberInfoResponse getLockStatus(String token, Long userId) {

		return null;

	}

	public ViewResponse userType(Long userId) {
		LOGGER.info("userType method started..!");
		List<UserType> userTypeList = Arrays.asList(UserType.values());

		ViewResponse viewResponse = new ViewResponse();
		viewResponse.setStatusText(Constants.SUCCESS);
		viewResponse.setMessage(Constants.USER_TYPE_FETCHED);
		viewResponse.setData(userTypeList);
		return viewResponse;
	}

}
