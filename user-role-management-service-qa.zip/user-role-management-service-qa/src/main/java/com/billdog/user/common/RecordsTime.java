package com.billdog.user.common;

public enum RecordsTime {

	All, Last_Week, Last_Month, Last_3_Months, Last_6_Months, Last_Year, Custom

}
