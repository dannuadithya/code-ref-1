package com.billdog.user.exception;

public class PasscodeExpiredException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PasscodeExpiredException(String exception) {
		super(exception);
	}
}