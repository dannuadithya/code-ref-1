package com.billdog.user.exception;

public class ServiceGatewayTimeoutException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ServiceGatewayTimeoutException(String message) {
		super(message);
	}
}
