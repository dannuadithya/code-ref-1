package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.user.entity.NavigationScreen;
import com.billdog.user.entity.Organization;

@Repository
public interface NavigationScreenRepository extends JpaRepository<NavigationScreen,Long> {

	List<NavigationScreen> findByOrganizationId(Organization organization);

	List<NavigationScreen> findByParentId(NavigationScreen navigationScreensId);

	Optional<NavigationScreen> findByIdAndType(long parentId, String string);

	List<NavigationScreen> findByOrganizationIdAndType(Organization organizationId, String type);

}
