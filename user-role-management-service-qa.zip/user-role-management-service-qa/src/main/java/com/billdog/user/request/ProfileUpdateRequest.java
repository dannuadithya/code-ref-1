package com.billdog.user.request;

import com.billdog.user.common.EmailTitles;

public class ProfileUpdateRequest {

	private String email;
	private EmailTitles emailTitle;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public EmailTitles getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(EmailTitles emailTitle) {
		this.emailTitle = emailTitle;
	}

}
