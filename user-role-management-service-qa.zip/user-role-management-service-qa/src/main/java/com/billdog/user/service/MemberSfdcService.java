package com.billdog.user.service;

import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.Marshaller;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.client.core.WebServiceMessageCallback;
import org.springframework.ws.client.core.WebServiceTemplate;
import org.springframework.ws.soap.SoapHeader;
import org.springframework.ws.soap.SoapMessage;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberAddress;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.MemberSfdcStatus;
import com.billdog.user.entity.SchedulerJob;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.repository.MemberAddressRepository;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberSfdcStatusRespository;
import com.billdog.user.repository.SchedulerJobRepository;
import com.billdog.user.sfdc.Account;
import com.billdog.user.sfdc.Contact;
import com.billdog.user.sfdc.Create;
import com.billdog.user.sfdc.CreateResponse;
import com.billdog.user.sfdc.Error;
import com.billdog.user.sfdc.GetUserInfo;
import com.billdog.user.sfdc.GetUserInfoResponse;
import com.billdog.user.sfdc.Login;
import com.billdog.user.sfdc.LoginResponse;
import com.billdog.user.sfdc.LoginResult;
import com.billdog.user.sfdc.Logout;
import com.billdog.user.sfdc.ObjectFactory;
import com.billdog.user.sfdc.Query;
import com.billdog.user.sfdc.QueryResponse;
import com.billdog.user.sfdc.RecordType;
import com.billdog.user.sfdc.SObject;
import com.billdog.user.sfdc.SaveResult;
import com.billdog.user.sfdc.SessionHeader;
import com.billdog.user.sfdc.Update;
import com.billdog.user.sfdc.UpdateResponse;
import com.billdog.user.view.ViewMemberSfdcFailed;
import com.billdog.user.view.ViewMemberSfdcQueue;
import com.billdog.user.view.ViewResponse;
import com.billdog.user.view.ViewSfdcResponse;

import net.javacrumbs.shedlock.core.SchedulerLock;

@Service
public class MemberSfdcService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(MemberSfdcService.class);

	@Autowired
	private Jaxb2Marshaller marshaller;

	@Autowired
	WebServiceTemplate webServiceTemplate;

	@Autowired
	MemberSfdcStatusRespository memberSfdcStatusRespository;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	MemberEmailRepository emailRepository;

	@Autowired
	MemberAddressRepository addressRepository;

	@Autowired
	LoginService loginService;

	@Autowired
	SchedulerJobRepository schedulerJobRepository;

	@Autowired
	AuditService auditService;

	@Value("${sfdc.username}")
	private String username;
	@Value("${sfdc.password}")
	private String password;
	@Value("${sfdc.authEndPoint}")
	private String authEndPoint;

	@Bean
	public Login countryClient() {

		Login login = new Login();
		login.setPassword(password);
		login.setUsername(username);
		return login;
	}

	public void marshallerTest() {

		try {
			webServiceTemplate = new WebServiceTemplate(marshaller);
			Login req = new ObjectFactory().createLogin();
			req.setPassword(password);
			req.setUsername(username);
			LOGGER.info("Request{}", req);
			LoginResult result = (LoginResult) webServiceTemplate.marshalSendAndReceive(authEndPoint, req);
			LOGGER.info("Response ");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public ViewResponse getSFConnection() {
		LoginResponse result = null;

		try {
			webServiceTemplate = new WebServiceTemplate(marshaller);
			Login req = new ObjectFactory().createLogin();
			req.setPassword(password);
			req.setUsername(username);
			LOGGER.info("Request{}", req);
			LOGGER.info("Template {}", webServiceTemplate);
			JAXBContext jaxbContext = JAXBContext.newInstance(Login.class);
			webServiceTemplate.setMarshaller(marshaller);
			webServiceTemplate.setUnmarshaller(marshaller);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
			jaxbMarshaller.marshal(req, System.out);
			result = (LoginResponse) webServiceTemplate.marshalSendAndReceive(authEndPoint, req);
			LOGGER.info("Response session id:: {}", result.getResult().getSessionId());
			LOGGER.info("Response user id:: {}", result.getResult().getUserId());
			LOGGER.info("Response service url:: {}", result.getResult().getServerUrl());

		} catch (Exception e) {
			e.printStackTrace();
		}

		ViewResponse response = new ViewResponse();
		response.setMessage("Connection created successfully");
		response.setStatusText(Constants.SUCCESS);
		response.setData(result);
		return response;
	}

	private GetUserInfoResponse getUserInfo(String serverUrl, String sessionId) {
		GetUserInfoResponse qResult = null;
		GetUserInfo info = new GetUserInfo();
		try {
			qResult = (GetUserInfoResponse) webServiceTemplate.marshalSendAndReceive(serverUrl, info,
					getCallBack(sessionId));
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (qResult != null) {

			LOGGER.info("User type id::{},  name::{}", qResult.getResult().getUserId(),
					qResult.getResult().getUserEmail());
			return qResult;
		}
		return null;
	}

	private Account getAccount(String serverUrl, String sessionId) {
		String sqlQuery = "SELECT Id, Name FROM Account WHERE Name='Wavelabs Technologies'";
		Query query = new Query();
		query.setQueryString(sqlQuery);
		QueryResponse qResult = null;

		try {
			qResult = (QueryResponse) webServiceTemplate.marshalSendAndReceive(serverUrl, query,
					getCallBack(sessionId));
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (qResult != null) {
			Account account = (Account) qResult.getResult().getRecords().get(0);

			LOGGER.info("Account type id::{},  name::{}", account.getId(), account.getName().getValue());
			return account;
		}

		return null;
	}

	private void createMember(String recordTypeId, String accountId, String serverUrl, String sessionId) {

		Contact contact = new ObjectFactory().createContact();
		JAXBElement<String> jaxbElement = new JAXBElement<>(new QName("accountId"), String.class, accountId);

		contact.setAccountId(jaxbElement);
		contact.setFirstName(new JAXBElement<>(new QName("FirstName"), String.class, "Nagaraju"));
		contact.setLastName(new JAXBElement<>(new QName("LastName"), String.class, "Kovi"));
		// contact.setRecordTypeId(value);

		SObject obj = contact;
		Create create = new Create();

		create.getSObjects().add(obj);

		Update update = new Update();
		Contact contact1 = new ObjectFactory().createContact();
		contact1.setId("0034C00000LRNPBQA5");
		contact.setFirstName(new JAXBElement<>(new QName("FirstName"), String.class, "Raju-updated"));
		SObject updateobj = contact;
		update.getSObjects().add(updateobj);

		try {
			/*
			 * JAXBContext jaxbContext = JAXBContext.newInstance(SObject.class);
			 * webServiceTemplate.setMarshaller(marshaller);
			 * webServiceTemplate.setUnmarshaller(marshaller); Marshaller jaxbMarshaller =
			 * jaxbContext.createMarshaller();
			 * 
			 * jaxbMarshaller.marshal(create, System.out);
			 */
			CreateResponse reponse = (CreateResponse) webServiceTemplate.marshalSendAndReceive(serverUrl, create,
					getCallBack(sessionId));

			LOGGER.info("Response id:: {}", reponse.getResult().get(0).getId());

			UpdateResponse updateRespo = (UpdateResponse) webServiceTemplate.marshalSendAndReceive(serverUrl, update,
					getCallBack(sessionId));

			LOGGER.info("Update Response id:: {}", updateRespo.getResult().get(0).getId());

			LOGGER.info("Session id:: {}", sessionId);
			LOGGER.info("Service url:: {}", serverUrl);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public JAXBElement<String> getElement(String value) {
		return new JAXBElement<>(new QName(String.class.getTypeName()), String.class, value);
	}

	private RecordType getRecordType(String serverUrl, String sessionId) {
		String sqlQuery = "SELECT Id, Name FROM RecordType WHERE Name='Employee' AND IsActive = true";
		Query query = new Query();
		query.setQueryString(sqlQuery);
		QueryResponse qResult = null;
		try {
			qResult = (QueryResponse) webServiceTemplate.marshalSendAndReceive(serverUrl, query,
					getCallBack(sessionId));
		} catch (Exception e) {
			e.printStackTrace();
		}
		if (qResult != null) {
			RecordType recordType = (RecordType) qResult.getResult().getRecords().get(0);

			return recordType;
		}

		return null;
	}

	private WebServiceMessageCallback getCallBack(String sessionId) {
		return new WebServiceMessageCallback() {
			@Override
			public void doWithMessage(WebServiceMessage message) {
				try {
					SoapHeader soapHeader = ((SoapMessage) message).getSoapHeader();
					ObjectFactory factory = new ObjectFactory();
					SessionHeader authSoapHeaders = factory.createSessionHeader();
					authSoapHeaders.setSessionId(sessionId);
					marshaller.marshal(authSoapHeaders, soapHeader.getResult());
				} catch (Exception e) {
					LOGGER.error("error during marshalling of the SOAP headers", e);
				}
			}
		};
	}

//	@Scheduled(cron = "0 0/5 * * * ?")
	// @SchedulerLock(name = "TaskScheduler_scheduledTask", lockAtLeastForString =
	// "PT2M", lockAtMostForString = "PT5M")
	public void multipleTimesScheduler() {
		LOGGER.info("multipleTimesScheduler job for multiple instances started at:: {}", DateAndTimeUtil.now());
		LOGGER.info("Testing multipleTimesScheduler job in multiple instances");
		LOGGER.info("multipleTimesScheduler job for multiple instances ended at:: {}", DateAndTimeUtil.now());
	}

//	@Scheduled(cron = "0 0/5 * * * ?")
//	@SchedulerLock(name = "TaskScheduler_scheduledTask", lockAtLeastForString = "PT2M", lockAtMostForString = "PT5M")
	public void singelTimeScheduler() {
		LOGGER.info("singelTimeScheduler job for multiple instances started at:: {}", DateAndTimeUtil.now());
		LOGGER.info("Testing singelTimeScheduler job in multiple instances");
		LOGGER.info("singelTimeScheduler job for multiple instances ended at:: {}", DateAndTimeUtil.now());
	}

	//@Scheduled(initialDelay =0,fixedDelayString = "${sfdc.job.cron}")
	public void onStartup() {
		LOGGER.info("onStartup started at:: {}", DateAndTimeUtil.now());	
	}
	
	
	//@Scheduled(cron = "0 0/5 * * * ?")
	@Scheduled(initialDelay =0,fixedDelayString = "${sfdc.job.cron}")
	@SchedulerLock(name = "MemberSfdcTask", lockAtLeastForString = "${sfdc.job.lock.min}", lockAtMostForString = "${sfdc.job.lock.max}")
	public void memberSfdcjob() {
		LOGGER.info("memberSfdcjob member method started at:: {}",DateAndTimeUtil.now());
		SchedulerJob schedulerJob = schedulerJobRepository.findByName(Constants.MEMBER_SFDC_JOB);
		if (schedulerJob != null && schedulerJob.getStatus().equalsIgnoreCase(Constants.ACTIVE)
				&& !schedulerJob.isRunning()) {
			long beginTs = System.currentTimeMillis();
			schedulerJob.setRunning(true);
			schedulerJob.setLastStartedAt(DateAndTimeUtil.now());
			schedulerJob.setUpdatedAt(DateAndTimeUtil.now());
			schedulerJobRepository.save(schedulerJob);
			try {
				LOGGER.info("memberSfdcjob member method started");
				LocalDateTime date = DateAndTimeUtil.now();
				LOGGER.info("Member Sfdc job started at :: {}", date);
				LOGGER.info("Fetching member data having sfdc null");
				List<Member> memberList = memberRepository.findAllBySfdcId(null);
				LOGGER.info("Fetched member data having sfdc null, total count:: {}", memberList.size());
				LOGGER.info("Fetching member sfdc status records to update members in sfdc");
				List<MemberSfdcStatus> memberSfdcList = new ArrayList<>();
				if (memberList.isEmpty()) {
					memberSfdcList = memberSfdcStatusRespository.findAllByProfileUpdated(true);
				} else {
					memberSfdcList = memberSfdcStatusRespository.findAllByProfileUpdatedAndMemberIdNotIn(true,
							memberList);
				}

				LOGGER.info("Fetched member sfdc status records to update members in sfdc, total count:: {}",
						memberSfdcList.size());
				List<Member> membersList = Stream
						.of(memberList,
								memberSfdcList.stream().map(memberSfdc -> memberSfdc.getMemberId())
										.collect(Collectors.toList()))
						.flatMap(Collection::stream).collect(Collectors.toList());

				membersList = membersList.stream().filter(distinctByKey(p -> p.getId())).collect(Collectors.toList());
				LOGGER.info("Total unique members:: {}", membersList.size());
				LOGGER.info("Fetching member email records");
				List<MemberEmail> emailsList = emailRepository.findAllByMemberIdInAndPrimary(membersList, true);
				LOGGER.info("Fetched member email records, total count:: {}", emailsList.size());
				LOGGER.info("Fetching member address records");
				List<MemberAddress> memberAddressList = addressRepository.findAllByMemberIdIn(membersList);
				LOGGER.info("Fetched member address records, total count:: {}", memberAddressList.size());
				List<MemberSfdcStatus> memberSfdcUpdateList = memberSfdcStatusRespository
						.findAllByMemberIdIn(membersList);
				if (!emailsList.isEmpty()) {
					LoginResponse sfdcLogin = sfdcLogin();
					if (sfdcLogin != null) {
						RecordType recordType = getRecordType(sfdcLogin.getResult().getServerUrl(),
								sfdcLogin.getResult().getSessionId());
						List<Member> updateMemberList = new ArrayList<>();
						List<MemberSfdcStatus> updateMemberSfdcStatusList = new ArrayList<>();

						emailsList.forEach(memberEmail -> {
							if (memberEmail.getMemberId() != null) {
								LOGGER.info("Fetching member address with member id:: {}",
										memberEmail.getMemberId().getId());
								MemberAddress address = getAddress(memberAddressList, memberEmail.getMemberId());
								LOGGER.info("Fetched member address with member id:: {}, address id:: {}",
										memberEmail.getMemberId().getId(), address != null ? address.getId() : 0);
								try {
									if (memberEmail.getMemberId().getSfdcId() == null) {
										LOGGER.info("Creating new member in sfdc system with member id:: {}",
												memberEmail.getMemberId().getId());
										Create create = new Create();
										create.getSObjects().add(getContact(address, memberEmail,
												recordType != null ? recordType.getId() : null));
										CreateResponse createResponse = (CreateResponse) webServiceTemplate
												.marshalSendAndReceive(sfdcLogin.getResult().getServerUrl(), create,
														getCallBack(sfdcLogin.getResult().getSessionId()));
										LOGGER.info("Created member info in sfdc system with member id:: {}",
												memberEmail.getMemberId().getId());
										LOGGER.info("Fetching member sfdc status record with member id:: {}",
												memberEmail.getMemberId().getId());
										MemberSfdcStatus memberSfdcStatus = getMemberSfdcStatus(memberSfdcUpdateList,
												memberEmail.getMemberId());
										LOGGER.info(
												"Fetched member sfdc status record with member id:: {}, status id:: {}",
												memberEmail.getMemberId().getId(),
												memberSfdcStatus != null ? memberSfdcStatus.getId() : 0);
										setSfdcResponse(createResponse.getResult(), updateMemberList,
												updateMemberSfdcStatusList, memberSfdcStatus, memberEmail.getMemberId(),
												date);
									} else {
										LOGGER.info("Updatig new member in sfdc system with member id:: {}",
												memberEmail.getMemberId().getId());
										Update update = new Update();
										update.getSObjects().add(getContact(address, memberEmail,
												recordType != null ? recordType.getId() : null));
										UpdateResponse updateResponse = (UpdateResponse) webServiceTemplate
												.marshalSendAndReceive(sfdcLogin.getResult().getServerUrl(), update,
														getCallBack(sfdcLogin.getResult().getSessionId()));
										LOGGER.info("Updated member info in sfdc system with member id:: {}",
												memberEmail.getMemberId().getId());
										LOGGER.info("Fetching member sfdc status record with member id:: {}",
												memberEmail.getMemberId().getId());
										MemberSfdcStatus memberSfdcStatus = getMemberSfdcStatus(memberSfdcUpdateList,
												memberEmail.getMemberId());
										LOGGER.info(
												"Fetched member sfdc status record with member id:: {}, status id:: {}",
												memberEmail.getMemberId().getId(),
												memberSfdcStatus != null ? memberSfdcStatus.getId() : 0);
										setSfdcResponse(updateResponse.getResult(), updateMemberList,
												updateMemberSfdcStatusList, memberSfdcStatus, memberEmail.getMemberId(),
												date);
									}
								} catch (Exception exception) {
									LOGGER.info("Exception occured when sending data to sfdc system, cause:: {}",
											exception.getMessage());
								}
							}
						});
						if (!updateMemberList.isEmpty()) {
							memberRepository.saveAll(updateMemberList);
						}
						if (!updateMemberSfdcStatusList.isEmpty()) {
							memberSfdcStatusRespository.saveAll(updateMemberSfdcStatusList);
						}
						LOGGER.info("Logout from sfdc system");
						Logout logout = new ObjectFactory().createLogout();
						webServiceTemplate.marshalSendAndReceive(sfdcLogin.getResult().getServerUrl(), logout,
								getCallBack(sfdcLogin.getResult().getSessionId()));
						LOGGER.info("Sfdc logout successfully");
					}
				}
				LOGGER.info("Member Sfdc job ended at :: {}", DateAndTimeUtil.now());
				LOGGER.info("memberSfdcjob method ended");
				long endTs = System.currentTimeMillis();
				schedulerJob.setTimeTaken("" + ((endTs - beginTs) / 1000));
				schedulerJob.setLastCompletedAt(DateAndTimeUtil.now());
			} catch (Exception exception) {
				LOGGER.info("Exception occured, cause:: {}", exception.getMessage());
			} finally {
				LOGGER.info("Updating scheduler job status in finally block");
				schedulerJob.setRunning(false);
				schedulerJobRepository.save(schedulerJob);
			}
		} else {
			LOGGER.info("Scheduler job not running");
		}
		LOGGER.info("memberSfdcjob member method ended at:: {}",DateAndTimeUtil.now());
	}

	private void setSfdcResponse(List<SaveResult> saveResultList, List<Member> updateMemberList,
			List<MemberSfdcStatus> updateMemberSfdcStatusList, MemberSfdcStatus sfdcStatus, Member member,
			LocalDateTime date) {
		LOGGER.info("setSfdcResponse method started");
		if (!saveResultList.isEmpty()) {
			SaveResult saveResult = saveResultList.get(0);
			if (sfdcStatus == null) {
				LOGGER.info("Creating new member sfdc status record for member id:: {}", member.getId());
				sfdcStatus = new MemberSfdcStatus();
				sfdcStatus.setCreatedAt(DateAndTimeUtil.now());
				sfdcStatus.setMemberId(member);
				sfdcStatus.setOrganizationId(member.getOrganizationId());
				sfdcStatus.setUpdatedAt(DateAndTimeUtil.now());
				sfdcStatus.setProfileUpdated(false);
			}
			if (saveResult.isSuccess()) {
				LOGGER.info("Updating member sfdc success status record for member id:: {}", member.getId());
				sfdcStatus.setIntegrationStatus(Constants.SUCCESS);
				sfdcStatus.setErrorMessage(null);
				if (member.getSfdcId() == null) {
					LOGGER.info("Updating member sfdc id for member id:: {}", member.getId());
					member.setSfdcId(saveResult.getId());
					String auditId = auditService.getAuditId();
					member.setAuditId(auditId);
					member.setSfdcUpdatedTime(DateAndTimeUtil.now());
					updateMemberList.add(member);
				}
			} else {
				LOGGER.info("Updating member sfdc failed status record for member id:: {}", member.getId());
				Error error = saveResult.getErrors().get(0);
				sfdcStatus.setIntegrationStatus(Constants.FAILED);
				sfdcStatus.setErrorMessage(error.getMessage());
			}
			if (sfdcStatus.isProfileUpdated() && sfdcStatus.getUpdatedAt().isBefore(date)) {
				sfdcStatus.setProfileUpdated(false);
			}

			sfdcStatus.setUpdatedAt(DateAndTimeUtil.now());
			updateMemberSfdcStatusList.add(sfdcStatus);
		}
		LOGGER.info("setSfdcResponse method ended");
	}

	public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
		Map<Object, Boolean> map = new ConcurrentHashMap<>();
		return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}

	private LoginResponse sfdcLogin() {
		LOGGER.info("sfdcLogin method started");
		LoginResponse loginResponse = null;
		try {
			webServiceTemplate = new WebServiceTemplate(marshaller);
			Login login = new ObjectFactory().createLogin();
			login.setUsername(username);
			login.setPassword(password);
			LOGGER.info("Login to sfdc system");
			loginResponse = (LoginResponse) webServiceTemplate.marshalSendAndReceive(authEndPoint, login);
			LOGGER.info("Sfdc login successfully");
			LOGGER.info("Login user id:: {}", loginResponse.getResult().getUserId());
		} catch (Exception exception) {
			LOGGER.info("Exception occured while login to sfdc system, cause:: {}", exception.getMessage());
		}
		LOGGER.info("sfdcLogin method ended");
		return loginResponse;
	}

	private MemberAddress getAddress(List<MemberAddress> memberAddressList, Member member) {

		return memberAddressList.stream().filter(address -> address.getMemberId().getId() == member.getId()).findFirst()
				.orElse(null);
	}

	private MemberSfdcStatus getMemberSfdcStatus(List<MemberSfdcStatus> memberSfdcList, Member member) {
		return memberSfdcList.stream().filter(status -> status.getMemberId().getId() == member.getId()).findFirst()
				.orElse(null);
	}

	private SObject getContact(MemberAddress memberAddress, MemberEmail memberEmail, String recordTypeId) {
		LOGGER.info("getContact method started");
		Contact contact = new ObjectFactory().createContact();
		if (memberEmail != null && memberEmail.getMemberId() != null) {
			Member member = memberEmail.getMemberId();
			LOGGER.info("Updating member info for member id:: {}", memberEmail.getMemberId().getId());
			if (member.getFirstName() != null) {
				contact.setFirstName(new JAXBElement<>(new QName("firstName"), String.class, member.getFirstName()));
			}
			if (member.getLastName() != null) {
				contact.setLastName(new JAXBElement<>(new QName("lastName"), String.class, member.getLastName()));
			}
			if (member.getMiddleName() != null) {
				contact.setMiddleName(new JAXBElement<>(new QName("middleName"), String.class, member.getMiddleName()));
			}
			if (member.getSfdcId() != null) {
				contact.setId(member.getSfdcId());
			}
			if (member.getPhoneNumber() != null) {
				contact.setPhone(new JAXBElement<>(new QName("phone"), String.class, member.getPhoneNumber()));
			}
			if (member.getNamePrefixMasterId() != null && member.getNamePrefixMasterId().getPrefix() != null) {
				contact.setSalutation(new JAXBElement<>(new QName("salutation"), String.class,
						member.getNamePrefixMasterId().getPrefix()));
			}
			if (member.getMemberId() != null) {
				contact.setBilldog_Member_ID__C(
						new JAXBElement<>(new QName("billdog_Member_ID__C"), String.class, member.getMemberId()));
			}

			if (member.getDateOfBirth() != null) {
				contact.setBirthdate(new JAXBElement<>(new QName("birthdate"), XMLGregorianCalendar.class,
						getDateTime(member.getDateOfBirth().atTime(LocalTime.parse("00:00:00")))));
			}
			if (member.getGenderId() != null && member.getGenderId().getGender() != null) {
				contact.setGender__C(
						new JAXBElement<>(new QName("gender__C"), String.class, member.getGenderId().getGender()));
			}
			if (member.getProductId() != null && member.getProductId().getProductName() != null) {
				contact.setMember_ProductType__C(new JAXBElement<>(new QName("member_ProductType__C"), String.class,
						member.getProductId().getProductName()));

			}
			if (member.getMemberTypeMasterId() != null && member.getMemberTypeMasterId().getTypeName() != null) {
				contact.setInitial_Opportunity_Type__C(new JAXBElement<>(new QName("initial_Opportunity_Type__C"),
						String.class, member.getMemberTypeMasterId().getTypeName()));
			}
			if (member.getStatus() != null) {
				contact.setMember_Status__C(
						new JAXBElement<>(new QName("member_Status__C"), String.class, member.getStatus()));

			}
			if (member.getOrganizationId().getName() != null) {
				contact.setOrganizationID__C(new JAXBElement<>(new QName("organizationID__C"), String.class,
						member.getOrganizationId().getName()));
			}
		}
		if (memberEmail.getEmail() != null) {
			contact.setEmail(new JAXBElement<>(new QName("email"), String.class, memberEmail.getEmail()));
		}
		if (memberEmail.getPassword() != null) {
			contact.setMember_PasswordCreatedDT__C(new JAXBElement<>(new QName("member_PasswordCreatedDT__C"),
					XMLGregorianCalendar.class, getDateTime(memberEmail.getCreatedAt())));
			contact.setMember_PasswordCreated__C(
					new JAXBElement<>(new QName("member_PasswordCreated__C"), Boolean.class, true));
		}
		if (memberEmail.isVerified()) {
			contact.setMember_EmailVerifiedDT__C(new JAXBElement<>(new QName("member_EmailVerifiedDT__C"),
					XMLGregorianCalendar.class, getDateTime(memberEmail.getCreatedAt())));
			contact.setMember_EmailVerified__C(
					new JAXBElement<>(new QName("member_EmailVerified__C"), Boolean.class, true));
		}
		if (recordTypeId != null) {
			contact.setRecordTypeId(new JAXBElement<>(new QName("recordTypeId"), String.class, recordTypeId));
		}

		if (memberAddress != null) {

			LOGGER.info("Updating address info to contact for member id:: {}", memberEmail.getMemberId().getId());
			if (memberAddress.getCityName() != null) {
				contact.setMailingCity(
						new JAXBElement<>(new QName("mailingCity"), String.class, memberAddress.getCityName()));
			}
			if (memberAddress.getCountryMasterId() != null
					&& memberAddress.getCountryMasterId().getCountryName() != null) {
				contact.setMailingCountry(new JAXBElement<>(new QName("mailingCountry"), String.class,
						memberAddress.getCountryMasterId().getCountryName()));
			}

			if (memberAddress.getStateMasterId() != null && memberAddress.getStateMasterId().getName() != null) {
				contact.setMailingState(new JAXBElement<>(new QName("mailingState"), String.class,
						memberAddress.getStateMasterId().getName()));
			}
			if (memberAddress.getZipCode() != null) {
				contact.setMailingPostalCode(
						new JAXBElement<>(new QName("mailingPostalCode"), String.class, memberAddress.getZipCode()));
			}
			if (memberAddress.getStreet() != null || memberAddress.getAddressLine1() != null
					|| memberAddress.getAddressLine2() != null) {

				String address = memberAddress.getStreet() != null ? memberAddress.getStreet() + " " : "";
				address += memberAddress.getAddressLine1() != null ? memberAddress.getAddressLine1() + " " : "";
				address += memberAddress.getAddressLine2() != null ? memberAddress.getAddressLine2() : "";
				contact.setMailingStreet(new JAXBElement<>(new QName("mailingStreet"), String.class, address));
			}

			if (memberAddress.getCreatedAt() != null) {
				contact.setMember_ProfileCreatedDT__C(new JAXBElement<>(new QName("member_ProfileCreatedDT__C"),
						XMLGregorianCalendar.class, getDateTime(memberAddress.getCreatedAt())));

			}

		}

		LOGGER.info("getContact method ended");
		return contact;
	}

	private XMLGregorianCalendar getDateTime(LocalDateTime dateTime) {
		Date date;
		try {
			date = Date.from(dateTime.atZone(ZoneId.systemDefault()).toInstant());
			GregorianCalendar cal = new GregorianCalendar();
			cal.setTime(date);
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(cal);
		} catch (Exception exception) {
			LOGGER.info("Exception occured while coverting created date, cause:: {}", exception.getMessage());
		}
		return null;
	}

	public ViewResponse getSfdcQueueResponse(Long userId) {
		LOGGER.info("getSfdcQueueResponse method started");
		SystemUsers systemUsers = loginService.getSystemUsers(userId);
		LOGGER.info("Fetching sfdc success count with organization id:: {}", systemUsers.getOrganizationId().getId());
		List<Member> membersList = memberRepository.findAllByOrganizationId(systemUsers.getOrganizationId());
		LOGGER.info("Fetched sfdc success count with organization id:: {}", systemUsers.getOrganizationId().getId());
		LOGGER.info("Fetching members count with organization id:: {}", systemUsers.getOrganizationId().getId());
		long totalMembersCount = memberRepository.countByOrganizationId(systemUsers.getOrganizationId());
		LOGGER.info("Fetched members count with organization id:: {}", systemUsers.getOrganizationId().getId());
		long failedCount = memberSfdcStatusRespository.countByIntegrationStatusAndOrganizationId(Constants.FAILED,
				systemUsers.getOrganizationId());

		ViewSfdcResponse viewSfdcResponse = new ViewSfdcResponse();
		viewSfdcResponse.setIntegrationFailedCount(failedCount);
		viewSfdcResponse
				.setIntegrationSuccessCount(membersList.stream().filter(member -> member.getSfdcId() != null).count());
		viewSfdcResponse.setTotalInQueue(membersList.stream().filter(member -> member.getSfdcId() == null).count());
		viewSfdcResponse.setTotalMembers(totalMembersCount);

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setData(viewSfdcResponse);
		response.setMessage(Constants.SFDC_QUEUE_FETCHED);
		LOGGER.info("getSfdcQueueResponse method ended");
		return response;
	}

	private ViewMemberSfdcFailed getMemberSfdcFailed(MemberSfdcStatus memberSfdc) {
		ViewMemberSfdcFailed viewMemberSfdc = new ViewMemberSfdcFailed();
		viewMemberSfdc.setId(memberSfdc.getMemberId().getId());
		viewMemberSfdc.setMemberId(memberSfdc.getMemberId().getMemberId());
		viewMemberSfdc.setMemberType(memberSfdc.getMemberId().getSfdcId() != null ? "UPDATED" : "NEW");
		viewMemberSfdc.setMessage(memberSfdc.getErrorMessage());
		viewMemberSfdc
				.setCreatedDate(DateAndTimeUtil.convertLocalDateToDDMMMYYYY(memberSfdc.getCreatedAt().toLocalDate()));
		return viewMemberSfdc;

	}

	public ViewResponse getSfdcFailedQueueInfo(Long userId) {
		LOGGER.info("getSfdcFailedQueueInfo method started");
		LOGGER.info("Fetching user info for user id:: {}", userId);
		SystemUsers systemUsers = loginService.getSystemUsers(userId);
		LOGGER.info("Fetched User info with id:: {} in Organization id:: {}", userId,
				systemUsers.getOrganizationId().getId());

		LOGGER.info("Fetching sfdc failed records with organization id:: {}", systemUsers.getOrganizationId().getId());
		List<MemberSfdcStatus> memberSfdcList = memberSfdcStatusRespository
				.findAllByIntegrationStatusAndOrganizationIdOrderByCreatedAtDesc(Constants.FAILED,
						systemUsers.getOrganizationId());
		LOGGER.info("Fetched sfdc failed records with organization id:: {}", systemUsers.getOrganizationId().getId());
		List<ViewMemberSfdcFailed> memberSfdcs = memberSfdcList.stream()
				.map(memberSfdc -> getMemberSfdcFailed(memberSfdc)).collect(Collectors.toList());
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.SFDC_FAILED_QUEUE_FETCHED);
		response.setData(memberSfdcs);
		if (memberSfdcs.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getSfdcFailedQueueInfo method ended");
		return response;
	}

	public ViewResponse getSfdcQueueInfo(Long userId) {
		LOGGER.info("getSfdcQueueInfo method started");
		LOGGER.info("Fetching user info for user id:: {}", userId);
		SystemUsers systemUsers = loginService.getSystemUsers(userId);
		LOGGER.info("Fetched User info with id:: {} in Organization id:: {}", userId,
				systemUsers.getOrganizationId().getId());

		LOGGER.info("Fetching new members with organization id:: {}", systemUsers.getOrganizationId().getId());
		List<Member> membersList = memberRepository
				.findAllBySfdcIdNullAndOrganizationIdOrderByCreatedAtDesc(systemUsers.getOrganizationId());
		LOGGER.info("Fetched new members records with organization id:: {}", systemUsers.getOrganizationId().getId());
		List<ViewMemberSfdcQueue> memberSfdcs = membersList.stream().map(member -> getMemberSfdcQueue(member))
				.collect(Collectors.toList());

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.SFDC_QUEUE_LIST_FETCHED);
		response.setData(memberSfdcs);
		if (memberSfdcs.isEmpty()) {
			response.setMessage(Constants.NO_RESULTS_FOUND);
		}
		LOGGER.info("getSfdcQueueInfo method ended");
		return response;
	}

	private ViewMemberSfdcQueue getMemberSfdcQueue(Member member) {
		ViewMemberSfdcQueue queue = new ViewMemberSfdcQueue();
		queue.setId(member.getId());
		queue.setMemberId(member.getMemberId());
		queue.setCreatedDate(DateAndTimeUtil.convertLocalDateToDDMMMYYYY(member.getCreatedAt().toLocalDate()));
		return queue;
	}

	private ViewResponse getContact(long memberId) {
		LoginResponse sfdcLogin = sfdcLogin();

		try {

		} catch (Exception exception) {
			LOGGER.info("exception occured", exception.getMessage());
		}

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.SFDC_QUEUE_LIST_FETCHED);

		LOGGER.info("getSfdcQueueInfo method ended");
		return response;
	}

}
