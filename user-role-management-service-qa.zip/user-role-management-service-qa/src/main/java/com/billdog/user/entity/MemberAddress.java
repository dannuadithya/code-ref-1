package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.envers.Audited;
import org.hibernate.envers.RelationTargetAuditMode;

@Entity(name = "MEMBER_ADDRESS")
@Table(name = "member_address", indexes = { @Index(name = "id_index", columnList = "ID", unique = true),
		@Index(name = "org_member_index", columnList = "MEMBER_ID,ORGANIZATION_ID", unique = false) })
public class MemberAddress extends BaseEntity {

	@Audited
	@Column(name = "STREET")
	private String street;

	@Audited
	@Column(name = "CITY_NAME")
	private String cityName;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "STATE_MASTER_ID")
	private StateMaster stateMasterId;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "COUNTRY_MASTER_ID")
	private CountryMaster countryMasterId;
	
	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "MEMBER_ID")
	private Member memberId;

	@Audited
	@Column(name = "ZIP_CODE")
	private String zipCode;

	@Audited
	@Column(name = "ADDRESS_LINE1")
	private String addressLine1;

	@Audited
	@Column(name = "ADDRESS_LINE2")
	private String addressLine2;

	@Audited(targetAuditMode = RelationTargetAuditMode.NOT_AUDITED)
	@ManyToOne
	@JoinColumn(name = "user_id")
	private SystemUsers userId;

	@Audited
	@Column(name = "audit_id")
	private String auditId;

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public Member getMemberId() {
		return memberId;
	}

	public void setMemberId(Member memberId) {
		this.memberId = memberId;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

	public StateMaster getStateMasterId() {
		return stateMasterId;
	}

	public void setStateMasterId(StateMaster stateMasterId) {
		this.stateMasterId = stateMasterId;
	}

	public CountryMaster getCountryMasterId() {
		return countryMasterId;
	}

	public void setCountryMasterId(CountryMaster countryMasterId) {
		this.countryMasterId = countryMasterId;
	}

	public SystemUsers getUserId() {
		return userId;
	}

	public void setUserId(SystemUsers userId) {
		this.userId = userId;
	}

	public String getAuditId() {
		return auditId;
	}

	public void setAuditId(String auditId) {
		this.auditId = auditId;
	}

}
