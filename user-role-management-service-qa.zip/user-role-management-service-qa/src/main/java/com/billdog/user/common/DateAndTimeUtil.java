package com.billdog.user.common;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.billdog.user.exception.InValidInputException;

//TODO time zone correction to (UTC)
@Component
public class DateAndTimeUtil {


	public static String TIMEZONE;

	@Value("${timezone}")
	public void setTimezone(String timezone) {
		TIMEZONE = timezone;
	}

	public static LocalDateTime now() {
		return LocalDateTime.now(ZoneId.of(DateAndTimeUtil.TIMEZONE));
	}

	// converts date dd-mm-yyyy to dd month yyyy
	public static String convertLocalDateToString(LocalDate localDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMMM yyyy");
		return formatter.format(localDate);
	}

	// converts date dd-mm-yyyy to dd mon yyyy
	public static String convertLocalDate(LocalDate localDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMM yyyy");
		return formatter.format(localDate);
	}

	public static String convertLocalDateToMMDDYYYY(LocalDate localDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
		return formatter.format(localDate);
	}

	public static LocalDate stringDateToLocalDate(String date) {
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM-dd-yyyy");
			return LocalDate.parse(date, formatter);
		} catch (Exception e) {
			throw new InValidInputException(ExceptionalMessages.DATE_FORMAT);
		}
	}

	// converts date dd-mm-yyyy to dd mon yyyy
	public static String convertLocalDateToDDMMMYYYY(LocalDate localDate) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MMM-yyyy");
		return formatter.format(localDate);
	}

	public static String getTime(LocalTime time) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm a");
		return formatter.format(time);
	}


}
