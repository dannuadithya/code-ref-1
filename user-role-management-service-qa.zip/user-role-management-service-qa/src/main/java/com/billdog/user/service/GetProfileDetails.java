package com.billdog.user.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.common.Constants;
import com.billdog.user.common.DateAndTimeUtil;
import com.billdog.user.common.EmailTitles;
import com.billdog.user.common.ExceptionalMessages;
import com.billdog.user.common.StatusConstants;
import com.billdog.user.entity.AuthTokens;
import com.billdog.user.entity.CountryMaster;
import com.billdog.user.entity.CountryPhoneCodeMaster;
import com.billdog.user.entity.GenderMaster;
import com.billdog.user.entity.Member;
import com.billdog.user.entity.MemberAddress;
import com.billdog.user.entity.MemberEmail;
import com.billdog.user.entity.MemberFamily;
import com.billdog.user.entity.MemberProduct;
import com.billdog.user.entity.MemberSfdcStatus;
import com.billdog.user.entity.MemberTypeMaster;
import com.billdog.user.entity.NamePrefixMaster;
import com.billdog.user.entity.StateMaster;
import com.billdog.user.entity.SystemUsers;
import com.billdog.user.exception.MemberNotFoundException;
import com.billdog.user.exception.NoRecordFoundException;
import com.billdog.user.repository.AuthTokensRepository;
import com.billdog.user.repository.CountryMasterRepository;
import com.billdog.user.repository.CountryPhoneCodeMasterRepository;
import com.billdog.user.repository.GenderMasterRepository;
import com.billdog.user.repository.InsuranceDetailsRepository;
import com.billdog.user.repository.InsuranceSubTypeRepository;
import com.billdog.user.repository.InsuranceTypeRepository;
import com.billdog.user.repository.MemberAddressRepository;
import com.billdog.user.repository.MemberEmailRepository;
import com.billdog.user.repository.MemberFamilyRepository;
import com.billdog.user.repository.MemberInsuranceDetailRepository;
import com.billdog.user.repository.MemberProductRepository;
import com.billdog.user.repository.MemberRepository;
import com.billdog.user.repository.MemberSfdcStatusRespository;
import com.billdog.user.repository.MemberTypeMasterRepository;
import com.billdog.user.repository.NamePrefixMasterRepository;
import com.billdog.user.repository.OrganizationRepository;
import com.billdog.user.repository.StateMasterRepository;
import com.billdog.user.request.CheckProductTypeRequest;
import com.billdog.user.request.UpdateEmailRequest;
import com.billdog.user.request.UpdatePersonalDetailsRequest;
import com.billdog.user.view.ViewMemberResponse;
import com.billdog.user.view.ViewPersonalInfoDetails;
import com.billdog.user.view.ViewProfileDetails;
import com.billdog.user.view.ViewResponse;

@Service
public class GetProfileDetails {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GetProfileDetails.class);

	@Autowired
	OrganizationRepository organizationRepository;

	@Autowired
	InsuranceTypeRepository insuranceTypeRepository;

	@Autowired
	InsuranceSubTypeRepository insuranceSubTypeRepository;

	@Autowired
	MemberRepository memberRepository;

	@Autowired
	InsuranceDetailsRepository insuranceDetailsRepository;

	@Autowired
	MemberInsuranceDetailRepository memberInsuranceDetailRepository;

	@Autowired
	MemberEmailRepository memberEmailRepository;

	@Autowired
	MemberProductRepository memberProductRepository;

	@Autowired
	NamePrefixMasterRepository namePrefixMasterRepository;

	@Autowired
	GenderMasterRepository genderMasterRepository;

	@Autowired
	MemberAddressRepository addressRepository;

	@Autowired
	CountryMasterRepository countryMasterRepository;

	@Autowired
	CountryPhoneCodeMasterRepository countryPhoneCodeMasterRepository;

	@Autowired
	MemberTypeMasterRepository memberTypeMasterRepository;

	@Autowired
	MemberAddressRepository memberAddressRepository;

	@Autowired
	StateMasterRepository stateMasterRepository;

	@Autowired
	EmailService emailService;

	@Autowired
	MemberService memberService;

	@Autowired
	MemberLoginService memberLoginService;

	@Autowired
	AuthTokensRepository authTokensRepository;

	@Autowired
	MemberFamilyRepository memberFamilyRepository;

	@Autowired
	MemberSfdcStatusRespository memberSfdcStatusRespository;

	@Autowired
	LoginService loginService;

	@Autowired
	LogoutService logoutService;

	@Autowired
	AuditService auditService;

	public ResponseEntity<ViewProfileDetails> getMemberProfileInfo(Long memberId) {
		LOGGER.info("getMemberProfileInfo strated..");

		Optional<Member> memberentity = memberRepository.findById(memberId);
		if (!memberentity.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		Member member = memberentity.get();
		ViewProfileDetails viewProfileDetails = new ViewProfileDetails();
		LOGGER.debug("Setting member details for new member object");
		viewProfileDetails.setFirstName(member.getFirstName());
		viewProfileDetails.setLastName(member.getLastName());
		viewProfileDetails.setMiddleName(member.getMiddleName());
		viewProfileDetails.setMemberId(member.getId());
		viewProfileDetails.setStatus(member.getStatus());
		viewProfileDetails.setSfdcId(member.getSfdcId());
		Optional<MemberEmail> memberEmail = memberEmailRepository.findByMemberIdAndDeletedAndPrimary(memberentity.get(),
				false, true);
		if (memberEmail.isPresent()) {
			viewProfileDetails.setEmailId(memberEmail.get().getEmail());
		}
		if (memberentity.get().getProductId() != null) {
			Optional<MemberProduct> memberProduct = memberProductRepository
					.findById(memberentity.get().getProductId().getId());
			if (memberProduct.isPresent()) {
				viewProfileDetails.setProductName(memberProduct.get().getProductName());
			}
		}
		viewProfileDetails.setMobileNumber(member.getPhoneNumber());
		if (memberentity.get().getCountryPhoneCodeMasterId() != null) {
			Optional<CountryPhoneCodeMaster> countryPhoneCode = countryPhoneCodeMasterRepository
					.findById(memberentity.get().getCountryPhoneCodeMasterId().getId());
			if (countryPhoneCode.isPresent()) {
				viewProfileDetails
						.setCountryPhoneCode(memberentity.get().getCountryPhoneCodeMasterId().getPhoneNumberCode());
			}
		}
		viewProfileDetails.setLockStatus(member.isLocked());
		Optional<MemberTypeMaster> memberTypeMaster = memberTypeMasterRepository.findByTypeNameAndOrganizationId(
				member.getMemberTypeMasterId().getTypeName(), member.getOrganizationId());
		if (memberTypeMaster.isPresent()) {
			viewProfileDetails.setOpportunityType(memberTypeMaster.get().getTypeName());
		}
		// Giving successful response
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.MEMBER_PROFILE);
		viewResponse.setStatusText(Constants.SUCCESS);
		LOGGER.info("getMemberProfileInfo ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewProfileDetails);
	}

	public ResponseEntity<ViewPersonalInfoDetails> getMemberPersonalInfo(Long memberId) {
		LOGGER.info("getMemberPersonalInfo strated..");
		LOGGER.info("Get member info from database started at: {}", DateAndTimeUtil.now());
		Optional<Member> memberentity = memberRepository.findById(memberId);
		LOGGER.info("Get member info from database ended at: {}", DateAndTimeUtil.now());
		if (!memberentity.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		Member member = memberentity.get();
		LOGGER.info("getting member details for new member object");
		ViewPersonalInfoDetails viewPersonalInfoDetails = new ViewPersonalInfoDetails();
		viewPersonalInfoDetails.setFirstName(member.getFirstName());
		viewPersonalInfoDetails.setLastName(member.getLastName());
		viewPersonalInfoDetails.setMiddleName(member.getMiddleName());
		viewPersonalInfoDetails.setMemberId(member.getId());
		viewPersonalInfoDetails.setStatus(member.getStatus());
		viewPersonalInfoDetails.setSfdcId(member.getSfdcId());
		if (member.getEmployerId() != null) {
			viewPersonalInfoDetails.setEmployerId(member.getEmployerId());
		}
		viewPersonalInfoDetails.setOpportunityId(member.getMemberTypeMasterId().getId());
		viewPersonalInfoDetails.setOpportunityName(member.getMemberTypeMasterId().getTypeName());
		LOGGER.info("Get member primary email from database started at: {}", DateAndTimeUtil.now());
		Optional<MemberEmail> memberEmail = memberEmailRepository.findByMemberIdAndDeletedAndPrimary(memberentity.get(),
				false, true);
		LOGGER.info("Get member primary email from database ended at: {}", DateAndTimeUtil.now());
		if (memberEmail.isPresent()) {
			viewPersonalInfoDetails.setPrimaryEmailId(memberEmail.get().getEmail());
		}
		LOGGER.info("Get member secondary email from database started at: {}", DateAndTimeUtil.now());
		Optional<MemberEmail> memberEmailOptional = memberEmailRepository
				.findByMemberIdAndDeletedAndSecondary(memberentity.get(), false, true);
		LOGGER.info("Get member secondary email from database ended at: {}", DateAndTimeUtil.now());
		if (memberEmailOptional.isPresent()) {
			viewPersonalInfoDetails.setSecoundaryEmailId(memberEmailOptional.get().getEmail());
		}
		if (memberentity.get().getProductId() != null) {
				viewPersonalInfoDetails.setProductName(memberentity.get().getProductId().getProductName());
				viewPersonalInfoDetails.setProductId(memberentity.get().getProductId().getId());
		}
		if (member.getCountryPhoneCodeMasterId() != null) {
				viewPersonalInfoDetails.setCountryPhoneCodeId(member.getCountryPhoneCodeMasterId().getId());
		}
		viewPersonalInfoDetails.setMobileNumber(member.getPhoneNumber());
		if (memberentity.get().getNamePrefixMasterId() != null) {
				viewPersonalInfoDetails.setNamePrefixMaster(memberentity.get().getNamePrefixMasterId().getPrefix());
				viewPersonalInfoDetails.setPrefixId(memberentity.get().getNamePrefixMasterId().getId());
		}
		if (memberentity.get().getGenderId() != null) {
				viewPersonalInfoDetails.setGenderName(memberentity.get().getGenderId().getGender());
				viewPersonalInfoDetails.setGenderId(memberentity.get().getGenderId().getId());
		}
		if (member.getDateOfBirth() != null) {
			viewPersonalInfoDetails.setDateOfBirth(DateAndTimeUtil.convertLocalDateToMMDDYYYY(member.getDateOfBirth()));
		}
		viewPersonalInfoDetails.setStatus(member.getStatus());
		LOGGER.info("Get member family count from database started at: {}", DateAndTimeUtil.now());
		List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndStatusAndIsDeleted(member,StatusConstants.ACTIVE,false);
		LOGGER.info("Get member  family count from database ended at: {}", DateAndTimeUtil.now());
		if (!memberFamily.isEmpty()) {
			viewPersonalInfoDetails.setFamilyMemberCount(memberFamily.size());
		} else {
			viewPersonalInfoDetails.setFamilyMemberCount(0);
		}
		viewPersonalInfoDetails.setMessageForMobile(Constants.PRODUCT_MESSAGE_MOBILE);
		viewPersonalInfoDetails.setMessageForWeb(Constants.PRODUCT_MESSAGE_WEB);
		LOGGER.info("Get member address info from database started at: {}", DateAndTimeUtil.now());
		Optional<MemberAddress> memberAddress = addressRepository.findByMemberId(memberentity.get());
		LOGGER.info("Get member address info from database ended at: {}", DateAndTimeUtil.now());
		if (memberAddress.isPresent()) {
			viewPersonalInfoDetails.setAddressLine1(memberAddress.get().getAddressLine1());
			viewPersonalInfoDetails.setAddressLine2(memberAddress.get().getAddressLine2());
			viewPersonalInfoDetails.setStreet(memberAddress.get().getStreet());
			viewPersonalInfoDetails.setCityName(memberAddress.get().getCityName());
			viewPersonalInfoDetails.setZipcode(memberAddress.get().getZipCode());
			if (memberAddress.get().getCountryMasterId() != null) {
				viewPersonalInfoDetails.setCountryName(memberAddress.get().getCountryMasterId().getCountryName());
				viewPersonalInfoDetails.setCountryId(memberAddress.get().getCountryMasterId().getId());
			}
			if (memberAddress.get().getStateMasterId() != null) {
				viewPersonalInfoDetails.setStateName(memberAddress.get().getStateMasterId().getName());
				viewPersonalInfoDetails.setStateId(memberAddress.get().getStateMasterId().getId());
			}
		}
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.MEMBER_PERSONAL);
		viewResponse.setStatusText(Constants.SUCCESS);
		LOGGER.info("getMemberProfileInfo ended..");
		return ResponseEntity.status(HttpStatus.OK).body(viewPersonalInfoDetails);
	}

	public ViewMemberResponse updatePersonalDetails(UpdatePersonalDetailsRequest updatePersonalDetailsRequest) {
		LOGGER.info("updatePersonalDetails strated..");

		SystemUsers user = loginService.getSystemUsers(updatePersonalDetailsRequest.getUserId());
		Optional<Member> memberentity = memberRepository.findById(updatePersonalDetailsRequest.getMemberId());
		if (!memberentity.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FOUND);
		}

//		Optional<MemberEmail> memberEmailentity = memberEmailRepository.findByEmailAndOrganizationIdAndDeleted(
//				updatePersonalDetailsRequest.getPrimaryEmailId(), memberentity.get().getOrganizationId(), false);
//		if (memberEmailentity.isPresent()) {
//			throw new MemberNotFoundException(
//					ExceptionalMessages.PRMARY_EMAIL_ALREADY_EXITS + updatePersonalDetailsRequest.getPrimaryEmailId());
//		}

//		Optional<MemberEmail> memberSecoundaryEmail = memberEmailRepository.findByEmailAndOrganizationIdAndDeleted(
//				updatePersonalDetailsRequest.getSecoundaryEmailId(), memberentity.get().getOrganizationId(), false);
//		if (memberSecoundaryEmail.isPresent()) {
//			throw new MemberNotFoundException(ExceptionalMessages.SECOUNDARY_EMAIL_ALREADY_EXITS
//					+ updatePersonalDetailsRequest.getSecoundaryEmailId());
//		}
		Optional<MemberEmail> memberEmailentity = memberEmailRepository
				.findByEmailAndPrimaryAndDeleted(updatePersonalDetailsRequest.getPrimaryEmailId(), true, false);
		if (memberEmailentity.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.EMAIL_ALREADY_EXITS_IN_ORGANIZATION);
		}

		Optional<MemberEmail> memberEmailentityOptional = memberEmailRepository
				.findByMemberIdAndDeletedAndPrimary(memberentity.get(), false, true);
		if (!memberEmailentityOptional.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		boolean isDisabled = false;
		boolean isActivated = false;
		if ((!memberentity.get().getStatus().equalsIgnoreCase(StatusConstants.TERMINATED)
				&& !memberentity.get().getStatus().equalsIgnoreCase(StatusConstants.DISABLED))
				&& (updatePersonalDetailsRequest.getStatus().equalsIgnoreCase(StatusConstants.TERMINATED)
						|| updatePersonalDetailsRequest.getStatus().equalsIgnoreCase(StatusConstants.DISABLED))) {
			isDisabled = true;
		}
		if ((memberentity.get().getStatus().equalsIgnoreCase(StatusConstants.TERMINATED)
				|| memberentity.get().getStatus().equalsIgnoreCase(StatusConstants.DISABLED))
				&& (!updatePersonalDetailsRequest.getStatus().equalsIgnoreCase(StatusConstants.TERMINATED)
						&& !updatePersonalDetailsRequest.getStatus().equalsIgnoreCase(StatusConstants.DISABLED))) {
			isActivated = true;
		}
		String auditId = auditService.getAuditId();
		saveMember(updatePersonalDetailsRequest, memberentity.get(), user, auditId);

//		if (updatePersonalDetailsRequest.getPrimaryEmailId() != null
//				&& !updatePersonalDetailsRequest.getPrimaryEmailId().isEmpty()) {
//			LOGGER.debug("email sending when primary email is not empty");
//			sendUpdatedEmail(updatePersonalDetailsRequest, EmailTitles.EMAIL_UPDATED, memberEmailentityOptional.get());
//
//		}

		if (updatePersonalDetailsRequest.getPrimaryEmailId() != null
				&& !updatePersonalDetailsRequest.getPrimaryEmailId().isEmpty()) {
			if (!memberEmailentityOptional.get().getEmail()
					.equalsIgnoreCase(updatePersonalDetailsRequest.getPrimaryEmailId())) {
				updateMemberToken(memberentity.get());
			}
			saveMemberEmail(memberentity.get(), memberEmailentityOptional, user,
					updatePersonalDetailsRequest.getPrimaryEmailId(), auditId);
		}

		if (updatePersonalDetailsRequest.getAddressLine1() != null
				|| updatePersonalDetailsRequest.getAddressLine2() != null
				|| updatePersonalDetailsRequest.getStreet() != null
				|| updatePersonalDetailsRequest.getCityName() != null || updatePersonalDetailsRequest.getCountryId() > 0
				|| updatePersonalDetailsRequest.getStateId() > 0 || updatePersonalDetailsRequest.getZipcode() != null) {
			saveMemberAddress(updatePersonalDetailsRequest, memberentity.get(), user, auditId);
		}

		if (updatePersonalDetailsRequest.getPrimaryEmailId() != null
				&& !updatePersonalDetailsRequest.getPrimaryEmailId().isEmpty()) {
			memberLoginService.sendUpdatedEmail(EmailTitles.OLD_EMAIL, memberentity.get(),
					memberEmailentityOptional.get(), updatePersonalDetailsRequest.getPrimaryEmailId());
		}
		if (updatePersonalDetailsRequest.getPrimaryEmailId() != null
				&& !updatePersonalDetailsRequest.getPrimaryEmailId().isEmpty()) {
			sendUpdatedEmailToMember(updatePersonalDetailsRequest, EmailTitles.NEW_EMAIL, memberentity.get());
		}

		memberService.sendEmailProfileUpdated(memberEmailentityOptional.get(), EmailTitles.PROFILE_UPDATED_WEB,
				memberentity.get());
		if (isDisabled) {
			logoutService.logoutMemberByReason(memberentity.get(), StatusConstants.TERMINATED);
		}
		if (isActivated) {
			logoutService.updateMemberToken(memberentity.get());
		}
		// Giving successful response
		updateMemberSfdcstatus(memberentity.get());
		ViewMemberResponse viewResponse = new ViewMemberResponse();
		viewResponse.setMessage(Constants.MEMBER_PROFILE_UPDATED);
		viewResponse.setStatusText(Constants.SUCCESS);
		LOGGER.info("updatePersonalDetails ended..");
		return viewResponse;
	}

	public void updateMemberSfdcstatus(Member member) {
		Optional<MemberSfdcStatus> memberSfdcStatus = memberSfdcStatusRespository.findByMemberId(member);
		if (!memberSfdcStatus.isPresent()) {
			MemberSfdcStatus sfdcStatus = new MemberSfdcStatus();
			sfdcStatus.setCreatedAt(DateAndTimeUtil.now());
			sfdcStatus.setMemberId(member);
			sfdcStatus.setOrganizationId(member.getOrganizationId());
			sfdcStatus.setUpdatedAt(DateAndTimeUtil.now());
			sfdcStatus.setProfileUpdated(true);
			memberSfdcStatusRespository.save(sfdcStatus);
		} else {
			MemberSfdcStatus sfdcStatus = memberSfdcStatus.get();
			sfdcStatus.setUpdatedAt(DateAndTimeUtil.now());
			sfdcStatus.setProfileUpdated(true);
			memberSfdcStatusRespository.save(sfdcStatus);
		}

	}

	public void updateMemberToken(Member member) {
		Optional<AuthTokens> memberToken = authTokensRepository.findByMemberId(member);
		if (memberToken.isPresent()) {
			LOGGER.info("Updating member token info for member id:: {}", member.getId());
			memberToken.get().setUpdatedAt(DateAndTimeUtil.now());
			memberToken.get().setExpiredAt(DateAndTimeUtil.now());
			authTokensRepository.save(memberToken.get());
		} else {
			LOGGER.info("Creating member token info for member id:: {}", member.getId());
			AuthTokens memberAuthToken = new AuthTokens();
			memberAuthToken.setCreatedAt(DateAndTimeUtil.now());
			memberAuthToken.setExpiredAt(DateAndTimeUtil.now());
			memberAuthToken.setMemberId(member);
			memberAuthToken.setOrganizationId(member.getOrganizationId());
			memberAuthToken.setUpdatedAt(DateAndTimeUtil.now());
			authTokensRepository.save(memberAuthToken);
			LOGGER.info("Created member token info with id:: {}", memberAuthToken.getId());
		}
		LOGGER.info("Save member token method started..!");
	}

	public void saveMemberEmail(Member member, Optional<MemberEmail> memberPrimaryEmail, SystemUsers user,
			String email, String auditId) {

		Optional<MemberEmail> memberEmailSecoundary = memberEmailRepository.findByEmailAndMemberIdAndSecondary(email,
				member, true);
		if (memberEmailSecoundary.isPresent()) {
			if (memberEmailSecoundary.get().getEmail().equalsIgnoreCase(email)) {
				if (memberPrimaryEmail.isPresent()) {
					memberPrimaryEmail.get().setUpdatedAt(DateAndTimeUtil.now());
					memberPrimaryEmail.get().setPrimary(false);
					memberPrimaryEmail.get().setSecondary(true);
					// memberPrimaryEmail.get().setPassword(null);
					memberPrimaryEmail.get().setVerified(false);
					memberPrimaryEmail.get().setDeleted(false);
					memberEmailRepository.save(memberPrimaryEmail.get());
				}
				memberEmailSecoundary.get().setPrimary(true);
				memberEmailSecoundary.get().setUpdatedAt(DateAndTimeUtil.now());
				if (memberPrimaryEmail.isPresent() && memberPrimaryEmail.get().getPassword() != null) {
					memberEmailSecoundary.get().setPassword(memberPrimaryEmail.get().getPassword());
				}
				memberEmailSecoundary.get().setDeleted(false);
				memberEmailSecoundary.get().setSecondary(false);
				memberEmailSecoundary.get().setUserId(user);
				memberEmailSecoundary.get().setAuditId(auditId);
				memberEmailRepository.save(memberEmailSecoundary.get());

			}
		} else {
			// deleting secondary email if exits for member
			deletingSecoundaryEmail(member, auditId);

			// old primary email to secondary
			Optional<MemberEmail> memberEmailOptional = memberEmailRepository.findByMemberIdAndDeletedAndPrimary(member,
					false, true);
			if (memberEmailOptional.isPresent()) {
				MemberEmail memberEmail = memberEmailOptional.get();
				memberEmail.setUpdatedAt(DateAndTimeUtil.now());
				memberEmail.setPrimary(false);
				memberEmail.setSecondary(true);
				memberEmail.setVerified(false);
				memberEmail.setUserId(user);
				memberEmail.setAuditId(auditId);
				memberEmailRepository.save(memberEmail);
			}

			// setting new email to primary
			if (memberEmailOptional.isPresent()) {
				if (memberPrimaryEmail.isPresent()) {
					newEmailToPrimary(memberPrimaryEmail.get(), email);
				}

			}
		}

	}

	private void deletingSecoundaryEmail(Member member, String auditId) {

		Optional<MemberEmail> memberEmailEntity = memberEmailRepository
				.findByMemberIdAndDeletedAndPrimaryAndSecondary(member, false, false, true);
		if (memberEmailEntity.isPresent()) {
			memberEmailEntity.get().setUpdatedAt(DateAndTimeUtil.now());
			memberEmailEntity.get().setDeleted(true);
			memberEmailEntity.get().setSecondary(false);
			memberEmailEntity.get().setAuditId(auditId);
			memberEmailRepository.save(memberEmailEntity.get());
		}
	}

	private void newEmailToPrimary(MemberEmail member, String email) {
		MemberEmail memberEmail = new MemberEmail();
		memberEmail.setCreatedAt(DateAndTimeUtil.now());
		memberEmail.setUpdatedAt(DateAndTimeUtil.now());
		memberEmail.setOrganizationId(member.getOrganizationId());
		memberEmail.setMemberId(member.getMemberId());
		memberEmail.setEmail(email);
		memberEmail.setPrimary(true);
		memberEmail.setVerified(false);
		memberEmail.setEmailCount(0l);
		memberEmail.setPassword(null);
		memberEmailRepository.save(memberEmail);
	}

	private void saveMemberAddress(UpdatePersonalDetailsRequest updatePersonalDetailsRequest, Member member,
			SystemUsers user, String auditId) {

		Optional<MemberAddress> memberAddress = memberAddressRepository.findByMemberId(member);

		if (memberAddress.isPresent()) {
			LOGGER.debug("updating member address");
			MemberAddress address = memberAddress.get();
			address.setUpdatedAt(DateAndTimeUtil.now());
			address.setStreet(updatePersonalDetailsRequest.getStreet());
			address.setCityName(updatePersonalDetailsRequest.getCityName());
			Optional<CountryMaster> countryMaster = countryMasterRepository
					.findByIdAndStatus(updatePersonalDetailsRequest.getCountryId(), Constants.ACTIVE);
			if (countryMaster.isPresent()) {
				address.setCountryMasterId(countryMaster.get());
			}
			Optional<StateMaster> stateMaster = stateMasterRepository
					.findByIdAndStatus(updatePersonalDetailsRequest.getStateId(), Constants.ACTIVE);
			if (stateMaster.isPresent()) {
				address.setStateMasterId(stateMaster.get());
			}
			address.setZipCode(updatePersonalDetailsRequest.getZipcode());
			address.setAddressLine1(updatePersonalDetailsRequest.getAddressLine1());
			address.setAddressLine2(updatePersonalDetailsRequest.getAddressLine2());
			address.setUserId(user);
			address.setAuditId(auditId);
			addressRepository.save(address);
		} else {
			LOGGER.debug("creating new address if member address is not present");
			MemberAddress address = new MemberAddress();
			address.setCreatedAt(DateAndTimeUtil.now());
			address.setUpdatedAt(DateAndTimeUtil.now());
			address.setStreet(updatePersonalDetailsRequest.getStreet());
			address.setCityName(updatePersonalDetailsRequest.getCityName());
			Optional<CountryMaster> countryMaster = countryMasterRepository
					.findByIdAndStatus(updatePersonalDetailsRequest.getCountryId(), Constants.ACTIVE);
			if (countryMaster.isPresent()) {
				address.setCountryMasterId(countryMaster.get());
			}
			Optional<StateMaster> stateMaster = stateMasterRepository
					.findByIdAndStatus(updatePersonalDetailsRequest.getStateId(), Constants.ACTIVE);
			if (stateMaster.isPresent()) {
				address.setStateMasterId(stateMaster.get());
			}
			address.setZipCode(updatePersonalDetailsRequest.getZipcode());
			address.setAddressLine1(updatePersonalDetailsRequest.getAddressLine1());
			address.setAddressLine2(updatePersonalDetailsRequest.getAddressLine2());
			address.setMemberId(member);
			address.setUserId(user);
			address.setAuditId(auditId);
			addressRepository.save(address);
		}

	}

	private void saveMember(UpdatePersonalDetailsRequest updatePersonalDetailsRequest, Member member,
			SystemUsers user, String auditId) {

		// Member member = memberentity.get();
		if (updatePersonalDetailsRequest.getStatus() != null && !updatePersonalDetailsRequest.getStatus().isEmpty()) {
			member.setStatus(updatePersonalDetailsRequest.getStatus());
		}
		Optional<NamePrefixMaster> namePrefixMaster = namePrefixMasterRepository
				.findByIdAndStatus(updatePersonalDetailsRequest.getPrefixId(), Constants.ACTIVE);
		if (namePrefixMaster.isPresent()) {
			member.setNamePrefixMasterId(namePrefixMaster.get());
		}
		member.setFirstName(WordUtils.capitalizeFully(updatePersonalDetailsRequest.getFirstName()));
		member.setLastName(WordUtils.capitalizeFully(updatePersonalDetailsRequest.getLastName()));
		member.setMiddleName(WordUtils.capitalizeFully(updatePersonalDetailsRequest.getMiddleName()));

		Optional<MemberTypeMaster> memberTypeOptional = memberTypeMasterRepository
				.findById(updatePersonalDetailsRequest.getOpportunityId());
		if (!memberTypeOptional.isPresent()) {
			throw new NoRecordFoundException(Constants.OPPORTUNITY_NOT_FOUND);
		}
		member.setMemberTypeMasterId(memberTypeOptional.get());

		if (memberTypeOptional.get().getTypeName().equalsIgnoreCase(Constants.DIRECT_MEMBER)) {
			member.setEmployerId(null);
		} else {
			member.setEmployerId(updatePersonalDetailsRequest.getEmployerId());
		}

		Optional<GenderMaster> genderMaster = genderMasterRepository
				.findByIdAndStatus(updatePersonalDetailsRequest.getGenderId(), Constants.ACTIVE);
		if (genderMaster.isPresent()) {
			member.setGenderId(genderMaster.get());
		}
		Optional<CountryPhoneCodeMaster> countryPhoneCode = countryPhoneCodeMasterRepository
				.findByIdAndStatus(updatePersonalDetailsRequest.getCountryPhoneCodeId(), Constants.ACTIVE);
		if (countryPhoneCode.isPresent()) {
			member.setCountryPhoneCodeMasterId(countryPhoneCode.get());
		}
		member.setPhoneNumber(updatePersonalDetailsRequest.getMobileNumber());
		if (!StringUtils.isBlank(updatePersonalDetailsRequest.getDateOfBirth())) {
			member.setDateOfBirth(DateAndTimeUtil.stringDateToLocalDate(updatePersonalDetailsRequest.getDateOfBirth()));
		}
		if ((updatePersonalDetailsRequest.getProductId() > 0 && member.getProductId() == null)
				|| (updatePersonalDetailsRequest.getProductId() > 0 && member.getProductId() != null
						&& updatePersonalDetailsRequest.getProductId() != member.getProductId().getId())) {
			Optional<MemberProduct> memberProduct = memberProductRepository
					.findById(updatePersonalDetailsRequest.getProductId());
			if (memberProduct.isPresent()) {
				// soft deleting family members if product type changed from Married/Family to
				// single

				if (member.getProductId() != null) {
					if (member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.FAMILY)
							&& memberProduct.get().getProductName().equalsIgnoreCase(StatusConstants.MARRIED)) {
						List<MemberFamily> memberFamilyList = new ArrayList<>();
						List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndIsDeleted(member,
								false);
						if (!memberFamily.isEmpty()) {
							memberFamily.forEach(family -> {
								if (family.getRelationShipMasterId().getRelationshipName()
										.equalsIgnoreCase(StatusConstants.CHILD)) {
									family.setDeleted(true);
									family.setStatus(StatusConstants.INACTIVE);
									memberFamilyList.add(family);
								}
							});
							memberFamilyRepository.saveAll(memberFamilyList);
						}
					}

					if ((member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.MARRIED)
							|| member.getProductId().getProductName().equalsIgnoreCase(StatusConstants.FAMILY))
							&& memberProduct.get().getProductName().equalsIgnoreCase(StatusConstants.SINGLE)) {

						List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndIsDeleted(member,
								false);
						List<MemberFamily> memberFamilyList = new ArrayList<>();
						if (!memberFamily.isEmpty()) {
							memberFamily.forEach(family -> {
								family.setDeleted(true);
								family.setStatus(StatusConstants.INACTIVE);
								memberFamilyList.add(family);
							});
							memberFamilyRepository.saveAll(memberFamilyList);
						}
					}
					member.setProductId(memberProduct.get());
				}
				else {
					member.setProductId(memberProduct.get());
				}

			}
		}
		member.setUserId(user);
		member.setAuditId(auditId);
		member.setUpdatedAt(DateAndTimeUtil.now());
		memberRepository.save(member);
		LOGGER.debug("updated member details and saved as per request");
	}

	public ViewMemberResponse getMemberInfo(Long memberId) {
		LOGGER.info("getMemberPersonalInfo method started..!");
		Member member = memberService.getMember(memberId);
		ViewMemberResponse memberResponse = new ViewMemberResponse();
		memberResponse.setStatusText(Constants.SUCCESS);
		memberResponse.setMessage(Constants.WELCOME_MEMBER);
		LOGGER.info("getMemberPersonalInfo method ended..!");
		return memberResponse;
	}

	public ViewResponse sendUpdatedEmailToMember(UpdatePersonalDetailsRequest updatePersonalDetailsRequest,
			EmailTitles emailTitles, Member member) {
		LOGGER.info("Send welcome mail method started..!");

		UpdateEmailRequest updateEmailRequest = new UpdateEmailRequest();
		updateEmailRequest.setEmailTitle(emailTitles);
		updateEmailRequest.setFirstName(member.getFirstName());
		updateEmailRequest.setLastName(member.getLastName());
		updateEmailRequest.setUserName(updatePersonalDetailsRequest.getPrimaryEmailId());
		updateEmailRequest.setOrgId(member.getOrganizationId().getId());
		ViewResponse viewResponse = new ViewResponse();
		try {
			LOGGER.debug("Calling email service to send welcome email");
			viewResponse = emailService.sendUpdatedEamil(updateEmailRequest);
		} catch (Exception exception) {
			LOGGER.debug("Exception occured while connecting email service, cause:: ", exception.getCause());
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
		}

		if (viewResponse != null && viewResponse.getStatusText() != null
				&& viewResponse.getStatusText().equalsIgnoreCase(Constants.SUCCESS)) {
			LOGGER.info("Calling email service to send welcome email");
			viewResponse.setStatusText(Constants.SUCCESS);
			viewResponse.setMessage(Constants.WELCOME_MEMBER);
		} else {
			// throw new
			// NoRecordFoundException(ExceptionalMessages.UNABLE_SEND_UPDATED_EMAIL);
		}

		return viewResponse;
	}

	public ViewResponse checkProductType(CheckProductTypeRequest checkProductTypeRequest) {
		LOGGER.info("check Product Type method started..!");

		Optional<Member> member = memberRepository.findById(checkProductTypeRequest.getMemberId());
		if (!member.isPresent()) {
			throw new MemberNotFoundException(ExceptionalMessages.MEMBER_NOT_FORUND_WITH_ID);
		}
		Optional<MemberProduct> memberProduct = memberProductRepository
				.findById(checkProductTypeRequest.getProductId());
		if (!memberProduct.isPresent()) {
			throw new MemberNotFoundException(
					ExceptionalMessages.PRODUCT_NOT_FOUND + checkProductTypeRequest.getMemberId());
		}
		ViewResponse response = new ViewResponse();
		List<MemberFamily> memberFamily = memberFamilyRepository.findByMemberIdAndIsDeleted(member.get(), false);
		for (MemberFamily family : memberFamily) {
			if (member.get().getProductId().getProductName().equalsIgnoreCase("Family")
					&& memberProduct.get().getProductName().equalsIgnoreCase("Married")
					&& family.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Child")) {
				response.setStatusText(Constants.SUCCESS);
				response.setMessage(Constants.FAMILY_TO_MARRIED);
				response.setPopup(true);
				return response;
			} else if (member.get().getProductId().getProductName().equalsIgnoreCase("Married")
					&& memberProduct.get().getProductName().equalsIgnoreCase("Single")
					&& family.getRelationShipMasterId().getRelationshipName().equalsIgnoreCase("Spouse")) {
				response.setStatusText(Constants.SUCCESS);
				response.setMessage(Constants.MARRIED_TO_SINGLE);
				response.setPopup(true);
				return response;
			} else if (member.get().getProductId().getProductName().equalsIgnoreCase("Family")
					&& memberProduct.get().getProductName().equalsIgnoreCase("Single")) {
				response.setStatusText(Constants.SUCCESS);
				response.setMessage(Constants.FAMILY_TO_SINGLE);
				response.setPopup(true);
				return response;
			} else if (memberFamily.indexOf(family) == memberFamily.size() - 1) {
				response.setStatusText(Constants.SUCCESS);
				response.setMessage(Constants.SUCCESS);
				response.setPopup(false);
				return response;
			}
		}
		if (memberFamily.isEmpty()) {
			response.setStatusText(Constants.SUCCESS);
			response.setMessage(Constants.SUCCESS);
			response.setPopup(false);
			return response;
		}
		return response;
	}

}
