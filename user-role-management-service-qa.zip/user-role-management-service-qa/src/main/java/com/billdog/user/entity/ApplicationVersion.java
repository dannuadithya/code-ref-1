package com.billdog.user.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "APPLICATION_VERSION")
@Table(name = "application_version")
public class ApplicationVersion extends BaseEntity {

	@Column(name = "IOS_VERSION")
	private String iosVersion;
	
	@Column(name = "ANDROID_VERSION")
	private String androidVersion;

	@Column(name = "GLOBAL_UPDATE")
	private boolean globalUpdate;

	@ManyToOne
	@JoinColumn(name = "ORGANIZATION_ID")
	private Organization organizationId;
	

	public String getIosVersion() {
		return iosVersion;
	}

	public void setIosVersion(String iosVersion) {
		this.iosVersion = iosVersion;
	}

	public String getAndroidVersion() {
		return androidVersion;
	}

	public void setAndroidVersion(String androidVersion) {
		this.androidVersion = androidVersion;
	}

	public boolean isGlobalUpdate() {
		return globalUpdate;
	}

	public void setGlobalUpdate(boolean globalUpdate) {
		this.globalUpdate = globalUpdate;
	}

	public Organization getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Organization organizationId) {
		this.organizationId = organizationId;
	}

}
