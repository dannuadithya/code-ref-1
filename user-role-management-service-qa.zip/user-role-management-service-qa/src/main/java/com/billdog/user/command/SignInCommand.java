package com.billdog.user.command;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.billdog.user.request.UserSignInRequest;
import com.billdog.user.service.LoginService;
import com.billdog.user.view.ViewResponse;

@Service
public class SignInCommand implements Command<UserSignInRequest, ResponseEntity<ViewResponse>> {

	@Autowired
	LoginService loginService;

	@Override
	public ResponseEntity<ViewResponse> excute(UserSignInRequest signInRequest) {
		return ResponseEntity.status(HttpStatus.OK).body(loginService.signInUser(signInRequest));

	}
}
