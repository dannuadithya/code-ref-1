package com.billdog.user.common;

public enum AuditModules {

	Members, Users, Entities, Opportunities, Cases, Roles

}
