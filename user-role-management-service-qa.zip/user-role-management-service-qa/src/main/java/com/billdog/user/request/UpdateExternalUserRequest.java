package com.billdog.user.request;

import com.billdog.user.config.WhiteSpaceRemovalDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class UpdateExternalUserRequest {

	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String oldEmail;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String newEmail;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String firstName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String lastName;
	@JsonDeserialize(using = WhiteSpaceRemovalDeserializer.class)
	private String brokerCompany;

	public String getOldEmail() {
		return oldEmail;
	}

	public void setOldEmail(String oldEmail) {
		this.oldEmail = oldEmail;
	}

	public String getNewEmail() {
		return newEmail;
	}

	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBrokerCompany() {
		return brokerCompany;
	}

	public void setBrokerCompany(String brokerCompany) {
		this.brokerCompany = brokerCompany;
	}

}
