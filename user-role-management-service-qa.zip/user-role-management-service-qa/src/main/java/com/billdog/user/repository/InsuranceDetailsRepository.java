package com.billdog.user.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.billdog.user.entity.InsuranceDetails;
import com.billdog.user.entity.Member;

public interface InsuranceDetailsRepository extends JpaRepository<InsuranceDetails, Long> {

	List<InsuranceDetails> findByMemberId(Member member);

}
