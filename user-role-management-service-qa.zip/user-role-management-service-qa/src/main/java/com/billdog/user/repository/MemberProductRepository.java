package com.billdog.user.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.billdog.user.entity.MemberProduct;
import com.billdog.user.entity.Organization;

public interface MemberProductRepository extends JpaRepository<MemberProduct, Long> {

	Optional<MemberProduct> findByIdAndStatus(long productId, String active);

	List<MemberProduct> findAllByStatus(String active);

	List<MemberProduct> findByOrganizationIdAndStatus(Organization organization, String active);
	
	@Query(value ="SELECT count(*) FROM billdog_case.member_case mc\n" + 
			"join case_status_master csm on csm.id = mc.status_id\n" + 
			"where csm.status_name not in ('Closed')", nativeQuery = true)
	Object[][] getClosedCases();
	
	@Query(value ="SELECT count(*) FROM billdog_case.member_case mc\n" + 
			"join case_status_master csm on csm.id = mc.status_id\n" + 
			"where csm.status_name in ('Closed')", nativeQuery = true)
	Object[][] getOpenCases();

	Optional<MemberProduct> findByProductNameAndOrganizationId(String productType, Organization organizationId);

}
