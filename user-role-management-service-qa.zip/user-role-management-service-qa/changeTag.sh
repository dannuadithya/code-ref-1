#!/bin/bash
sed "s/latest/$1/g" user-pod.yaml > user-role-management.yaml