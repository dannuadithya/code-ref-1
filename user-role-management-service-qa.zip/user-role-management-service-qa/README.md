# user-role-management-service

This micro service hold the source code of user-role-management-service API's 