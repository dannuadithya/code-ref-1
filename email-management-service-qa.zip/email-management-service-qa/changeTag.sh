#!/bin/bash
sed "s/latest/$1/g" email-pod.yaml > email-management.yaml