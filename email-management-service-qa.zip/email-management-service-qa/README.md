# emial-management-service

This micro service hold the source code of email-management-service API's 
