package com.billdog.email.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.email.entity.EmailMaster;

@Repository
public interface EmailMasterRepository extends JpaRepository<EmailMaster, Long> {

	Optional<EmailMaster> findByEmailTitleAndOrganizationId(String string, Long organizationId);
	
	
}