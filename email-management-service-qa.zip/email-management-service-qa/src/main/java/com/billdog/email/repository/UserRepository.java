package com.billdog.email.repository;

import retrofit2.Call;
import retrofit2.http.GET;

public interface UserRepository {


	@GET("/user/v1/organizationInfo")
	public Call<String> getOrganizationInfo(Long orgId);


}
