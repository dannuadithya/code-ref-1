package com.billdog.email.common;

public class ExceptionalMessages {

	public static final String EMAIL_TITLE_NOT_FOUND = "No template is found with title :: ";

	public static final String UNABLE_TO_SEND_EMAIL = "We are unable to send passcode. Please try after some time.!!";

	public static final String USER_NOT_FOUND = "User not found with id:: ";

	public static final String UNABLE_TO_SEND_WELCOME_EMAIL = "Unable to send welcome email";

	public static final String UNABLE_TO_SEND_UPDATED_EMAIL = "Unable to send updated email to member";

}
