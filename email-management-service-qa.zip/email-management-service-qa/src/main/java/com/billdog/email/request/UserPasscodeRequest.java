package com.billdog.email.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.billdog.email.common.EmailTitles;

public class UserPasscodeRequest {
	
	//@NotNull(message = "Passcode must not be null")
	private String passcode;

	@NotBlank(message = "Please enter Email")
	@Email(message = "Invalid email format")
	private String email;

	@NotNull(message = "Email title name must not be null")
	private EmailTitles emailTitle;

	@NotNull(message = "User id must not be null")
	private Long userId;

	@NotBlank(message = "Please enter user name")
	private String username;

	@NotBlank(message = "Please enter sender name")
	private String senderName;

	@NotNull(message = "Organization id must not be null")
	private Long organizationId;

	public String getPasscode() {
		return passcode;
	}

	public void setPasscode(String passcode) {
		this.passcode = passcode;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


	public EmailTitles getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(EmailTitles emailTitle) {
		this.emailTitle = emailTitle;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getSenderName() {
		return senderName;
	}

	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

}
