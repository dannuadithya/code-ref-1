package com.billdog.email.config;

import java.util.Properties;

import javax.mail.PasswordAuthentication;
import javax.mail.Session;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

@Configuration
public class EmailConfiguration {

	@Bean
	public JavaMailSender getJavaMailSender() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		mailSender.setHost("smtp.gmail.com");
		mailSender.setPort(587);

		mailSender.setUsername("no-reply@billdog.com");
		mailSender.setPassword("40#Lions#");

		/*
		 * mailSender.setUsername("billdogtest@gmail.com");
		 * mailSender.setPassword("billdog@123");
		 */

		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.debug", "false");
		props.put("mail.smtp.timeout", 5000);
		props.put("mail.smtp.writetimeout", 5000);
		props.put("mail.smtp.connectiontimeout", 5000);

		return mailSender;
	}

	@Bean
	public Session getSession() {
		return Session.getInstance(getProps(), new javax.mail.Authenticator() {
			@Override
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication("no-reply@billdog.com", "40#Lions#");
			}
		});
	}

	public Properties getProps() {
		JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
		/*
		 * mailSender.setHost("smtp.gmail.com"); mailSender.setPort(587);
		 * 
		 * mailSender.setUsername("no-reply@billdog.com");
		 * mailSender.setPassword("40#Lions#");
		 * 
		 * mailSender.setUsername("billdogtest@gmail.com");
		 * mailSender.setPassword("billdog@123");
		 */
		Properties props = mailSender.getJavaMailProperties();
		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		props.put("mail.debug", "false");
		props.put("mail.smtp.timeout", 5000);
		props.put("mail.smtp.writetimeout", 5000);
		props.put("mail.smtp.connectiontimeout", 5000);
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "587");
		return props;
	}

}
