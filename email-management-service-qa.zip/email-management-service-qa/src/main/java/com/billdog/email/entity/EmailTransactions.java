package com.billdog.email.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity(name = "EMAIL_TRANSACTIONS")
@Table(name = "email_transactions")
public class EmailTransactions extends BaseEntity {

	@Column(name = "MEMBER_EMAIL")
	private String memberEmail;

	@Column(name = "FROM_EMAIL")
	private String fromEmail;

	@Column(name = "ORGANIZATION_ID")
	private Long organizationId;

	@Column(name = "MEMBER_ID")
	private Long memberId;

	@Column(name = "USER_ID")
	private Long userId;

	@ManyToOne
	@JoinColumn(name = "EMAIL_MASTER_ID")
	private EmailMaster emailMasterId;

	public String getMemberEmail() {
		return memberEmail;
	}

	public void setMemberEmail(String memberEmail) {
		this.memberEmail = memberEmail;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public EmailMaster getEmailMasterId() {
		return emailMasterId;
	}

	public void setEmailMasterId(EmailMaster emailMasterId) {
		this.emailMasterId = emailMasterId;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
}
