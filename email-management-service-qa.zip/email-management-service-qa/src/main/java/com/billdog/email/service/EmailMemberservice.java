package com.billdog.email.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.billdog.email.common.Constants;
import com.billdog.email.common.DateAndTimeUtil;
import com.billdog.email.common.ExceptionalMessages;
import com.billdog.email.entity.EmailMaster;
import com.billdog.email.entity.EmailTransactions;
import com.billdog.email.exception.RecordNotFoundException;
import com.billdog.email.repository.EmailMasterRepository;
import com.billdog.email.repository.EmailTransactionsRepository;
import com.billdog.email.request.MemberPasscodeRequest;
import com.billdog.email.view.ViewResponse;

@Service
public class EmailMemberservice {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmailMemberservice.class);

	@Autowired
	EmailMasterRepository emailMasterRepository;

	@Autowired
	EmailTransactionsRepository emailTransactionsRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	UpdateEmailService updateEmailService;

	/*
	 * This method is used to send an email to user or update password.
	 */
	@Transactional
	public ViewResponse sendPasscodeEmail(MemberPasscodeRequest passcodeMemberEmailRequest) {

		return sendEmail(passcodeMemberEmailRequest);
	}

	private ViewResponse sendEmail(MemberPasscodeRequest passcodeMemberEmailRequest) {
		LOGGER.info("sendEmail method started..!");
		// SimpleMailMessage message = new SimpleMailMessage();
		// Fetching email template
		Optional<EmailMaster> emailMasterOptional = emailMasterRepository
				.findByEmailTitleAndOrganizationId(passcodeMemberEmailRequest.getEmailTitle().toString(),
						passcodeMemberEmailRequest.getOrgId());

		if (!emailMasterOptional.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.EMAIL_TITLE_NOT_FOUND + passcodeMemberEmailRequest.getEmailTitle().toString());
		}
		LOGGER.info("found email title");
		try {
		LOGGER.info("try block started");
		String mailText = getMailText(emailMasterOptional.get().getBody(), passcodeMemberEmailRequest.getPasscode(),
				passcodeMemberEmailRequest.getEmail(), passcodeMemberEmailRequest.getFirstName());

			updateEmailService.sendTemplate(emailMasterOptional.get(), mailText, passcodeMemberEmailRequest.getEmail(),
					passcodeMemberEmailRequest.getOrgId());
		LOGGER.info("Sending email from Organization:: " + passcodeMemberEmailRequest.getEmail());
		updateEmailTransactions(passcodeMemberEmailRequest.getEmail(), emailMasterOptional.get());
		} catch (Exception exception) {
			LOGGER.warn("Exception occured while sending email, Cause dev exception:: ", exception.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MAIL_SENT);
		return response;
	}

	/*
	 * This method is used to save email details that has sent to user
	 */
	@Transactional
	private void updateEmailTransactions(String memberEmail, EmailMaster emailMaster) {
		LOGGER.warn("updateEmailTransactions method started");
		EmailTransactions emailTransactions = new EmailTransactions();
		emailTransactions.setCreatedAt(DateAndTimeUtil.now());
		emailTransactions.setUpdatedAt(DateAndTimeUtil.now());
		emailTransactions.setMemberEmail(memberEmail);
		emailTransactions.setEmailMasterId(emailMaster);
		emailTransactions.setOrganizationId(emailMaster.getOrganizationId());
		emailTransactionsRepository.save(emailTransactions);
		LOGGER.warn("updateEmailTransactions method ended");
	}

	private String getMailText(String emailTemplate, String passcode, String username, String firstName) {
		String message = emailTemplate.toString();
		LOGGER.warn("getMailText method started");
		message = message.replace("{{USERNAME}}", username);
		message = message.replace("{{PASSCODE}}", passcode);
		if (firstName == null || firstName.isEmpty()) {
			message = message.replace("{{FIRSTNAME}}", "");
		} else {
			message = message.replace("{{FIRSTNAME}}", firstName);
		}
		LOGGER.warn("getMailText method end");
		return message;
	}

}
