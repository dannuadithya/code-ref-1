package com.billdog.email.common;

public class Constants {

	public static final String FAILED = "FAILED";

	public static final String SUCCESS = "SUCCESS";

	public static final String PASSCODE_SENT = "Passcode sent to your email successfully";

	public static final String MAIL_SENT = "Mail sent to your email address successfully";
}
