package com.billdog.email.controller;

import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.billdog.email.exception.ErrorResponse;
import com.billdog.email.request.MemberCaseMail;
import com.billdog.email.request.MemberPasscodeRequest;
import com.billdog.email.request.UpdateEmailrequest;
import com.billdog.email.request.UpdateMemberEmailRequest;
import com.billdog.email.request.UserPasscodeRequest;
import com.billdog.email.request.WelcomeEmailRequest;
import com.billdog.email.service.CaseEmailService;
import com.billdog.email.service.EmailMemberservice;
import com.billdog.email.service.EmailService;
import com.billdog.email.service.UpdateEmailService;
import com.billdog.email.service.WelcomeEmailMember;
import com.billdog.email.view.ViewResponse;

import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/v1")
@CrossOrigin(origins = "*")
public class EmailController {

	@Autowired
	EmailMemberservice emailMemberservice;

	@Autowired
	EmailService emailService;

	@Autowired
	CaseEmailService caseEmailService;

	@Autowired
	WelcomeEmailMember welcomeEmailMember;

	@Autowired
	UpdateEmailService updateEmailService;

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Generate OTP"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/email", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> sendPasscodeEmail(@Valid @RequestBody UserPasscodeRequest userPasscodeRequest) {

		return ResponseEntity.status(HttpStatus.OK).body(emailService.sendPasscodeEmail(userPasscodeRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Generate OTP"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/emailMember", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> sendPasscodeEmailToMember(
			@Valid @RequestBody MemberPasscodeRequest memberPasscodeRequest) {

		return ResponseEntity.status(HttpStatus.OK).body(emailMemberservice.sendPasscodeEmail(memberPasscodeRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "Generate OTP"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/caseEmail", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> sendPasscodeEmailToMember(@Valid @RequestBody MemberCaseMail memberCaseMail) {

		return ResponseEntity.status(HttpStatus.OK).body(caseEmailService.sendCaseEmail(memberCaseMail));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "welcome email sent successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/welcomeEmailMember", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> welcomeEmailMember(
			@Valid @RequestBody WelcomeEmailRequest welcomeEmailRequest) {

		return ResponseEntity.status(HttpStatus.OK)
				.body(welcomeEmailMember.sendWelcomeEmailMember(welcomeEmailRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "updated email sent successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/UpdateEmailMember", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> udateEmailMember(
			@Valid @RequestBody UpdateMemberEmailRequest updateMemberEmailRequest) {

		return ResponseEntity.status(HttpStatus.OK)
				.body(updateEmailService.sendUpdatedEmailMember(updateMemberEmailRequest));
	}

	@ApiResponses(value = {
			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "updated email sent successfully"),
			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
	@PostMapping(value = "/UpdateEmailForMobile", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)

	public ResponseEntity<ViewResponse> udateEmailForMobile(@Valid @RequestBody UpdateEmailrequest updateEmailrequest) {
		return ResponseEntity.status(HttpStatus.OK).body(updateEmailService.sendUpdatedEmail(updateEmailrequest));
	}

//	@ApiResponses(value = {
//			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "updated email sent successfully"),
//			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })
//	@PostMapping(value = "/sendHtml", consumes = MediaType.APPLICATION_JSON_UTF8_VALUE, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
//	public ResponseEntity<ViewResponse> sendhtml() {
//
//		return ResponseEntity.status(HttpStatus.OK).body(emailService.sendEmail());
//	}

	@ApiResponses(value = {

			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "updated email sent successfully"),

			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })

	@GetMapping(value = "/oauth2mail", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<ViewResponse> sendOauthMail() {

		return ResponseEntity.status(HttpStatus.OK).body(emailService.sendOauthMail());
	}

	@ApiResponses(value = {

			@ApiResponse(code = HttpServletResponse.SC_OK, response = ViewResponse.class, message = "updated email sent successfully"),

			@ApiResponse(code = HttpServletResponse.SC_BAD_REQUEST, response = ErrorResponse.class, message = "Invalid parameters") })

	@GetMapping(value = "/oauth2callback", produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	public ResponseEntity<String> oAuthCallback() {

		return ResponseEntity.status(HttpStatus.OK).body("Received verification code. You may now close this window.");
	}


}
