package com.billdog.email.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.Optional;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.transaction.Transactional;

import org.apache.commons.text.WordUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.billdog.email.common.Constants;
import com.billdog.email.common.DateAndTimeUtil;
import com.billdog.email.common.ExceptionalMessages;
import com.billdog.email.entity.EmailMaster;
import com.billdog.email.entity.EmailTransactions;
import com.billdog.email.exception.RecordNotFoundException;
import com.billdog.email.repository.EmailMasterRepository;
import com.billdog.email.repository.EmailTransactionsRepository;
import com.billdog.email.request.UserPasscodeRequest;
import com.billdog.email.view.TemplateInfo;
import com.billdog.email.view.ViewResponse;
import com.github.mustachejava.DefaultMustacheFactory;
import com.github.mustachejava.Mustache;
import com.github.mustachejava.MustacheFactory;

@Service
public class EmailService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(EmailService.class);

	@Autowired
	EmailMasterRepository emailMasterRepository;

	@Autowired
	EmailTransactionsRepository emailTransactionsRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	private Session session;

	@Autowired
	ResourceLoader resourceLoader;

	@Autowired
	GMailOauthService gmailOauthService;

	/*
	 * This method is used to send an email to user or update password.
	 */
	@Transactional
	public ViewResponse sendPasscodeEmail(UserPasscodeRequest userPasscodeRequest) {
		LOGGER.info("sendPasscodeEmail method started..!");
		return sendEmail(userPasscodeRequest);
	}

	private ViewResponse sendEmail(UserPasscodeRequest passcodeEmailRequest) {
		LOGGER.info("sendEmail method started..!");

		// Fetching email template
		Optional<EmailMaster> emailMasterOptional = emailMasterRepository.findByEmailTitleAndOrganizationId(
				passcodeEmailRequest.getEmailTitle().toString(), passcodeEmailRequest.getOrganizationId());
		LOGGER.info("Fetched email template for mail type:: {}", passcodeEmailRequest.getEmailTitle());
		if (!emailMasterOptional.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.EMAIL_TITLE_NOT_FOUND + passcodeEmailRequest.getEmailTitle().toString());
		}

		try {
			String firstname = null;
			String mailText = getMailText(emailMasterOptional.get().getBody(), passcodeEmailRequest.getPasscode(),
					passcodeEmailRequest.getUsername(), firstname);
			sendTemplate(emailMasterOptional.get(), mailText,
					passcodeEmailRequest.getSenderName() + "< no-reply@domain.com >", passcodeEmailRequest.getEmail(),
					emailMasterOptional.get().getOrganizationId());
			LOGGER.info("Sending email from Organization:: " + passcodeEmailRequest.getSenderName());

			updateEmailTransactions(passcodeEmailRequest, emailMasterOptional.get());
		} catch (Exception exception) {
			LOGGER.warn("Exception occured while sending email, Cause:: ", exception.getCause());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MAIL_SENT);
		LOGGER.info("Email sent to user mail type:: " + passcodeEmailRequest.getEmailTitle());
		LOGGER.info("sendEmail method ended..!");
		return response;
	}

	/*
	 * This method is used to save email details that has sent to user
	 */
	@Transactional
	private void updateEmailTransactions(UserPasscodeRequest passcodeEmailRequest, EmailMaster emailMaster) {
		LOGGER.info("Creating email trasaction for user email:: " + passcodeEmailRequest.getEmail());
		EmailTransactions emailTransactions = new EmailTransactions();
		emailTransactions.setCreatedAt(DateAndTimeUtil.now());
		emailTransactions.setUpdatedAt(DateAndTimeUtil.now());
		emailTransactions.setFromEmail(passcodeEmailRequest.getSenderName());
		emailTransactions.setMemberEmail(passcodeEmailRequest.getEmail());
		emailTransactions.setOrganizationId(passcodeEmailRequest.getOrganizationId());
		emailTransactions.setEmailMasterId(emailMaster);
		emailTransactions.setUserId(passcodeEmailRequest.getOrganizationId());
		emailTransactionsRepository.save(emailTransactions);
	}

	private String getMailText(String emailTemplate, String passcode, String username, String firstname) {
		String message = emailTemplate.toString();
		message = message.replace("{{FIRSTNAME}}", WordUtils.capitalizeFully(username));
		message = message.replace("{{PASSCODE}}", passcode);
		if (firstname == null || firstname.isEmpty()) {
			message = message.replace("{{FIRSTNAME}}", "");
		} else {
			message = message.replace("{{FIRSTNAME}}", firstname);
		}
		message = message.replace("{{FIRSTNAME}}", WordUtils.capitalizeFully(username));
		message = message.replace("{{passcode}}", passcode);
		return message;
	}

	private TemplateInfo getTemplateInfo(EmailMaster email, String message) {
		TemplateInfo templateInfo = new TemplateInfo();
		templateInfo.setMessageBody(message);
		templateInfo.setMessageFooter(email.getFooter());
		templateInfo.setMessageHeader(email.getHeader());
		templateInfo.setSubject(email.getSubject());
		return templateInfo;
	}

	private TemplateInfo getTemplateInfoCase(EmailMaster email, String message, String caseId) {
		TemplateInfo templateInfo = new TemplateInfo();
		templateInfo.setMessageBody(message);
		templateInfo.setMessageFooter(email.getFooter());
		templateInfo.setMessageHeader(email.getHeader());
		String subject = email.getSubject();
		if (email.getSubject().contains("A new Bill Review ID has been started {{CASE_ID}}")) {
			subject = subject.replace("{{CASE_ID}}", caseId);
		}
		templateInfo.setSubject(subject);

		return templateInfo;
	}

	public ViewResponse sendEmail(EmailMaster email, String message, String fromMail, String toMail) {

		MustacheFactory mf = new DefaultMustacheFactory();
		Mustache mustache = mf.compile("./src/main/resources/email_templates/body.mustache");

		TemplateInfo templateInfo = getTemplateInfo(email, message);
		StringWriter writer = new StringWriter();

		try {
			mustache.execute(writer, templateInfo).flush();
			Message messageText = new MimeMessage(session);
			messageText.setFrom(new InternetAddress(fromMail));
			messageText.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toMail));
			messageText.setSubject(templateInfo.getSubject());
			messageText.setContent(writer.toString(), "text/html");
			Transport.send(messageText);
			LOGGER.info("Sent message successfully....");
		} catch (MessagingException | IOException e) {
			e.printStackTrace();
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}

		ViewResponse response = new ViewResponse();
		response.setStatusText("Success");
		return response;
	}

	public void sendTemplate(EmailMaster email, String message, String fromMail, String toMail, long orgId) {
		LOGGER.warn("sendTemplate method started");
		MustacheFactory mustacheFactory = new DefaultMustacheFactory();
		try {
			Resource file = resourceLoader.getResource("classpath:email_templates/body.mustache");
			InputStream inputStream = file.getInputStream();
			BufferedReader bufferReader = new BufferedReader(new InputStreamReader(inputStream));
			Mustache mustache = mustacheFactory.compile(bufferReader, "body.mustache");
			TemplateInfo templateInfo = getTemplateInfo(email, message);
			StringWriter writer = new StringWriter();
			mustache.execute(writer, templateInfo).flush();

			/*
			 * Message messageText = new MimeMessage(session);
			 * messageText.setRecipients(Message.RecipientType.TO,
			 * InternetAddress.parse(toMail));
			 * messageText.setSubject(templateInfo.getSubject());
			 * messageText.setContent(writer.toString(), "text/html");
			 * Transport.send(messageText);
			 */

			// messageText.addRecipients(RecipientType.CC,
			// InternetAddress.parse("charanrajj@wavelabs.ai"));
			/*
			 * SMTPTransport transport = new SMTPTransport(session, null);
			 * transport.connect("smtp.gmail.com", "no-reply@billdog.com", null);
			 * 
			 * transport.issueCommand("AUTH XOAUTH2 " + new
			 * String(BASE64EncoderStream.encode(String
			 * .format("user=%s\1auth=Bearer %s\1\1", "no-reply@billdog.com",
			 * smtpUserAccessToken).getBytes())), 235);
			 * 
			 * 
			 * transport.sendMessage(messageText, messageText.getAllRecipients());
			 */

			MimeMessage mimeMessage = new MimeMessage(Session.getDefaultInstance(new Properties(), null));
			mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toMail));
			mimeMessage.setSubject(templateInfo.getSubject());
			mimeMessage.setContent(writer.toString(), "text/html");
			gmailOauthService.sendMimeMessage(mimeMessage, orgId);

			LOGGER.info("Sent message successfully....");
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("exception occured while sending mail:: {}", e.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
	}

	public void sendTemplateCase(EmailMaster email, String message, String fromMail, String toMail, String caseId,
			long orgId) {
		LOGGER.warn("sendTemplate method started");
		MustacheFactory mustacheFactory = new DefaultMustacheFactory();
		try {
			Resource file = resourceLoader.getResource("classpath:email_templates/body.mustache");
			InputStream inputStream = file.getInputStream();
			BufferedReader bufferReader = new BufferedReader(new InputStreamReader(inputStream));
			Mustache mustache = mustacheFactory.compile(bufferReader, "body.mustache");
			TemplateInfo templateInfo = getTemplateInfoCase(email, message, caseId);
			StringWriter writer = new StringWriter();
			mustache.execute(writer, templateInfo).flush();

			/*
			 * Message messageText = new MimeMessage(session); messageText.setFrom(new
			 * InternetAddress(fromMail));
			 * messageText.setRecipients(Message.RecipientType.TO,
			 * InternetAddress.parse(toMail));
			 * messageText.setSubject(templateInfo.getSubject());
			 * messageText.setContent(writer.toString(), "text/html");
			 * Transport.send(messageText);
			 */

			MimeMessage mimeMessage = new MimeMessage(Session.getDefaultInstance(new Properties(), null));
			mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toMail));
			mimeMessage.setSubject(templateInfo.getSubject());
			mimeMessage.setContent(writer.toString(), "text/html");
			gmailOauthService.sendMimeMessage(mimeMessage, orgId);

			LOGGER.info("Sent message successfully....");
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("exception occured while sending mail:: {}", e.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
	}

	public static MimeMessage createEmail(String to, String from, String subject, String bodyText)
			throws MessagingException {
		Properties props = new Properties();
		Session session = Session.getDefaultInstance(props, null);

		MimeMessage email = new MimeMessage(session);

		email.setFrom(new InternetAddress(from));
		email.addRecipient(javax.mail.Message.RecipientType.TO, new InternetAddress(to));
		email.setSubject(subject);
		email.setText(bodyText);
		return email;
	}

	public ViewResponse sendOauthMail() {
		LOGGER.warn("sendOauthMail method started");
		try {
			/*
			 * Message messageText = new MimeMessage(session);
			 * messageText.setRecipients(Message.RecipientType.TO,
			 * InternetAddress.parse(toMail));
			 * messageText.setSubject(templateInfo.getSubject());
			 * messageText.setContent(writer.toString(), "text/html");
			 * Transport.send(messageText);
			 */

			// messageText.addRecipients(RecipientType.CC,
			// InternetAddress.parse("charanrajj@wavelabs.ai"));
			/*
			 * SMTPTransport transport = new SMTPTransport(session, null);
			 * transport.connect("smtp.gmail.com", "no-reply@billdog.com", null);
			 * 
			 * transport.issueCommand("AUTH XOAUTH2 " + new
			 * String(BASE64EncoderStream.encode(String
			 * .format("user=%s\1auth=Bearer %s\1\1", "no-reply@billdog.com",
			 * smtpUserAccessToken).getBytes())), 235);
			 * 
			 * 
			 * transport.sendMessage(messageText, messageText.getAllRecipients());
			 */

			MimeMessage mimeMessage = new MimeMessage(Session.getDefaultInstance(new Properties(), null));
			mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse("charanrajj@wavelabs.ai"));
			mimeMessage.setSubject("Oauth2 Email");
			mimeMessage.setContent("Hi Charan!!", "text/html");
			gmailOauthService.sendMimeMessage(mimeMessage, 1);

			LOGGER.info("Sent message successfully....");
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("exception occured while sending mail:: {}", e.getMessage());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MAIL_SENT);
		LOGGER.info("sendOauthMail method ended..!");
		return response;
	}
}
