package com.billdog.email.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.billdog.email.entity.EmailTransactions;

@Repository
public interface EmailTransactionsRepository extends JpaRepository<EmailTransactions, Long> {

}