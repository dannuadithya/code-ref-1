package com.billdog.email.view;

public class TemplateInfo {

	private String subject;
	private String messageHeader;
	private String messageBody;
	private String messageFooter;

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMessageHeader() {
		return messageHeader;
	}

	public void setMessageHeader(String messageHeader) {
		this.messageHeader = messageHeader;
	}

	public String getMessageBody() {
		return messageBody;
	}

	public void setMessageBody(String messageBody) {
		this.messageBody = messageBody;
	}

	public String getMessageFooter() {
		return messageFooter;
	}

	public void setMessageFooter(String messageFooter) {
		this.messageFooter = messageFooter;
	}

}
