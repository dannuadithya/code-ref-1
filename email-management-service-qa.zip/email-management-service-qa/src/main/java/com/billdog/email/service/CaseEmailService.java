package com.billdog.email.service;

import java.util.Optional;

import javax.mail.Session;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.billdog.email.common.Constants;
import com.billdog.email.common.DateAndTimeUtil;
import com.billdog.email.common.ExceptionalMessages;
import com.billdog.email.entity.EmailMaster;
import com.billdog.email.entity.EmailTransactions;
import com.billdog.email.exception.RecordNotFoundException;
import com.billdog.email.repository.EmailMasterRepository;
import com.billdog.email.repository.EmailTransactionsRepository;
import com.billdog.email.request.MemberCaseMail;
import com.billdog.email.view.ViewResponse;

@Service
public class CaseEmailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(CaseEmailService.class);

	@Autowired
	EmailTransactionsRepository emailTransactionsRepository;

	@Autowired
	EmailMasterRepository emailMasterRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	EmailService emailService;

	@Autowired
	private Session session;

	public ViewResponse sendCaseEmail(MemberCaseMail memberCaseMail) {
		LOGGER.info("sendCaseEmail method started..!");

		Optional<EmailMaster> emailMasterOptional = emailMasterRepository.findByEmailTitleAndOrganizationId(
				memberCaseMail.getEmailTitle().toString(), memberCaseMail.getOrganizationId());
		LOGGER.info("Fetched email template for mail type:: {}", memberCaseMail.getEmailTitle());
		if (!emailMasterOptional.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.EMAIL_TITLE_NOT_FOUND + memberCaseMail.getEmailTitle().toString());
		}
		try {
			String mailText = getMailText(emailMasterOptional.get().getBody(), memberCaseMail);
			emailService.sendTemplateCase(emailMasterOptional.get(), mailText,
					memberCaseMail.getOrganizationName() + "< no-reply@domain.com >", memberCaseMail.getMemberEmail(),
					memberCaseMail.getCaseId(), memberCaseMail.getOrganizationId());
			LOGGER.info("Sending email from Organization:: " + memberCaseMail.getOrganizationName());

			updateEmailTransactions(memberCaseMail, emailMasterOptional.get());
		} catch (Exception exception) {
			LOGGER.warn("Exception occured while sending email, Cause:: ", exception.getCause());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MAIL_SENT);
		LOGGER.info("Email sent to member mail type:: {}", memberCaseMail.getEmailTitle());
		LOGGER.info("sendCaseEmail method ended..!");
		return response;
	}

	/*
	 * This method is used to save email details that has sent to member
	 */
	@Transactional
	private void updateEmailTransactions(MemberCaseMail memberCaseMail, EmailMaster emailMaster) {
		LOGGER.info("Creating email trasaction for user email:: {}", memberCaseMail.getMemberEmail());
		EmailTransactions emailTransactions = new EmailTransactions();
		emailTransactions.setCreatedAt(DateAndTimeUtil.now());
		emailTransactions.setUpdatedAt(DateAndTimeUtil.now());
		emailTransactions.setFromEmail(memberCaseMail.getFromEmail());
		emailTransactions.setMemberEmail(memberCaseMail.getMemberEmail());
		emailTransactions.setOrganizationId(memberCaseMail.getOrganizationId());
		emailTransactions.setEmailMasterId(emailMaster);
		emailTransactions.setMemberId(memberCaseMail.getMemberId());
		emailTransactionsRepository.save(emailTransactions);
	}

	private String getMailText(String emailTemplate, MemberCaseMail memberCaseMail) {
		String message = emailTemplate;
		if (memberCaseMail.getMemberFirstName() == null || memberCaseMail.getMemberFirstName().isEmpty()) {
			message = message.replace("{{FIRSTNAME}}", "");
		} else {
			message = message.replace("{{FIRSTNAME}}", memberCaseMail.getMemberFirstName());
		}
		if (memberCaseMail.getCaseId() == null || memberCaseMail.getCaseId().isEmpty()) {
			message = message.replace("{{CASE_ID}}", "");
		} else {
			message = message.replace("{{CASE_ID}}", memberCaseMail.getCaseId());
		}
		message = message.replace("{{ORGANIZATION_NAME}}", memberCaseMail.getOrganizationName());
		message = message.replace("{{CONTACT_NUMBER}}", memberCaseMail.getOrganizationContact());
		return message;
	}

}
