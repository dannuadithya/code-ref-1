package com.billdog.email.service;

import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.billdog.email.common.Constants;
import com.billdog.email.common.DateAndTimeUtil;
import com.billdog.email.common.ExceptionalMessages;
import com.billdog.email.entity.EmailMaster;
import com.billdog.email.entity.EmailTransactions;
import com.billdog.email.exception.RecordNotFoundException;
import com.billdog.email.repository.EmailMasterRepository;
import com.billdog.email.repository.EmailTransactionsRepository;
import com.billdog.email.request.WelcomeEmailRequest;
import com.billdog.email.view.ViewResponse;

@Service
public class WelcomeEmailMember {

	private static final Logger LOGGER = LoggerFactory.getLogger(WelcomeEmailMember.class);

	@Autowired
	EmailMasterRepository emailMasterRepository;

	@Autowired
	EmailTransactionsRepository emailTransactionsRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	UpdateEmailService updateEmailService;

	/*
	 * This method is used to send an email to user or update password.
	 */
	@Transactional
	public ViewResponse sendWelcomeEmailMember(WelcomeEmailRequest welcomeEmailRequest) {

		return sendEmail(welcomeEmailRequest);
	}

	private ViewResponse sendEmail(WelcomeEmailRequest welcomeEmailRequest) {
		LOGGER.info("sendEmail method started..!");
		SimpleMailMessage message = new SimpleMailMessage();
		// Fetching email template
		Optional<EmailMaster> emailMasterOptional = emailMasterRepository
				.findByEmailTitleAndOrganizationId(welcomeEmailRequest.getEmailTitle().toString(),
						welcomeEmailRequest.getOrgId());

		if (!emailMasterOptional.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.EMAIL_TITLE_NOT_FOUND + welcomeEmailRequest.getEmailTitle().toString());
		}
		try {
			String mailText = getMailText(emailMasterOptional.get().getBody(), welcomeEmailRequest.getEmail(),
					welcomeEmailRequest.getFirstName());
			updateEmailService.sendTemplate(emailMasterOptional.get(), mailText, welcomeEmailRequest.getEmail(),
					welcomeEmailRequest.getOrgId());
			LOGGER.info("Sending email from Organization:: " + welcomeEmailRequest.getEmail());
			updateEmailTransactions(welcomeEmailRequest.getEmail(), emailMasterOptional.get());
		} catch (Exception exception) {
			LOGGER.warn("Exception occured while sending email, Cause:: ", exception.getCause());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}

		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MAIL_SENT);
		return response;
	}

	/*
	 * This method is used to save email details that has sent to user
	 */
	@Transactional
	private void updateEmailTransactions(String memberEmail, EmailMaster emailMaster) {
		EmailTransactions emailTransactions = new EmailTransactions();
		emailTransactions.setCreatedAt(DateAndTimeUtil.now());
		emailTransactions.setUpdatedAt(DateAndTimeUtil.now());
		emailTransactions.setMemberEmail(memberEmail);
		emailTransactions.setEmailMasterId(emailMaster);
		emailTransactions.setOrganizationId(emailMaster.getOrganizationId());
		emailTransactionsRepository.save(emailTransactions);
	}

	private String getMailText(String emailTemplate, String username, String firstName) {
		String message = emailTemplate.toString();
		message = message.replace("{{USERNAME}}", username);
		if (firstName == null || firstName.isEmpty()) {
			message = message.replace("{{FIRSTNAME}}", "");
		} else {
			message = message.replace("{{FIRSTNAME}}", firstName);
		}
		return message;
	}

}
