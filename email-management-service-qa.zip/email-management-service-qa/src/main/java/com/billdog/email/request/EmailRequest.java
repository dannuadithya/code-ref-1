package com.billdog.email.request;

public class EmailRequest {

}
