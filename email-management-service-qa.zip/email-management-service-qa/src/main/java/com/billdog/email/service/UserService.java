package com.billdog.email.service;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.billdog.email.exception.BadRequestException;
import com.billdog.email.exception.InternalServerException;
import com.billdog.email.exception.RecordNotFoundException;
import com.billdog.email.exception.ServiceUnavailableException;
import com.billdog.email.repository.UserRepository;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

@Component
public class UserService {

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(UserService.class);

	@Value("${userservice.baseurl}")
	private String userBaseUrl;

	private UserRepository getUserRepository(String token) {
		OkHttpClient.Builder userHttpClient;
		if (StringUtils.isNotBlank(token)) {
			userHttpClient = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
				@Override
				public Response intercept(Chain chain) throws IOException {
					Request request = chain.request().newBuilder().addHeader("authorization", token).build();
					return chain.proceed(request);
				}
			});
		} else {
			userHttpClient = new OkHttpClient.Builder();
		}
		Retrofit retrofit = new Retrofit.Builder().baseUrl(userBaseUrl)
				.addConverterFactory(GsonConverterFactory.create())
				.client(userHttpClient.connectTimeout(10, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build())
				.build();
		return retrofit.create(UserRepository.class);
	}

	public void getOrganizationInfo(String token, Long orgId) {
		LOGGER.info("verifyUserToken method started..!");
		UserRepository userRepository = getUserRepository(null);
		Call<String> callSync = userRepository.getOrganizationInfo(orgId);

		try {
			retrofit2.Response<String> response = callSync.execute();
			LOGGER.info("Getting response from rest call");
			if (response.code() == 200 && response.isSuccessful()) {
				LOGGER.info("Returning success response from user service");

			} else {
				if (response.code() == 404) {
					throw new RecordNotFoundException("");
				} else if (response.code() == 400) {
					throw new BadRequestException("");
				}
				if (response.code() == 503) {
					throw new ServiceUnavailableException("");
				} else if (response.code() == 500) {
					throw new InternalServerException("");
				} else {
					throw new BadRequestException("");
				}

			}

		} catch (Exception exception) {
			throw new RecordNotFoundException("");
		}
	}

}
