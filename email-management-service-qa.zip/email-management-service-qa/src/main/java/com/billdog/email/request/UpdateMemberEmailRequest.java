package com.billdog.email.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.billdog.email.common.EmailTitles;

public class UpdateMemberEmailRequest {

	@NotBlank(message = "Please enter oldEmail")
	@Email(message = "Invalid oldEmail format")
	private String oldEmail;

	@NotBlank(message = "Please enter newEmail")
	@Email(message = "Invalid newEmail format")
	private String newEmail;

	@NotNull(message = "Email title name must not be null")
	private EmailTitles emailTitle;

	private String firstName;

	private long orgId;

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getOldEmail() {
		return oldEmail;
	}

	public void setOldEmail(String oldEmail) {
		this.oldEmail = oldEmail;
	}

	public String getNewEmail() {
		return newEmail;
	}

	public void setNewEmail(String newEmail) {
		this.newEmail = newEmail;
	}

	public EmailTitles getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(EmailTitles emailTitle) {
		this.emailTitle = emailTitle;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

}
