package com.billdog.email.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity(name = "EMAIL_MASTER")
@Table(name = "EMAIL_MASTER")
public class EmailMaster extends BaseEntity {


	@Column(name = "EMAIL_TITLE")
	private String emailTitle;

	@Column(name = "SUBJECT")
	private String subject;

	@Column(name = "ORGANIZATION_ID")
	private Long organizationId;

	@Column(name = "HEADER", columnDefinition = "NVARCHAR(5000)")
	private String header;

	@Column(name = "BODY", columnDefinition = "NVARCHAR(5000)")
	private String body;

	@Column(name = "FOOTER", columnDefinition = "NVARCHAR(5000)")
	private String footer;


	public String getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(String emailTitle) {
		this.emailTitle = emailTitle;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public String getHeader() {
		return header;
	}

	public void setHeader(String header) {
		this.header = header;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getFooter() {
		return footer;
	}

	public void setFooter(String footer) {
		this.footer = footer;
	}

}
