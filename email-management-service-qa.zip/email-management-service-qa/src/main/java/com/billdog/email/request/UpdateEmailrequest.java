package com.billdog.email.request;

import javax.validation.constraints.NotNull;

import com.billdog.email.common.EmailTitles;

public class UpdateEmailrequest {

	private String userName;
	private String firstName;
	private String lastName;
	@NotNull(message = "Email title name must not be null")
	private EmailTitles emailTitle;

	private long orgId;

	public EmailTitles getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(EmailTitles emailTitle) {
		this.emailTitle = emailTitle;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getOrgId() {
		return orgId;
	}

	public void setOrgId(long orgId) {
		this.orgId = orgId;
	}

}
