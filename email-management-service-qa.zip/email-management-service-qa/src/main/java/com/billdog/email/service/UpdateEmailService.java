package com.billdog.email.service;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.Optional;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.view.mustache.MustacheViewResolver;
import org.springframework.web.servlet.view.mustache.java.MustacheJTemplateFactory;

import com.billdog.email.common.Constants;
import com.billdog.email.common.DateAndTimeUtil;
import com.billdog.email.common.ExceptionalMessages;
import com.billdog.email.entity.EmailMaster;
import com.billdog.email.entity.EmailTransactions;
import com.billdog.email.exception.RecordNotFoundException;
import com.billdog.email.repository.EmailMasterRepository;
import com.billdog.email.repository.EmailTransactionsRepository;
import com.billdog.email.request.UpdateEmailrequest;
import com.billdog.email.request.UpdateMemberEmailRequest;
import com.billdog.email.view.TemplateInfo;
import com.billdog.email.view.ViewResponse;
import com.github.mustachejava.DefaultMustacheFactory;
import com.github.mustachejava.Mustache;
import com.github.mustachejava.MustacheFactory;

@Service
public class UpdateEmailService {

	private static final Logger LOGGER = LoggerFactory.getLogger(UpdateEmailService.class);

	@Autowired
	EmailMasterRepository emailMasterRepository;

	@Autowired
	EmailTransactionsRepository emailTransactionsRepository;

	@Autowired
	private JavaMailSender mailSender;

	@Autowired
	EmailService emailService;

	@Autowired
	private Session session;

	@Autowired
	ResourceLoader resourceLoader;

	@Autowired
	GMailOauthService gmailOauthService;

	/*
	 * This method is used to send an email to user or update password.
	 */
	@Transactional
	public ViewResponse sendUpdatedEmailMember(UpdateMemberEmailRequest updateMemberEmailRequest) {

		return sendEmail(updateMemberEmailRequest);
	}

	private ViewResponse sendEmail(UpdateMemberEmailRequest updateMemberEmailRequest) {
		LOGGER.info("sendEmail method started..!");
		// SimpleMailMessage message = new SimpleMailMessage();
		// Fetching email template
		Optional<EmailMaster> emailMasterOptional = emailMasterRepository
				.findByEmailTitleAndOrganizationId(updateMemberEmailRequest.getEmailTitle().toString(),
						updateMemberEmailRequest.getOrgId());

		if (!emailMasterOptional.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.EMAIL_TITLE_NOT_FOUND + updateMemberEmailRequest.getEmailTitle().toString());
		}

		try {
			String mailText = getMailText(emailMasterOptional.get().getBody(), updateMemberEmailRequest.getOldEmail(),
					updateMemberEmailRequest.getNewEmail(), updateMemberEmailRequest.getFirstName());
			sendTemplate(emailMasterOptional.get(), mailText, updateMemberEmailRequest.getOldEmail(),
					updateMemberEmailRequest.getOrgId());
			LOGGER.info("Sending email from Organization:: " + updateMemberEmailRequest.getOldEmail());

			updateEmailTransactionsOldEmail(updateMemberEmailRequest, emailMasterOptional.get());
		} catch (Exception exception) {
			LOGGER.warn("Exception occured while sending email, Cause:: ", exception.getCause());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MAIL_SENT);
		return response;
	}

	@Transactional
	private void updateEmailTransactionsOldEmail(UpdateMemberEmailRequest updateMemberEmailRequest,
			EmailMaster emailMaster) {
		EmailTransactions emailTransactions = new EmailTransactions();
		emailTransactions.setCreatedAt(DateAndTimeUtil.now());
		emailTransactions.setUpdatedAt(DateAndTimeUtil.now());
		emailTransactions.setMemberEmail(updateMemberEmailRequest.getOldEmail());
		emailTransactions.setEmailMasterId(emailMaster);
		emailTransactions.setOrganizationId(emailMaster.getOrganizationId());
		emailTransactionsRepository.save(emailTransactions);
	}

	/*
	 * This method is used to save email details that has sent to user
	 */
	@Transactional
	private void updateEmailTransactions(String memberEmail, EmailMaster emailMaster) {
		EmailTransactions emailTransactions = new EmailTransactions();
		emailTransactions.setCreatedAt(DateAndTimeUtil.now());
		emailTransactions.setUpdatedAt(DateAndTimeUtil.now());
		emailTransactions.setMemberEmail(memberEmail);
		emailTransactions.setEmailMasterId(emailMaster);
		emailTransactions.setOrganizationId(emailMaster.getOrganizationId());
		emailTransactionsRepository.save(emailTransactions);
	}

	@Transactional
	private void updateEmailTransactionsNewEmail(UpdateEmailrequest passcodeEmailRequest, EmailMaster emailMaster) {
		EmailTransactions emailTransactions = new EmailTransactions();
		emailTransactions.setCreatedAt(DateAndTimeUtil.now());
		emailTransactions.setUpdatedAt(DateAndTimeUtil.now());
		emailTransactions.setMemberEmail(passcodeEmailRequest.getUserName());
		emailTransactions.setEmailMasterId(emailMaster);
		emailTransactions.setOrganizationId(emailMaster.getOrganizationId());
		emailTransactionsRepository.save(emailTransactions);
	}

	private String getMailText(String emailTemplate, String oldusername, String newusername, String firstName) {
		String message = emailTemplate.toString();
		message = message.replace("{{OLDUSERNAME}}", oldusername);
		message = message.replace("{{NEWUSERNAME}}", newusername);
		if (firstName == null || firstName.isEmpty()) {
			message = message.replace("{{FIRSTNAME}}", "");
		} else {
			message = message.replace("{{FIRSTNAME}}", firstName);
		}
		return message;
	}

	@Transactional
	public ViewResponse sendUpdatedEmail(UpdateEmailrequest updateEmailrequest) {

		return sendEmail(updateEmailrequest);
	}

	private ViewResponse sendEmail(UpdateEmailrequest passcodeEmailRequest) {
		LOGGER.info("sendEmail method started..!");

		// Fetching email template
		Optional<EmailMaster> emailMasterOptional = emailMasterRepository
				.findByEmailTitleAndOrganizationId(passcodeEmailRequest.getEmailTitle().toString(),
						passcodeEmailRequest.getOrgId());
		LOGGER.info("Fetched email template for mail type:: {}", passcodeEmailRequest.getEmailTitle());
		if (!emailMasterOptional.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.EMAIL_TITLE_NOT_FOUND + passcodeEmailRequest.getEmailTitle().toString());
		}

		try {
			String mailText = getMailText(emailMasterOptional.get().getBody(), passcodeEmailRequest.getFirstName(),
					passcodeEmailRequest.getLastName(), passcodeEmailRequest.getFirstName());
			sendTemplate(emailMasterOptional.get(), mailText, passcodeEmailRequest.getUserName(),
					passcodeEmailRequest.getOrgId());
			LOGGER.info("Sending email from Organization:: " + passcodeEmailRequest.getUserName());

			updateEmailTransactionsNewEmail(passcodeEmailRequest, emailMasterOptional.get());
		} catch (Exception exception) {
			LOGGER.warn("Exception occured while sending email, Cause:: ", exception.getCause());
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MAIL_SENT);
		LOGGER.info("Email sent to user mail type:: " + passcodeEmailRequest.getEmailTitle());
		LOGGER.info("sendEmail method ended..!");
		return response;
	}

	public void sendTemplate(EmailMaster email, String message, String toMail, long orgId) {
		LOGGER.warn("sendTemplate method started");
		MustacheFactory mustacheFactory = new DefaultMustacheFactory();
		try {
			Resource file = resourceLoader.getResource("classpath:email_templates/body.mustache");
			InputStream inputStream = file.getInputStream();
			BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
			Mustache mustache = mustacheFactory.compile(bufferedReader, "body.mustache");
			TemplateInfo templateInfo = getTemplateInfo(email, message);
			StringWriter writer = new StringWriter();
			mustache.execute(writer, templateInfo).flush();
			/*
			 * Message messageText = new MimeMessage(session);
			 * messageText.setRecipients(Message.RecipientType.TO,
			 * InternetAddress.parse(toMail));
			 * messageText.setSubject(templateInfo.getSubject());
			 * messageText.setContent(writer.toString(), "text/html");
			 * Transport.send(messageText);
			 */

			MimeMessage mimeMessage = new MimeMessage(Session.getDefaultInstance(new Properties(), null));
			mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(toMail));
			mimeMessage.setSubject(templateInfo.getSubject());
			mimeMessage.setContent(writer.toString(), "text/html");
			gmailOauthService.sendMimeMessage(mimeMessage, orgId);

			LOGGER.info("Sent message successfully....");
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info("exception in dev");
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
	}

	private TemplateInfo getTemplateInfo(EmailMaster email, String message) {
		LOGGER.warn("getTemplateInfo started");
		TemplateInfo templateInfo = new TemplateInfo();
		templateInfo.setMessageBody(message);
		templateInfo.setMessageFooter(email.getFooter());
		templateInfo.setMessageHeader(email.getHeader());
		templateInfo.setSubject(email.getSubject());
		LOGGER.warn("getTemplateInfo ended");
		return templateInfo;
	}

	private ViewResponse sendEmailMember(UpdateEmailrequest updateEmailrequest) {
		LOGGER.info("sendEmail method started..!");
		SimpleMailMessage message = new SimpleMailMessage();
		// Fetching email template
		Optional<EmailMaster> emailMasterOptional = emailMasterRepository
				.findByEmailTitleAndOrganizationId(updateEmailrequest.getEmailTitle().toString(),
						updateEmailrequest.getOrgId());

		if (!emailMasterOptional.isPresent()) {
			throw new RecordNotFoundException(
					ExceptionalMessages.EMAIL_TITLE_NOT_FOUND + updateEmailrequest.getEmailTitle().toString());
		}
		try {
			EmailMaster emailMaster = emailMasterOptional.get();
			message.setTo(updateEmailrequest.getUserName());
			message.setSubject(emailMaster.getSubject());
			String mailText = "";
			message.setText(mailText);
			mailSender.send(message);
			updateEmailTransactions(updateEmailrequest.getUserName(), emailMaster);
		} catch (Exception exception) {
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_UPDATED_EMAIL);
		}
		ViewResponse response = new ViewResponse();
		response.setStatusText(Constants.SUCCESS);
		response.setMessage(Constants.MAIL_SENT);
		return response;
	}

	private String getMailData(String emailTemplate, String firstName, String lastName, String username) {
		String message = emailTemplate.toString();
		if (firstName == null || firstName.isEmpty()) {
			message = message.replace("{{FIRSTNAME}}", "");
		} else {
			message = message.replace("{{FIRSTNAME}}", firstName);
		}
		message = message.replace("{{LASTNAME}}", lastName);
		message = message.replace("{{USERNAME}}", username);
		return message;
	}

	public MustacheViewResolver viewResolver() {
		MustacheViewResolver resolver = new MustacheViewResolver();
		resolver.setPrefix("/WEB-INF/views/mustache/");
		resolver.setSuffix("hbs");
		resolver.setCache(true);

		resolver.setTemplateFactory(new MustacheJTemplateFactory());
		return resolver;
	}

}
