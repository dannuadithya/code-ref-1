package com.billdog.email.service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.stereotype.Service;

import com.billdog.email.common.DateAndTimeUtil;
import com.billdog.email.common.ExceptionalMessages;
import com.billdog.email.entity.GmailOauthInfo;
import com.billdog.email.exception.RecordNotFoundException;
import com.billdog.email.repository.GmailOauthInfoRepository;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.googleapis.auth.oauth2.GoogleRefreshTokenRequest;
import com.google.api.client.googleapis.auth.oauth2.GoogleTokenResponse;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.api.client.util.Base64;
import com.google.api.client.util.Value;
import com.google.api.services.gmail.Gmail;
import com.google.api.services.gmail.GmailScopes;
import com.google.api.services.gmail.model.Message;
import com.google.api.services.storage.StorageScopes;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.auth.oauth2.ServiceAccountCredentials;

@Service
public class GMailOauthService {

	@Autowired
	ResourceLoader resourceLoader;

	@Value("${gmail.port}")
	private Integer port;

	@Autowired
	GmailOauthInfoRepository gmailOauthInfoRepository;

	private static final org.slf4j.Logger LOGGER = LoggerFactory.getLogger(GMailOauthService.class);

	// private static final String APPLICATION_NAME = "Wavelabs Test";
	// private static final JsonFactory JSON_FACTORY =
	// JacksonFactory.getDefaultInstance();
	// private static final String USER_ID = "me";
	private static final String SEND_URL = "https://www.googleapis.com/gmail/v1/users/me/messages/send";
	private static final String CLIENT_ID = "491802422331-igfgr1jaqrbil3opu7n5f6196p1qinsu.apps.googleusercontent.com";
	private static final String CLIENT_SECRET = "wEl9h5-0a17xeydkKstcaizA";
	private static final String GMAIL = "no-reply@billdog.com";
	private static final List<String> SCOPES = Collections.singletonList(GmailScopes.GMAIL_SEND);

	/*
	 * private static final String CREDENTIALS_FILE_PATH =
	 * System.getProperty("user.dir") + File.separator + "src" + File.separator +
	 * "main" + File.separator + "resources" + File.separator + "credentials.json";
	 */
	/*
	 * private static final String TOKENS_DIRECTORY_PATH =
	 * System.getProperty("user.dir") + File.separator + "src" + File.separator +
	 * "main" + File.separator + "resources" + File.separator + "credentials";
	 * 
	 *//**
		 * Creates an authorized Credential object.
		 * 
		 * @param httpTransport The network HTTP Transport.
		 * @return An authorized Credential object.
		 * @throws IOException If the credentials.json file cannot be found.
		 *//*
			 * private Credential getCredentials(NetHttpTransport httpTransport, long orgId)
			 * throws IOException { try { Resource file =
			 * resourceLoader.getResource("classpath:credentials.json"); InputStream
			 * inputStream = file.getInputStream(); GoogleClientSecrets clientSecrets =
			 * GoogleClientSecrets.load(JSON_FACTORY, new InputStreamReader(inputStream));
			 * // Build flow and trigger user authorization request.
			 * GoogleAuthorizationCodeFlow flow = new
			 * GoogleAuthorizationCodeFlow.Builder(httpTransport, JSON_FACTORY,
			 * clientSecrets, SCOPES) .setDataStoreFactory(new FileDataStoreFactory(new
			 * java.io.File(TOKENS_DIRECTORY_PATH))) .setAccessType("offline").build(); //
			 * AuthorizationCodeFlow flow2 = gmailSample.initializeFlow(); Credential
			 * credential = new AuthorizationCodeInstalledApp(flow, new
			 * LocalServerReceiver()) .authorize("user");
			 * saveData(credential.getAccessToken(), credential.getRefreshToken(), orgId,
			 * credential.getExpiresInSeconds());
			 * 
			 * return credential; } catch (
			 * 
			 * Exception exception) { exception.printStackTrace();
			 * LOGGER.info("Exception occured:: {}", exception.getMessage()); throw new
			 * RecordNotFoundException(exception.getMessage()); }
			 * 
			 * }
			 */

	private GoogleCredentials serviceAccount(long orgId) {
		try {
			Resource file = resourceLoader.getResource("classpath:serviceCredentials.json");
			InputStream inputStream = file.getInputStream();
			GoogleCredentials credentials = ServiceAccountCredentials.fromStream(inputStream)
					.createScoped(Collections.singletonList(StorageScopes.DEVSTORAGE_FULL_CONTROL))
					.createDelegated(GMAIL).createScoped(SCOPES);
			credentials.refresh();
			/*
			 * AccessToken refreshToken = credentials.refreshAccessToken();
			 * OAuth2Credentials credentialsAccess = OAuth2Credentials.create(refreshToken);
			 * LOGGER.info("refresh token {}",
			 * credentials.refreshAccessToken().getTokenValue());
			 * LOGGER.info("refresh token {}",
			 * credentialsAccess.getAccessToken().getTokenValue()); HttpRequestInitializer
			 * requestInitializer = new HttpCredentialsAdapter(credentials); Gmail service =
			 * new Gmail.Builder(new NetHttpTransport(),
			 * JacksonFactory.getDefaultInstance(),
			 * requestInitializer).setApplicationName(APPLICATION_NAME).build();
			 * NetHttpTransport HTTP_TRANSPORT =
			 * GoogleNetHttpTransport.newTrustedTransport(); Gmail service2 = new
			 * Gmail.Builder(HTTP_TRANSPORT, JSON_FACTORY, new
			 * HttpCredentialsAdapter(credentials))
			 * .setApplicationName(APPLICATION_NAME).build(); Users a = service.users();
			 * sendMessage(service2, "me", mimeMessage);
			 */
			return credentials;
		} catch (Exception ex) {
			LOGGER.info("Exception log {}", ex.getMessage());
		}
		return null;
	}

	/*
	 * private static Credentials getCredentials(String CREDENTIALS_FILE_PATH)
	 * throws IOException { InputStream in =
	 * FileLoaderImpl.getStream(CREDENTIALS_FILE_PATH); if (in == null) { throw new
	 * FileNotFoundException("Resource not found: " + CREDENTIALS_FILE_PATH); }
	 * GoogleCredentials credentials = GoogleCredentials .fromStream(in)
	 * .createDelegated(EMAIL_FROM) .createScoped(List.of(GmailScopes.GMAIL_SEND,
	 * GmailScopes.GMAIL_LABELS)); return credentials; }
	 * 
	 * private Gmail getGmailService() throws IOException, GeneralSecurityException
	 * { NetHttpTransport HTTP_TRANSPORT =
	 * GoogleNetHttpTransport.newTrustedTransport(); return new
	 * Gmail.Builder(HTTP_TRANSPORT, JSON_FACTORY, new
	 * HttpCredentialsAdapter(getCredentials(CREDENTIALS_FILE_PATH)))
	 * .setApplicationName(APPLICATION_NAME) .build(); }
	 * 
	 * @Override public Message sendMailWithTemplate(StarMail starMail, boolean
	 * isHtml) { try { MimeMessage mimeMessage =
	 * EmailUtils.createEmailMessage(starMail, isHtml); // MimeMessage mm =
	 * EmailUtils.createEmail(toEmail, USER_ID, subject, bodyText); Gmail service =
	 * getGmailService(); Message message = EmailUtils.sendMessage(service, USER_ID,
	 * mimeMessage); LOGGER.info("Message id: {} ", message.getId());
	 * LOGGER.info(message.toPrettyString()); return message; } catch (IOException |
	 * MessagingException | GeneralSecurityException e) {
	 * LOGGER.error("sending email failed {}", e); throw new
	 * RuntimeException("sending email failed " + e.getMessage()); } }
	 */

	/*
	 * private ServiceAccountCredentials getServiceAccountCredentials(String
	 * privateKeyJson) throws IOException { try (InputStream stream = new
	 * ByteArrayInputStream(privateKeyJson.getBytes())) { return
	 * ServiceAccountCredentials.fromStream(stream); } }
	 */
	/*
	 * private void saveData(String token, String reToken, long orgId, long timeout)
	 * { LocalDateTime expiredAt = LocalDateTime.now().plusSeconds(timeout);
	 * GmailOauthInfo gmailOauthInfo =
	 * gmailOauthInfoRepository.findByOrganizationId(orgId); if (gmailOauthInfo !=
	 * null) { gmailOauthInfo.setAccessToken(token);
	 * gmailOauthInfo.setExpiresInSeconds(timeout);
	 * gmailOauthInfo.setOrganizationId(orgId);
	 * gmailOauthInfo.setRefreshToken(reToken);
	 * gmailOauthInfo.setUpdatedAt(DateAndTimeUtil.now());
	 * gmailOauthInfo.setExpiredAt(expiredAt);
	 * gmailOauthInfoRepository.save(gmailOauthInfo); } else { GmailOauthInfo
	 * oauthInfo = new GmailOauthInfo(); oauthInfo.setAccessToken(token);
	 * oauthInfo.setCreatedAt(DateAndTimeUtil.now());
	 * oauthInfo.setExpiresInSeconds(timeout); oauthInfo.setOrganizationId(orgId);
	 * oauthInfo.setRefreshToken(reToken);
	 * oauthInfo.setUpdatedAt(DateAndTimeUtil.now());
	 * oauthInfo.setExpiredAt(expiredAt); gmailOauthInfoRepository.save(oauthInfo);
	 * } }
	 */

	/*
	 * public void doGet(HttpServletRequest request, HttpServletResponse response)
	 * throws IOException { String url = new
	 * GoogleBrowserClientRequestUrl("812741506391.apps.googleusercontent.com",
	 * "https://oauth2.example.com/oauthcallback",
	 * Arrays.asList("https://www.googleapis.com/auth/userinfo.email",
	 * "https://www.googleapis.com/auth/userinfo.profile")).setState("/profile").
	 * build(); response.sendRedirect(url); }
	 * 
	 * static String getRedirectUri(HttpServletRequest req) { GenericUrl url = new
	 * GenericUrl(""); url.setRawPath("/oauth2callback"); return url.build(); }
	 */

	/*
	 * public Gmail getService() throws IOException, GeneralSecurityException { //
	 * Build a new authorized API client service. final NetHttpTransport
	 * httpTransport = GoogleNetHttpTransport.newTrustedTransport();
	 * 
	 * PrivateKey key = (PrivateKey) keystore.getKey("privatekey",
	 * "somepass".toCharArray()); ServiceAccountCredentials
	 * serviceAccountCredentials = ServiceAccountCredentials.newBuilder()
	 * .setClientEmail("somestuff@developer.gserviceaccount.com")
	 * .setServiceAccountUser("somestuff@developer.gserviceaccount.com").setClientId
	 * ("somenumber") .setScopes(SCOPES).setPrivateKey(key).build(); Gmail service =
	 * new Gmail.Builder(httpTransport, JSON_FACTORY, httpTransport)
	 * .setApplicationName(APPLICATION_NAME).build(); HttpRequestInitializer
	 * requestInitializer = new HttpCredentialsAdapter(serviceAccountCredentials);
	 * 
	 * Gmail service = new Gmail.Builder(new NetHttpTransport(),
	 * JacksonFactory.getDefaultInstance(),
	 * requestInitializer).setApplicationName(APPLICATION_NAME).build();
	 * Gmail.Users.Labels.List list = service.users().labels().list("b@someemail")
	 * .setAccessToken(credential.getAccessToken().getTokenValue());
	 * 
	 * return null; }
	 */
	/*
	 * public static List<Message> listMessagesMatchingQuery(Gmail service, String
	 * userId, String query) throws IOException { ListMessagesResponse response =
	 * service.users().messages().list(userId).setQ(query).execute(); List<Message>
	 * messages = new ArrayList<>(); while (response.getMessages() != null) {
	 * messages.addAll(response.getMessages()); if (response.getNextPageToken() !=
	 * null) { String pageToken = response.getNextPageToken(); response =
	 * service.users().messages().list(userId).setQ(query).setPageToken(pageToken).
	 * execute(); } else { break; } } return messages; }
	 * 
	 * public static Message getMessage(Gmail service, String userId, List<Message>
	 * messages, int index) throws IOException { return
	 * service.users().messages().get(userId,
	 * messages.get(index).getId()).execute(); }
	 */
	/*
	 * public Map<String, String> getGmailData(String query) { try { Gmail service =
	 * getService(); List<Message> messages = listMessagesMatchingQuery(service,
	 * USER_ID, query); Message message = getMessage(service, USER_ID, messages, 0);
	 * 
	 * message.getLabelIds().forEach(a -> {
	 * 
	 * }); JsonPath jp = new JsonPath(message.toString());
	 * Optional<MessagePartHeader> subjectOptional =
	 * message.getPayload().getHeaders().stream() .filter(a ->
	 * a.getName().equalsIgnoreCase("Subject")).findFirst(); String subject =
	 * subjectOptional.isPresent() ? subjectOptional.get().getName() : ""; String
	 * body = message.getPayload().getBody().getData(); String link = null;
	 * HashMap<String, String> hm = new HashMap<>(); return hm; } catch (Exception
	 * e) { LOGGER.info("email not found...."); throw new
	 * RecordNotFoundException(e.getMessage()); } }
	 */
	/*
	 * public int getTotalCountOfMails() { int size; try { final NetHttpTransport
	 * httpTransport = GoogleNetHttpTransport.newTrustedTransport(); Gmail service =
	 * new Gmail.Builder(httpTransport, JSON_FACTORY, getCredentials(httpTransport,
	 * 0)) .setApplicationName(APPLICATION_NAME).build();
	 * List<com.google.api.services.gmail.model.Thread> threads =
	 * service.users().threads().list("me").execute() .getThreads(); size =
	 * threads.size(); } catch (Exception e) { LOGGER.info("Exception log {}",
	 * e.getMessage()); size = -1; } return size; }
	 */
	/*
	 * public boolean isMailExist(String messageTitle) { try { final
	 * NetHttpTransport httpTransport =
	 * GoogleNetHttpTransport.newTrustedTransport(); Gmail service = new
	 * Gmail.Builder(httpTransport, JSON_FACTORY, getCredentials(httpTransport, 0))
	 * .setApplicationName(APPLICATION_NAME).build(); ListMessagesResponse response
	 * = service.users().messages().list("me").setQ("subject:" + messageTitle)
	 * .execute(); List<Message> messages = getMessages(response); return
	 * !messages.isEmpty(); } catch (Exception e) { LOGGER.info("Exception log {}",
	 * e.getMessage()); return false; } }
	 */
	/*
	 * private List<Message> getMessages(ListMessagesResponse response) {
	 * List<Message> messages = new ArrayList<>(); try { final NetHttpTransport
	 * httpTransport = GoogleNetHttpTransport.newTrustedTransport(); Gmail service =
	 * new Gmail.Builder(httpTransport, JSON_FACTORY, getCredentials(httpTransport,
	 * 0)) .setApplicationName(APPLICATION_NAME).build(); while
	 * (response.getMessages() != null) { messages.addAll(response.getMessages());
	 * if (response.getNextPageToken() != null) { String pageToken =
	 * response.getNextPageToken(); response =
	 * service.users().messages().list(USER_ID).setPageToken(pageToken).execute(); }
	 * else { break; } } return messages; } catch (Exception e) {
	 * LOGGER.info("Exception log {}", e.getMessage()); return messages; } }
	 */

	/*
	 * public static void main(String[] args) throws IOException,
	 * GeneralSecurityException { Map<String, String> hm =
	 * getGmailData("subject:password"); LOGGER.info(hm.get("subject"));
	 * LOGGER.info("================="); LOGGER.info(hm.get("body"));
	 * LOGGER.info("================="); LOGGER.info(hm.get("link"));
	 * 
	 * LOGGER.info("================="); LOGGER.info("Total count of emails is :" +
	 * getTotalCountOfMails());
	 * 
	 * LOGGER.info("================="); boolean exist = isMailExist("new link");
	 * LOGGER.info("title exist or not: " + exist); GMailOauthService mail = new
	 * GMailOauthService(); try { mail.sendMessage("me", "charanrajj@wavelabs.ai",
	 * "Test email", "Hi Charan 2"); } catch (Exception e) { e.printStackTrace(); }
	 * 
	 * }
	 */
	/*
	 * public boolean sendMessage(String user, String recipientAddress, String
	 * subject, String body) throws MessagingException, IOException,
	 * GeneralSecurityException { Message message = createMessageWithEmail(
	 * createEmail(recipientAddress, "charanrajj@wavelabs.ai", subject, body));
	 * final NetHttpTransport httpTransport =
	 * GoogleNetHttpTransport.newTrustedTransport(); return
	 * createGmail(getCredentials(httpTransport, 0)).users().messages().send(user,
	 * message).execute() .getLabelIds().contains("SENT"); }
	 */

	public boolean sendMimeMessage(MimeMessage mimeMessage, long orgId) throws GeneralSecurityException, IOException {
		/*
		 * final NetHttpTransport httpTransport =
		 * GoogleNetHttpTransport.newTrustedTransport(); getCredentials(httpTransport,
		 * orgId);
		 */

		try {
			String token = getToken(orgId);
			sendEmail(token, createEmailString(mimeMessage));
		} catch (Exception e) {
			LOGGER.info("Access token: {}", e.getMessage());
			e.printStackTrace();
			throw new RecordNotFoundException(ExceptionalMessages.UNABLE_TO_SEND_EMAIL);
		}
		return true;
	}

	public TokenResponse getAccessToken(String refreshToken) throws IOException {
		LOGGER.info("Get Access token using refresh token method started");
		GoogleTokenResponse response = new GoogleRefreshTokenRequest(new NetHttpTransport(), new JacksonFactory(),
				refreshToken, CLIENT_ID, CLIENT_SECRET).execute();
		LOGGER.info("Get Access token using refresh token method ended");
		return response;
	}
	/*
	 * private Credential getCredentialsObject(NetHttpTransport httpTransport) { try
	 * { Resource file =
	 * resourceLoader.getResource("classpath:serviceCredentials.json"); InputStream
	 * inputStream = file.getInputStream();
	 * GoogleCredentials.getApplicationDefault(); GoogleCredentials
	 * googleCredentials = GoogleCredentials.fromStream(inputStream)
	 * .createScoped(Collections.singletonList(GmailScopes.MAIL_GOOGLE_COM));
	 * HttpRequestInitializer requestInitializer = new
	 * HttpCredentialsAdapter(googleCredentials);
	 * com.google.api.services.storage.Storage myStorage = new
	 * com.google.api.services.storage.Storage.Builder( new NetHttpTransport(), new
	 * JacksonFactory(), requestInitializer)
	 * .setApplicationName(APPLICATION_NAME).build(); return null; } catch
	 * (Exception e) { LOGGER.info("Getting exception:: {}", e.getMessage()); }
	 * 
	 * return null; }
	 */

	/*
	 * private Gmail createGmail(Credential credentials) throws
	 * GeneralSecurityException, IOException { NetHttpTransport httpTransportTest =
	 * GoogleNetHttpTransport.newTrustedTransport(); return new
	 * Gmail.Builder(httpTransportTest, JSON_FACTORY,
	 * getCredentialsObject(httpTransportTest))
	 * .setApplicationName(APPLICATION_NAME).build(); }
	 */

	/*
	 * public MimeMessage createEmail(String to, String from, String subject, String
	 * bodyText) throws MessagingException { MimeMessage email = new
	 * MimeMessage(Session.getDefaultInstance(new Properties(), null));
	 * email.setFrom(new InternetAddress(from));
	 * email.addRecipient(javax.mail.Message.RecipientType.TO, new
	 * InternetAddress(to)); email.setSubject(subject); email.setText(bodyText);
	 * return email; }
	 * 
	 * private Message createMessageWithEmail(MimeMessage emailContent) throws
	 * MessagingException, IOException { ByteArrayOutputStream buffer = new
	 * ByteArrayOutputStream(); emailContent.writeTo(buffer);
	 * 
	 * return new
	 * Message().setRaw(com.google.api.client.util.Base64.encodeBase64URLSafeString(
	 * buffer.toByteArray())); }
	 */

	public static Message sendMessage(Gmail service, String userId, MimeMessage emailContent)
			throws MessagingException, IOException {
		Message message = createMessageWithEmail(emailContent);
		message = service.users().messages().send(userId, message).execute();

		System.out.println("Message id: " + message.getId());
		System.out.println(message.toPrettyString());
		return message;
	}

	public static Message createMessageWithEmail(MimeMessage emailContent) throws MessagingException, IOException {
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		emailContent.writeTo(buffer);
		byte[] bytes = buffer.toByteArray();
		String encodedEmail = Base64.encodeBase64URLSafeString(bytes);
		Message message = new Message();
		message.setRaw(encodedEmail);
		return message;
	}

	public String sendEmail(String token, String encodedEmail) throws Exception {
		LOGGER.info("Send email using access token method started");
		token = "Bearer " + token;
		URL serverUrl = new URL(SEND_URL);
		HttpURLConnection urlConnection = (HttpURLConnection) serverUrl.openConnection();
		urlConnection.setDoOutput(true);
		urlConnection.setRequestMethod("POST");
		urlConnection.setRequestProperty("Authorization", token);
		urlConnection.setRequestProperty("Content-Type", "application/json");
		String d = "{\r\n\"raw\": \"" + encodedEmail + "\"\r\n}";
		BufferedWriter httpRequestBodyWriter = new BufferedWriter(
				new OutputStreamWriter(urlConnection.getOutputStream()));
		httpRequestBodyWriter.write(d);
		httpRequestBodyWriter.close();
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(urlConnection.getInputStream(), Charset.forName("UTF-8")));
		// BufferedReader reader = new BufferedReader(new
		// InputStreamReader(urlConnection.getInputStream()));
		StringBuilder results = new StringBuilder();
		String line;
		while ((line = reader.readLine()) != null) {
			results.append(line);
		}
		urlConnection.disconnect();
		LOGGER.info("Send email using access token method ended");
		return results.toString();
	}

	private String getToken(long orgId) throws IOException {
		LOGGER.info("Get token method started");
		GmailOauthInfo gmailOauthInfo = gmailOauthInfoRepository.findByOrganizationId(orgId);
		if (LocalDateTime.now().isAfter(gmailOauthInfo.getExpiredAt())) {
			GoogleCredentials response = serviceAccount(orgId);
			if (response != null) {
				gmailOauthInfo.setAccessToken(response.getAccessToken().getTokenValue());
				gmailOauthInfo.setExpiredAt(convertToLocalDateTime(response.getAccessToken().getExpirationTime()));
				gmailOauthInfo.setRefreshToken(response.refreshAccessToken().getTokenValue());
				gmailOauthInfo.setUpdatedAt(DateAndTimeUtil.now());
				gmailOauthInfoRepository.save(gmailOauthInfo);
			}
			LOGGER.info("Get token method ended");
			return gmailOauthInfo.getAccessToken();
		} else {
			LOGGER.info("Get token method ended");
			return gmailOauthInfo.getAccessToken();
		}
	}

	public LocalDateTime convertToLocalDateTime(Date dateToConvert) {
		return LocalDateTime.ofInstant(dateToConvert.toInstant(), ZoneId.systemDefault());
	}

	public static String createEmailString(MimeMessage email) throws MessagingException, IOException {
		LOGGER.info("Create email string method is started");
		ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		email.writeTo(buffer);
		byte[] bytes = buffer.toByteArray();
		String encodedEmail = com.google.api.client.util.Base64.encodeBase64URLSafeString(bytes);
		LOGGER.info("Create email string method is ended");
		return encodedEmail;
	}

}