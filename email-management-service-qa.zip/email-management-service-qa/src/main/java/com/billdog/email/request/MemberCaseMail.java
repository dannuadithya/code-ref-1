package com.billdog.email.request;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.billdog.email.common.EmailTitles;

public class MemberCaseMail {

	@NotNull(message = "Email title must not be null")
	private EmailTitles emailTitle;

	@NotBlank(message = "Please enter Email")
	@Email(message = "Invalid email format")
	private String memberEmail;

	@NotNull(message = "Member id must not be null")
	private Long memberId;

	@NotBlank(message = "Please enter case id")
	private String caseId;

	@NotBlank(message = "Please enter member name")
	private String memberFirstName;

	// @NotBlank(message = "Please enter member name")
	private String fromEmail;

	@NotNull(message = "Organization id must not be null")
	private Long organizationId;

//	@NotBlank(message = "Please enter member name")
	private String organizationContact;

//	@NotBlank(message = "Please enter member name")
	private String organizationName;

	public EmailTitles getEmailTitle() {
		return emailTitle;
	}

	public void setEmailTitle(EmailTitles emailTitle) {
		this.emailTitle = emailTitle;
	}

	public String getMemberEmail() {
		return memberEmail;
	}

	public void setMemberEmail(String memberEmail) {
		this.memberEmail = memberEmail;
	}

	public Long getMemberId() {
		return memberId;
	}

	public void setMemberId(Long memberId) {
		this.memberId = memberId;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}

	public String getMemberFirstName() {
		return memberFirstName;
	}

	public void setMemberFirstName(String memberFirstName) {
		this.memberFirstName = memberFirstName;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public Long getOrganizationId() {
		return organizationId;
	}

	public void setOrganizationId(Long organizationId) {
		this.organizationId = organizationId;
	}

	public String getOrganizationContact() {
		return organizationContact;
	}

	public void setOrganizationContact(String organizationContact) {
		this.organizationContact = organizationContact;
	}

	public String getOrganizationName() {
		return organizationName;
	}

	public void setOrganizationName(String organizationName) {
		this.organizationName = organizationName;
	}

}
